<?php
// இந்த device-க்கு மீண்டும் PIN கேட்க வேண்டும் என்றால் இதை பயன்படுத்தவும்.
setcookie('pcm_auth', '', time() - 3600, '/');
header('Location: index.php');
exit;
