<?php
require 'config.php';

$data = null;
if (file_exists(DATA_FILE)) {
    $data = json_decode(file_get_contents(DATA_FILE), true);
}

$now = time();
$isOnline = false;
$secondsAgo = null;

if ($data && isset($data['last_seen'])) {
    $secondsAgo = $now - $data['last_seen'];
    $isOnline = $secondsAgo <= OFFLINE_THRESHOLD;
}

$statusText  = $isOnline ? 'POWER ON' : 'POWER OFF';
$statusEmoji = $isOnline ? '✅' : '⚠️';
$statusColor = $isOnline ? '#16a34a' : '#dc2626';

$logLines = [];
if (file_exists(LOG_FILE)) {
    $lines = file(LOG_FILE, FILE_IGNORE_NEW_LINES);
    $logLines = array_slice(array_reverse($lines), 0, 25);
}

// தற்போதைய servo settings (form-இல் default-ஆக காட்ட)
$servoSettings = ['rest_angle' => 0, 'press_angle' => 90, 'press_time' => 500];
if (file_exists(SERVO_SETTINGS_FILE)) {
    $saved = json_decode(file_get_contents(SERVO_SETTINGS_FILE), true);
    if ($saved) {
        $servoSettings = array_merge($servoSettings, $saved);
    }
}

// தற்போதைய WiFi hotspot settings (form-இல் default-ஆக காட்ட)
$wifiSettings = ['ssid' => '', 'pass' => ''];
$wifiIsCustom = false;
if (file_exists(WIFI_SETTINGS_FILE)) {
    $savedWifi = json_decode(file_get_contents(WIFI_SETTINGS_FILE), true);
    if ($savedWifi && !empty($savedWifi['ssid'])) {
        $wifiSettings = $savedWifi;
        $wifiIsCustom = true;
    }
}

$authed = isAuthenticated();
?>
<!DOCTYPE html>
<html lang="ta">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Power Cut Monitor</title>
<meta http-equiv="refresh" content="5">
<style>
  body { font-family: -apple-system, Segoe UI, Arial, sans-serif; background:#0f172a; color:#e2e8f0; margin:0; padding:24px; }
  .card { max-width:480px; margin:0 auto; background:#1e293b; border-radius:16px; padding:32px; text-align:center; box-shadow:0 8px 24px rgba(0,0,0,.3);}
  .status { font-size:28px; font-weight:700; color:<?= $statusColor ?>; margin:16px 0; }
  .meta { color:#94a3b8; font-size:14px; margin-top:8px; }
  .timebox { max-width:480px; margin:16px auto 0; background:#1e293b; border-radius:16px; padding:20px 24px; }
  .timebox .row2 { display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #334155; }
  .timebox .row2:last-child { border-bottom:none; }
  .timebox .label { font-size:14px; color:#94a3b8; }
  .timebox .value { font-size:20px; font-weight:700; }
  .value.cut { color:#f87171; }
  .value.restored { color:#4ade80; }
  .log { max-width:480px; margin:24px auto 0; background:#1e293b; border-radius:16px; padding:20px; font-size:13px; }
  .log h3 { margin-top:0; color:#e2e8f0; font-size:15px;}
  .log div { padding:4px 0; border-bottom:1px solid #334155; color:#cbd5e1; word-break:break-word;}
  .row { display:flex; gap:8px; justify-content:center; flex-wrap:wrap; margin-bottom:8px; }
  input[type=password], input[type=number] { padding:8px; border-radius:8px; border:1px solid #334155; background:#0f172a; color:#e2e8f0; width:100px; }
  .btn { padding:8px 16px; border-radius:8px; border:none; background:#2563eb; color:white; font-weight:600; cursor:pointer; }
  .btn-outline { background:transparent; border:1px solid #475569; color:#94a3b8; padding:6px 12px; border-radius:8px; font-size:12px; cursor:pointer; text-decoration:none; }
  label { font-size:12px; color:#94a3b8; display:block; margin-bottom:4px; text-align:left; }
  .field { display:flex; flex-direction:column; }
</style>
</head>
<body>
  <div class="card">
    <h2>🖨️ 3D Printer Power Monitor</h2>
    <div class="status"><?= $statusEmoji . ' ' . $statusText ?></div>
    <?php if ($data): ?>
      <div class="meta">Device: <?= htmlspecialchars($data['device']) ?></div>
      <div class="meta">
        <?= $isOnline ? 'கடைசியாக signal வந்தது' : 'கடைசியாக ON-ஆக இருந்தது' ?>:
        <?= htmlspecialchars($data['last_seen_readable']) ?>
      </div>
      <div class="meta"><?= htmlspecialchars(formatDuration($secondsAgo)) ?> முன்</div>
    <?php else: ?>
      <div class="meta">இதுவரை எந்த signal-உம் வரவில்லை. NodeMCU சரியாக இணைக்கப்பட்டுள்ளதா எனச் சரிபார்க்கவும்.</div>
    <?php endif; ?>
    <div class="meta" style="margin-top:16px;">இந்தப் பக்கம் ஒவ்வொரு 5 வினாடிக்கும் தானாக refresh ஆகும்.</div>
  </div>

  <?php
    // ரெசுமே பட்டனை அழுத்த வேண்டுமா என்பதை சீக்கிரமாக முடிவெடுக்க
    // கடைசி power cut மற்றும் power restore நேரங்களை பெரிய எழுத்தில் காட்டவும்.
    $cutTimeToShow      = $isOnline ? ($data['last_cut_readable'] ?? null)      : ($data['last_seen_readable'] ?? null);
    $restoredTimeToShow = $isOnline ? ($data['last_restored_readable'] ?? null) : null;
  ?>
  <?php if ($data && ($cutTimeToShow || $restoredTimeToShow)): ?>
    <div class="timebox">
      <?php if ($cutTimeToShow): ?>
        <div class="row2">
          <span class="label">⚡ கரண்ட் <?= $isOnline ? 'கடைசியாக' : '' ?> கட் ஆனது</span>
          <span class="value cut"><?= htmlspecialchars($cutTimeToShow) ?></span>
        </div>
      <?php endif; ?>
      <?php if ($isOnline): ?>
        <div class="row2">
          <span class="label">✅ கரண்ட் திரும்ப வந்தது</span>
          <span class="value restored"><?= $restoredTimeToShow ? htmlspecialchars($restoredTimeToShow) : 'இன்னும் cut ஆகவில்லை' ?></span>
        </div>
      <?php else: ?>
        <div class="row2">
          <span class="label">⏳ இப்போது நிலை</span>
          <span class="value cut">கரண்ட் இன்னும் இல்லை</span>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <?php if (!$authed): ?>
    <div class="log">
      <h3>🔐 இந்த Device-ஐ அங்கீகரிக்கவும் (ஒரு முறை மட்டும்)</h3>
      <div class="meta" style="margin-bottom:8px;">PIN சரியாக கொடுத்தால், இந்த device-இல் மீண்டும் கேட்காது.</div>
      <form method="post" action="login.php" class="row">
        <input type="password" name="password" placeholder="Admin PIN" required>
        <button type="submit" class="btn">Unlock</button>
      </form>
      <?php if (isset($_GET['error'])): ?>
        <div class="meta" style="color:#dc2626;">❌ தவறான PIN. மீண்டும் முயற்சிக்கவும்.</div>
      <?php endif; ?>
    </div>
  <?php else: ?>
    <div class="log">
      <h3>🔁 Print Resume</h3>
      <form method="post" action="resume.php" class="row">
        <button type="submit" class="btn">Resume Print</button>
      </form>
      <?php if (isset($_GET['resumed'])): ?>
        <div class="meta" style="color:#16a34a;">✅ Resume command NodeMCU-க்கு அனுப்பப்பட்டது! சில வினாடிகளில் servo இயங்கும்.</div>
      <?php endif; ?>
      <a href="logout.php" class="btn-outline" style="display:inline-block; margin-top:12px;">இந்த Device-ஐ Forget செய்</a>
    </div>

    <div class="log">
      <h3>⚙️ Servo Rotation Settings</h3>
      <div class="meta" style="margin-bottom:8px;">Servo எவ்வளவு டிகிரி rotate ஆக வேண்டும் என இங்கே செட் செய்யலாம் (0-180).</div>
      <form method="post" action="servo_settings.php" class="row" style="align-items:flex-end;">
        <div class="field">
          <label>Rest Angle</label>
          <input type="number" name="rest_angle" min="0" max="180" value="<?= htmlspecialchars($servoSettings['rest_angle']) ?>">
        </div>
        <div class="field">
          <label>Press Angle</label>
          <input type="number" name="press_angle" min="0" max="180" value="<?= htmlspecialchars($servoSettings['press_angle']) ?>">
        </div>
        <div class="field">
          <label>Press Time (ms)</label>
          <input type="number" name="press_time" min="100" max="5000" step="50" value="<?= htmlspecialchars($servoSettings['press_time']) ?>">
        </div>
        <button type="submit" class="btn">Save</button>
      </form>
      <?php if (isset($_GET['settings_saved'])): ?>
        <div class="meta" style="color:#16a34a;">✅ Servo settings சேமிக்கப்பட்டது. அடுத்த heartbeat-இல் NodeMCU இதைப் பயன்படுத்தும்.</div>
      <?php endif; ?>
    </div>

    <div class="log">
      <h3>📶 WiFi Hotspot Settings</h3>
      <div class="meta" style="margin-bottom:8px;">
        NodeMCU இணைக்க வேண்டிய WiFi Hotspot-இன் Username (SSID) &amp;
        Password-ஐ இங்கே மாற்றலாம். Save செய்தவுடன், NodeMCU அடுத்த
        heartbeat-இல் (5 வினாடிக்குள்) இதைப் பெற்று, தன் flash memory
        (EEPROM)-இல் நிரந்தரமாக சேமித்துக் கொண்டு, உடனே அந்த hotspot-க்கு
        மாறி இணைக்கும். பவர் கட் ஆகி மறுபடியும் பவர் வந்தாலும், சேமிக்கப்பட்ட
        இதே hotspot-க்கே NodeMCU தானாக இணைந்துவிடும்.
      </div>
      <div class="meta" style="margin-bottom:8px;">
        <?php if ($wifiIsCustom): ?>
          தற்போது set செய்யப்பட்டுள்ள Hotspot: <b><?= htmlspecialchars($wifiSettings['ssid']) ?></b>
        <?php else: ?>
          தற்போது NodeMCU-வின் .ino கோப்பில் உள்ள default WiFi-ஐயே பயன்படுத்துகிறது (இன்னும் இங்கே எதுவும் set செய்யவில்லை).
        <?php endif; ?>
      </div>
      <form method="post" action="wifi_settings.php" class="row" style="align-items:flex-end;">
        <div class="field">
          <label>Hotspot SSID (Username)</label>
          <input type="text" name="wifi_ssid" maxlength="32" placeholder="WiFi பெயர்" value="<?= htmlspecialchars($wifiSettings['ssid']) ?>" required style="width:160px;">
        </div>
        <div class="field">
          <label>Hotspot Password</label>
          <input type="text" name="wifi_pass" maxlength="64" placeholder="WiFi பாஸ்வேர்ட்" value="<?= htmlspecialchars($wifiSettings['pass']) ?>" style="width:160px;">
        </div>
        <button type="submit" class="btn">Save</button>
      </form>
      <?php if (isset($_GET['wifi_saved'])): ?>
        <div class="meta" style="color:#16a34a; margin-top:8px;">✅ WiFi Hotspot settings சேமிக்கப்பட்டது. அடுத்த heartbeat-இல் NodeMCU புதிய hotspot-க்கு மாறி இணைக்கும்.</div>
      <?php endif; ?>
      <?php if (isset($_GET['wifi_error']) && $_GET['wifi_error'] === 'empty_ssid'): ?>
        <div class="meta" style="color:#dc2626; margin-top:8px;">❌ SSID காலியாக இருக்கக்கூடாது.</div>
      <?php endif; ?>
      <?php if (isset($_GET['wifi_error']) && $_GET['wifi_error'] === 'invalid_chars'): ?>
        <div class="meta" style="color:#dc2626; margin-top:8px;">❌ SSID/Password-இல் " அல்லது \ எழுத்துகள் பயன்படுத்த வேண்டாம்.</div>
      <?php endif; ?>
      <div class="meta" style="margin-top:8px; color:#facc15;">
        ⚠️ கவனம்: தவறான SSID/Password கொடுத்தால் NodeMCU அந்த hotspot-க்கு
        இணைக்க முடியாமல் போகலாம். அப்படி நடந்தால், NodeMCU தானாகவே 20
        வினாடிக்குள் .ino-வில் உள்ள original default WiFi-க்கு fallback
        ஆகி முயற்சிக்கும் (device offline ஆகிவிடாமல் இருக்க).
      </div>
    </div>
  <?php endif; ?>

  <div class="log">
    <h3>சமீபத்திய நிகழ்வுகள் (Log)</h3>
    <?php if ($authed): ?>
      <form method="post" action="clear_log.php" class="row" style="margin-bottom:12px;" onsubmit="return confirm('Log-ஐ முழுவதுமாக காலி செய்யவா?');">
        <button type="submit" class="btn" style="background:#dc2626;">🗑️ Log Clear செய்</button>
      </form>
      <?php if (isset($_GET['log_cleared'])): ?>
        <div class="meta" style="color:#16a34a; margin-bottom:8px;">✅ Log காலி செய்யப்பட்டது.</div>
      <?php endif; ?>
    <?php endif; ?>
    <?php if (empty($logLines)): ?>
      <div>எந்த நிகழ்வும் இல்லை.</div>
    <?php else: foreach ($logLines as $l): ?>
      <div><?= htmlspecialchars($l) ?></div>
    <?php endforeach; endif; ?>
  </div>
</body>
</html>
