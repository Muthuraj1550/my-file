<?php
// முதல் முறை PIN சரியாக கொடுத்தால், இந்த device-இல் ஒரு cookie
// (1 வருடம்) வைக்கப்படும் - பிறகு மீண்டும் PIN கேட்காது.
require 'config.php';

$password = $_POST['password'] ?? '';

if ($password === ADMIN_PASSWORD) {
    setcookie('pcm_auth', authCookieValue(), time() + 60 * 60 * 24 * 365, '/');
    header('Location: index.php?authed=1');
} else {
    header('Location: index.php?error=1');
}
exit;
