<?php
// Website-இல் உள்ள "Resume Print" பட்டனை அழுத்தும்போது இது அழைக்கப்படும்.
// இது ஒரு "pending command" கோப்பில் எழுதி வைக்கும்; NodeMCU அடுத்த
// heartbeat-இன் போது (5 வினாடிக்குள்) இதைப் படித்து servo-வை இயக்கும்.
require 'config.php';

if (!isAuthenticated()) {
    header('Location: index.php?error=1');
    exit;
}

if (!is_dir(dirname(COMMAND_FILE))) {
    mkdir(dirname(COMMAND_FILE), 0755, true);
}

$commandData = [
    'pending'   => true,
    'command'   => 'resume',
    'issued_at' => time(),
];
file_put_contents(COMMAND_FILE, json_encode($commandData));

// log-இலும் பதிவு செய்யவும்
$logLine = formatIndianTime(time()) . " | WEBSITE | resume button pressed\n";
file_put_contents(LOG_FILE, $logLine, FILE_APPEND);

header('Location: index.php?resumed=1');
exit;
