<?php
// JSON status endpoint - இதை வேறு எந்த ஆப் / widget-இலும் பயன்படுத்தலாம்
require 'config.php';

header('Content-Type: application/json');

$data = null;
if (file_exists(DATA_FILE)) {
    $data = json_decode(file_get_contents(DATA_FILE), true);
}

$now = time();
$isOnline = false;
$secondsAgo = null;

if ($data && isset($data['last_seen'])) {
    $secondsAgo = $now - $data['last_seen'];
    $isOnline = $secondsAgo <= OFFLINE_THRESHOLD;
}

echo json_encode([
    'power_status'  => $isOnline ? 'ON' : 'OFF',
    'device'        => $data['device'] ?? null,
    'last_seen'     => $data['last_seen_readable'] ?? null,
    'seconds_ago'   => $secondsAgo,
    'server_time'   => date('Y-m-d H:i:s', $now),
]);
