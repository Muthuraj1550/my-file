<?php
// ==================================================
// Power Cut Monitor - Settings
// ==================================================

// இந்திய நேரம் (IST) - இது இல்லாமல் இருந்தால் server UTC நேரத்தில் காட்டும்
date_default_timezone_set('Asia/Kolkata');

// நேரத்தை "am/pm" உடன் இந்திய வழக்கப்படி காட்ட (ரயில்வே/24-hour டைம் இல்லாமல்)
function formatIndianTime($timestamp) {
    if (!$timestamp) return null;
    return date('d-M-Y, h:i:s A', $timestamp);
}

// வினாடிகளை "X நிமிடம் Y வினாடி" என்று எளிதாகப் படிக்கும்படி மாற்ற
function formatDuration($seconds) {
    if ($seconds === null) return '';
    $seconds = (int)$seconds;
    if ($seconds < 60) return $seconds . ' வினாடிகள்';
    $mins = intdiv($seconds, 60);
    $secs = $seconds % 60;
    if ($mins < 60) return $mins . ' நிமிடம் ' . $secs . ' வினாடி';
    $hrs = intdiv($mins, 60);
    $remMins = $mins % 60;
    return $hrs . ' மணி ' . $remMins . ' நிமிடம்';
}

// NodeMCU .ino கோப்பில் உள்ள DEVICE_TOKEN-உடன் இது
// சரியாக ஒத்திருக்க வேண்டும். உங்கள் சொந்த ரகசிய வார்த்தையாக மாற்றவும்.
define('DEVICE_TOKEN', 'change_this_secret_123');

// இவ்வளவு வினாடிகள் heartbeat வரவில்லை என்றால் "POWER OFF" எனக் காட்டப்படும்.
// NodeMCU 5 வினாடிக்கு ஒரு முறை heartbeat அனுப்புகிறது என்பதால்,
// 15-20 வினாடி வைத்தால் தவறான அலார்ம் வராது.
define('OFFLINE_THRESHOLD', 20);

// data சேமிக்கும் கோப்புகள் (எதுவும் மாற்ற வேண்டாம்)
define('DATA_FILE', __DIR__ . '/data/last_seen.json');
define('LOG_FILE', __DIR__ . '/data/events.log');
define('COMMAND_FILE', __DIR__ . '/data/command.json');
define('SERVO_SETTINGS_FILE', __DIR__ . '/data/servo_settings.json');

// NodeMCU இணைக்க வேண்டிய WiFi Hotspot (SSID/Password) - Website-இல்
// இருந்தே மாற்றக்கூடியது. இது இல்லாத வரை NodeMCU .ino-வில் உள்ள
// default WIFI_SSID/WIFI_PASSWORD-ஐயே பயன்படுத்தும்.
define('WIFI_SETTINGS_FILE', __DIR__ . '/data/wifi_settings.json');

// Resume பட்டனை யார் வேண்டுமானாலும் அழுத்தாமல் இருக்க ஒரு simple PIN.
// இதை உங்கள் சொந்த எண்/வார்த்தையாக மாற்றவும்.
define('ADMIN_PASSWORD', 'Muthu55');

// -------- Device-க்கு ஒரு முறை மட்டும் PIN கேட்க (cookie based) --------
// PIN சரியாக இருந்தால், இந்த மதிப்பு cookie-ஆக அந்த device-இல் 1
// வருடத்திற்கு சேமிக்கப்படும். மீண்டும் மீண்டும் PIN கேட்காது.
function authCookieValue() {
    return hash('sha256', ADMIN_PASSWORD . '_pcm_device_v1');
}

function isAuthenticated() {
    return isset($_COOKIE['pcm_auth']) && $_COOKIE['pcm_auth'] === authCookieValue();
}
