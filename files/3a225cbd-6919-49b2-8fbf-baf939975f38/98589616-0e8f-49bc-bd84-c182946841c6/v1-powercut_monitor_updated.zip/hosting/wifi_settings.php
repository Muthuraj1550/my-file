<?php
// Website-இல் இருந்து NodeMCU இணைக்க வேண்டிய WiFi Hotspot SSID/Password-ஐ
// மாற்றி சேமிக்க இது பயன்படும். இதற்கு அதே Admin PIN (servo settings-க்கு
// பயன்படுத்தும் ADMIN_PASSWORD) தேவை.
//
// சேமித்தவுடன், NodeMCU அடுத்த heartbeat-இல் (5 வினாடிக்குள்) இந்த
// புதிய SSID/Password-ஐப் பெற்று, அதனுடைய EEPROM (flash memory)-இல்
// நிரந்தரமாக சேமித்துக் கொண்டு, உடனே அந்த hotspot-க்கு மாறி இணைக்கும்.
// பவர் கட் ஆகி மீண்டும் பவர் வந்தாலும், EEPROM-இல் இருப்பதால் அதே
// புதிய hotspot-க்கே தானாக இணைக்கும்.
require 'config.php';

if (!isAuthenticated()) {
    header('Location: index.php?error=1');
    exit;
}

$ssid = isset($_POST['wifi_ssid']) ? trim($_POST['wifi_ssid']) : '';
$pass = isset($_POST['wifi_pass']) ? trim($_POST['wifi_pass']) : '';

// SSID கட்டாயம் தேவை (காலியாக இருக்கக்கூடாது)
if ($ssid === '') {
    header('Location: index.php?wifi_error=empty_ssid');
    exit;
}

// பாதுகாப்பான வரம்பு - SSID 32 எழுத்துகள், Password 64 எழுத்துகள் வரை
// (WiFi standard வரம்பு, NodeMCU EEPROM buffer-உடன் பொருந்தும் வகையில்)
if (strlen($ssid) > 32) {
    $ssid = substr($ssid, 0, 32);
}
if (strlen($pass) > 64) {
    $pass = substr($pass, 0, 64);
}

// " அல்லது \ போன்ற எழுத்துகள் NodeMCU-வின் எளிய JSON parsing-ஐ
// குழப்பிவிடும் என்பதால் அவற்றை தவிர்க்கச் சொல்கிறோம்.
if (strpos($ssid, '"') !== false || strpos($pass, '"') !== false ||
    strpos($ssid, '\\') !== false || strpos($pass, '\\') !== false) {
    header('Location: index.php?wifi_error=invalid_chars');
    exit;
}

$settings = [
    'ssid'       => $ssid,
    'pass'       => $pass,
    'updated_at' => time(),
];

if (!is_dir(dirname(WIFI_SETTINGS_FILE))) {
    mkdir(dirname(WIFI_SETTINGS_FILE), 0755, true);
}
file_put_contents(WIFI_SETTINGS_FILE, json_encode($settings));

// log-இலும் பதிவு செய்யவும் (password-ஐ log-இல் காட்ட வேண்டாம்)
$logLine = formatIndianTime(time()) . " | WEBSITE | WiFi hotspot settings மாற்றப்பட்டது -> SSID: {$ssid}\n";
file_put_contents(LOG_FILE, $logLine, FILE_APPEND);

header('Location: index.php?wifi_saved=1');
exit;
