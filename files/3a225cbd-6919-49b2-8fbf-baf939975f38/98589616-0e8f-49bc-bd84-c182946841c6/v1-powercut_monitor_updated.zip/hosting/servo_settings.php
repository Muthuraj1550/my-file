<?php
// Website-இல் இருந்து servo-வின் Rest angle, Press angle, Press time
// ஆகியவற்றை மாற்றி சேமிக்க இது பயன்படும். NodeMCU ஒவ்வொரு heartbeat-இலும்
// இந்த மதிப்புகளைப் படித்துக் கொள்ளும்.
require 'config.php';

if (!isAuthenticated()) {
    header('Location: index.php?error=1');
    exit;
}

$rest  = isset($_POST['rest_angle'])  ? intval($_POST['rest_angle'])  : 0;
$press = isset($_POST['press_angle']) ? intval($_POST['press_angle']) : 90;
$time  = isset($_POST['press_time'])  ? intval($_POST['press_time'])  : 500;

// பாதுகாப்பான வரம்பு (servo-வுக்கு தவறான மதிப்பு போகாமல் இருக்க)
$rest  = max(0, min(180, $rest));
$press = max(0, min(180, $press));
$time  = max(100, min(5000, $time));

$settings = [
    'rest_angle'  => $rest,
    'press_angle' => $press,
    'press_time'  => $time,
];

if (!is_dir(dirname(SERVO_SETTINGS_FILE))) {
    mkdir(dirname(SERVO_SETTINGS_FILE), 0755, true);
}
file_put_contents(SERVO_SETTINGS_FILE, json_encode($settings));

header('Location: index.php?settings_saved=1');
exit;
