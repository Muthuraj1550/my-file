<?php
// NodeMCU இதை அழைக்கும் endpoint. இது last-seen நேரத்தை update செய்யும்.
require 'config.php';

header('Content-Type: application/json');

$token  = $_GET['token']  ?? '';
$device = $_GET['device'] ?? 'unknown';
$event  = $_GET['event']  ?? 'alive';

if ($token !== DEVICE_TOKEN) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid token']);
    exit;
}

$now = time();

// power cut இருந்ததா எனப் பார்க்க முந்தைய நிலையை படிக்கவும்
$prev = null;
if (file_exists(DATA_FILE)) {
    $prev = json_decode(file_get_contents(DATA_FILE), true);
}

$wasOffline = false;
if ($prev && isset($prev['last_seen'])) {
    if (($now - $prev['last_seen']) > OFFLINE_THRESHOLD) {
        $wasOffline = true;
    }
}

// தற்போதைய நிலையை சேமிக்கவும்
$data = [
    'device'             => $device,
    'last_seen'          => $now,
    'last_seen_readable' => formatIndianTime($now),
];

// கடைசியாக நடந்த power cut / power restore நேரத்தை கண்காணிக்கவும்
if ($wasOffline) {
    // இந்த heartbeat வருவதற்கு முன் power cut ஆகி, இப்போது restore ஆகியுள்ளது
    $data['last_cut_at']         = $prev['last_seen'] ?? null;
    $data['last_cut_readable']   = formatIndianTime($prev['last_seen'] ?? null);
    $data['last_restored_at']       = $now;
    $data['last_restored_readable'] = formatIndianTime($now);
} else {
    // முந்தைய cut/restore தகவலை அப்படியே தொடர்ந்து வைத்திருக்கவும்
    $data['last_cut_at']            = $prev['last_cut_at'] ?? null;
    $data['last_cut_readable']      = $prev['last_cut_readable'] ?? null;
    $data['last_restored_at']       = $prev['last_restored_at'] ?? null;
    $data['last_restored_readable'] = $prev['last_restored_readable'] ?? null;
}

if (!is_dir(dirname(DATA_FILE))) {
    mkdir(dirname(DATA_FILE), 0755, true);
}
file_put_contents(DATA_FILE, json_encode($data));

// log எழுதவும்
$logLine = formatIndianTime($now) . " | device={$device} | event={$event}";
if ($wasOffline) {
    $logLine .= " | *** POWER RESTORED (outage detected before this, cut at " . formatIndianTime($prev['last_seen'] ?? null) . ") ***";
}
$logLine .= "\n";
file_put_contents(LOG_FILE, $logLine, FILE_APPEND);

// pending command (resume button) இருந்தால் response-இல் சேர்க்கவும்
$commandToSend = null;
if (file_exists(COMMAND_FILE)) {
    $cmd = json_decode(file_get_contents(COMMAND_FILE), true);
    if ($cmd && !empty($cmd['pending'])) {
        $commandToSend = $cmd['command'];
        // ஒரு முறை மட்டும் அனுப்ப, உடனே clear செய்யவும்
        file_put_contents(COMMAND_FILE, json_encode(['pending' => false]));
    }
}

// servo settings படிக்கவும் (website-இல் இருந்து மாற்றப்பட்டிருக்கலாம்)
$servoSettings = ['rest_angle' => 0, 'press_angle' => 90, 'press_time' => 500];
if (file_exists(SERVO_SETTINGS_FILE)) {
    $saved = json_decode(file_get_contents(SERVO_SETTINGS_FILE), true);
    if ($saved) {
        $servoSettings = array_merge($servoSettings, $saved);
    }
}

// WiFi hotspot settings படிக்கவும் (website-இல் இருந்து மாற்றப்பட்டிருந்தால் மட்டும்)
// மாற்றப்படவில்லை என்றால் wifi_ssid/wifi_pass response-இல் அனுப்பப்படாது -
// அப்போது NodeMCU தன் .ino-வில் உள்ள default/EEPROM-இல் ஏற்கனவே இருப்பதையே
// தொடர்ந்து பயன்படுத்தும்.
$wifiSSID = null;
$wifiPass = null;
if (file_exists(WIFI_SETTINGS_FILE)) {
    $savedWifi = json_decode(file_get_contents(WIFI_SETTINGS_FILE), true);
    if ($savedWifi && !empty($savedWifi['ssid'])) {
        $wifiSSID = $savedWifi['ssid'];
        $wifiPass = $savedWifi['pass'] ?? '';
    }
}

echo json_encode([
    'status'                  => 'ok',
    'server_time'             => $now,
    'power_restored_detected' => $wasOffline,
    'command'                 => $commandToSend, // null அல்லது "resume"
    'servo_rest'              => $servoSettings['rest_angle'],
    'servo_press'             => $servoSettings['press_angle'],
    'servo_time_ms'           => $servoSettings['press_time'],
    'wifi_ssid'                => $wifiSSID, // null அல்லது புதிய Hotspot SSID
    'wifi_pass'                => $wifiPass, // null அல்லது புதிய Hotspot Password
]);
