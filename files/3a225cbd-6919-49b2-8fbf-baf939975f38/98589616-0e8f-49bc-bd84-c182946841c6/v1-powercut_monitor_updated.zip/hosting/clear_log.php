<?php
// Website-இல் உள்ள "Log Clear" பட்டனை அழுத்தும்போது இது அழைக்கப்படும்.
// events.log கோப்பை காலி செய்யும் (PIN போட்ட device மட்டும்).
require 'config.php';

if (!isAuthenticated()) {
    header('Location: index.php?error=1');
    exit;
}

// கோப்பை முழுவதுமாக காலி செய்யவும்
file_put_contents(LOG_FILE, '');

// காலி செய்தது என்பதையே முதல் வரியாக பதிவு செய்யவும்
$logLine = formatIndianTime(time()) . " | WEBSITE | log cleared\n";
file_put_contents(LOG_FILE, $logLine, FILE_APPEND);

header('Location: index.php?log_cleared=1');
exit;
