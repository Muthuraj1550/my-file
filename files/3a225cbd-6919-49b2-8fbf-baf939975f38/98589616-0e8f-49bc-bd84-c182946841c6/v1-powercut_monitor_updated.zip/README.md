# Power Cut Monitor - NodeMCU (ESP8266)

3D பிரிண்டர் இருக்கும் இடத்தில் பவர் கட் ஆகும் போது தெரிந்து கொள்ள
உதவும் சிறிய சிஸ்டம். NodeMCU போர்டு, "நான் உயிரோடு இருக்கிறேன்"
என்ற heartbeat சிக்னலை ஒவ்வொரு 5 வினாடிக்கும் உங்கள் இணையதளத்திற்கு
அனுப்பிக் கொண்டே இருக்கும். பவர் கட் ஆன உடனே போர்டும் ஆஃப் ஆகும் -
signal நிற்கும் - இணையதளம் அதைப் பார்த்து "POWER OFF" எனக் காட்டும்.

## கோப்புகள்

```
powercut_monitor/
├── nodemcu_code/
│   └── powercut_monitor.ino   <- Arduino IDE-யில் upload செய்ய வேண்டிய கோப்பு
└── hosting/
    ├── config.php             <- settings (token, threshold நேரம்)
    ├── heartbeat.php          <- NodeMCU அழைக்கும் endpoint
    ├── index.php              <- Power ON/OFF காட்டும் dashboard பக்கம்
    ├── wifi_settings.php      <- WiFi Hotspot SSID/Password மாற்றும் endpoint
    ├── status.php             <- JSON API (optional, apps-க்கு பயன்படும்)
    └── data/                  <- last_seen.json, events.log தானாக உருவாகும்
```

## படி 1: Hosting Setup

இந்த `hosting` கோப்புறையை PHP ஆதரிக்கும் எந்த hosting-இலும்
(Hostinger, InfinityFree, 000webhost, அல்லது உங்கள் சொந்த server /
XAMPP local server) பதிவேற்றவும். எடுத்துக்காட்டாக:

`http://yourdomain.com/powercut/` எனும் இடத்தில் இந்த கோப்புகள்
இருக்கும் படி வையுங்கள்.

1. `hosting` கோப்புறை முழுவதையும் upload செய்யவும்.
2. `data` கோப்புறைக்கு write permission (755 அல்லது 775) கொடுக்கவும்.
3. `config.php`-யில் உள்ள `DEVICE_TOKEN` மதிப்பை உங்கள் சொந்த
   ரகசிய வார்த்தையாக மாற்றவும்.
4. browser-இல் `http://yourdomain.com/powercut/index.php` திறந்து
   பார்க்கவும் - "இதுவரை signal வரவில்லை" என்று காட்டும், அது சரி.

> Local-ஆக (வீட்டு wifi-இலேயே) வைக்க விரும்பினால், ஒரு பழைய
> Android போன் அல்லது Raspberry Pi-இல் PHP install செய்து
> local server ஆக்கலாம், அல்லது XAMPP/Laragon PC-இல் install
> செய்யலாம். அப்பொழுது SERVER_URL-இல் உங்கள் PC-யின்
> local IP (எ.கா 192.168.1.10) பயன்படுத்தவும்.

## படி 2: NodeMCU Setup (Arduino IDE)

1. Arduino IDE திறக்கவும் (இல்லையெனில் arduino.cc-யில் இருந்து இலவசமாக
   download செய்யவும்).
2. File -> Preferences -> "Additional Board Manager URLs" -இல் இதை
   சேர்க்கவும்:
   `http://arduino.esp8266.com/stable/package_esp8266com_index.json`
3. Tools -> Board -> Boards Manager -இல் "esp8266" எனத் தேடி install
   செய்யவும்.
4. Tools -> Board -> "NodeMCU 1.0 (ESP-12E Module)" தேர்வு செய்யவும்.
5. `nodemcu_code/powercut_monitor.ino` கோப்பைத் திறக்கவும்.
6. மேலே உள்ள CONFIG பகுதியில்:
   - `WIFI_SSID`, `WIFI_PASSWORD` - உங்கள் வைஃபை பெயர்/பாஸ்வேர்ட்
   - `SERVER_URL` - படி 1-இல் upload செய்த `heartbeat.php`-யின்
     முழு URL (எ.கா `http://yourdomain.com/powercut/heartbeat.php`)
   - `DEVICE_TOKEN` - `config.php`-யில் வைத்த அதே ரகசிய வார்த்தை
7. NodeMCU-வை USB மூலம் PC-யுடன் இணைக்கவும், சரியான COM Port
   தேர்வு செய்து Upload செய்யவும்.
8. Upload முடிந்தவுடன் Serial Monitor (115200 baud) திறந்து
   WiFi இணைந்து heartbeat அனுப்புவதை உறுதி செய்யவும்.

## படி 3: பயன்பாடு

- NodeMCU-வை wall socket-இல் ஒரு USB adapter மூலம் (சாதாரண மொபைல்
  chargers போன்றது) இணைத்து plug பண்ணி வையுங்கள் - அதே circuit
  அல்லது அதே room-இல் உள்ள எந்த சாக்கெட்டும் சரி.
- பவர் இருக்கும் வரை `index.php` பக்கத்தில் "POWER ON ✅" எனக்
  காட்டும்.
- பவர் கட் ஆன சில வினாடிகளில் (20 வினாடிக்குள்) "POWER OFF ⚠️"
  எனக் காட்டும், மேலும் log-இல் நேரம் பதிவாகும்.
- பவர் திரும்ப வந்தவுடன் NodeMCU தானாக reboot ஆகி மீண்டும்
  heartbeat அனுப்பத் தொடங்கும் - "POWER RESTORED" எனக் log-இல்
  பதிவாகும்.
- உங்கள் மொபைலில் `index.php` பக்கத்தை browser-இல் open வைத்திருந்தால்
  (5 வினாடிக்கு ஒரு முறை auto-refresh ஆகும்), பவர் status-ஐ
  தொலைவில் இருந்தே கண்காணிக்கலாம்.

## புதிதாக சேர்க்கப்பட்டது: ஒரு முறை Login + Servo Degree Settings

### 1. PIN ஒரே ஒரு முறை மட்டும் (device-க்கு)

- பக்கம் திறக்கும்போது device authenticate ஆகவில்லை என்றால், "🔐
  இந்த Device-ஐ அங்கீகரிக்கவும்" எனும் PIN பாக்ஸ் மட்டும் காட்டப்படும்.
- சரியான PIN கொடுத்தவுடன், அந்த device (browser)-இல் ஒரு cookie
  1 வருடத்திற்கு சேமிக்கப்படும். பிறகு பக்கம் refresh ஆனாலும்,
  மீண்டும் திறந்தாலும் PIN கேட்காது - நேரடியாக "Resume Print"
  பட்டனும் Servo Settings-உம் தெரியும்.
- வேறு device/browser-இல் திறந்தால் மட்டும் மீண்டும் ஒரு முறை PIN
  கேட்கும் (அது இயல்பானது, அந்த device இன்னும் அங்கீகரிக்கப்படவில்லை).
- "இந்த Device-ஐ Forget செய்" என்ற பட்டனை அழுத்தி எப்போது வேண்டுமானாலும்
  logout செய்யலாம்.

### 2. தனி Database Table தேவையில்லை

MySQL/database எதுவும் தேவையில்லை. ஏற்கனவே உள்ள `data/` கோப்புறையில்
சிறிய JSON கோப்புகள் (`last_seen.json`, `command.json`,
`servo_settings.json`) மூலமே எல்லாம் சேமிக்கப்படுகிறது. Login
cookie-வும் ஒரு hash மதிப்பை browser-இலேயே வைத்திருக்கும் - சர்வரில்
தனி user table தேவையில்லை.

### 3. Servo எத்தனை டிகிரி rotate ஆக வேண்டும் என Website-இலேயே செட் செய்யலாம்

Login செய்தபின், "⚙️ Servo Rotation Settings" எனும் பகுதியில்:
- **Rest Angle** - பட்டனைத் தொடாத இயல்பு நிலை (0-180)
- **Press Angle** - பட்டனை அழுத்தும் நிலை (0-180)
- **Press Time (ms)** - எவ்வளவு நேரம் அழுத்தி வைத்திருக்க வேண்டும்

இவற்றை மாற்றி "Save" அழுத்தினால், மீண்டும் NodeMCU-வுக்கு code
upload செய்ய வேண்டாம் - அடுத்த heartbeat-இலேயே (5 வினாடிக்குள்)
புதிய மதிப்புகளை பெற்று பயன்படுத்தும்.

## புதிய வசதி: மொபைலில் இருந்தே "Resume Print" பட்டன்

இப்போது `index.php` பக்கத்தில் ஒரு **Resume Print** பட்டனும் PIN
பாக்ஸும் இருக்கும். இதை அழுத்தினால், அந்த command சர்வரில் சேமிக்கப்பட்டு,
NodeMCU-வின் அடுத்த heartbeat-இல் (5 வினாடிக்குள்) அதைப் பெற்று,
அதனுடன் இணைக்கப்பட்ட **servo motor**-ஐ இயக்கி, 3D பிரிண்டரின் physical
"Resume" பட்டனை ஒரு முறை "அழுத்தி" மீண்டும் விடும்.

### வயரிங் (SG90 போன்ற சிறிய servo)

| Servo வயர்            | NodeMCU பின்                              |
|------------------------|--------------------------------------------|
| சிக்னல் (ஆரஞ்சு/மஞ்சள்) | D4                                          |
| VCC (சிவப்பு)          | 5V/VIN (முடிந்தால் தனி 5V சப்ளை பயன்படுத்தவும்) |
| GND (கருப்பு/பிரவுன்)  | GND (தனி சப்ளை என்றால் அதன் GND-உடனும் இணைக்கவும்) |

Servo-வின் arm-ஐ, பிரிண்டரின் resume பட்டனுக்கு நேராக, லேசாகத் தொடும்படி
ஒரு சிறிய bracket/double-sided tape மூலம் பொருத்தவும்.

### Library தேவை (Arduino IDE)

Tools -> Manage Libraries -> "**ESP8266Servo**" எனத் தேடி install
செய்யவும் (இது ESP8266-க்கான தனி servo library, ஆனால் code-இல்
`#include <Servo.h>` என்றே எழுதுவோம்).

### Setup

1. `config.php`-யில் `ADMIN_PASSWORD` மதிப்பை உங்கள் சொந்த PIN
   ஆக மாற்றவும் (இது யார் வேண்டுமானாலும் பட்டனை அழுத்தாமல் இருக்க).
2. `hosting/resume.php` கோப்பையும் மற்ற கோப்புகளுடன் சேர்த்து
   அதே இடத்தில் upload செய்யவும்.
3. `.ino`-வில் மேலே சொன்ன wiring முடித்தபின், மீண்டும் upload
   செய்யவும் (இப்போதைய code-இல் servo support-உம் சேர்க்கப்பட்டுவிட்டது).
4. Website-இல் "Resume Print" பட்டனை அழுத்தி, சில வினாடிகளில்
   servo இயங்குவதைப் பார்க்கவும்.

**குறிப்பு:** Servo-வுக்குத் தேவையான current NodeMCU-வின் 3.3V பின்
சில நேரங்களில் போதாமல் போகலாம் (servo தடுமாறலாம் / போர்டு reset
ஆகலாம்). முடிந்தால் servo-வுக்கு தனியாக ஒரு 5V, 1A சப்ளை
கொடுத்து, GND மட்டும் NodeMCU-உடன் common ஆக வையுங்கள்.

## புதிய வசதி: Website-இலேயே WiFi Hotspot Password மாற்றலாம்

இப்போது Login செய்தபின் "📶 WiFi Hotspot Settings" எனும் பகுதி
கிடைக்கும் (Servo Settings-க்கு பயன்படுத்தும் அதே Admin PIN
login-ஐயே இதற்கும் பயன்படுத்துகிறோம் - தனி பாஸ்வேர்ட் தேவையில்லை).

### எப்படி வேலை செய்கிறது

1. Website-இல் Admin PIN கொடுத்து Login செய்யவும் (ஏற்கனவே Servo
   Settings-க்கு பயன்படுத்திய அதே PIN).
2. "📶 WiFi Hotspot Settings" படிவத்தில் புதிய **Hotspot SSID
   (Username)** மற்றும் **Hotspot Password**-ஐ கொடுத்து **Save**
   அழுத்தவும்.
3. NodeMCU அடுத்த heartbeat-இல் (5 வினாடிக்குள்) இந்த புதிய
   credentials-ஐப் பெறும், அதை தன் **EEPROM (flash memory)**-இல்
   நிரந்தரமாக சேமித்துக் கொண்டு, உடனே அந்த புதிய hotspot-க்கு மாறி
   இணைத்துக் கொள்ளும்.
4. **பவர் கட் ஆகி மறுபடியும் பவர் வந்தாலும்** (board reboot ஆனாலும்),
   EEPROM-இல் சேமிக்கப்பட்டிருக்கும் அதே புதிய Hotspot SSID/Password-க்கே
   NodeMCU தானாக இணைத்துக் கொள்ளும் - மீண்டும் Arduino IDE-யில் code
   upload செய்ய வேண்டியதே இல்லை.

### Safety - தவறுதலாக தவறான Password கொடுத்தால்

புதிய hotspot-க்கு இணைக்க முடியாவிட்டால் (தவறான Password/SSID,
அல்லது அந்த hotspot அப்போது ஆஃப் இருந்தால்), NodeMCU 20 வினாடிக்குள்
தானாகவே `.ino`-வில் CONFIG பகுதியில் இருக்கும் **original default
WiFi**-க்கு fallback ஆகி முயற்சிக்கும். இதனால் device முழுவதுமாக
offline ஆகிவிடாமல், மீண்டும் Website வழியாக சரியான credentials
கொடுக்க வாய்ப்பு கிடைக்கும். (இது வேலை செய்ய, `.ino`-வில் உள்ள
default WIFI_SSID/WIFI_PASSWORD எப்போதும் இயங்கக்கூடிய ஒரு network-ஆக
வைத்திருங்கள் - எ.கா உங்கள் வீட்டு/கடை router.)

### குறிப்புகள்

- SSID 32 எழுத்துகள், Password 64 எழுத்துகள் வரை மட்டுமே
  அனுமதிக்கப்படும் (சாதாரண WiFi standard வரம்பு).
- SSID/Password-இல் `"` (மேற்கோள்) அல்லது `\` (backslash) எழுத்துகள்
  பயன்படுத்த வேண்டாம் - அவை NodeMCU-வின் எளிய JSON parsing-ஐ
  குழப்பிவிடும்.
- இந்த மாற்றத்திற்குப் பிறகு, NodeMCU இருக்கும் இடத்தில் அந்த புதிய
  hotspot-இன் signal சரியாக கிடைக்க வேண்டும் (இல்லையெனில் fallback
  logic default WiFi-க்கே திரும்பிவிடும்).

## கவனிக்க வேண்டியவை

- NodeMCU-வும் அதற்கான wifi router-உம் அதே பவர் சப்ளையில் இருந்தால்,
  பவர் கட் ஆனவுடன் router-உம் ஆஃப் ஆகிவிடும் - அப்பொழுது heartbeat
  அனுப்ப முடியாது, ஆனால் இணையதளம் "signal வரவில்லை" எனப் பார்த்து
  எப்படியும் "POWER OFF" எனக் காட்டிவிடும் (silence = power cut
  என்பதே இந்த சிஸ்டத்தின் logic).
- Router-க்கு UPS/power bank backup இருந்தால் இன்னும் துல்லியமான
  timestamp கிடைக்கும் (ஏனெனில் router இயங்கும் வரை NodeMCU wifi
  வழியாக status அனுப்ப முடியும் - ஆனால் NodeMCU-வே wall power
  இல்லாமல் இயங்காது என்பதால் அது தேவையில்லை, silence-ஆல் detect
  ஆகிவிடும்).
- `status.php` ஒரு simple JSON கொடுக்கும் - இதை வைத்து பின்னால்
  ஒரு Android/iOS widget அல்லது Telegram bot notification கூட
  உருவாக்கலாம் என்றால் சொல்லுங்கள், அதுவும் செய்து தருகிறேன்.
