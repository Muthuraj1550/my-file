/*
  ==================================================
  Power Cut Monitor - NodeMCU ESP8266
  ==================================================
  எப்படி வேலை செய்கிறது:
  - இந்த போர்டு உங்கள் பிளக் பாயிண்ட்டில் USB மூலம் இணைக்கப்பட்டு
    வால் பவர் இருக்கும் வரை மட்டுமே இயங்கும்.
  - பவர் இருக்கும் போது ஒவ்வொரு 5 வினாடிக்கும் ஒரு "heartbeat"
    (நான் உயிரோடு இருக்கிறேன்) சிக்னலை உங்கள் இணையதளத்திற்கு
    அனுப்பிக் கொண்டே இருக்கும்.
  - பவர் கட் ஆன உடனே இந்த போர்டும் ஆஃப் ஆகிவிடும் -> heartbeat
    நிறுத்தப்படும்.
  - இணையதளம் கடைசியாக heartbeat வந்த நேரத்தைப் பார்த்து,
    நிர்ணயிக்கப்பட்ட நேரத்திற்கு மேல் signal வரவில்லை என்றால்
    "POWER OFF" எனக் காண்பிக்கும்.
  - பவர் திரும்ப வந்தவுடன் போர்டு boot ஆகி "boot" event ஒன்றை
    அனுப்பும் -> இணையதளம் "POWER RESTORED" எனக் log செய்யும்.

  Resume பட்டன் வசதி:
  - Website-இல் "Resume Print" பட்டனை அழுத்தினால், அது server-இல்
    ஒரு "pending command" வைத்துவிடும்.
  - இந்த போர்டு ஒவ்வொரு heartbeat-இலும் (5 வினாடிக்கு ஒரு முறை)
    server பதிலில் அந்த command இருக்கிறதா எனப் பார்க்கும்.
  - command="resume" வந்தால், servo motor-ஐ இயக்கி பிரிண்டரின்
    physical resume பட்டனை ஒரு முறை "அழுத்தி" மீண்டும் இயல்பு
    நிலைக்கு திரும்பும்.

  WiFi Hotspot Password Change வசதி (Website-இல் இருந்தே மாற்றலாம்):
  - Website dashboard-இல் "📶 WiFi Hotspot Settings" படிவத்தில் (Servo
    Settings-க்கு பயன்படுத்தும் அதே Admin PIN login தேவை) புதிய SSID/
    Password கொடுத்து Save செய்தால், அடுத்த heartbeat-இலேயே (5
    வினாடிக்குள்) NodeMCU அதைப் பெறும்.
  - புதிய SSID/Password கிடைத்தவுடன், இந்த போர்டு அதை EEPROM (flash
    memory)-இல் நிரந்தரமாக சேமித்துக் கொண்டு, உடனே அந்த hotspot-க்கு
    மாறி இணைக்கும்.
  - பவர் கட் ஆகி மறுபடியும் பவர் வந்தாலும் (reboot ஆனாலும்), EEPROM-இல்
    சேமித்து வைத்திருக்கும் அதே புதிய hotspot-க்கே தானாக இணைக்கும் -
    மீண்டும் code upload செய்ய வேண்டியதில்லை.
  - Safety: புதிய hotspot-க்கு இணைக்க முடியாவிட்டால் (தவறான பாஸ்வேர்ட்/
    hotspot ஆஃப்), 20 வினாடிக்குள் NodeMCU தானாகவே கீழே உள்ள CONFIG
    பகுதியில் இருக்கும் original default WiFi (WIFI_SSID/WIFI_PASSWORD)
    -க்கு fallback ஆகி முயற்சிக்கும் - device முழுவதுமாக offline
    ஆகிவிடாமல் இருக்க.

  Servo Degree Settings (Website-இல் இருந்தே மாற்றலாம்):
  - கீழே கொடுக்கப்பட்டுள்ள SERVO_REST_ANGLE / SERVO_PRESS_ANGLE /
    SERVO_PRESS_TIME_MS ஆகியவை ஆரம்ப (default) மதிப்புகள் மட்டுமே.
  - Website dashboard-இல் "Servo Rotation Settings" படிவத்தில்
    இவற்றை மாற்றி Save செய்தால், ஒவ்வொரு heartbeat-இலும் NodeMCU
    புதிய மதிப்புகளை server-இல் இருந்து பெற்று தானாகப் பயன்படுத்தும்
    - மீண்டும் code upload செய்ய வேண்டியதில்லை.

  Website Login:
  - Dashboard-இல் "Resume Print" மற்றும் "Servo Settings" பயன்படுத்த
    முதல் முறை மட்டும் Admin PIN கேட்கப்படும். சரியான PIN கொடுத்தால்
    அந்த device-இல் cookie ஆக சேமிக்கப்பட்டு, மீண்டும் மீண்டும்
    கேட்காது.

  வயரிங் (Servo - எ.கா SG90):
  - Servo சிக்னல் (ஆரஞ்சு/மஞ்சள் வயர்)  -> NodeMCU பின் D4
  - Servo VCC (சிவப்பு)                  -> 5V / VIN (best: வெளி 5V
    சப்ளை பயன்படுத்தவும், NodeMCU-வின் 3.3V servo-வுக்கு போதாமல்
    போகலாம்)
  - Servo GND (பிரவுன்/கருப்பு)          -> NodeMCU GND (மற்றும்
    வெளி சப்ளை பயன்படுத்தினால் அதன் GND-உடனும் இணைக்கவும்)
  - Servo-வின் arm-ஐ 3D printer-இன் physical resume பட்டனுக்கு
    மேலே, அதை lightly தொடும்படி/அழுத்தும்படி பொருத்தவும் (double
    sided tape/3D printed bracket).

  தேவையான Library (Arduino IDE -> Library Manager):
  - ESP8266WiFi        (ESP8266 board package உடன் தானாக வரும்)
  - ESP8266HTTPClient  (அதே package உடன் வரும்)
  - ESP8266Servo       (Library Manager-இல் "ESP8266Servo" எனத்
    தேடி install செய்யவும் - இது ESP8266-க்கு servo support தரும்)
  - EEPROM             (ESP8266 board package உடன் தானாக வரும் - இதை
    வைத்தே புதிய WiFi Hotspot SSID/Password flash memory-இல்
    நிரந்தரமாக சேமிக்கப்படுகிறது)

  Board Manager URL (முதல் முறை setup செய்ய):
  http://arduino.esp8266.com/stable/package_esp8266com_index.json
  Tools -> Board -> "NodeMCU 1.0 (ESP-12E Module)" தேர்வு செய்யவும்.
*/

#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <Servo.h>   // ESP8266Servo library
#include <EEPROM.h>  // WiFi Hotspot SSID/Password நிரந்தரமாக சேமிக்க

// -------------------- CONFIG: இவற்றை மாற்றவும் --------------------
// இவை DEFAULT / FALLBACK WiFi credentials மட்டுமே. முதல் முறை (இதுவரை
// Website-இல் இருந்து எதுவும் மாற்றப்படாத போது) இதையே பயன்படுத்தும்.
// Website "WiFi Hotspot Settings"-இல் இருந்து மாற்றியதும், அந்த புதிய
// SSID/Password EEPROM-இல் சேமிக்கப்பட்டு, இதற்குப் பதிலாக அதையே
// பயன்படுத்தும் (பவர் கட்/reboot ஆனாலும் தொடரும்). இது default என்பதால்
// custom hotspot இணைக்க முடியாவிட்டால் fallback-ஆகவும் பயன்படும்.
const char* WIFI_SSID     = "Moon";
const char* WIFI_PASSWORD = "12345679";

// hosting/heartbeat.php இருக்கும் full URL
// உதாரணம்: http://yourdomain.com/powercut/heartbeat.php
// அல்லது local server: http://192.168.1.10/powercut/heartbeat.php
const char* SERVER_URL = "https://power.my3dgifts.com/heartbeat.php";

// config.php-யில் உள்ள DEVICE_TOKEN-உடன் இது சரியாக ஒத்திருக்க வேண்டும்
const char* DEVICE_TOKEN = "change_this_secret_123";

// இந்த போர்டுக்கு ஒரு பெயர் (பல போர்டு வைத்தால் வேறு வேறு பெயர் கொடுக்கவும்)
const char* DEVICE_NAME  = "3DPrinter_Room";

// heartbeat அனுப்பும் இடைவெளி (மில்லி விநாடி) - 5000 = 5 வினாடி
const unsigned long HEARTBEAT_INTERVAL = 5000;

// -------- Servo (Resume பட்டன்) CONFIG --------
const int SERVO_PIN = D4;  // servo சிக்னல் வயர் இணைக்கும் பின்

// இவை ஆரம்ப (default) மதிப்புகள் மட்டும். Website-இல் இருந்து
// மாற்றினால், ஒவ்வொரு heartbeat-இலும் இவை புதுப்பிக்கப்படும்.
int currentRestAngle  = 0;    // இயல்பு நிலை (பட்டனைத் தொடாத நிலை)
int currentPressAngle = 90;   // பட்டனை அழுத்தும் நிலை
int currentPressTime  = 500;  // எவ்வளவு நேரம் அழுத்தி வைத்திருக்க வேண்டும் (ms)
// -------------------------------------------------------------------

Servo resumeServo;
unsigned long lastHeartbeat = 0;

// -------- WiFi Hotspot credentials - EEPROM-இல் நிரந்தரமாக சேமிக்க --------
// Website-இல் இருந்து SSID/Password மாற்றினால், அது இந்த struct-ஆக
// flash memory-இல் (EEPROM) எழுதப்பட்டு, பவர் கட்/reboot ஆனாலும்
// அப்படியே இருக்கும். MAGIC byte வைத்து "இதுவரை ஒரு custom hotspot
// சேமிக்கப்பட்டுள்ளதா" எனத் தெரிந்து கொள்கிறோம்.
#define WIFI_EEPROM_MAGIC 0xA5
struct WifiCreds {
  uint8_t magic;
  char ssid[33];
  char pass[65];
};
#define WIFI_EEPROM_SIZE sizeof(WifiCreds)

// இப்போது உண்மையில் இணைக்க பயன்படுத்தும் SSID/Password (RAM-இல்).
// setup()-இல் EEPROM-இல் இருந்து load ஆகும் (இருந்தால்), இல்லையென்றால்
// மேலே உள்ள default WIFI_SSID/WIFI_PASSWORD-ஐ பயன்படுத்தும்.
char currentSSID[33];
char currentPASS[65];

// EEPROM-இல் இருந்து சேமிக்கப்பட்ட WiFi credentials படிக்கவும்
// (boot ஆகும் ஒவ்வொரு முறையும் - பவர் கட்/restore ஆன பிறகும் - அழைக்கப்படும்)
void loadWifiCredsFromEEPROM() {
  EEPROM.begin(WIFI_EEPROM_SIZE);
  WifiCreds creds;
  EEPROM.get(0, creds);
  EEPROM.end();

  if (creds.magic == WIFI_EEPROM_MAGIC) {
    creds.ssid[32] = '\0';
    creds.pass[64] = '\0';
    strncpy(currentSSID, creds.ssid, sizeof(currentSSID));
    strncpy(currentPASS, creds.pass, sizeof(currentPASS));
    Serial.println("EEPROM-இல் சேமிக்கப்பட்ட WiFi Hotspot load ஆனது: " + String(currentSSID));
  } else {
    strncpy(currentSSID, WIFI_SSID, sizeof(currentSSID));
    strncpy(currentPASS, WIFI_PASSWORD, sizeof(currentPASS));
    currentSSID[32] = '\0';
    currentPASS[64] = '\0';
    Serial.println("EEPROM-இல் custom WiFi இல்லை - default WiFi பயன்படுத்தப்படுகிறது: " + String(currentSSID));
  }
}

// புதிய SSID/Password-ஐ EEPROM-இல் நிரந்தரமாக எழுதவும்
void saveWifiCredsToEEPROM(const String &ssid, const String &pass) {
  WifiCreds creds;
  creds.magic = WIFI_EEPROM_MAGIC;
  memset(creds.ssid, 0, sizeof(creds.ssid));
  memset(creds.pass, 0, sizeof(creds.pass));
  ssid.toCharArray(creds.ssid, sizeof(creds.ssid));
  pass.toCharArray(creds.pass, sizeof(creds.pass));

  EEPROM.begin(WIFI_EEPROM_SIZE);
  EEPROM.put(0, creds);
  EEPROM.commit();
  EEPROM.end();

  strncpy(currentSSID, creds.ssid, sizeof(currentSSID));
  strncpy(currentPASS, creds.pass, sizeof(currentPASS));
  Serial.println("புதிய WiFi Hotspot EEPROM-இல் சேமிக்கப்பட்டது: " + String(currentSSID));
}

// ஒரு குறிப்பிட்ட SSID/Password-க்கு இணைக்க முயற்சிக்கும் helper function
bool tryConnectWiFi(const char* ssid, const char* pass, int maxRetries = 40) {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, pass);
  Serial.print("WiFi இணைக்கப்படுகிறது (" + String(ssid) + ")");
  int retries = 0;
  while (WiFi.status() != WL_CONNECTED && retries < maxRetries) {
    delay(500);
    Serial.print(".");
    retries++;
  }
  Serial.println();
  return WiFi.status() == WL_CONNECTED;
}

void connectWiFi() {
  // முதலில் இப்போது சேமிக்கப்பட்டுள்ள (custom அல்லது default) hotspot-க்கு
  // இணைக்க முயற்சிக்கவும்.
  if (tryConnectWiFi(currentSSID, currentPASS)) {
    Serial.println("WiFi இணைக்கப்பட்டது! IP: " + WiFi.localIP().toString());
    return;
  }

  // Custom hotspot (EEPROM-இல் இருந்து வந்தது) இணைக்க முடியவில்லை என்றால்,
  // device offline ஆகிவிடாமல் இருக்க .ino-வில் உள்ள original default
  // WiFi-க்கு fallback ஆக முயற்சிக்கவும்.
  if (String(currentSSID) != String(WIFI_SSID)) {
    Serial.println("Custom WiFi Hotspot-க்கு இணைக்க முடியவில்லை. Default WiFi-க்கு fallback ஆகி முயற்சிக்கிறோம்...");
    if (tryConnectWiFi(WIFI_SSID, WIFI_PASSWORD)) {
      Serial.println("Default WiFi-இல் இணைக்கப்பட்டது (fallback)! IP: " + WiFi.localIP().toString());
      return;
    }
  }

  Serial.println("WiFi இணைக்க முடியவில்லை - சிறிது நேரம் கழித்து மீண்டும் முயற்சிக்கும்");
}

void pressResumeButton() {
  Serial.println("Resume command கிடைத்தது - servo பட்டனை அழுத்துகிறது...");
  resumeServo.write(currentPressAngle);
  delay(currentPressTime);
  resumeServo.write(currentRestAngle);
  Serial.println("Servo இயல்பு நிலைக்கு திரும்பியது.");
}

// server response payload-இல் இருந்து ஒரு எண் மதிப்பை எடுக்க உதவும் function
// (e.g. "servo_rest":45 -> 45). கிடைக்கவில்லை என்றால் -9999 திருப்பும்.
int extractIntValue(const String &payload, const String &key) {
  String searchKey = "\"" + key + "\":";
  int idx = payload.indexOf(searchKey);
  if (idx == -1) return -9999;
  idx += searchKey.length();
  while (idx < (int)payload.length() && payload[idx] == ' ') idx++;

  bool neg = false;
  if (idx < (int)payload.length() && payload[idx] == '-') {
    neg = true;
    idx++;
  }
  int start = idx;
  while (idx < (int)payload.length() && isDigit(payload[idx])) idx++;
  if (idx == start) return -9999;

  int val = payload.substring(start, idx).toInt();
  return neg ? -val : val;
}

// server response payload-இல் இருந்து ஒரு string மதிப்பை எடுக்க உதவும்
// function (e.g. "wifi_ssid":"MyHotspot" -> "MyHotspot"). key இல்லை
// அல்லது மதிப்பு null என்றால் "" (காலி string) திருப்பும்.
// குறிப்பு: SSID/Password-இல் " அல்லது \ எழுத்துகள் இருக்கக்கூடாது
// (wifi_settings.php-யே அப்படி வர விடாது).
String extractStringValue(const String &payload, const String &key) {
  String searchKey = "\"" + key + "\":\"";
  int idx = payload.indexOf(searchKey);
  if (idx == -1) return "";
  idx += searchKey.length();
  int endIdx = payload.indexOf("\"", idx);
  if (endIdx == -1) return "";
  return payload.substring(idx, endIdx);
}

void sendHeartbeat(bool isBoot) {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
    if (WiFi.status() != WL_CONNECTED) return;
  }

  BearSSL::WiFiClientSecure client;
  client.setInsecure(); // https certificate-ஐ strict-ஆக சரிபார்க்காமல் இணைக்கும் (simple hobby setup-க்கு போதும்)
  HTTPClient http;

  String url = String(SERVER_URL) +
               "?token=" + DEVICE_TOKEN +
               "&device=" + DEVICE_NAME +
               "&event=" + (isBoot ? "boot" : "alive");

  http.begin(client, url);
  int httpCode = http.GET();

  if (httpCode > 0) {
    String payload = http.getString();
    Serial.printf("Heartbeat அனுப்பப்பட்டது. HTTP code: %d\n", httpCode);

    // website-இல் இருந்து servo settings மாறியிருந்தால் புதுப்பிக்கவும்
    int restVal  = extractIntValue(payload, "servo_rest");
    int pressVal = extractIntValue(payload, "servo_press");
    int timeVal  = extractIntValue(payload, "servo_time_ms");
    if (restVal  != -9999) currentRestAngle  = restVal;
    if (pressVal != -9999) currentPressAngle = pressVal;
    if (timeVal  != -9999) currentPressTime  = timeVal;

    // server response-இல் resume command இருக்கிறதா எனப் பார்க்கவும்
    if (payload.indexOf("\"command\":\"resume\"") != -1) {
      pressResumeButton();
    }

    // website-இல் இருந்து WiFi Hotspot SSID/Password மாறியிருந்தால்
    // (wifi_ssid காலியில்லாமல் இருந்து, தற்போதைய credentials-உடன்
    // வேறுபட்டிருந்தால்), அதை EEPROM-இல் சேமித்து உடனே அந்த hotspot-க்கு
    // மாறி இணைக்கவும்.
    String newSSID = extractStringValue(payload, "wifi_ssid");
    String newPass = extractStringValue(payload, "wifi_pass");
    if (newSSID.length() > 0 &&
        (newSSID != String(currentSSID) || newPass != String(currentPASS))) {
      Serial.println("புதிய WiFi Hotspot settings Website-இல் இருந்து கிடைத்தது - சேமித்து இணைக்கிறோம்...");
      saveWifiCredsToEEPROM(newSSID, newPass);
      WiFi.disconnect();
      delay(200);
      connectWiFi();
    }
  } else {
    Serial.printf("Heartbeat அனுப்ப முடியவில்லை: %s\n", http.errorToString(httpCode).c_str());
  }
  http.end();
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n=== Power Cut Monitor Starting ===");

  resumeServo.attach(SERVO_PIN);
  resumeServo.write(currentRestAngle);

  // முதலில் EEPROM-இல் ஏதேனும் custom WiFi Hotspot சேமிக்கப்பட்டுள்ளதா
  // எனப் படிக்கவும் (Website-இல் இருந்து முன்பே மாற்றியிருந்தால் அதுவே
  // load ஆகும்; இல்லையென்றால் மேலே உள்ள default பயன்படுத்தப்படும்).
  loadWifiCredsFromEEPROM();
  connectWiFi();

  // போர்டு இப்போதுதான் boot ஆனது (அதாவது பவர் புதிதாக வந்திருக்கலாம்)
  sendHeartbeat(true);
  lastHeartbeat = millis();
}

void loop() {
  if (millis() - lastHeartbeat >= HEARTBEAT_INTERVAL) {
    sendHeartbeat(false);
    lastHeartbeat = millis();
  }
}
