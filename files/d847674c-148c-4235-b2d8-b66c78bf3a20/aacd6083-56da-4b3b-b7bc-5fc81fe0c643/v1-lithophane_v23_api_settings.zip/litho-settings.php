<?php
/**
 * Lithophane Studio — API settings page.
 * Course site (my3dgifts) oda API URL / API key / API ID ah ingaye add pannalaam.
 * Save aana values -> litho-settings.json
 */
require_once __DIR__ . '/litho-config.php';
session_start();

if (isset($_POST['login'])) {
    if (($_POST['u'] ?? '') === LITHO_ADMIN_USER && ($_POST['p'] ?? '') === LITHO_ADMIN_PASS) $_SESSION['litho_admin'] = true;
    else $err = 'Wrong username / password';
}
if (isset($_GET['logout'])) { unset($_SESSION['litho_admin']); header('Location: litho-settings.php'); exit; }

$css = '<style>body{background:#070a12;color:#dde4f0;font-family:system-ui,sans-serif;margin:0;padding:28px}
h1{font-size:20px;margin:0 0 6px}.sub{color:#6b7a94;font-size:13px;margin-bottom:20px}
.card{max-width:720px;background:#0e1320;border:1px solid #1e2840;border-radius:14px;padding:22px;margin-bottom:18px}
label{display:block;font-size:12px;color:#8fa3c4;margin:12px 0 5px}
input{width:100%;padding:10px 12px;background:#080c14;border:1px solid #1e2840;border-radius:8px;color:#dde4f0;box-sizing:border-box}
button{margin-top:16px;padding:10px 18px;background:#0ea5a4;border:none;border-radius:8px;color:#04191c;font-weight:800;cursor:pointer}
a{color:#38bdf8}.ok{background:#0f2f2b;color:#34d399;padding:10px 14px;border-radius:8px;margin-bottom:14px}
.bad{background:#3a1414;color:#f87171;padding:10px 14px;border-radius:8px;margin-bottom:14px}
.box{max-width:380px;margin:80px auto}.muted{color:#6b7a94;font-size:12px}
table{width:100%;border-collapse:collapse;font-size:13px;margin-top:10px}td,th{padding:8px 10px;border-bottom:1px solid #1e2840;text-align:left}</style>';

if (empty($_SESSION['litho_admin'])) {
    echo $css . '<div class="card box"><h1>🔐 Litho Settings</h1>'
       . (isset($err) ? '<div class="bad">'.htmlspecialchars($err).'</div>' : '')
       . '<form method="post"><label>Username</label><input name="u"><label>Password</label><input name="p" type="password">'
       . '<button name="login" value="1">Login →</button></form></div>';
    exit;
}

$saved = null; $test = null;
if (isset($_POST['save'])) {
    $saved = litho_settings_save($_POST);
    // reload page so the new constants apply
    if ($saved) { header('Location: litho-settings.php?saved=1'); exit; }
}
if (isset($_GET['saved'])) $saved = true;

if (isset($_POST['test'])) {
    $ch = curl_init(COURSE_USERS_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['api_key'=>COURSE_API_KEY, 'site'=>COURSE_SITE_ID]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
    ]);
    $res = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $j = $res ? json_decode($res, true) : null;
    $test = !empty($j['ok'])
        ? ['ok', 'API connect aachu ✅ — '.(int)($j['count'] ?? 0).' users kidaichathu.']
        : ['bad', 'Connect aagala (HTTP '.$code.'): '.htmlspecialchars(substr((string)$res, 0, 200))];
}

$s = litho_settings();
$f = function ($k) use ($s) { return htmlspecialchars((string)($s[$k] ?? '')); };
echo $css;
?>
<h1>🔌 API Settings <a href="?logout=1" style="float:right;font-size:13px">Logout</a></h1>
<div class="sub">Course site → Admin → <b>Tool Sites &amp; Access</b> la ithu site kku API ID + API key generate pannunga, appuram inga paste pannunga.
  · <a href="litho-users.php">User list →</a></div>

<?php if ($saved): ?><div class="card" style="padding:0;border:0"><div class="ok">Settings save aachu ✅</div></div><?php endif; ?>
<?php if ($test): ?><div class="card" style="padding:0;border:0"><div class="<?php echo $test[0]; ?>"><?php echo $test[1]; ?></div></div><?php endif; ?>

<form method="post" class="card">
  <h3 style="margin:0">Course site API</h3>
  <label>API ID (site key) — e.g. litho / balloon</label>
  <input name="site_id" value="<?php echo $f('site_id'); ?>">
  <label>API key (server-side only — browser la vaikka koodathu)</label>
  <input name="api_key" value="<?php echo $f('api_key'); ?>">
  <label>Verify endpoint URL</label>
  <input name="api_url" value="<?php echo $f('api_url'); ?>">
  <label>User list endpoint URL</label>
  <input name="users_url" value="<?php echo $f('users_url'); ?>">

  <h3 style="margin:22px 0 0">Master / admin login</h3>
  <label>Master username (course API down aana use pannalaam)</label>
  <input name="master_user" value="<?php echo $f('master_user'); ?>">
  <label>Master password</label>
  <input name="master_pass" value="<?php echo $f('master_pass'); ?>">
  <label>Admin page username</label>
  <input name="admin_user" value="<?php echo $f('admin_user'); ?>">
  <label>Admin page password</label>
  <input name="admin_pass" value="<?php echo $f('admin_pass'); ?>">

  <button name="save" value="1">💾 Save settings</button>
  <button name="test" value="1" style="background:#1e2840;color:#dde4f0">🔍 Test connection</button>
  <div class="muted" style="margin-top:12px">Save aagum file: <code>litho-settings.json</code> (folder write permission venum).</div>
</form>
