<?php
// ========== Lithophane Studio — "Edit in Editor" XML hand-off ==========
// The My3DGifts main editor (designer.php) can auto-load a project from
// ?load_xml=<url-to-xml-file>  (see protected/engine.html: "Auto-load
// project from ?load_xml=<url> URL param"). Since that needs a URL and not
// raw XML, this endpoint just takes the XML the lithophane tool built
// (a full <project> doc, or a template merged with the lithophane object)
// and stores it as a small file we can hand back a URL for.
//
// POST raw XML as the request body. Returns JSON: {"url": "https://..."}

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

header('Content-Type: application/json');

// ─── This file lives on the LITHOPHANE subdomain (litho.my3dgifts.com),
//     not on the main editor's domain (my3dgifts.com). The URL we hand back
//     must point to wherever this script + xml-cache/ actually is, or the
//     main editor will try to fetch the XML from the wrong domain and get a
//     404 — which is why "Edit in Editor" was failing. ─────────────────────
define('SITE_BASE_URL', 'https://litho.my3dgifts.com');

$cacheDir = __DIR__ . '/xml-cache';
if (!is_dir($cacheDir)) {
    @mkdir($cacheDir, 0755, true);
}
// Always (re)write .htaccess: the main editor (my3dgifts.com) fetches this
// XML cross-origin via plain fetch(), so the static file needs CORS headers
// or the browser blocks the response even when the URL is correct.
@file_put_contents($cacheDir . '/.htaccess',
    "Options -Indexes\n" .
    "<IfModule mod_headers.c>\n" .
    "  <FilesMatch \"\\.xml$\">\n" .
    "    Header set Access-Control-Allow-Origin \"*\"\n" .
    "  </FilesMatch>\n" .
    "</IfModule>\n"
);

$xml = file_get_contents('php://input');
if ($xml === false || trim($xml) === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Empty XML body']);
    exit;
}
if (strlen($xml) > 60 * 1024 * 1024) { // 60MB safety cap (raised from 15MB — large/high-poly
    // lithophane models legitimately produce big position/index arrays even
    // after trimming normals+uv on the client side). Files are auto-deleted
    // after 2 hours below, so this is never long-term server storage.
    http_response_code(413);
    echo json_encode(['error' => 'XML too large']);
    exit;
}

// ─── Housekeeping: delete cached files older than 2 hours on every request
//     (no cron needed — this endpoint is called rarely enough that a sweep
//     here is cheap, and files are meant to be loaded within minutes anyway) ───
$maxAgeSecs = 2 * 3600;
foreach (glob($cacheDir . '/*.xml') ?: [] as $f) {
    if (time() - filemtime($f) > $maxAgeSecs) @unlink($f);
}

$id = bin2hex(random_bytes(12));
$path = $cacheDir . '/' . $id . '.xml';
if (@file_put_contents($path, $xml) === false) {
    http_response_code(500);
    echo json_encode(['error' => 'Could not write file']);
    exit;
}

echo json_encode(['url' => SITE_BASE_URL . '/xml-cache/' . $id . '.xml']);
