<?php
// ========== Lithophane Studio — Admin Panel + Analytics ==========
// முதல் முறை login: username = admin , password = changeme123
// உடனே கீழே ADMIN_USER / ADMIN_PASS மாற்றவும்.
define('ADMIN_USER', 'Adminlitho');
define('ADMIN_PASS', 'Litho@123');

session_start();
$cfgFile       = __DIR__ . '/config.json';
$analyticsFile = __DIR__ . '/analytics.json';

// ─── Login / Logout ───────────────────────────────────────────────────────────
if (isset($_POST['login'])) {
    if ($_POST['u'] === ADMIN_USER && $_POST['p'] === ADMIN_PASS) {
        $_SESSION['ok'] = true;
    } else {
        $loginErr = 'தவறான username/password';
    }
}
if (isset($_GET['logout'])) { session_destroy(); header('Location: admin.php'); exit; }

// ─── Record a page-view (called by tracking-snippet via AJAX) ─────────────────
if (isset($_GET['track'])) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    $data  = loadAnalytics();
    $today = date('Y-m-d');

    // ── Views counter ──
    $data['views'][$today] = ($data['views'][$today] ?? 0) + 1;

    // ── Traffic Source ──
    $searchEngines = ['google','bing','duckduckgo','yahoo'];
    $socialSites   = ['youtube','facebook','instagram','whatsapp','twitter','pinterest','linkedin','tiktok','telegram'];
    $allowed = array_merge($searchEngines, $socialSites, ['direct','other']);

    $src = strtolower(trim($_GET['src'] ?? 'direct'));
    if (!in_array($src, $allowed, true)) $src = 'other';

    if (!isset($data['sources']))         $data['sources']         = [];
    if (!isset($data['sources_daily']))   $data['sources_daily']   = [];
    $data['sources'][$src]               = ($data['sources'][$src] ?? 0) + 1;
    $data['sources_daily'][$today][$src] = ($data['sources_daily'][$today][$src] ?? 0) + 1;

    // ── Page tracking ──
    $allowedPages = ['index.html','custom-gift.html','lithophane-editor.html',
                     'lithophane-3d-print.html','lithophane-balloon.html','other'];
    $rawPage = trim($_GET['page'] ?? 'other');
    // sanitize
    $page = preg_replace('/[^a-zA-Z0-9\-_\.\/]/', '', $rawPage);
    if (!in_array($page, $allowedPages, true)) $page = 'other';

    if (!isset($data['pages']))         $data['pages']         = [];
    if (!isset($data['pages_daily']))   $data['pages_daily']   = [];
    $data['pages'][$page]               = ($data['pages'][$page] ?? 0) + 1;
    $data['pages_daily'][$today][$page] = ($data['pages_daily'][$today][$page] ?? 0) + 1;

    // ── Time-on-page ──
    $secs = intval($_GET['secs'] ?? 0);
    if ($secs > 0 && $secs < 86400) {
        $data['time'][$today]   = ($data['time'][$today]   ?? 0) + $secs;
        $data['tcount'][$today] = ($data['tcount'][$today] ?? 0) + 1;
    }

    saveAnalytics($data);
    echo json_encode(['ok'=>true]);
    exit;
}

// ─── Save settings ───────────────────────────────────────────────────────────
$saved = false;
if (!empty($_SESSION['ok']) && isset($_POST['save'])) {
    $cfg = [
        'balloonPassword'    => trim($_POST['balloonPassword']   ?? 'moon3d'),
        'bodyPassword'       => trim($_POST['bodyPassword']      ?? 'moon3d'),
        'homeUrl'            => trim($_POST['homeUrl']           ?? 'https://my3dgifts.com/'),
        'sphereTemplateUrl'  => trim($_POST['sphereTemplateUrl'] ?? 'sphere-image-template.png'),
        'paywallText'        => trim($_POST['paywallText']       ?? ''),
        'paywallButtonLabel' => trim($_POST['paywallButtonLabel']?? ''),
        'paywallButtonUrl'   => trim($_POST['paywallButtonUrl']  ?? ''),
        'paywallButton2Label'=> trim($_POST['paywallButton2Label']?? ''),
        'paywallButton2Url'  => trim($_POST['paywallButton2Url'] ?? ''),
    ];
    file_put_contents($cfgFile, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    $saved = true;
}

// ─── Load config ─────────────────────────────────────────────────────────────
$cfg = [
  'balloonPassword'=>'moon3d','bodyPassword'=>'moon3d',
  'homeUrl'=>'https://my3dgifts.com/','sphereTemplateUrl'=>'sphere-image-template.png',
  'paywallText'=>'🔒 இந்த அம்சத்தைப் பயன்படுத்த, முதலில் எங்கள் கோர்ஸை வாங்கி பாஸ்வேர்டைப் பெறுங்கள்.',
  'paywallButtonLabel'=>'👉 கோர்ஸ் வாங்க',
  'paywallButtonUrl'=>'https://my3dgifts.com/course',
  'paywallButton2Label'=>'',
  'paywallButton2Url'=>'',
];
if (file_exists($cfgFile)) {
    $j = json_decode(file_get_contents($cfgFile), true);
    if (is_array($j)) $cfg = array_merge($cfg, $j);
}

// ─── Analytics helpers ────────────────────────────────────────────────────────
function loadAnalytics() {
    global $analyticsFile;
    $base = ['views'=>[],'time'=>[],'tcount'=>[],'sources'=>[],'sources_daily'=>[],
             'pages'=>[],'pages_daily'=>[]];
    if (!file_exists($analyticsFile)) return $base;
    $j = json_decode(file_get_contents($analyticsFile), true);
    return is_array($j) ? array_merge($base, $j) : $base;
}
function saveAnalytics($data) {
    global $analyticsFile;
    file_put_contents($analyticsFile, json_encode($data, JSON_PRETTY_PRINT));
}
function avgTime($data, $date) {
    $t = $data['time'][$date]  ?? 0;
    $c = $data['tcount'][$date] ?? 0;
    if ($c === 0) return '—';
    $avg = intdiv($t, $c);
    return sprintf('%d:%02d நிமிடம்', intdiv($avg,60), $avg%60);
}
function fmtSecs($secs) {
    if (!$secs) return '—';
    return sprintf('%d:%02d நிமிடம்', intdiv($secs,60), $secs%60);
}

// ─── Build analytics summary ─────────────────────────────────────────────────
$ana       = loadAnalytics();
$today     = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));
$monthKey  = date('Y-m');

$vToday = $ana['views'][$today]     ?? 0;
$vYest  = $ana['views'][$yesterday] ?? 0;
$vMonth = 0;
foreach ($ana['views'] as $d => $v) {
    if (str_starts_with($d, $monthKey)) $vMonth += $v;
}
$vAll = array_sum($ana['views']);

// ── Traffic source categories ──
$searchEngines = ['google','bing','duckduckgo','yahoo'];
$socialSites   = ['youtube','facebook','instagram','whatsapp','twitter',
                  'pinterest','linkedin','tiktok','telegram'];

$srcAll = $ana['sources'] ?? [];
arsort($srcAll);
$srcTotal = array_sum($srcAll);

// Totals per category
$totalDirect  = $srcAll['direct'] ?? 0;
$totalSearch  = 0; foreach ($searchEngines as $e) $totalSearch  += ($srcAll[$e] ?? 0);
$totalSocial  = 0; foreach ($socialSites   as $s) $totalSocial  += ($srcAll[$s] ?? 0);
$totalOther   = $srcAll['other'] ?? 0;

// Today sources
$srcToday      = $ana['sources_daily'][$today] ?? [];
arsort($srcToday);
$srcTodayTotal = array_sum($srcToday);

// ── Page popularity ──
$pagesAll   = $ana['pages']         ?? [];
$pagesToday = $ana['pages_daily'][$today] ?? [];
arsort($pagesAll);
arsort($pagesToday);
$pagesTotal = array_sum($pagesAll);

// ── Custom date filter ──
$filterDate = $_GET['date'] ?? '';
$vCustom    = 0;
if ($filterDate && preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterDate)) {
    $vCustom = $ana['views'][$filterDate] ?? 0;
}

// ── Chart: last 14 days ──
$chartDays  = [];
$chartViews = [];
for ($i = 13; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i day"));
    $chartDays[]  = date('d/m', strtotime("-$i day"));
    $chartViews[] = $ana['views'][$d] ?? 0;
}

// ── Top 10 days ──
$sorted = $ana['views'];
arsort($sorted);
$top10 = array_slice($sorted, 0, 10, true);

// ── Source labels ──
$srcLabels = [
  'google'    =>'🔎 Google Search',  'youtube'   =>'▶ YouTube',
  'facebook'  =>'📘 Facebook',        'instagram' =>'📸 Instagram',
  'whatsapp'  =>'💬 WhatsApp',        'twitter'   =>'𝕏 Twitter/X',
  'bing'      =>'🅱 Bing',            'duckduckgo'=>'🦆 DuckDuckGo',
  'yahoo'     =>'🟣 Yahoo',           'pinterest' =>'📌 Pinterest',
  'linkedin'  =>'💼 LinkedIn',        'tiktok'    =>'🎵 TikTok',
  'telegram'  =>'✈ Telegram',         'direct'    =>'➡ Direct / Bookmark',
  'other'     =>'🌐 Other sites',
];

// ── Page labels ──
$pageLabels = [
  'index.html'              => '🏠 Home (index.html)',
  'custom-gift.html'        => '🎁 Custom Gift',
  'lithophane-editor.html'  => '✏️ Lithophane Editor',
  'lithophane-3d-print.html'=> '🖨 3D Print Page',
  'lithophane-balloon.html' => '🎈 Balloon Page',
  'other'                   => '📄 Other Pages',
];
?><!DOCTYPE html>
<html lang="ta">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin · Lithophane Studio Analytics</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,sans-serif;background:#080c14;color:#dde4f0;min-height:100vh}
.topbar{background:#0e1320;border-bottom:1px solid #1e2840;padding:12px 24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px}
.topbar h1{font-size:16px;font-weight:700;background:linear-gradient(90deg,#6c4fff,#00d4ff);-webkit-background-clip:text;background-clip:text;color:transparent}
.topbar .links a{margin-left:16px;color:#7eb8ff;font-size:12px;text-decoration:none}
.topbar .links a:hover{color:#fff}
.topbar .links a.btn-nav{display:inline-block;padding:7px 14px;border-radius:8px;background:#151d31;border:1px solid #24304d;color:#dde4f0;font-weight:700;font-size:12px}
.topbar .links a.btn-nav:hover{background:#1e2840;border-color:#00d4ff;color:#00d4ff}

/* TAB NAV */
.tab-nav{background:#0a0e1a;border-bottom:1px solid #1e2840;display:flex;gap:0;overflow-x:auto}
.tab-btn{padding:12px 20px;font-size:12px;font-weight:600;color:#6b7a94;cursor:pointer;border:none;background:transparent;border-bottom:2px solid transparent;white-space:nowrap;text-transform:uppercase;letter-spacing:.8px;transition:.2s}
.tab-btn:hover{color:#aab8d0}
.tab-btn.active{color:#00d4ff;border-bottom-color:#00d4ff}

.wrap{max-width:1000px;margin:0 auto;padding:24px 16px}
.tab-panel{display:none}.tab-panel.active{display:block}

/* CARDS */
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(175px,1fr));gap:14px;margin-bottom:24px}
.card{background:#0e1320;border:1px solid #1e2840;border-radius:12px;padding:18px 20px}
.card .label{font-size:11px;color:#6b7a94;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.card .val{font-size:32px;font-weight:700;color:#fff}
.card .sub{font-size:11px;color:#4b5e78;margin-top:4px}
.card.blue{border-color:#6c4fff44}
.card.cyan{border-color:#00d4ff44}
.card.green{border-color:#10b98144}
.card.yellow{border-color:#f59e0b44}
.card.purple{border-color:#a855f744}
.card.red{border-color:#ef444444}

/* CATEGORY SUMMARY ROW */
.cat-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:20px}
.cat-card{background:#0e1320;border:1px solid #1e2840;border-radius:10px;padding:14px 16px;text-align:center}
.cat-card .cat-icon{font-size:22px;margin-bottom:6px}
.cat-card .cat-label{font-size:10px;color:#6b7a94;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px}
.cat-card .cat-val{font-size:24px;font-weight:700;color:#fff}
.cat-card .cat-pct{font-size:11px;margin-top:2px}
.cat-card.direct .cat-val{color:#60a5fa}
.cat-card.search .cat-val{color:#34d399}
.cat-card.social .cat-val{color:#fb923c}
.cat-card.other2 .cat-val{color:#a78bfa}

/* SECTION */
.section{background:#0e1320;border:1px solid #1e2840;border-radius:12px;padding:20px;margin-bottom:20px}
.section h2{font-size:13px;font-weight:600;color:#9ba9bd;margin-bottom:16px;text-transform:uppercase;letter-spacing:1px}

/* CHART */
.chart-wrap{position:relative;height:160px;display:flex;align-items:flex-end;gap:6px}
.bar-col{display:flex;flex-direction:column;align-items:center;flex:1;gap:4px}
.bar{width:100%;background:linear-gradient(180deg,#6c4fff,#4a2fe0);border-radius:4px 4px 0 0;min-height:2px;transition:.3s}
.bar-lbl{font-size:9px;color:#4b5e78;white-space:nowrap}
.bar-num{font-size:9px;color:#9ba9bd}

/* SEARCH RANK HIGHLIGHT */
.rank-box{background:#0a1a10;border:1px solid #10b98144;border-radius:10px;padding:14px 18px;margin-bottom:16px;display:flex;align-items:center;gap:14px}
.rank-box .rank-icon{font-size:32px}
.rank-box .rank-info .rank-title{font-size:13px;font-weight:700;color:#6ee7b7;margin-bottom:2px}
.rank-box .rank-info .rank-sub{font-size:11px;color:#4b7a5e}
.rank-breakdown{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:16px}
.rank-engine{background:#0b1520;border:1px solid #1e2840;border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px}
.rank-engine .re-label{font-size:12px;color:#9ba9bd}
.rank-engine .re-val{font-size:18px;font-weight:700;color:#fff;margin-left:auto}
.rank-engine .re-pct{font-size:10px;color:#4b5e78;margin-left:4px}

/* TABLE */
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;color:#6b7a94;font-size:11px;padding:8px 10px;border-bottom:1px solid #1e2840;text-transform:uppercase;letter-spacing:.8px}
td{padding:9px 10px;border-bottom:1px solid #111827}
tr:last-child td{border:none}
tr:hover td{background:#0b1020}
.badge{display:inline-block;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600}
.badge-blue{background:#6c4fff22;color:#a78bfa}
.badge-green{background:#10b98122;color:#6ee7b7}
.badge-orange{background:#f59e0b22;color:#fbbf24}

/* PROGRESS BAR */
.prog-wrap{background:#1e2840;border-radius:4px;height:6px;margin-top:4px}
.prog-bar{height:6px;border-radius:4px;transition:width .4s}

/* FILTER */
.filter-row{display:flex;gap:10px;align-items:center;margin-bottom:20px;flex-wrap:wrap}
.filter-row input[type=date]{background:#0b0f17;border:1px solid #1e2840;border-radius:8px;color:#dde4f0;padding:8px 12px;font-size:13px}
.filter-row button{background:#6c4fff;border:none;border-radius:8px;color:#fff;padding:8px 16px;font-size:13px;cursor:pointer;font-weight:600}
.filter-row button:hover{background:#5b3eee}

/* SETTINGS */
.settings-box{background:#0e1320;border:1px solid #1e2840;border-radius:12px;padding:20px;margin-bottom:20px}
.settings-box label{display:block;margin:10px 0 4px;font-size:12px;color:#6b7a94}
.settings-box input,.settings-box textarea{width:100%;padding:9px 11px;background:#080c14;border:1px solid #1e2840;border-radius:8px;color:#dde4f0;font-size:13px}
.settings-box textarea{font-family:inherit;resize:vertical}
.settings-box button{margin-top:14px;padding:10px 24px;background:#3b82f6;border:none;border-radius:8px;color:#fff;font-weight:700;cursor:pointer;font-size:13px}
.settings-box button:hover{background:#2563eb}
.ok-msg{background:#0f2a1a;border:1px solid #1f5a35;padding:10px 14px;border-radius:8px;color:#6ee7b7;font-size:13px;margin-bottom:14px}
.divider{border:none;border-top:1px solid #1e2840;margin:20px 0}

/* NEWS COUNTER */
.news-count-box{background:linear-gradient(135deg,#0e1320,#0a1828);border:1px solid #00d4ff33;border-radius:12px;padding:18px 20px;margin-bottom:20px;display:flex;align-items:center;gap:16px}
.news-icon{font-size:36px}
.news-info{flex:1}
.news-info h3{font-size:15px;font-weight:700;color:#00d4ff;margin-bottom:4px}
.news-info p{font-size:12px;color:#6b7a94}
.news-val{font-size:42px;font-weight:800;color:#fff}

/* ── POST WRITER ── */
.pw-grid{display:grid;grid-template-columns:320px 1fr;gap:20px;align-items:start}
@media(max-width:700px){.pw-grid{grid-template-columns:1fr}}
.pw-form-box{background:#0e1320;border:1px solid #1e2840;border-radius:12px;padding:20px;position:sticky;top:16px}
.pw-form-box h2{font-size:13px;font-weight:700;color:#9ba9bd;text-transform:uppercase;letter-spacing:1px;margin-bottom:16px}
.pw-label{display:block;font-size:11px;color:#6b7a94;text-transform:uppercase;letter-spacing:.7px;margin:14px 0 5px}
.pw-input,.pw-select,.pw-textarea{width:100%;padding:9px 12px;background:#080c14;border:1px solid #1e2840;border-radius:8px;color:#dde4f0;font-size:13px;font-family:inherit;transition:border-color .2s}
.pw-input:focus,.pw-select:focus,.pw-textarea:focus{outline:none;border-color:#6c4fff}
.pw-select option{background:#0e1320}
.pw-textarea{resize:vertical;line-height:1.5}
.pw-tags{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.pw-tag{background:#6c4fff22;border:1px solid #6c4fff44;color:#a78bfa;border-radius:20px;padding:3px 10px;font-size:11px;cursor:pointer;transition:.15s}
.pw-tag:hover{background:#6c4fff44}
.pw-tag.sel{background:#6c4fff;color:#fff;border-color:#6c4fff}
.pw-btn{width:100%;padding:12px;background:linear-gradient(135deg,#6c4fff,#00d4ff);border:none;border-radius:10px;color:#fff;font-weight:700;font-size:14px;cursor:pointer;margin-top:16px;letter-spacing:.5px;transition:.2s}
.pw-btn:hover{opacity:.9;transform:translateY(-1px)}
.pw-btn:disabled{opacity:.5;transform:none;cursor:not-allowed}
.pw-output-box{background:#0e1320;border:1px solid #1e2840;border-radius:12px;padding:20px;min-height:400px}
.pw-output-box h2{font-size:13px;font-weight:700;color:#9ba9bd;text-transform:uppercase;letter-spacing:1px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center}
.pw-placeholder{color:#2a3a54;font-size:14px;text-align:center;padding:60px 20px;line-height:2}
.pw-placeholder .big-icon{font-size:48px;display:block;margin-bottom:12px}
.pw-result{display:none}
.pw-result-tabs{display:flex;gap:0;border-bottom:1px solid #1e2840;margin-bottom:16px}
.pw-rtab{padding:8px 16px;font-size:12px;font-weight:600;color:#6b7a94;cursor:pointer;border:none;background:transparent;border-bottom:2px solid transparent;text-transform:uppercase;letter-spacing:.7px}
.pw-rtab.active{color:#00d4ff;border-bottom-color:#00d4ff}
.pw-content-area{display:none}
.pw-content-area.active{display:block}
.pw-post-preview{font-size:14px;line-height:1.8;color:#c8d4e8}
.pw-post-preview h1{font-size:22px;font-weight:700;color:#fff;margin-bottom:8px;line-height:1.3}
.pw-post-preview h2{font-size:17px;font-weight:600;color:#a78bfa;margin:20px 0 8px}
.pw-post-preview h3{font-size:15px;font-weight:600;color:#60a5fa;margin:16px 0 6px}
.pw-post-preview p{margin-bottom:12px}
.pw-post-preview ul,.pw-post-preview ol{margin:8px 0 12px 20px}
.pw-post-preview li{margin-bottom:4px}
.pw-post-preview strong{color:#fff}
.pw-post-preview em{color:#fbbf24}
.pw-seo-box{background:#080c14;border-radius:10px;padding:16px}
.pw-seo-row{display:flex;gap:10px;align-items:flex-start;padding:10px 0;border-bottom:1px solid #1e2840}
.pw-seo-row:last-child{border:none}
.pw-seo-icon{font-size:18px;flex-shrink:0;margin-top:2px}
.pw-seo-label{font-size:11px;color:#6b7a94;text-transform:uppercase;letter-spacing:.7px;margin-bottom:3px}
.pw-seo-val{font-size:13px;color:#dde4f0}
.pw-seo-score{display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700}
.score-good{background:#10b98122;color:#6ee7b7}
.score-ok{background:#f59e0b22;color:#fbbf24}
.pw-copy-btn{padding:6px 14px;background:#1e2840;border:1px solid #2a3a54;border-radius:7px;color:#9ba9bd;font-size:11px;cursor:pointer;transition:.15s;margin-left:8px}
.pw-copy-btn:hover{background:#2a3a54;color:#fff}
.pw-loading{display:none;text-align:center;padding:40px;color:#6b7a94}
.pw-loading .spin{font-size:32px;animation:spin 1s linear infinite;display:block;margin-bottom:12px}
@keyframes spin{to{transform:rotate(360deg)}}
.pw-error{background:#2a0f0f;border:1px solid #7a2020;border-radius:8px;padding:12px;color:#ff9c9c;font-size:13px;display:none;margin-top:12px}
/* LOGIN */
.login-box{max-width:380px;margin:80px auto;background:#0e1320;border:1px solid #1e2840;border-radius:14px;padding:28px}
.login-box h1{margin-bottom:20px;font-size:18px}
.login-box input{width:100%;padding:10px 12px;background:#080c14;border:1px solid #1e2840;border-radius:8px;color:#dde4f0;font-size:14px;margin-bottom:10px}
.login-box button{width:100%;padding:11px;background:#6c4fff;border:none;border-radius:8px;color:#fff;font-weight:700;cursor:pointer;font-size:14px}
.err-msg{background:#2a0f0f;border:1px solid #7a2020;padding:10px;border-radius:8px;color:#ff9c9c;font-size:13px;margin-bottom:12px}
.empty{color:#4b5e78;font-size:13px;padding:16px 0;text-align:center}
</style>
</head>
<body>

<?php if (empty($_SESSION['ok'])): ?>
<!-- ══════════════════ LOGIN ══════════════════ -->
<div class="login-box">
  <h1>🔐 Admin Login</h1>
  <?php if (!empty($loginErr)): ?><div class="err-msg"><?= htmlspecialchars($loginErr) ?></div><?php endif; ?>
  <form method="post">
    <input name="u" placeholder="Username" autofocus>
    <input name="p" type="password" placeholder="Password">
    <button name="login" value="1">Login →</button>
  </form>
</div>

<?php else: ?>
<!-- ══════════════════ ADMIN PANEL ══════════════════ -->
<div class="topbar">
  <h1>⚡ Lithophane Studio — Admin Analytics</h1>
  <div class="links">
    <a class="btn-nav" href="litho-settings.php">🔌 API Settings</a>
    <a class="btn-nav" href="litho-users.php">👥 Users</a>
    <a href="index.html" target="_blank">→ App திற</a>
    <a href="?logout=1">Logout</a>
  </div>
</div>

<!-- TAB NAVIGATION -->
<div class="tab-nav">
  <button class="tab-btn active" onclick="showTab('overview')">📊 Overview</button>
  <button class="tab-btn" onclick="showTab('traffic')">🌍 Traffic Sources</button>
  <button class="tab-btn" onclick="showTab('pages')">📄 Pages</button>
  <button class="tab-btn" onclick="showTab('search')">🔎 Search Ranking</button>
  <button class="tab-btn" onclick="showTab('postwriter')">✍️ Post Writer</button>
  <button class="tab-btn" onclick="showTab('settings')">⚙ Settings</button>
</div>

<div class="wrap">
  <?php if ($saved): ?><div class="ok-msg">✓ Settings சேமிக்கப்பட்டது</div><?php endif; ?>

  <!-- ══════════════════ TAB: OVERVIEW ══════════════════ -->
  <div id="tab-overview" class="tab-panel active">

    <!-- Summary cards -->
    <div class="cards">
      <div class="card blue">
        <div class="label">📅 இன்று</div>
        <div class="val"><?= number_format($vToday) ?></div>
        <div class="sub"><?= date('d M Y') ?> · <?= avgTime($ana, $today) ?> சராசரி நேரம்</div>
      </div>
      <div class="card cyan">
        <div class="label">📆 நேற்று</div>
        <div class="val"><?= number_format($vYest) ?></div>
        <div class="sub"><?= date('d M Y', strtotime('-1 day')) ?> · <?= avgTime($ana, $yesterday) ?> சராசரி நேரம்</div>
      </div>
      <div class="card green">
        <div class="label">🗓 இந்த மாதம்</div>
        <div class="val"><?= number_format($vMonth) ?></div>
        <div class="sub"><?= date('F Y') ?> மொத்தம்</div>
      </div>
      <div class="card yellow">
        <div class="label">📊 மொத்தம்</div>
        <div class="val"><?= number_format($vAll) ?></div>
        <div class="sub">All-time views</div>
      </div>
    </div>

    <!-- News / Total visits counter highlight -->
    <div class="news-count-box">
      <div class="news-icon">🗞</div>
      <div class="news-info">
        <h3>மொத்த Visits இன்று</h3>
        <p>அனைத்து பக்கங்களிலும் சேர்ந்த இன்றைய visitors count</p>
      </div>
      <div class="news-val"><?= number_format($vToday) ?></div>
    </div>

    <!-- Chart: last 14 days -->
    <div class="section">
      <h2>📈 கடந்த 14 நாள் Views</h2>
      <?php $maxV = max(max($chartViews), 1); ?>
      <div class="chart-wrap">
        <?php foreach ($chartViews as $i => $cv): ?>
        <div class="bar-col">
          <div class="bar-num"><?= $cv ?: '' ?></div>
          <div class="bar" style="height:<?= round(($cv/$maxV)*130) ?>px" title="<?= $chartDays[$i] ?>: <?= $cv ?>"></div>
          <div class="bar-lbl"><?= $chartDays[$i] ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Custom date filter -->
    <div class="section">
      <h2>🔍 குறிப்பிட்ட தேதி தேடு</h2>
      <form method="get" class="filter-row">
        <input type="date" name="date" value="<?= htmlspecialchars($filterDate) ?>" max="<?= $today ?>">
        <button type="submit">தேடு</button>
        <?php if ($filterDate): ?><a href="admin.php" style="color:#6b7a94;font-size:12px">✕ Clear</a><?php endif; ?>
      </form>
      <?php if ($filterDate && preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterDate)): ?>
      <table>
        <tr><th>தேதி</th><th>Views</th><th>சராசரி நேரம்</th><th>மொத்த நேரம்</th></tr>
        <tr>
          <td><?= htmlspecialchars($filterDate) ?></td>
          <td><span class="badge badge-blue"><?= number_format($vCustom) ?></span></td>
          <td><?= avgTime($ana, $filterDate) ?></td>
          <td><?= fmtSecs($ana['time'][$filterDate] ?? 0) ?></td>
        </tr>
      </table>
      <?php endif; ?>
    </div>

    <!-- Top 10 days -->
    <div class="section">
      <h2>🏆 Top 10 நாட்கள்</h2>
      <?php if (empty($top10)): ?>
        <div class="empty">இன்னும் data இல்லை</div>
      <?php else: ?>
      <table>
        <tr><th>#</th><th>தேதி</th><th>Views</th><th>சராசரி நேரம்</th></tr>
        <?php $rank=1; foreach ($top10 as $d => $v): ?>
        <tr>
          <td style="color:#4b5e78"><?= $rank++ ?></td>
          <td><?= htmlspecialchars($d) ?></td>
          <td><span class="badge badge-blue"><?= number_format($v) ?></span></td>
          <td><?= avgTime($ana, $d) ?></td>
        </tr>
        <?php endforeach; ?>
      </table>
      <?php endif; ?>
    </div>
  </div><!-- /tab-overview -->


  <!-- ══════════════════ TAB: TRAFFIC SOURCES ══════════════════ -->
  <div id="tab-traffic" class="tab-panel">

    <!-- Category summary -->
    <div class="cat-row">
      <?php
        $catPctDirect = $srcTotal ? round($totalDirect*100/$srcTotal,1) : 0;
        $catPctSearch = $srcTotal ? round($totalSearch*100/$srcTotal,1) : 0;
        $catPctSocial = $srcTotal ? round($totalSocial*100/$srcTotal,1) : 0;
        $catPctOther  = $srcTotal ? round($totalOther*100/$srcTotal,1) : 0;
      ?>
      <div class="cat-card direct">
        <div class="cat-icon">➡</div>
        <div class="cat-label">நேரடி வருகை</div>
        <div class="cat-val"><?= number_format($totalDirect) ?></div>
        <div class="cat-pct" style="color:#60a5fa"><?= $catPctDirect ?>%</div>
      </div>
      <div class="cat-card search">
        <div class="cat-icon">🔎</div>
        <div class="cat-label">Search Engine</div>
        <div class="cat-val"><?= number_format($totalSearch) ?></div>
        <div class="cat-pct" style="color:#34d399"><?= $catPctSearch ?>%</div>
      </div>
      <div class="cat-card social">
        <div class="cat-icon">📱</div>
        <div class="cat-label">Social Media</div>
        <div class="cat-val"><?= number_format($totalSocial) ?></div>
        <div class="cat-pct" style="color:#fb923c"><?= $catPctSocial ?>%</div>
      </div>
      <div class="cat-card other2">
        <div class="cat-icon">🌐</div>
        <div class="cat-label">Other Sites</div>
        <div class="cat-val"><?= number_format($totalOther) ?></div>
        <div class="cat-pct" style="color:#a78bfa"><?= $catPctOther ?>%</div>
      </div>
    </div>

    <!-- All-time sources table -->
    <div class="section">
      <h2>🌍 All-time Traffic Sources <?php if($srcTotal): ?><span style="font-size:11px;color:#4b5e78;font-weight:400;text-transform:none;letter-spacing:0">(மொத்தம்: <?= number_format($srcTotal) ?>)</span><?php endif; ?></h2>
      <?php if ($srcTotal === 0): ?>
        <div class="empty">இன்னும் referrer data இல்லை</div>
      <?php else: ?>
        <table>
          <tr><th>Source</th><th>Views</th><th>%</th><th>Graph</th></tr>
          <?php foreach ($srcAll as $s => $n):
            $pct = $srcTotal ? round($n*100/$srcTotal,1) : 0;
            $isSearch = in_array($s, $searchEngines);
            $isDirect = ($s === 'direct');
            $barColor = $isDirect ? '#60a5fa' : ($isSearch ? '#34d399' : '#fb923c');
          ?>
          <tr>
            <td><?= htmlspecialchars($srcLabels[$s] ?? $s) ?></td>
            <td><span class="badge badge-blue"><?= number_format($n) ?></span></td>
            <td style="color:<?= $barColor ?>;font-weight:600"><?= $pct ?>%</td>
            <td style="width:120px">
              <div class="prog-wrap"><div class="prog-bar" style="width:<?= $pct ?>%;background:<?= $barColor ?>"></div></div>
            </td>
          </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>

    <!-- Today sources -->
    <div class="section">
      <h2>📅 இன்றைய Traffic Sources</h2>
      <?php if ($srcTodayTotal === 0): ?>
        <div class="empty">இன்று இன்னும் traffic இல்லை</div>
      <?php else: ?>
        <table>
          <tr><th>Source</th><th>Views</th><th>%</th><th>Graph</th></tr>
          <?php foreach ($srcToday as $s => $n):
            $pct = $srcTodayTotal ? round($n*100/$srcTodayTotal,1) : 0;
            $isSearch = in_array($s, $searchEngines);
            $isDirect = ($s === 'direct');
            $barColor = $isDirect ? '#60a5fa' : ($isSearch ? '#34d399' : '#fb923c');
          ?>
          <tr>
            <td><?= htmlspecialchars($srcLabels[$s] ?? $s) ?></td>
            <td><span class="badge badge-green"><?= number_format($n) ?></span></td>
            <td style="color:<?= $barColor ?>;font-weight:600"><?= $pct ?>%</td>
            <td style="width:120px">
              <div class="prog-wrap"><div class="prog-bar" style="width:<?= $pct ?>%;background:<?= $barColor ?>"></div></div>
            </td>
          </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>
  </div><!-- /tab-traffic -->


  <!-- ══════════════════ TAB: PAGES ══════════════════ -->
  <div id="tab-pages" class="tab-panel">

    <!-- News count highlight -->
    <div class="news-count-box" style="border-color:#6c4fff44">
      <div class="news-icon">📄</div>
      <div class="news-info">
        <h3 style="color:#a78bfa">மொத்த Page Views</h3>
        <p><?= count($pagesAll) ?> வெவ்வேறு பக்கங்கள் track ஆகின்றன</p>
      </div>
      <div class="news-val" style="color:#a78bfa"><?= number_format($pagesTotal) ?></div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <!-- All time pages -->
      <div class="section">
        <h2>📄 All-time Page Views</h2>
        <?php if (empty($pagesAll)): ?>
          <div class="empty">இன்னும் page data இல்லை</div>
        <?php else: ?>
          <table>
            <tr><th>Page</th><th>Views</th><th>%</th></tr>
            <?php foreach ($pagesAll as $pg => $n):
              $pct = $pagesTotal ? round($n*100/$pagesTotal,1) : 0;
            ?>
            <tr>
              <td><?= htmlspecialchars($pageLabels[$pg] ?? $pg) ?></td>
              <td><span class="badge badge-blue"><?= number_format($n) ?></span></td>
              <td>
                <span style="color:#a78bfa"><?= $pct ?>%</span>
                <div class="prog-wrap"><div class="prog-bar" style="width:<?= $pct ?>%;background:#6c4fff"></div></div>
              </td>
            </tr>
            <?php endforeach; ?>
          </table>
        <?php endif; ?>
      </div>

      <!-- Today pages -->
      <div class="section">
        <h2>📅 இன்றைய Page Views</h2>
        <?php $pagesTodayTotal = array_sum($pagesToday); ?>
        <?php if (empty($pagesToday)): ?>
          <div class="empty">இன்று page data இல்லை</div>
        <?php else: ?>
          <table>
            <tr><th>Page</th><th>Views</th><th>%</th></tr>
            <?php foreach ($pagesToday as $pg => $n):
              $pct = $pagesTodayTotal ? round($n*100/$pagesTodayTotal,1) : 0;
            ?>
            <tr>
              <td><?= htmlspecialchars($pageLabels[$pg] ?? $pg) ?></td>
              <td><span class="badge badge-orange"><?= number_format($n) ?></span></td>
              <td>
                <span style="color:#fbbf24"><?= $pct ?>%</span>
                <div class="prog-wrap"><div class="prog-bar" style="width:<?= $pct ?>%;background:#f59e0b"></div></div>
              </td>
            </tr>
            <?php endforeach; ?>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div><!-- /tab-pages -->


  <!-- ══════════════════ TAB: SEARCH RANKING ══════════════════ -->
  <div id="tab-search" class="tab-panel">

    <?php
      $googleViews = $srcAll['google'] ?? 0;
      $bingViews   = $srcAll['bing']   ?? 0;
      $ddgViews    = $srcAll['duckduckgo'] ?? 0;
      $yahooViews  = $srcAll['yahoo']  ?? 0;
      $isRanking   = $googleViews > 0 || $bingViews > 0 || $ddgViews > 0 || $yahooViews > 0;
    ?>

    <!-- Search Rank status -->
    <div class="rank-box">
      <div class="rank-icon"><?= $isRanking ? '🏆' : '⏳' ?></div>
      <div class="rank-info">
        <?php if ($isRanking): ?>
          <div class="rank-title">உங்கள் site Search Engine-ல் Rank ஆகி வருகிறது!</div>
          <div class="rank-sub">மொத்தம் <?= number_format($totalSearch) ?> organic search visitors வந்துள்ளனர் — இது மொத்த traffic-ல் <?= $srcTotal ? round($totalSearch*100/$srcTotal,1) : 0 ?>%</div>
        <?php else: ?>
          <div class="rank-title" style="color:#fbbf24">இன்னும் Search Ranking visitors வரவில்லை</div>
          <div class="rank-sub" style="color:#6b5a20">Google, Bing போன்ற search engine-ல் index ஆகும்போது இங்கே காண்பிக்கப்படும்</div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Per search engine breakdown -->
    <div class="rank-breakdown">
      <?php
        $engines = [
          ['key'=>'google',     'label'=>'🔎 Google',     'color'=>'#34d399'],
          ['key'=>'bing',       'label'=>'🅱 Bing',       'color'=>'#60a5fa'],
          ['key'=>'duckduckgo', 'label'=>'🦆 DuckDuckGo', 'color'=>'#fb923c'],
          ['key'=>'yahoo',      'label'=>'🟣 Yahoo',      'color'=>'#a78bfa'],
        ];
        foreach ($engines as $eng):
          $n   = $srcAll[$eng['key']] ?? 0;
          $pct = $srcTotal ? round($n*100/$srcTotal,1) : 0;
      ?>
      <div class="rank-engine">
        <span style="font-size:13px;color:#9ba9bd"><?= $eng['label'] ?></span>
        <span class="re-val" style="color:<?= $eng['color'] ?>"><?= number_format($n) ?></span>
        <span class="re-pct"><?= $pct ?>%</span>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Google vs Direct vs Social comparison -->
    <div class="section">
      <h2>📊 நேரடி vs Search vs Social — ஒப்பீடு</h2>
      <?php if ($srcTotal === 0): ?>
        <div class="empty">இன்னும் data இல்லை</div>
      <?php else:
        $comparisons = [
          ['label'=>'➡ நேரடி வருகை (Direct)',    'val'=>$totalDirect, 'color'=>'#60a5fa'],
          ['label'=>'🔎 Search Engine Organic',   'val'=>$totalSearch, 'color'=>'#34d399'],
          ['label'=>'📱 Social Media',            'val'=>$totalSocial, 'color'=>'#fb923c'],
          ['label'=>'🌐 Other Websites',          'val'=>$totalOther,  'color'=>'#a78bfa'],
        ];
        usort($comparisons, fn($a,$b) => $b['val'] - $a['val']);
      ?>
        <table>
          <tr><th>வகை</th><th>மொத்தம்</th><th>%</th><th>Graph</th></tr>
          <?php foreach ($comparisons as $row):
            $pct = $srcTotal ? round($row['val']*100/$srcTotal,1) : 0;
          ?>
          <tr>
            <td style="font-weight:600"><?= $row['label'] ?></td>
            <td><span class="badge badge-blue"><?= number_format($row['val']) ?></span></td>
            <td style="color:<?= $row['color'] ?>;font-weight:700"><?= $pct ?>%</td>
            <td style="width:200px">
              <div class="prog-wrap" style="height:10px;border-radius:5px">
                <div class="prog-bar" style="height:10px;border-radius:5px;width:<?= $pct ?>%;background:<?= $row['color'] ?>"></div>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>

    <!-- Today search ranking -->
    <div class="section">
      <h2>📅 இன்று Search Engine வருகை</h2>
      <?php
        $todaySearchTotal = 0;
        foreach ($searchEngines as $e) $todaySearchTotal += ($srcToday[$e] ?? 0);
      ?>
      <?php if ($todaySearchTotal === 0): ?>
        <div class="empty">இன்று search engine வழி யாரும் வரவில்லை</div>
      <?php else: ?>
        <table>
          <tr><th>Search Engine</th><th>Visitors</th><th>%</th></tr>
          <?php foreach ($searchEngines as $e):
            $n = $srcToday[$e] ?? 0;
            if (!$n) continue;
            $pct = $srcTodayTotal ? round($n*100/$srcTodayTotal,1) : 0;
          ?>
          <tr>
            <td><?= $srcLabels[$e] ?></td>
            <td><span class="badge badge-green"><?= number_format($n) ?></span></td>
            <td style="color:#34d399;font-weight:600"><?= $pct ?>%</td>
          </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>
  </div><!-- /tab-search -->


  <!-- ══════════════════ TAB: SETTINGS ══════════════════ -->
  <div id="tab-settings" class="tab-panel">
    <div class="settings-box">
      <h2 style="font-size:13px;color:#9ba9bd;text-transform:uppercase;letter-spacing:1px;margin-bottom:16px">⚙ Settings</h2>
      <form method="post">
        <label>Balloon Password</label>
        <input name="balloonPassword" value="<?= htmlspecialchars($cfg['balloonPassword']) ?>">
        <label>Body Password</label>
        <input name="bodyPassword" value="<?= htmlspecialchars($cfg['bodyPassword']) ?>">
        <label>Home Button URL</label>
        <input name="homeUrl" value="<?= htmlspecialchars($cfg['homeUrl']) ?>">
        <label>🌐 Sphere Template Image URL</label>
        <input name="sphereTemplateUrl" value="<?= htmlspecialchars($cfg['sphereTemplateUrl'] ?? 'sphere-image-template.png') ?>" placeholder="https://yoursite.com/media/sphere-template.png">
        <div style="font-size:11px;color:#6b7a94;margin-top:4px">Host the image on your site's media page, then paste its full URL here.</div>
        <hr class="divider">
        <h3 style="font-size:12px;color:#fbbf24;margin-bottom:8px;text-transform:uppercase;letter-spacing:1px">💳 Paywall Settings</h3>
        <label>Paywall Text (Tamil/English/HTML allowed)</label>
        <textarea name="paywallText" rows="3"><?= htmlspecialchars($cfg['paywallText'] ?? '') ?></textarea>
        <label>Paywall Button Label</label>
        <input name="paywallButtonLabel" value="<?= htmlspecialchars($cfg['paywallButtonLabel'] ?? '') ?>" placeholder="👉 கோர்ஸ் வாங்க">
        <label>Paywall Button URL</label>
        <input name="paywallButtonUrl" value="<?= htmlspecialchars($cfg['paywallButtonUrl'] ?? '') ?>" placeholder="https://yoursite.com/course">
        <label>Paywall Button 2 Label <span style="color:#6b7a94;font-weight:400">(optional)</span></label>
        <input name="paywallButton2Label" value="<?= htmlspecialchars($cfg['paywallButton2Label'] ?? '') ?>" placeholder="👉 மேலும் விவரம்">
        <label>Paywall Button 2 URL</label>
        <input name="paywallButton2Url" value="<?= htmlspecialchars($cfg['paywallButton2Url'] ?? '') ?>" placeholder="https://yoursite.com/info">
        <button name="save" value="1">💾 Save Settings</button>
      </form>
    </div>
  </div><!-- /tab-settings -->

  <!-- ══════════════════ TAB: POST WRITER ══════════════════ -->
  <div id="tab-postwriter" class="tab-panel">
    <div class="pw-grid">

      <!-- LEFT: Form -->
      <div class="pw-form-box">
        <h2>✍️ Post Writer</h2>

        <label class="pw-label">📌 Category</label>
        <select class="pw-select" id="pw-category">
          <option value="lithophane">🎨 Lithophane / 3D Gift</option>
          <option value="3dprint">🖨 3D Printing Tips</option>
          <option value="gift">🎁 Custom Gift Ideas</option>
          <option value="tutorial">📖 Tutorial / How-to</option>
          <option value="product">🛒 Product Description</option>
          <option value="review">⭐ Review / Testimonial</option>
          <option value="festival">🎉 Festival / Occasion</option>
          <option value="general">📝 General Blog</option>
        </select>

        <label class="pw-label">🔑 Main Topic / Keyword (Tamil or English)</label>
        <input class="pw-input" id="pw-topic" type="text" placeholder="எ.கா: Lithophane gift for wedding, 3D print moon lamp..." />

        <label class="pw-label">🌐 Target Language</label>
        <select class="pw-select" id="pw-lang">
          <option value="tamil">தமிழ்</option>
          <option value="english">English</option>
          <option value="both">Tamil + English (bilingual)</option>
        </select>

        <label class="pw-label">📏 Post Length</label>
        <select class="pw-select" id="pw-length">
          <option value="short">Short (300–400 words)</option>
          <option value="medium" selected>Medium (600–800 words)</option>
          <option value="long">Long (1000+ words)</option>
        </select>

        <label class="pw-label">🎯 Post Tone</label>
        <div class="pw-tags">
          <span class="pw-tag sel" data-tone="informative">📚 Informative</span>
          <span class="pw-tag" data-tone="friendly">😊 Friendly</span>
          <span class="pw-tag" data-tone="professional">💼 Professional</span>
          <span class="pw-tag" data-tone="promotional">🔥 Promotional</span>
          <span class="pw-tag" data-tone="storytelling">📖 Storytelling</span>
        </div>

        <label class="pw-label">🔎 SEO Keywords (comma separated)</label>
        <input class="pw-input" id="pw-keywords" type="text" placeholder="எ.கா: lithophane gift, 3d print photo, personalised lamp" />

        <label class="pw-label">📝 Extra Notes (optional)</label>
        <textarea class="pw-textarea" id="pw-notes" rows="3" placeholder="Product price, offer, special points, call-to-action link..."></textarea>

        <button class="pw-btn" id="pw-generate-btn" onclick="generatePost()">
          ✨ Generate SEO Post
        </button>
        <div class="pw-error" id="pw-error"></div>
      </div>

      <!-- RIGHT: Output -->
      <div class="pw-output-box">
        <h2>
          <span>📄 Generated Post</span>
          <span id="pw-copy-area" style="display:none">
            <button class="pw-copy-btn" onclick="copyPost('html')">Copy HTML</button>
            <button class="pw-copy-btn" onclick="copyPost('text')">Copy Text</button>
          </span>
        </h2>

        <div class="pw-placeholder" id="pw-placeholder">
          <span class="big-icon">✍️</span>
          <strong style="color:#4b5e78;font-size:15px">உங்கள் SEO Post இங்கே தயாராகும்</strong><br>
          <span style="color:#2a3a54;font-size:13px">Category, Topic, Keywords கொடுத்து Generate பண்ணுங்கள்</span>
        </div>

        <div class="pw-loading" id="pw-loading">
          <span class="spin">⚙️</span>
          <div style="font-size:14px;color:#6b7a94">AI post எழுதுகிறது...<br><span style="font-size:11px">SEO optimization + formatting சேர்க்கிறது</span></div>
        </div>

        <div class="pw-result" id="pw-result">
          <!-- Sub-tabs: Preview / HTML / SEO -->
          <div class="pw-result-tabs">
            <button class="pw-rtab active" onclick="showRTab('preview', this)">👁 Preview</button>
            <button class="pw-rtab" onclick="showRTab('html-code', this)">🖥 HTML Code</button>
            <button class="pw-rtab" onclick="showRTab('seo', this)">🔎 SEO Check</button>
          </div>

          <!-- Preview -->
          <div class="pw-content-area active" id="rarea-preview">
            <div class="pw-post-preview" id="pw-preview-content"></div>
          </div>

          <!-- HTML Source -->
          <div class="pw-content-area" id="rarea-html-code">
            <textarea id="pw-html-source" class="pw-textarea" rows="20" style="font-family:monospace;font-size:12px;color:#6ee7b7" readonly></textarea>
          </div>

          <!-- SEO Report -->
          <div class="pw-content-area" id="rarea-seo">
            <div class="pw-seo-box" id="pw-seo-content"></div>
          </div>
        </div><!-- /pw-result -->
      </div><!-- /pw-output-box -->

    </div><!-- /pw-grid -->
  </div><!-- /tab-postwriter -->

</div><!-- /wrap -->

<script>
/* ── TAB NAVIGATION ── */
function showTab(id) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + id).classList.add('active');
  event.target.classList.add('active');
}

/* ── TONE TAGS ── */
document.querySelectorAll('.pw-tag').forEach(tag => {
  tag.addEventListener('click', () => {
    document.querySelectorAll('.pw-tag').forEach(t => t.classList.remove('sel'));
    tag.classList.add('sel');
  });
});

/* ── RESULT SUB-TABS ── */
function showRTab(id, btn) {
  document.querySelectorAll('.pw-content-area').forEach(a => a.classList.remove('active'));
  document.querySelectorAll('.pw-rtab').forEach(b => b.classList.remove('active'));
  document.getElementById('rarea-' + id).classList.add('active');
  btn.classList.add('active');
}

/* ── COPY ── */
function copyPost(type) {
  const text = type === 'html'
    ? document.getElementById('pw-html-source').value
    : document.getElementById('pw-preview-content').innerText;
  navigator.clipboard.writeText(text).then(() => {
    const btns = document.querySelectorAll('.pw-copy-btn');
    btns.forEach(b => { const orig = b.textContent; b.textContent = '✓ Copied!'; setTimeout(() => b.textContent = orig, 1500); });
  });
}

/* ── GENERATE POST ── */
async function generatePost() {
  const topic    = document.getElementById('pw-topic').value.trim();
  const category = document.getElementById('pw-category').value;
  const lang     = document.getElementById('pw-lang').value;
  const length   = document.getElementById('pw-length').value;
  const keywords = document.getElementById('pw-keywords').value.trim();
  const notes    = document.getElementById('pw-notes').value.trim();
  const tone     = document.querySelector('.pw-tag.sel')?.dataset.tone || 'informative';

  if (!topic) {
    const errEl = document.getElementById('pw-error');
    errEl.textContent = '⚠️ Topic / Keyword கொடுக்கவும்!';
    errEl.style.display = 'block';
    setTimeout(() => errEl.style.display = 'none', 3000);
    return;
  }

  const btn = document.getElementById('pw-generate-btn');
  btn.disabled = true;
  document.getElementById('pw-placeholder').style.display = 'none';
  document.getElementById('pw-loading').style.display = 'block';
  document.getElementById('pw-result').style.display = 'none';
  document.getElementById('pw-copy-area').style.display = 'none';
  document.getElementById('pw-error').style.display = 'none';

  const catLabels = {
    lithophane:'Lithophane / 3D Gift', '3dprint':'3D Printing Tips',
    gift:'Custom Gift Ideas', tutorial:'Tutorial / How-to',
    product:'Product Description', review:'Review / Testimonial',
    festival:'Festival / Occasion Post', general:'General Blog'
  };

  const lengthMap = { short:'300-400 words', medium:'600-800 words', long:'1000+ words' };

  const langInstruction = {
    tamil: 'Write ENTIRELY in Tamil language (தமிழில் எழுது). Use natural Tamil, not transliteration.',
    english: 'Write entirely in English.',
    both: 'Write as bilingual post: each section first in Tamil, then same section in English below it.'
  }[lang];

  const systemPrompt = `You are an expert SEO content writer specializing in Tamil small businesses, 3D printing, and e-commerce. 
You write blog posts, product descriptions, and marketing content that rank well on Google Search.
You understand Google SEO requirements: proper H1/H2/H3 structure, keyword density 1-2%, meta descriptions, internal linking suggestions, and user intent.
Always respond with valid HTML only — no markdown, no backticks, no explanations outside the HTML.`;

  const userPrompt = `Write an SEO-optimized blog post with these details:

CATEGORY: ${catLabels[category]}
TOPIC / MAIN KEYWORD: ${topic}
TARGET KEYWORDS: ${keywords || topic}
TONE: ${tone}
LENGTH: ${lengthMap[length]}
LANGUAGE: ${langInstruction}
${notes ? 'ADDITIONAL NOTES: ' + notes : ''}

REQUIREMENTS:
1. Start with a compelling <h1> tag containing the main keyword
2. Write a 150-160 character meta description in a <p class="meta-desc"> tag at the very top (before h1), prefixed with "META:" 
3. Use <h2> and <h3> subheadings with secondary keywords naturally
4. Include keyword "${topic}" 3-5 times naturally in the text
5. Add a FAQ section at the end with 3 questions (use <h3> for questions)
6. End with a clear Call-To-Action paragraph with <strong> tags
7. Add SEO score data as an HTML comment at the very end in this exact JSON format:
   <!-- SEO_DATA: {"keyword":"${topic}","wordCount":700,"keywordDensity":"1.5%","headings":5,"hasMeta":true,"hasFAQ":true,"score":88} -->

Format: Clean HTML using <h1>,<h2>,<h3>,<p>,<ul>,<li>,<strong>,<em> tags only. No inline styles.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      })
    });

    const data = await response.json();
    const rawHTML = data.content?.find(b => b.type === 'text')?.text || '';

    if (!rawHTML) throw new Error('No content returned');

    // Extract SEO data from comment
    let seoData = { keyword: topic, wordCount: '?', keywordDensity: '?', headings: '?', hasMeta: false, hasFAQ: false, score: 0 };
    const seoMatch = rawHTML.match(/<!--\s*SEO_DATA:\s*(\{.*?\})\s*-->/s);
    if (seoMatch) {
      try { seoData = { ...seoData, ...JSON.parse(seoMatch[1]) }; } catch(e) {}
    }

    // Clean HTML for display (remove the comment)
    const cleanHTML = rawHTML.replace(/<!--\s*SEO_DATA:.*?-->/s, '').trim();

    // Populate preview
    document.getElementById('pw-preview-content').innerHTML = cleanHTML;

    // Populate HTML source
    document.getElementById('pw-html-source').value = cleanHTML;

    // Build SEO report
    const scoreColor = seoData.score >= 80 ? '#6ee7b7' : seoData.score >= 60 ? '#fbbf24' : '#ff9c9c';
    const scoreClass = seoData.score >= 80 ? 'score-good' : 'score-ok';
    document.getElementById('pw-seo-content').innerHTML = `
      <div class="pw-seo-row">
        <span class="pw-seo-icon">🏆</span>
        <div><div class="pw-seo-label">SEO Score</div>
        <span class="pw-seo-score ${scoreClass}" style="font-size:22px;padding:4px 16px">${seoData.score}/100</span></div>
      </div>
      <div class="pw-seo-row">
        <span class="pw-seo-icon">🔑</span>
        <div><div class="pw-seo-label">Focus Keyword</div><div class="pw-seo-val">${seoData.keyword}</div></div>
      </div>
      <div class="pw-seo-row">
        <span class="pw-seo-icon">📝</span>
        <div><div class="pw-seo-label">Word Count</div><div class="pw-seo-val">${seoData.wordCount} words</div></div>
      </div>
      <div class="pw-seo-row">
        <span class="pw-seo-icon">📊</span>
        <div><div class="pw-seo-label">Keyword Density</div><div class="pw-seo-val">${seoData.keywordDensity} <span style="color:#6b7a94;font-size:11px">(Ideal: 1–2%)</span></div></div>
      </div>
      <div class="pw-seo-row">
        <span class="pw-seo-icon">🗂</span>
        <div><div class="pw-seo-label">Headings (H1/H2/H3)</div><div class="pw-seo-val">${seoData.headings} headings <span class="pw-seo-score score-good">✓ Good</span></div></div>
      </div>
      <div class="pw-seo-row">
        <span class="pw-seo-icon">📋</span>
        <div><div class="pw-seo-label">Meta Description</div><div class="pw-seo-val">
          ${seoData.hasMeta ? '<span class="pw-seo-score score-good">✓ உள்ளது</span>' : '<span class="pw-seo-score score-ok">⚠ இல்லை</span>'}
        </div></div>
      </div>
      <div class="pw-seo-row">
        <span class="pw-seo-icon">❓</span>
        <div><div class="pw-seo-label">FAQ Section</div><div class="pw-seo-val">
          ${seoData.hasFAQ ? '<span class="pw-seo-score score-good">✓ உள்ளது — Featured Snippet வாய்ப்பு</span>' : '<span class="pw-seo-score score-ok">⚠ இல்லை</span>'}
        </div></div>
      </div>
      <div class="pw-seo-row">
        <span class="pw-seo-icon">💡</span>
        <div><div class="pw-seo-label">Google Rank Tips</div>
        <div class="pw-seo-val" style="font-size:12px;line-height:1.7;color:#9ba9bd">
          • இந்த post-ஐ WordPress / Blogger-ல் paste செய்யும்போது Image Alt text சேர்க்கவும்<br>
          • Internal links: உங்கள் மற்ற pages-க்கு link சேர்க்கவும்<br>
          • URL slug: <em style="color:#60a5fa">/lithophane-${topic.toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9-]/g,'').slice(0,30)}</em><br>
          • Publish frequency: வாரம் 2–3 posts = Google ranking boost
        </div></div>
      </div>
    `;

    // Show result
    document.getElementById('pw-loading').style.display = 'none';
    document.getElementById('pw-result').style.display = 'block';
    document.getElementById('pw-copy-area').style.display = 'block';

    // Default to preview tab
    showRTab('preview', document.querySelector('.pw-rtab'));

  } catch (err) {
    document.getElementById('pw-loading').style.display = 'none';
    document.getElementById('pw-placeholder').style.display = 'block';
    const errEl = document.getElementById('pw-error');
    errEl.textContent = '❌ Error: ' + (err.message || 'AI connection failed. Retry.');
    errEl.style.display = 'block';
  }

  btn.disabled = false;
}
</script>


<?php endif; ?>
</body>
</html>
