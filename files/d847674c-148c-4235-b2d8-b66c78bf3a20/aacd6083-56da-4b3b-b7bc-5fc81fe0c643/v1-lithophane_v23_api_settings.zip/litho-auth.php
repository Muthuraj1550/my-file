<?php
/**
 * Single login gate for Lithophane Studio.
 * Balloon + Create Body — rendukkum ithe oru username/password thaan.
 *
 * POST action=login   {username, password}  -> {ok:true, name, product}
 * GET  action=status                        -> {ok:bool, name, product}
 * GET  action=logout                        -> {ok:true}
 */
require_once __DIR__ . '/litho-config.php';

session_start();
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? ($_POST['action'] ?? 'status');

function litho_log_user($username, $name, $product, $source) {
    $file = LITHO_USERS_FILE;
    $all  = is_file($file) ? (json_decode((string)file_get_contents($file), true) ?: []) : [];
    $key  = strtolower($username);
    $now  = date('Y-m-d H:i:s');
    if (!isset($all[$key])) {
        $all[$key] = ['username'=>$username, 'first_login'=>$now, 'logins'=>0];
    }
    $all[$key]['name']       = $name;
    $all[$key]['product']    = $product;
    $all[$key]['source']     = $source;
    $all[$key]['last_login'] = $now;
    $all[$key]['last_ip']    = $_SERVER['REMOTE_ADDR'] ?? '';
    $all[$key]['logins']     = (int)$all[$key]['logins'] + 1;
    @file_put_contents($file, json_encode($all, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

/** Course site la verify pannu (server-to-server, api_key browser ku poga koodathu). */
function course_verify($username, $password) {
    $payload = json_encode([
        'api_key'  => COURSE_API_KEY,
        'site'     => COURSE_SITE_ID,
        'username' => $username,
        'password' => $password,
    ]);
    $ch = curl_init(COURSE_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    if (!$res) return null;
    $j = json_decode($res, true);
    return is_array($j) ? $j : null;
}

if ($action === 'logout') {
    unset($_SESSION['litho_user']);
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'status') {
    $u = $_SESSION['litho_user'] ?? null;
    echo json_encode($u ? ['ok'=>true, 'name'=>$u['name'], 'product'=>$u['product']] : ['ok'=>false]);
    exit;
}

if ($action === 'login') {
    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true) ?: ($_POST + $_GET);
    $username = trim((string)($data['username'] ?? ''));
    $password = (string)($data['password'] ?? '');

    if ($username === '' || $password === '') {
        echo json_encode(['ok'=>false, 'reason'=>'Username and password required']);
        exit;
    }

    // 1) Master login (offline fallback)
    if (hash_equals(MASTER_USER, $username) && hash_equals(MASTER_PASS, $password)) {
        $_SESSION['litho_user'] = ['name'=>'Master', 'product'=>'Master access', 'username'=>$username];
        litho_log_user($username, 'Master', 'Master access', 'master');
        echo json_encode(['ok'=>true, 'name'=>'Master', 'product'=>'Master access']);
        exit;
    }

    // 2) Course site license
    $r = course_verify($username, $password);
    if ($r && !empty($r['valid'])) {
        $name    = $r['user_name'] ?? $username;
        $product = $r['product'] ?? 'Course';
        $_SESSION['litho_user'] = ['name'=>$name, 'product'=>$product, 'username'=>$username];
        litho_log_user($username, $name, $product, 'course');
        echo json_encode(['ok'=>true, 'name'=>$name, 'product'=>$product]);
        exit;
    }

    echo json_encode(['ok'=>false, 'reason'=>$r['reason'] ?? 'Course la login details thavaru (or course vaangala)']);
    exit;
}

echo json_encode(['ok'=>false, 'reason'=>'Unknown action']);
