<?php
/**
 * Lithophane Studio – course-site (my3dgifts) login settings.
 *
 * Ella settings-um `litho-settings.php` page la (browser la) maathalaam —
 * atha `litho-settings.json` la save aagum. Antha file illaina keezha ulla
 * default values use aagum.
 */

define('LITHO_SETTINGS_FILE', __DIR__ . '/litho-settings.json');

function litho_settings() {
    static $s = null;
    if ($s !== null) return $s;
    $defaults = [
        // Course/design site API endpoints
        'api_url'      => 'https://bfdes.my3dgifts.com/api/verify-license.php',
        'users_url'    => 'https://bfdes.my3dgifts.com/api/license-users.php',
        // Course site → Admin → Tool Sites & Access la generate pannuna API key
        'api_key'      => '67afdbf2e7ddf144b533e83d669e9c5279b898c491f30e3e6c9aba145dfd9ed2',
        // Ithu site oda API ID
        'site_id'      => 'litho',
        // Offline / emergency master login (course API down aana kooda work aagum)
        'master_user'  => 'lithomaster',
        'master_pass'  => 'moon3d',
        // litho-users.php / litho-settings.php admin login
        'admin_user'   => 'Adminlitho',
        'admin_pass'   => 'Litho@123',
    ];
    $saved = is_file(LITHO_SETTINGS_FILE)
        ? (json_decode((string)file_get_contents(LITHO_SETTINGS_FILE), true) ?: [])
        : [];
    $s = array_merge($defaults, array_filter($saved, static function ($v) { return $v !== null && $v !== ''; }));
    return $s;
}

function litho_settings_save(array $values) {
    $current = litho_settings();
    $allowed = ['api_url','users_url','api_key','site_id','master_user','master_pass','admin_user','admin_pass'];
    $out = [];
    foreach ($allowed as $k) {
        $out[$k] = isset($values[$k]) && $values[$k] !== '' ? trim((string)$values[$k]) : $current[$k];
    }
    return @file_put_contents(LITHO_SETTINGS_FILE, json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) !== false;
}

$__ls = litho_settings();

define('COURSE_API_URL',   $__ls['api_url']);
define('COURSE_USERS_URL', $__ls['users_url']);
define('COURSE_API_KEY',   $__ls['api_key']);
define('COURSE_SITE_ID',   $__ls['site_id']);

define('MASTER_USER', $__ls['master_user']);
define('MASTER_PASS', $__ls['master_pass']);

// Login pannuna users log
define('LITHO_USERS_FILE', __DIR__ . '/litho-users.json');

define('LITHO_ADMIN_USER', $__ls['admin_user']);
define('LITHO_ADMIN_PASS', $__ls['admin_pass']);
