<?php
/** Lithophane Studio — user list (course licenses + local login log). */
require_once __DIR__ . '/litho-config.php';
session_start();

if (isset($_POST['login'])) {
    if (($_POST['u'] ?? '') === LITHO_ADMIN_USER && ($_POST['p'] ?? '') === LITHO_ADMIN_PASS) $_SESSION['litho_admin'] = true;
    else $err = 'Wrong username / password';
}
if (isset($_GET['logout'])) { unset($_SESSION['litho_admin']); header('Location: litho-users.php'); exit; }

$css = '<style>body{background:#070a12;color:#dde4f0;font-family:system-ui,sans-serif;margin:0;padding:28px}
h1{font-size:20px;margin:0 0 18px}table{width:100%;border-collapse:collapse;font-size:13px;background:#0e1320;border-radius:12px;overflow:hidden}
th,td{padding:10px 12px;border-bottom:1px solid #1e2840;text-align:left}th{background:#131a2b;color:#8fa3c4;font-size:12px}
.box{max-width:380px;margin:80px auto;background:#0e1320;border:1px solid #1e2840;border-radius:14px;padding:26px}
input{width:100%;padding:10px 12px;background:#080c14;border:1px solid #1e2840;border-radius:8px;color:#dde4f0;margin-bottom:10px}
button{padding:10px 16px;background:#6c4fff;border:none;border-radius:8px;color:#fff;font-weight:700;cursor:pointer}
.tag{padding:2px 8px;border-radius:20px;font-size:11px;background:#132c22;color:#34d399}.muted{color:#6b7a94}</style>';

if (empty($_SESSION['litho_admin'])) {
    echo $css . '<div class="box"><h1>🔐 Litho Users</h1>'
       . (isset($err) ? '<div style="color:#f87171;margin-bottom:8px">'.htmlspecialchars($err).'</div>' : '')
       . '<form method="post"><input name="u" placeholder="Username"><input name="p" type="password" placeholder="Password">'
       . '<button name="login" value="1">Login →</button></form></div>';
    exit;
}

// --- Course site la irundhu active license users ---
$remote = [];
$ch = curl_init(COURSE_USERS_URL);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['api_key'=>COURSE_API_KEY, 'site'=>COURSE_SITE_ID]),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
]);
$res = curl_exec($ch); curl_close($ch);
$j = $res ? json_decode($res, true) : null;
if (!empty($j['users'])) $remote = $j['users'];

$local = is_file(LITHO_USERS_FILE) ? (json_decode((string)file_get_contents(LITHO_USERS_FILE), true) ?: []) : [];

echo $css . '<h1>👥 Litho Studio Users <a href="?logout=1" style="float:right;font-size:13px;color:#8fa3c4">Logout</a>'
   . '<a href="litho-settings.php" style="float:right;font-size:13px;color:#38bdf8;margin-right:14px">🔌 API Settings</a></h1>';
echo '<p class="muted" style="font-size:12px">API ID: <b>' . htmlspecialchars(COURSE_SITE_ID) . '</b> — ' . htmlspecialchars(COURSE_USERS_URL) . '</p>';
echo '<h3 style="font-size:15px;margin:18px 0 8px">Course licenses (my3dgifts)</h3>';
if (!$remote) {
    echo '<p class="muted">Course site la irundhu list varala (API URL / key check pannunga).</p>';
} else {
    echo '<table><tr><th>Username</th><th>Name</th><th>Course / Product</th><th>Access sites</th><th>Status</th><th>Created</th><th>Last used</th></tr>';
    foreach ($remote as $u) {
        $prod = $u['product'] ?? '';
        if (is_array($u['products'] ?? null)) $prod = implode(', ', $u['products']);
        $siteList = $u['sites'] ?? ($u['site'] ?? '');
        if (is_array($siteList)) {
            $parts = [];
            foreach ($siteList as $sk => $src) { $parts[] = '<span class="tag" style="background:'.($src==='manual'?'#3a2a12;color:#fbbf24':'#132c22;color:#34d399').'">'.htmlspecialchars($sk).' · '.htmlspecialchars($src).'</span>'; }
            $siteList = implode(' ', $parts);
        } else { $siteList = htmlspecialchars((string)$siteList); }
        echo '<tr><td>'.htmlspecialchars($u['username'] ?? '').'</td><td>'.htmlspecialchars($u['user_name'] ?? '').'</td>'
           . '<td>'.htmlspecialchars($prod).'</td><td>'.$siteList.'</td>'
           . '<td><span class="tag">'.htmlspecialchars($u['status'] ?? '').'</span></td>'
           . '<td class="muted">'.htmlspecialchars($u['created_at'] ?? '').'</td>'
           . '<td class="muted">'.htmlspecialchars($u['last_verified_at'] ?? '-').'</td></tr>';
    }
    echo '</table>';
}

echo '<h3 style="font-size:15px;margin:26px 0 8px">Ithu site la login pannavanga</h3>';
if (!$local) { echo '<p class="muted">Innum yaarum login pannala.</p>'; }
else {
    echo '<table><tr><th>Username</th><th>Name</th><th>Product</th><th>Source</th><th>Logins</th><th>First</th><th>Last</th><th>IP</th></tr>';
    foreach (array_reverse($local) as $u) {
        echo '<tr><td>'.htmlspecialchars($u['username'] ?? '').'</td><td>'.htmlspecialchars($u['name'] ?? '').'</td>'
           . '<td>'.htmlspecialchars($u['product'] ?? '').'</td><td>'.htmlspecialchars($u['source'] ?? '').'</td>'
           . '<td>'.(int)($u['logins'] ?? 0).'</td><td class="muted">'.htmlspecialchars($u['first_login'] ?? '').'</td>'
           . '<td class="muted">'.htmlspecialchars($u['last_login'] ?? '').'</td><td class="muted">'.htmlspecialchars($u['last_ip'] ?? '').'</td></tr>';
    }
    echo '</table>';
}
