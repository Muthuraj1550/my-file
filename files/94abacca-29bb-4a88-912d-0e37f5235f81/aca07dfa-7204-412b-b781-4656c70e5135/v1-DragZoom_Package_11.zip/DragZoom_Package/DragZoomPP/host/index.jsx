// Drag Zoom — host/index.jsx
// Runs inside Premiere Pro's ExtendScript engine (talks to app.project.activeSequence)

// ---------------------------------------------------------------------------
// PIXEL <-> NORMALIZED conversion (the real cause of the black screen).
// Premiere's Motion > Position property is stored NORMALIZED (0..1 of the
// frame) in the scripting DOM, NOT in pixels. Writing a pixel value such as
// 1066.7 overflows Premiere's internal fixed-point range and gets clamped to
// 32767 / -32768 -> the image is thrown far off-frame -> black screen.
// So: everything inside this script works in pixels, and we convert at the
// very last moment before touching Premiere (and right after reading it).
// Reads are heuristic-safe: values with |v| <= 2 are treated as normalized.
// ---------------------------------------------------------------------------
function posToNorm(px, py, frameW, frameH) {
    return [px / frameW, py / frameH];
}
function posToPx(raw, frameW, frameH) {
    if (!raw || raw.length < 2) return null;
    var a = Number(raw[0]), b = Number(raw[1]);
    if (!isFinite(a) || !isFinite(b)) return null;
    if (Math.abs(a) <= 2 && Math.abs(b) <= 2) return [a * frameW, b * frameH]; // normalized
    return [a, b]; // already pixels (older builds)
}

function getSelectedClip(seq) {
    for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var track = seq.videoTracks[t];
        for (var c = 0; c < track.clips.numItems; c++) {
            var clip = track.clips[c];
            try {
                if (clip.isSelected()) { clip.__trackIndex = t; clip.__clipIndex = c; return clip; }
            } catch (e) { /* some items don't implement isSelected, skip */ }
        }
    }
    return null;
}

// An Adjustment Layer (and other synthetic items) has no media file on disk.
function isAdjustmentLayer(clip) {
    try {
        var pi = clip.projectItem;
        if (!pi) return false;
        var mp = "";
        try { mp = String(pi.getMediaPath()); } catch (e) { mp = ""; }
        return (!mp || mp.length === 0);
    } catch (e) { return false; }
}

function findComponent(clip, name) {
    for (var i = 0; i < clip.components.numItems; i++) {
        if (clip.components[i].displayName === name) return clip.components[i];
    }
    return null;
}

function readProps(comp) {
    if (!comp) return null;
    var name = "";
    try { name = String(comp.displayName); } catch (e) { name = ""; }
    var out = { scale: null, position: null, uniform: null, comp: comp, name: name, isTransform: (name === "Transform") };
    for (var j = 0; j < comp.properties.numItems; j++) {
        var p = comp.properties[j];
        if (p.displayName === "Scale") out.scale = p;
        else if (p.displayName === "Position") out.position = p;
        else if (p.displayName === "Uniform Scale") out.uniform = p;
    }
    return (out.scale && out.position) ? out : null;
}

// Tries to drop the built-in "Transform" effect onto the clip through the QE DOM.
function addTransformEffect(clip) {
    try {
        if (typeof app.enableQE === "function") app.enableQE();
        if (typeof qe === "undefined" || !qe.project) return false;
        var qeSeq = qe.project.getActiveSequence();
        if (!qeSeq) return false;
        var qeTrack = qeSeq.getVideoTrackAt(clip.__trackIndex);
        if (!qeTrack) return false;
        var qeClip = qeTrack.getItemAt(clip.__clipIndex);
        if (!qeClip) return false;
        var fx = qe.project.getVideoEffectByName("Transform");
        if (!fx) return false;
        qeClip.addVideoEffect(fx);
        return true;
    } catch (e) { return false; }
}

// Which component do we animate?
//  - normal clip      -> Motion (fastest, GPU accelerated)
//  - adjustment layer -> Transform  (Motion on an adjustment layer does NOT
//    move the footage underneath it — that's why "nothing happened" before)
function findMotionProps(clip) {
    var adj = isAdjustmentLayer(clip);

    if (!adj) {
        var m = readProps(findComponent(clip, "Motion"));
        if (m) return m;
    }

    var t = readProps(findComponent(clip, "Transform"));
    if (t) return t;

    if (adj) {
        if (addTransformEffect(clip)) {
            t = readProps(findComponent(clip, "Transform"));
            if (t) return t;
        }
        return null;
    }

    return readProps(findComponent(clip, "Motion"));
}

// Motion stores Position NORMALIZED (0..1 of the frame).
// The Transform effect stores Position in PIXELS.
// We know which component we're on, so decide from that (deterministic) and
// only fall back to the value heuristic for unknown components.
// UNIT DETECTION (this is the adjustment-layer black-screen bug).
// It is NOT safe to assume "Motion = normalized, Transform = pixels". On many
// builds the Transform effect applied to an Adjustment Layer also exposes its
// Position NORMALIZED (0..1) to the scripting DOM. Writing a pixel value like
// 960 into a normalized property overflows Premiere's fixed-point range and is
// clamped to ~32767 (the "position 30000 + black screen" symptom).
// So we DETECT the unit from the value Premiere actually reports, and we cache
// a correction on the component if a verified write proves us wrong.
function propIsNormalized(motion) {
    if (!motion) return true;
    if (typeof motion.forcedNormalized === "boolean") return motion.forcedNormalized;
    try {
        var v = motion.position.getValue();
        var a = Number(v[0]), b = Number(v[1]);
        if (isFinite(a) && isFinite(b)) {
            // a real pixel position is (roughly) frame-sized; a normalized one is ~0..1
            return (Math.abs(a) <= 2 && Math.abs(b) <= 2);
        }
    } catch (e) { /* fall through */ }
    // last resort only: component-name guess
    return !(motion.isTransform);
}
function flipUnits(motion) {
    motion.forcedNormalized = !propIsNormalized(motion);
}
function posStore(motion, px, py, frameW, frameH) {
    return propIsNormalized(motion) ? [px / frameW, py / frameH] : [px, py];
}
function posRead(motion, raw, frameW, frameH) {
    if (!raw || raw.length < 2) return null;
    var a = Number(raw[0]), b = Number(raw[1]);
    if (!isFinite(a) || !isFinite(b)) return null;
    return propIsNormalized(motion) ? [a * frameW, b * frameH] : [a, b];
}

// Transform's Scale only drives BOTH axes when Uniform Scale is on.
function ensureUniformScale(motion) {
    try {
        if (motion && motion.uniform && motion.uniform.getValue() !== true) {
            motion.uniform.setValue(true, 1);
        }
    } catch (e) { /* not all builds expose it */ }
}

// ---------------------------------------------------------------------------
// CLIP-LOCAL TIME (this is why the keyframes landed in the wrong place).
// Keyframe times on a TrackItem's components are expressed in the CLIP's own
// time base (source time), NOT in sequence time. If the clip doesn't start at
// 00:00 of the sequence, or it was trimmed (inPoint > 0), then writing the raw
// playhead seconds drops the keyframes somewhere else entirely - the values
// change but the animation in Effect Controls looks wrong / empty at the
// playhead. Convert once, here.
// ---------------------------------------------------------------------------
function clipTimeOffset(clip) {
    try {
        return Number(clip.inPoint.seconds) - Number(clip.start.seconds);
    } catch (e) { return 0; }
}
function toClipTime(seconds, offset) {
    var t = new Time();
    t.seconds = seconds + offset;
    return t;
}

// Returns JSON: sequence frame size + current playhead position in seconds
// + the clip's CURRENT Scale/Position, so the panel can show a live-accurate
// starting point (also used defensively on the host side before every apply).
function getSequenceInfo() {
    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, error: "No active sequence. Open a sequence first." });

    var clip = getSelectedClip(seq);
    var playhead = seq.getPlayerPosition();

    var cur = null;
    if (clip) {
        var motion = findMotionProps(clip);
        if (motion && motion.scale && motion.position) {
            try {
                var _fw = Number(seq.frameSizeHorizontal), _fh = Number(seq.frameSizeVertical);
                var _p = posRead(motion, motion.position.getValue(), _fw, _fh);
                cur = { scale: motion.scale.getValue(), position: _p || [_fw / 2, _fh / 2] };
            } catch (e) { cur = null; }
        }
    }

    return JSON.stringify({
        ok: true,
        frameW: Number(seq.frameSizeHorizontal),
        frameH: Number(seq.frameSizeVertical),
        playheadSeconds: playhead.seconds,
        hasSelectedClip: !!clip,
        clipName: clip ? clip.name : null,
        currentScale: cur ? cur.scale : 100,
        currentPosX: cur ? cur.position[0] : Number(seq.frameSizeHorizontal) / 2,
        currentPosY: cur ? cur.position[1] : Number(seq.frameSizeVertical) / 2
    });
}

// ---------------------------------------------------------------------------
// Core fix: the panel's box is drawn on the WYSIWYG preview — i.e. it
// describes a rectangle of the CURRENT on-screen frame, not of the raw
// (100%, centered) source. Earlier versions computed the target Scale/
// Position as if the clip always started at 100% centered, so a SECOND
// zoom on an already-zoomed clip compounded into huge Position values
// (e.g. ~3000) that pushed the image off-frame -> black screen.
//
// Fix: read the clip's CURRENT Scale/Position, project the box back
// through the inverse of that transform to find the equivalent rectangle
// in the clip's original 100%-scale source space, then solve for the
// Scale/Position that makes THAT rectangle fill the frame. This composes
// correctly no matter how many zooms deep you are.
//
// Guarded: if curScale or the box fraction is ever ~0 (bad read, stray
// click, corrupted prior keyframe, etc.) the division below can produce
// Infinity/NaN. Premiere then can't store that in the Position property
// and silently clamps it to -32768 (its int16 "invalid value" sentinel) —
// that's the exact symptom of the black-screen bug. So every input is
// floored to a safe minimum and every output is checked with isFinite()
// before it's ever handed to Premiere.
// ---------------------------------------------------------------------------
function solveTargetTransform(frameW, frameH, curScale, curPosX, curPosY, boxXFrac, boxYFrac, boxWFrac, boxHFrac) {
    // sanitize the "current" state read from Premiere — if it ever comes back
    // missing/zero/NaN, fall back to the safe default (100%, frame center)
    // instead of propagating a division-by-zero downstream.
    if (typeof curScale !== "number" || !isFinite(curScale) || curScale < 1) curScale = 100;
    if (typeof curPosX !== "number" || !isFinite(curPosX)) curPosX = frameW / 2;
    if (typeof curPosY !== "number" || !isFinite(curPosY)) curPosY = frameH / 2;

    // floor the box fractions so width/height can never hit exactly 0
    var MIN_FRAC = 0.02; // 2% of frame — matches the panel's own min box size
    boxWFrac = Math.max(MIN_FRAC, boxWFrac);
    boxHFrac = Math.max(MIN_FRAC, boxHFrac);

    var bx = boxXFrac * frameW, by = boxYFrac * frameH;
    var bw = boxWFrac * frameW, bh = boxHFrac * frameH;
    var bcx = bx + bw / 2, bcy = by + bh / 2;

    var s0 = curScale / 100;
    // box center/size, projected back into the clip's original source space
    var srcCx = frameW / 2 + (bcx - curPosX) / s0;
    var srcCy = frameH / 2 + (bcy - curPosY) / s0;
    var srcW = Math.max(1, bw / s0);
    var srcH = Math.max(1, bh / s0);

    var scaleNew = (frameW / srcW) * 100;
    var dx = srcCx - frameW / 2, dy = srcCy - frameH / 2;
    var posXNew = frameW / 2 - dx * (scaleNew / 100);
    var posYNew = frameH / 2 - dy * (scaleNew / 100);

    // hard cap so a runaway calculation can never reach Premiere's internal
    // Position limits (this is what previously overflowed to -32768)
    var MAX_SCALE = 6000;      // 60x zoom ceiling — already extreme for this use case
    var MAX_POS = Math.max(frameW, frameH) * 4; // bounded, frame-relative pixel range
    scaleNew = Math.min(MAX_SCALE, Math.max(1, scaleNew));
    posXNew = Math.min(MAX_POS, Math.max(-MAX_POS, posXNew));
    posYNew = Math.min(MAX_POS, Math.max(-MAX_POS, posYNew));

    return {
        scale: scaleNew, posX: posXNew, posY: posYNew,
        valid: isFinite(scaleNew) && isFinite(posXNew) && isFinite(posYNew) && scaleNew > 0
    };
}

// Applies a drag-zoom: keyframes Scale + Position on the selected clip's Motion effect.
// boxXFrac/boxYFrac/boxWFrac/boxHFrac: the zoom-target rectangle as FRACTIONS (0..1) of
// the current on-screen frame (this is what makes repeated zooms compose correctly).
//
// Camtasia-style timing: the property you're setting NOW lands exactly AT the
// current playhead (that's "where you parked it, that's what's on screen there").
// A hold keyframe is placed `durationSeconds` BEFORE the playhead, using whatever
// value was ALREADY playing in the timeline at that earlier point (read live via
// getValueAtTime, not assumed) — so the ease-in always matches what the viewer
// already saw, with no jump. 'instant' mode is just this same model with a
// near-zero duration (one frame), giving a hard pop/cut instead of a ramp.
function applyDragZoom(boxXFrac, boxYFrac, boxWFrac, boxHFrac, durationSeconds, mode) {
    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, error: "No active sequence." });

    var clip = getSelectedClip(seq);
    if (!clip) return JSON.stringify({ ok: false, error: "Select a clip on the timeline first." });

    var motion = findMotionProps(clip);
    if (!motion || !motion.scale || !motion.position) {
        return JSON.stringify({ ok: false, error: "No usable transform on this clip. If it's an Adjustment Layer, drag the Effects > Distort > Transform effect onto it once, then try again." });
    }

    try {
        var frameW = Number(seq.frameSizeHorizontal), frameH = Number(seq.frameSizeVertical);

        ensureUniformScale(motion);

        // sequence seconds -> clip-local seconds (see clipTimeOffset above)
        var tOff = clipTimeOffset(clip);
        var playheadSec = seq.getPlayerPosition().seconds;
        var endTime = toClipTime(playheadSec, tOff);

        // frame duration, in seconds — the floor for how close start/end can be
        var frameSeconds = 1 / 30;
        try {
            if (seq.videoFrameRate && typeof seq.videoFrameRate.seconds === "number" && seq.videoFrameRate.seconds > 0) {
                frameSeconds = seq.videoFrameRate.seconds;
            }
        } catch (e) { /* keep default */ }

        var dur = (mode === 'instant') ? frameSeconds : Math.max(frameSeconds, Number(durationSeconds));
        var clipStartSec = 0;
        try { clipStartSec = Number(clip.inPoint.seconds); } catch (e) { clipStartSec = 0; }
        var startTime = new Time();
        startTime.seconds = Math.max(clipStartSec, endTime.seconds - dur);
        // if the playhead sits right at the head of the clip there is no room for
        // a ramp before it — nudge the end forward so the two keys never collapse
        // onto the same instant (which is what left Effect Controls with a single,
        // useless keyframe).
        if (endTime.seconds - startTime.seconds < frameSeconds * 0.5) {
            endTime = toClipTime(playheadSec, tOff);
            startTime.seconds = endTime.seconds - frameSeconds;
            if (startTime.seconds < clipStartSec) {
                startTime.seconds = clipStartSec;
                endTime.seconds = clipStartSec + Math.max(frameSeconds, dur);
            }
        }

        // read the CURRENT on-screen transform (at the playhead, before this edit) —
        // this is what the panel's box was drawn against, so it's what we invert
        // against to solve the new target.
        var startScale = motion.scale.getValue();
        if (typeof startScale !== "number" || !isFinite(startScale) || startScale <= 0) startScale = 100;

        var curPos = posRead(motion, motion.position.getValue(), frameW, frameH) || [frameW / 2, frameH / 2];

        var target = solveTargetTransform(
            frameW, frameH, startScale, curPos[0], curPos[1],
            boxXFrac, boxYFrac, boxWFrac, boxHFrac
        );

        if (!target.valid) {
            return JSON.stringify({ ok: false, error: "Zoom math produced an invalid value — nothing was changed. Try Reset, then adjust the box again." });
        }

        // the "hold" value at startTime: whatever was ALREADY in the timeline there,
        // read before we touch anything. If that time is before any keyframes exist
        // (e.g. very start of the clip / no prior animation), this correctly falls
        // back to the same static current value.
        var holdScale = startScale, holdPos = curPos;
        try {
            var s = motion.scale.getValueAtTime(startTime);
            if (typeof s === "number" && isFinite(s) && s > 0) holdScale = s;
        } catch (e) { /* keep current value */ }
        try {
            var p = posRead(motion, motion.position.getValueAtTime(startTime), frameW, frameH);
            if (p) holdPos = p;
        } catch (e) { /* keep current value */ }

        if (!motion.scale.isTimeVarying()) motion.scale.setTimeVarying(true);
        if (!motion.position.isTimeVarying()) motion.position.setTimeVarying(true);

        // Re-applying at the SAME playhead (e.g. trying a few presets/handle drags
        // in a row without moving the playhead) means startTime/endTime land on the
        // exact same two instants every time. Writing straight over an existing
        // keyframe at that instant is where Premiere's scripting API has been seen
        // to corrupt the value (the -32768 sentinel). So clear anything sitting
        // exactly at these two times first, THEN write clean keyframes.
        function clearKeyAt(prop, t) {
            try { prop.removeKey(t); } catch (e) { /* no key there — fine */ }
        }
        clearKeyAt(motion.scale, startTime);
        clearKeyAt(motion.position, startTime);
        clearKeyAt(motion.scale, endTime);
        clearKeyAt(motion.position, endTime);

        motion.scale.addKey(startTime);
        motion.scale.setValueAtKey(startTime, holdScale, 1);
        motion.position.addKey(startTime);
        motion.position.setValueAtKey(startTime, posStore(motion, holdPos[0], holdPos[1], frameW, frameH), 1);

        motion.scale.addKey(endTime);
        motion.scale.setValueAtKey(endTime, target.scale, 1);
        motion.position.addKey(endTime);
        motion.position.setValueAtKey(endTime, posStore(motion, target.posX, target.posY, frameW, frameH), 1);

        // Give the ramp a real ease so Effect Controls shows proper bezier
        // keyframes instead of raw linear ticks (best effort: some property
        // types reject the call, which is harmless).
        if (mode !== 'instant') {
            var EASE = 5; // kfInterpMode Bezier / ease
            var props = [motion.scale, motion.position];
            for (var pi2 = 0; pi2 < props.length; pi2++) {
                try { props[pi2].setInterpolationTypeAtKey(startTime, EASE, 1); } catch (e) {}
                try { props[pi2].setInterpolationTypeAtKey(endTime, EASE, 1); } catch (e) {}
            }
        }

        // Verify what actually landed in Premiere before reporting success — if the
        // scripting API silently clamped/corrupted the value (the -32768 symptom),
        // catch it here instead of leaving a black-screen keyframe behind.
        var TOLERANCE = 5;
        var writtenPos = null, writtenScale = null;
        function readBackPos() {
            try { return posRead(motion, motion.position.getValueAtTime(endTime), frameW, frameH); } catch (e) { return null; }
        }
        function posMatches(wp) {
            return wp && Math.abs(wp[0] - target.posX) < TOLERANCE && Math.abs(wp[1] - target.posY) < TOLERANCE;
        }

        writtenPos = readBackPos();
        // If the value came back clamped/huge (Premiere's overflow sentinel) or
        // simply wrong, our unit guess for this property was inverted. Flip the
        // unit once and rewrite the two Position keys — this is what rescues the
        // Transform-on-Adjustment-Layer case instead of leaving a black frame.
        if (!posMatches(writtenPos)) {
            flipUnits(motion);
            try {
                clearKeyAt(motion.position, startTime);
                clearKeyAt(motion.position, endTime);
                motion.position.addKey(startTime);
                motion.position.setValueAtKey(startTime, posStore(motion, holdPos[0], holdPos[1], frameW, frameH), 1);
                motion.position.addKey(endTime);
                motion.position.setValueAtKey(endTime, posStore(motion, target.posX, target.posY, frameW, frameH), 1);
                if (mode !== 'instant') {
                    try { motion.position.setInterpolationTypeAtKey(startTime, 5, 1); } catch (e) {}
                    try { motion.position.setInterpolationTypeAtKey(endTime, 5, 1); } catch (e) {}
                }
            } catch (e) { /* handled by the check below */ }
            writtenPos = readBackPos();
            if (!posMatches(writtenPos)) flipUnits(motion); // restore previous assumption
        }
        try { writtenScale = motion.scale.getValueAtTime(endTime); } catch (e) {}
        var posOk = posMatches(writtenPos);
        var scaleOk = typeof writtenScale === "number" && Math.abs(writtenScale - target.scale) < TOLERANCE;

        if ((writtenPos !== null && !posOk) || (writtenScale !== null && !scaleOk)) {
            // something wrote a bad value — undo by resetting this clip's motion so
            // it never plays back black, and tell the user plainly what happened.
            try {
                motion.scale.setTimeVarying(false);
                motion.position.setTimeVarying(false);
                motion.scale.setValue(100, 1);
                motion.position.setValue(posStore(motion, frameW / 2, frameH / 2, frameW, frameH), 1);
            } catch (e) { /* best effort */ }
            return JSON.stringify({ ok: false, error: "Premiere rejected the keyframe value and it was rolled back to avoid a black frame. Try moving the playhead slightly and applying again." });
        }

        return JSON.stringify({ ok: true, scale: target.scale, posX: target.posX, posY: target.posY });
    } catch (e) {
        return JSON.stringify({ ok: false, error: String(e) });
    }
}

// Exports a still of the CURRENT PLAYHEAD FRAME to a temp PNG so the panel can show it
// as the drag-zoom background (uses the QE/"Quality Engineering" DOM — undocumented but
// widely used by third-party panels for frame grabs; wrapped so it fails gracefully).
function exportCurrentFramePNG() {
    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, error: "No active sequence." });

    var destFile = new File(Folder.temp.fsName + "/dragzoom_frame_" + new Date().getTime() + ".png");
    try {
        if (typeof app.enableQE === "function") app.enableQE();
        if (typeof qe === "undefined" || !qe.project) {
            return JSON.stringify({ ok: false, error: "Frame preview needs the QE DOM, which isn't available in this Premiere build. Use Sync instead." });
        }
        var qeSeq = qe.project.getActiveSequence();
        var t = seq.getPlayerPosition();
        qeSeq.exportFramePNG(t.seconds, destFile.fsName, 0, 0);
        if (destFile.exists) {
            return JSON.stringify({ ok: true, path: destFile.fsName });
        }
        return JSON.stringify({ ok: false, error: "Export ran but no file was written." });
    } catch (e) {
        return JSON.stringify({ ok: false, error: "Frame preview isn't supported on this Premiere version (" + String(e) + ")." });
    }
}

// Removes all keyframes and resets Scale/Position to default (100%, frame center) on the selected clip
function resetMotion(frameW, frameH) {
    var seq = app.project.activeSequence;
    if (!seq) return JSON.stringify({ ok: false, error: "No active sequence." });

    var clip = getSelectedClip(seq);
    if (!clip) return JSON.stringify({ ok: false, error: "Select a clip on the timeline first." });

    var motion = findMotionProps(clip);
    if (!motion) return JSON.stringify({ ok: false, error: "No usable transform on this clip. If it's an Adjustment Layer, drag the Effects > Distort > Transform effect onto it once, then try again." });

    try {
        if (motion.scale.isTimeVarying()) motion.scale.setTimeVarying(false);
        if (motion.position.isTimeVarying()) motion.position.setTimeVarying(false);
        motion.scale.setValue(100, 1);
        var _fw = Number(seq.frameSizeHorizontal), _fh = Number(seq.frameSizeVertical);
        motion.position.setValue(posStore(motion, _fw / 2, _fh / 2, _fw, _fh), 1);
        return JSON.stringify({ ok: true });
    } catch (e) {
        return JSON.stringify({ ok: false, error: String(e) });
    }
}
