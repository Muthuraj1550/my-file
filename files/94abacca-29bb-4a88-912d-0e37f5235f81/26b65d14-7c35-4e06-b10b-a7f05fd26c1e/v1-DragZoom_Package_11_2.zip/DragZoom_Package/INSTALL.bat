@echo off
setlocal
title Drag Zoom - Installer
echo ==========================================
echo   Drag Zoom - Installer
echo   for Adobe Premiere Pro
echo ==========================================
echo.

set "SRC=%~dp0DragZoomPP"
set "DEST=%APPDATA%\Adobe\CEP\extensions\DragZoomPP"

if not exist "%SRC%\CSXS\manifest.xml" (
  echo [ERROR] DragZoomPP folder kaanom.
  echo Zip-a MUZHUSA extract pannitu, apparam INSTALL.bat run pannunga.
  echo.
  pause
  exit /b 1
)

echo [1/4] Premiere Pro moodirukka nu paarkuren...
tasklist /FI "IMAGENAME eq Adobe Premiere Pro.exe" 2>nul | find /I "Adobe Premiere Pro.exe" >nul
if not errorlevel 1 (
  echo.
  echo [!] Premiere Pro open-a irukku. Mudhalla adha close pannunga.
  echo     Close pannitu inga enter adikkunga.
  pause
)

echo [2/4] Pazhaya version-a remove panren...
if exist "%DEST%" rmdir /S /Q "%DEST%"

echo [3/4] Files copy panren...
mkdir "%DEST%" >nul 2>&1
xcopy "%SRC%\*" "%DEST%\" /E /I /Y /Q >nul
if not exist "%DEST%\CSXS\manifest.xml" (
  echo [ERROR] Copy fail aachu.
  pause
  exit /b 1
)

echo [4/4] Unsigned extension-a allow panren (PlayerDebugMode)...
for %%V in (9 10 11 12 13 14) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v LogLevel /t REG_SZ /d 1 /f >nul 2>&1
)

echo.
echo ==========================================
echo   INSTALL MUDINCHUDUCHU!
echo ==========================================
echo Install location:
echo   %DEST%
echo.
echo Ippo:
echo   1. Premiere Pro open pannunga
echo   2. Window ^> Extensions ^> Drag Zoom
echo.
pause
