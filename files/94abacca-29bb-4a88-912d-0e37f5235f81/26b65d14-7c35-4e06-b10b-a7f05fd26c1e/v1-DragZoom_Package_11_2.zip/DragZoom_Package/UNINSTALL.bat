@echo off
setlocal
title Drag Zoom - Uninstaller
set "DEST=%APPDATA%\Adobe\CEP\extensions\DragZoomPP"
echo Premiere Pro-va close pannitu enter adikkunga.
pause
if exist "%DEST%" (
  rmdir /S /Q "%DEST%"
  echo Remove aachu: %DEST%
) else (
  echo Install-e illa.
)
echo.
pause
