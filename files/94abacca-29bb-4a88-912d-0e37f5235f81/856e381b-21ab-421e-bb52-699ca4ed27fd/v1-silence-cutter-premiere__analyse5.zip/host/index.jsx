/**
 * Silence Cutter - ExtendScript host for Adobe Premiere Pro
 *
 * Premiere 25+/26 removed the ExtendScript `system` object, so FFmpeg is run
 * from the panel's Node.js runtime (client/main.js). This host only reads
 * clip info and edits the timeline. Every entry point returns a STRING and
 * never throws.
 */

var SC_TICKS_PER_SECOND = 254016000000;

function SC_err(e) {
  var msg = "";
  try { msg = String(e && e.message ? e.message : e); } catch (x) { msg = "unknown"; }
  var line = "";
  try { if (e && e.line) line = " (line " + e.line + ")"; } catch (x) {}
  return "ERROR: " + msg + line;
}

function SC_ping() {
  try {
    return "Host OK - " + app.version + " / " + $.os;
  } catch (e) {
    return SC_err(e);
  }
}

function SC_extRoot() {
  return new File($.fileName).parent.parent.fsName;
}

/** Path of a bundled ffmpeg binary, or "" when none is shipped. */
function SC_bundledFfmpeg() {
  try {
    var root = SC_extRoot();
    var win = new File(root + "/bin/ffmpeg.exe");
    if (win.exists) return win.fsName;
    var nix = new File(root + "/bin/ffmpeg");
    if (nix.exists) return nix.fsName;
  } catch (e) {}
  return "";
}

function SC_activeSequence() {
  return app.project.activeSequence;
}

/** First selected clip, else first clip on the lowest populated track. */
function SC_pickClip(seq) {
  var i, j, track;
  for (i = 0; i < seq.videoTracks.numTracks; i++) {
    track = seq.videoTracks[i];
    for (j = 0; j < track.clips.numItems; j++) {
      if (track.clips[j].isSelected()) return track.clips[j];
    }
  }
  for (i = 0; i < seq.audioTracks.numTracks; i++) {
    track = seq.audioTracks[i];
    for (j = 0; j < track.clips.numItems; j++) {
      if (track.clips[j].isSelected()) return track.clips[j];
    }
  }
  for (i = 0; i < seq.videoTracks.numTracks; i++) {
    track = seq.videoTracks[i];
    if (track.clips.numItems > 0) return track.clips[0];
  }
  for (i = 0; i < seq.audioTracks.numTracks; i++) {
    track = seq.audioTracks[i];
    if (track.clips.numItems > 0) return track.clips[0];
  }
  return null;
}

function SC_mediaPath(clip) {
  var p = null;
  try {
    var proj = clip.projectItem;
    if (proj) {
      try { p = proj.getMediaPath(); } catch (e) {}
      if (!p) { try { p = proj.getFilePath ? proj.getFilePath() : null; } catch (e2) {} }
    }
  } catch (e3) {}
  return p;
}

function SC_seconds(t) {
  if (t === undefined || t === null) return 0;
  try {
    if (t.ticks !== undefined && t.ticks !== null) return parseFloat(t.ticks) / SC_TICKS_PER_SECOND;
  } catch (e) {}
  try { return parseFloat(t.seconds); } catch (e2) {}
  return 0;
}

function SC_fps(seq) {
  try {
    var s = seq.getSettings();
    if (s && s.videoFrameRate) {
      var ticks = parseFloat(s.videoFrameRate.ticks);
      if (ticks > 0) return SC_TICKS_PER_SECOND / ticks;
    }
  } catch (e) {}
  try {
    var qeS = qe.project.getActiveSequence();
    if (qeS && qeS.getFrameRate) {
      var fr = parseFloat(qeS.getFrameRate());
      if (fr > 0) return fr;
    }
  } catch (e2) {}
  return 30;
}

function SC_jsonEscape(s) {
  return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

/** Everything the panel needs to run FFmpeg and map results back. */
function SC_getClipInfo() {
  try {
    var seq = SC_activeSequence();
    if (!seq) return '{"error":"No active sequence. Open a sequence first."}';

    var clip = SC_pickClip(seq);
    if (!clip) return '{"error":"No clip found on the timeline."}';

    var mediaPath = SC_mediaPath(clip);
    if (!mediaPath) return '{"error":"Could not resolve the clip\'s media file (synthetic clip?)."}';
    if (!new File(mediaPath).exists) return '{"error":"Media file is offline: ' + SC_jsonEscape(mediaPath) + '"}';

    return (
      '{"mediaPath":"' + SC_jsonEscape(mediaPath) + '",' +
      '"ffmpeg":"' + SC_jsonEscape(SC_bundledFfmpeg()) + '",' +
      '"clipStart":' + SC_seconds(clip.start) + "," +
      '"inPoint":' + SC_seconds(clip.inPoint) + "," +
      '"clipEnd":' + SC_seconds(clip.end) + "," +
      '"fps":' + SC_fps(seq) + "}"
    );
  } catch (e) {
    return '{"error":"' + SC_jsonEscape(SC_err(e)) + '"}';
  }
}

/** In/out point of the active sequence, in seconds. */
function SC_seqInOut(seq) {
  var inSec = null, outSec = null;
  try { if (seq.getInPointAsTime) inSec = SC_seconds(seq.getInPointAsTime()); } catch (e) {}
  try { if (seq.getOutPointAsTime) outSec = SC_seconds(seq.getOutPointAsTime()); } catch (e) {}
  if (inSec === null || isNaN(inSec)) { try { inSec = parseFloat(seq.getInPoint()); } catch (e) {} }
  if (outSec === null || isNaN(outSec)) { try { outSec = parseFloat(seq.getOutPoint()); } catch (e) {} }
  return { start: inSec, end: outSec };
}

/** Clip that covers a given sequence time, on any track. */
function SC_clipAt(seq, timeSec) {
  var i, j, t, c;
  for (i = 0; i < seq.audioTracks.numTracks; i++) {
    t = seq.audioTracks[i];
    for (j = 0; j < t.clips.numItems; j++) {
      c = t.clips[j];
      if (SC_seconds(c.start) <= timeSec && SC_seconds(c.end) > timeSec) return c;
    }
  }
  for (i = 0; i < seq.videoTracks.numTracks; i++) {
    t = seq.videoTracks[i];
    for (j = 0; j < t.clips.numItems; j++) {
      c = t.clips[j];
      if (SC_seconds(c.start) <= timeSec && SC_seconds(c.end) > timeSec) return c;
    }
  }
  return null;
}

/**
 * Maps the sequence in/out range onto the underlying media file, so the panel
 * can measure the loudness of a range the user marked as "silent".
 */
function SC_getRangeInfo() {
  try {
    var seq = SC_activeSequence();
    if (!seq) return '{"error":"No active sequence. Open a sequence first."}';

    var io = SC_seqInOut(seq);
    if (io.start === null || io.end === null || isNaN(io.start) || isNaN(io.end) || io.end - io.start <= 0.02) {
      return '{"error":"Mark an In and Out point on the timeline over a part where nobody is speaking, then try again."}';
    }

    var mid = (io.start + io.end) / 2;
    var clip = SC_clipAt(seq, mid);
    if (!clip) return '{"error":"No clip found inside the In/Out range."}';

    var mediaPath = SC_mediaPath(clip);
    if (!mediaPath) return '{"error":"Could not resolve the clip\'s media file (synthetic clip?)."}';
    if (!new File(mediaPath).exists) return '{"error":"Media file is offline: ' + SC_jsonEscape(mediaPath) + '"}';

    var clipStart = SC_seconds(clip.start);
    var clipEnd = SC_seconds(clip.end);
    var inPoint = SC_seconds(clip.inPoint);

    var s = io.start < clipStart ? clipStart : io.start;
    var e = io.end > clipEnd ? clipEnd : io.end;
    if (e - s <= 0.02) return '{"error":"The In/Out range does not overlap a clip."}';

    return (
      '{"mediaPath":"' + SC_jsonEscape(mediaPath) + '",' +
      '"ffmpeg":"' + SC_jsonEscape(SC_bundledFfmpeg()) + '",' +
      '"mediaStart":' + (inPoint + (s - clipStart)) + "," +
      '"duration":' + (e - s) + "," +
      '"seqStart":' + s + "," +
      '"seqEnd":' + e + "}"
    );
  } catch (e) {
    return '{"error":"' + SC_jsonEscape(SC_err(e)) + '"}';
  }
}

function SC_pad2(n) { return (n < 10 ? "0" : "") + n; }

/** HH:MM:SS:FF without relying on Time.getFormatted. */
function SC_timecode(sec, fps) {
  if (sec < 0) sec = 0;
  var fpsInt = Math.round(fps);
  if (fpsInt < 1) fpsInt = 1;
  var totalFrames = Math.round(sec * fps);
  var frames = totalFrames % fpsInt;
  var totalSeconds = Math.floor(totalFrames / fpsInt);
  var s = totalSeconds % 60;
  var m = Math.floor(totalSeconds / 60) % 60;
  var h = Math.floor(totalSeconds / 3600);
  return SC_pad2(h) + ":" + SC_pad2(m) + ":" + SC_pad2(s) + ":" + SC_pad2(frames);
}

/** cutsJson: {"fps":30,"ripple":true,"cuts":[{"start":1.2,"end":2.4}, ...]} */
function SC_applyCuts(cutsJson) {
  try {
    return SC_applyCutsInner(cutsJson);
  } catch (e) {
    return SC_err(e);
  }
}

function SC_applyCutsInner(cutsJson) {
  var data;
  try { data = eval("(" + cutsJson + ")"); } catch (err) { return "Bad cut data."; }
  var cuts = data.cuts || [];
  if (!cuts.length) return "Nothing to cut.";

  var seq = SC_activeSequence();
  if (!seq) return "No active sequence.";
  var fps = data.fps || SC_fps(seq);

  try { app.enableQE(); } catch (e) { return "Could not enable QE scripting: " + SC_err(e); }
  var qeSeq = qe.project.getActiveSequence();
  if (!qeSeq) return "QE could not read the active sequence.";

  var razorFails = 0;
  for (var c = cuts.length - 1; c >= 0; c--) {
    if (!SC_razor(qeSeq, SC_timecode(cuts[c].end, fps))) razorFails++;
    if (!SC_razor(qeSeq, SC_timecode(cuts[c].start, fps))) razorFails++;
  }
  if (razorFails === cuts.length * 2) return "Could not cut the timeline (razor failed at every point).";

  var removed = 0;
  for (var k = cuts.length - 1; k >= 0; k--) {
    var mid = (cuts[k].start + cuts[k].end) / 2;
    if (SC_removeAt(seq, mid, data.ripple)) removed++;
  }

  return "Done. Removed " + removed + " of " + cuts.length + " silent segments.";
}

/** Razor across all tracks; falls back to per-track razor on older builds. */
function SC_razor(qeSeq, tc) {
  try { qeSeq.razor(tc); return true; } catch (e) {}
  try {
    var i;
    for (i = 0; i < qeSeq.numVideoTracks; i++) qeSeq.getVideoTrackAt(i).razor(tc);
    for (i = 0; i < qeSeq.numAudioTracks; i++) qeSeq.getAudioTrackAt(i).razor(tc);
    return true;
  } catch (e2) {
    return false;
  }
}

function SC_removeAt(seq, timeSec, ripple) {
  var done = false;
  var i, j;
  for (i = 0; i < seq.videoTracks.numTracks; i++) {
    var vt = seq.videoTracks[i];
    for (j = vt.clips.numItems - 1; j >= 0; j--) {
      var c = vt.clips[j];
      if (SC_seconds(c.start) <= timeSec && SC_seconds(c.end) > timeSec) {
        try { c.remove(ripple, true); done = true; } catch (e) {}
        break;
      }
    }
  }
  for (i = 0; i < seq.audioTracks.numTracks; i++) {
    var at = seq.audioTracks[i];
    for (j = at.clips.numItems - 1; j >= 0; j--) {
      var ac = at.clips[j];
      if (SC_seconds(ac.start) <= timeSec && SC_seconds(ac.end) > timeSec) {
        try { ac.remove(ripple, true); done = true; } catch (e2) {}
        break;
      }
    }
  }
  return done;
}
