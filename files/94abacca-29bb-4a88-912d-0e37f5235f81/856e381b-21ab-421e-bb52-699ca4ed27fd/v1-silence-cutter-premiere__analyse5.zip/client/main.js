/**
 * Silence Cutter - panel logic.
 *
 * FFmpeg runs here in the panel's Node.js runtime (CEP --enable-nodejs),
 * because Premiere 25+/26 removed ExtendScript's `system.callSystem`.
 */

var cs = new CSInterface();
var logEl = document.getElementById("log");

var nodeChildProcess = null;
try { nodeChildProcess = require("child_process"); } catch (e) { nodeChildProcess = null; }

function log(msg) {
  logEl.textContent += "\n" + msg;
  logEl.scrollTop = logEl.scrollHeight;
}

function clearLog(msg) {
  logEl.textContent = msg || "";
}

function setBusy(busy) {
  document.getElementById("run").disabled = busy;
  document.getElementById("check").disabled = busy;
  document.getElementById("auto").disabled = busy;
}

/** Call the host and surface real errors instead of "EvalScript error." */
function callHost(call, cb) {
  var wrapped = "(function(){try{return " + call + ";}catch(e){return 'ERROR: '+e;}})()";
  cs.evalScript(wrapped, function (res) {
    if (res === undefined || res === "EvalScript error." || res === "EvalScript error") {
      cb(
        "EvalScript error - the host script did not load.\n" +
          "Check that host/index.jsx sits next to CSXS/manifest.xml in the installed folder, " +
          "then restart Premiere Pro."
      );
      return;
    }
    cb(res);
  });
}

function quote(p) {
  return '"' + String(p).replace(/"/g, '\\"') + '"';
}

/** Run ffmpeg via Node. cb(errorStringOrNull, combinedOutput) */
function runFfmpeg(ffmpegPath, args, cb) {
  if (!nodeChildProcess) {
    cb(
      "Node.js is not enabled for this panel. Reinstall with the updated manifest " +
        "(it needs --enable-nodejs) and restart Premiere Pro."
    );
    return;
  }
  var exe = ffmpegPath ? quote(ffmpegPath) : "ffmpeg";
  nodeChildProcess.exec(
    exe + " " + args,
    { maxBuffer: 40 * 1024 * 1024, windowsHide: true },
    function (err, stdout, stderr) {
      var out = (stdout || "") + (stderr || "");
      if (err && !out) {
        cb(
          "FFmpeg could not be started. Install FFmpeg and add it to PATH, or drop " +
            "ffmpeg.exe into the extension's bin folder. (" + err.message + ")"
        );
        return;
      }
      cb(null, out);
    }
  );
}

function parseSilence(text) {
  var ranges = [];
  var lines = text.split("\n");
  var start = null;
  for (var i = 0; i < lines.length; i++) {
    var s = lines[i].match(/silence_start:\s*(-?[0-9.]+)/);
    if (s) { start = parseFloat(s[1]); continue; }
    var e = lines[i].match(/silence_end:\s*(-?[0-9.]+)/);
    if (e && start !== null) {
      ranges.push({ start: start, end: parseFloat(e[1]) });
      start = null;
    }
  }
  return ranges;
}

document.getElementById("check").addEventListener("click", function () {
  clearLog("Checking host, Node and FFmpeg...");
  setBusy(true);
  callHost("SC_ping()", function (ping) {
    log(ping);
    log(nodeChildProcess ? "Node runtime OK." : "Node runtime MISSING (--enable-nodejs).");
    callHost("SC_bundledFfmpeg()", function (bundled) {
      var ffmpegPath = bundled && bundled.indexOf("ERROR") !== 0 ? bundled : "";
      log(ffmpegPath ? "Using bundled FFmpeg: " + ffmpegPath : "Using FFmpeg from PATH.");
      runFfmpeg(ffmpegPath, "-version", function (err, out) {
        setBusy(false);
        if (err) { log(err); return; }
        var first = (out || "").split("\n")[0];
        log(first.indexOf("ffmpeg version") === 0 ? "OK - " + first : "FFmpeg not found on PATH.");
      });
    });
  });
});

document.getElementById("run").addEventListener("click", function () {
  var threshold = parseFloat(document.getElementById("threshold").value);
  var minLen = parseFloat(document.getElementById("minlen").value);
  var padding = parseFloat(document.getElementById("padding").value);
  var ripple = document.getElementById("ripple").checked;
  if (isNaN(threshold)) threshold = -35;
  if (isNaN(minLen) || minLen <= 0) minLen = 0.5;
  if (isNaN(padding) || padding < 0) padding = 0;

  clearLog("Reading the clip...");
  setBusy(true);

  callHost("SC_getClipInfo()", function (res) {
    var info;
    try { info = JSON.parse(res); } catch (e) { setBusy(false); log(res); return; }
    if (info.error) { setBusy(false); log(info.error); return; }

    log("Analyzing audio, please wait...");
    var args =
      "-hide_banner -nostats -i " + quote(info.mediaPath) +
      " -af silencedetect=noise=" + threshold + "dB:d=" + minLen +
      " -f null -";

    runFfmpeg(info.ffmpeg, args, function (err, out) {
      if (err) { setBusy(false); log(err); return; }

      var ranges = parseSilence(out);
      if (!ranges.length) { setBusy(false); log("No silence detected with these settings."); return; }

      var fps = info.fps || 30;
      var cuts = [];
      for (var i = 0; i < ranges.length; i++) {
        var s = info.clipStart + (ranges[i].start - info.inPoint) + padding;
        var e = info.clipStart + (ranges[i].end - info.inPoint) - padding;
        if (e <= info.clipStart || s >= info.clipEnd) continue;
        if (s < info.clipStart) s = info.clipStart;
        if (e > info.clipEnd) e = info.clipEnd;
        if (e - s < 1.5 / fps) continue;
        cuts.push({ start: s, end: e });
      }
      if (!cuts.length) { setBusy(false); log("Silence found but too short after padding."); return; }

      log("Found " + cuts.length + " silent segments. Cutting...");
      var payload = JSON.stringify({ fps: fps, ripple: ripple, cuts: cuts });
      callHost("SC_applyCuts(" + JSON.stringify(payload) + ")", function (result) {
        setBusy(false);
        log(result);
      });
    });
  });
});


/* ---------- Auto threshold from a marked silent range ---------- */

function parseVolumeDetect(text) {
  var mean = null, max = null;
  var m = text.match(/mean_volume:\s*(-?[0-9.]+)\s*dB/);
  if (m) mean = parseFloat(m[1]);
  var x = text.match(/max_volume:\s*(-?[0-9.]+)\s*dB/);
  if (x) max = parseFloat(x[1]);
  return { mean: mean, max: max };
}

document.getElementById("auto").addEventListener("click", function () {
  var resultEl = document.getElementById("autoresult");
  resultEl.textContent = "";
  clearLog("Reading the In/Out range...");
  setBusy(true);

  callHost("SC_getRangeInfo()", function (res) {
    var info;
    try { info = JSON.parse(res); } catch (e) { setBusy(false); log(res); return; }
    if (info.error) { setBusy(false); log(info.error); return; }

    log(
      "Measuring " + info.duration.toFixed(2) + "s of room tone " +
      "(timeline " + info.seqStart.toFixed(2) + "s - " + info.seqEnd.toFixed(2) + "s)..."
    );

    var args =
      "-hide_banner -nostats -ss " + info.mediaStart +
      " -t " + info.duration +
      " -i " + quote(info.mediaPath) +
      " -af volumedetect -f null -";

    runFfmpeg(info.ffmpeg, args, function (err, out) {
      setBusy(false);
      if (err) { log(err); return; }

      var v = parseVolumeDetect(out || "");
      if (v.max === null) { log("Could not measure the audio in that range."); return; }

      log("Room tone: mean " + v.mean + " dB, peak " + v.max + " dB.");

      /* Sit just above the loudest noise in the silent range, so the noise
         counts as silence and real speech does not. */
      var suggested = Math.round(v.max + 3);
      if (suggested > -12) suggested = -12;
      if (suggested < -70) suggested = -70;

      document.getElementById("threshold").value = suggested;
      resultEl.textContent =
        "Suggested threshold: " + suggested + " dB (peak " + v.max + " dB, mean " + v.mean + " dB)";
      log("Threshold set to " + suggested + " dB. Now press Cut Silence.");
    });
  });
});
