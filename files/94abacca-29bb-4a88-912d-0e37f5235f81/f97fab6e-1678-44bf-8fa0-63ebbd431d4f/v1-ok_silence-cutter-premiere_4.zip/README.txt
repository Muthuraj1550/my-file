Silence Cutter - Adobe Premiere Pro Extension
=============================================

INSTALL (Windows)
1. Unzip this folder anywhere.
2. Right-click install.bat -> Run as administrator (normal run also works).
   It installs the panel AND FFmpeg in one go.
3. Restart Premiere Pro.
4. Window > Extensions > Silence Cutter

FFMPEG (no separate install needed)
install.bat downloads FFmpeg automatically and places ffmpeg.exe inside the
extension's bin folder. Nothing else to install.
If the machine is offline, the installer tells you; you can then run
  winget install Gyan.FFmpeg
or copy ffmpeg.exe manually into
  %APPDATA%\Adobe\CEP\extensions\com.silencecut.premiere\bin\
Click "Check FFmpeg" in the panel to verify.

HOW TO USE
1. Open a sequence, select the clip you want to clean (or leave nothing
   selected to use the first clip on the timeline).
2. Set the options:
   - Silence threshold (dB): louder rooms need a higher value, e.g. -30.
   - Minimum silence length (sec): ignore pauses shorter than this.
   - Padding (sec): keeps a little air around speech so cuts don't clip words.
   - Ripple delete: closes the gaps automatically.
3. Click "Cut Silence". Analysis takes a few seconds per minute of footage.

UNINSTALL
Run uninstall.bat.

NOTES
- Always work on a duplicate sequence first; there is no one-click undo of the
  entire batch (Ctrl+Z steps back cut by cut).
- Tested on Premiere Pro 2019 and newer (CEP 6+).
