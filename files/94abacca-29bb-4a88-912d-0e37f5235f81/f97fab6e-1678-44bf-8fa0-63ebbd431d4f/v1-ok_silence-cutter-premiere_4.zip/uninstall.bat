@echo off
title Silence Cutter - Uninstall
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.silencecut.premiere"
if exist "%DEST%" (
  rmdir /s /q "%DEST%"
  echo Removed: %DEST%
) else (
  echo Not installed.
)
pause
