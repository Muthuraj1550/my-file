@echo off
setlocal enabledelayedexpansion
title Silence Cutter - Premiere Pro Extension Installer

echo ============================================
echo   Silence Cutter for Adobe Premiere Pro
echo   One-click installer (FFmpeg included)
echo ============================================
echo.

set "SRC=%~dp0"
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.silencecut.premiere"

echo [1/4] Enabling unsigned extensions (CEP debug mode)...
for %%V in (6 7 8 9 10 11 12 13) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)
echo      done.

echo [2/4] Copying files to:
echo      %DEST%
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%" >nul 2>&1
xcopy "%SRC%CSXS" "%DEST%\CSXS\" /e /i /y >nul
xcopy "%SRC%client" "%DEST%\client\" /e /i /y >nul
xcopy "%SRC%host" "%DEST%\host\" /e /i /y >nul
if exist "%SRC%bin" xcopy "%SRC%bin" "%DEST%\bin\" /e /i /y >nul
if not exist "%DEST%\bin" mkdir "%DEST%\bin" >nul 2>&1
echo      done.

echo [3/4] Setting up FFmpeg (no separate install needed)...
if exist "%DEST%\bin\ffmpeg.exe" (
  echo      Bundled ffmpeg.exe already present.
  goto :ffdone
)
where ffmpeg >nul 2>&1
if %errorlevel%==0 (
  echo      FFmpeg already on PATH - using it.
  goto :ffdone
)

echo      Downloading FFmpeg ^(~30 MB^), please wait...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "try {" ^
  "  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
  "  $tmp=Join-Path $env:TEMP ('sc_ffmpeg_'+[guid]::NewGuid());" ^
  "  New-Item -ItemType Directory -Path $tmp | Out-Null;" ^
  "  $zip=Join-Path $tmp 'ffmpeg.zip';" ^
  "  $urls=@('https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip','https://github.com/GyanD/codexffmpeg/releases/latest/download/ffmpeg-release-essentials.zip');" ^
  "  $ok=$false;" ^
  "  foreach($u in $urls){ try { Invoke-WebRequest -Uri $u -OutFile $zip -UseBasicParsing; $ok=$true; break } catch {} }" ^
  "  if(-not $ok){ throw 'download failed' };" ^
  "  Add-Type -AssemblyName System.IO.Compression.FileSystem;" ^
  "  [IO.Compression.ZipFile]::ExtractToDirectory($zip,$tmp);" ^
  "  $exe=Get-ChildItem -Path $tmp -Recurse -Filter ffmpeg.exe | Select-Object -First 1;" ^
  "  if(-not $exe){ throw 'ffmpeg.exe not found in archive' };" ^
  "  Copy-Item $exe.FullName -Destination (Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.silencecut.premiere\bin\ffmpeg.exe') -Force;" ^
  "  Remove-Item $tmp -Recurse -Force;" ^
  "  Write-Host '     FFmpeg installed into the extension.'" ^
  "} catch { Write-Host ('     Auto-download failed: '+$_.Exception.Message); exit 1 }"

if exist "%DEST%\bin\ffmpeg.exe" (
  echo      FFmpeg ready.
) else (
  echo      WARNING: could not fetch FFmpeg automatically ^(no internet?^).
  echo      Fallback: run  winget install Gyan.FFmpeg
  echo      or copy ffmpeg.exe into: %DEST%\bin\
)
:ffdone

echo [4/4] Verifying...
if exist "%DEST%\CSXS\manifest.xml" (echo      Extension files OK.) else (echo      ERROR: copy failed.)

echo.
echo ============================================
echo   Installed!
echo   Restart Premiere Pro, then open:
echo   Window ^> Extensions ^> Silence Cutter
echo ============================================
echo.
pause
