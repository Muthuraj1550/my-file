(function () {
  var csInterface = new CSInterface();
  var LS_KEY = 'dragzoom.lastUsed.v1';

  var stage = document.getElementById('stage');
  var stageImg = document.getElementById('stageImg');
  var box = document.getElementById('box');
  var boxBadge = document.getElementById('boxBadge');
  var handles = Array.prototype.slice.call(box.querySelectorAll('.handle'));
  var hint = document.getElementById('hint');
  var frameSizeSel = document.getElementById('frameSize');
  var durationInput = document.getElementById('duration');
  var statusEl = document.getElementById('status');
  var applyBtn = document.getElementById('applyBtn');
  var resetBtn = document.getElementById('resetBtn');
  var syncBtn = document.getElementById('syncBtn');
  var frameBtn = document.getElementById('frameBtn');
  var saveLastBtn = document.getElementById('saveLastBtn');
  var loadLastBtn = document.getElementById('loadLastBtn');
  var inScale = document.getElementById('valScale');
  var inPosX = document.getElementById('valPosX');
  var inPosY = document.getElementById('valPosY');
  var presetSizeInput = document.getElementById('presetSize');
  var presetGrid = document.getElementById('presetGrid');
  var modeAnimateBtn = document.getElementById('modeAnimateBtn');
  var modeInstantBtn = document.getElementById('modeInstantBtn');

  var frameW = 1920, frameH = 1080;
  // Persistent rectangle (Camtasia-style) — always present, in frame-pixel units.
  // Defaults to the full frame ("Actual size") until the user adjusts it.
  var boxState = { x: 0, y: 0, w: frameW, h: frameH };
  var mode = null;        // 'move' | 'resize'
  var dragStart = null;
  var activeHandle = null;
  var keyMode = 'animate'; // 'animate' | 'instant'
  var interacted = false;

  function setStatus(msg, kind) {
    statusEl.textContent = msg;
    statusEl.className = 'status' + (kind ? ' ' + kind : '');
  }

  function clampBox(b) {
    b.w = Math.max(20, Math.min(b.w, frameW));
    b.h = Math.max(20, Math.min(b.h, frameH));
    b.x = Math.max(0, Math.min(b.x, frameW - b.w));
    b.y = Math.max(0, Math.min(b.y, frameH - b.h));
    return b;
  }

  function boxFromValues(scale, posX, posY) {
    var w = frameW / (scale / 100);
    var h = frameH / (scale / 100);
    var dx = (frameW / 2 - posX) * (100 / scale);
    var dy = (frameH / 2 - posY) * (100 / scale);
    var cx = frameW / 2 + dx, cy = frameH / 2 + dy;
    return clampBox({ x: cx - w / 2, y: cy - h / 2, w: w, h: h });
  }

  function valuesFromBox(b) {
    var scale = (frameW / b.w) * 100;
    var boxCx = b.x + b.w / 2, boxCy = b.y + b.h / 2;
    var dx = boxCx - frameW / 2, dy = boxCy - frameH / 2;
    var posX = frameW / 2 - dx * (scale / 100);
    var posY = frameH / 2 - dy * (scale / 100);
    return { scale: scale, posX: posX, posY: posY };
  }

  function renderBoxOverlay() {
    var r = stage.getBoundingClientRect();
    box.style.left = (boxState.x / frameW * r.width) + 'px';
    box.style.top = (boxState.y / frameH * r.height) + 'px';
    box.style.width = (boxState.w / frameW * r.width) + 'px';
    box.style.height = (boxState.h / frameH * r.height) + 'px';
  }

  function renderReadout() {
    var v = valuesFromBox(boxState);
    inScale.value = v.scale.toFixed(1);
    inPosX.value = v.posX.toFixed(1);
    inPosY.value = v.posY.toFixed(1);
    boxBadge.textContent = v.scale.toFixed(0) + '%';
  }

  function setBox(b, fromFields) {
    boxState = clampBox(b);
    renderBoxOverlay();
    if (!fromFields) renderReadout();
  }

  function applyAspect() {
    var parts = frameSizeSel.value.split('x').map(Number);
    var oldW = frameW, oldH = frameH;
    frameW = parts[0]; frameH = parts[1];
    stage.style.setProperty('--ar', frameW + '/' + frameH);
    // rescale the existing box proportionally into the new frame size
    if (oldW && oldH) {
      setBox({
        x: boxState.x / oldW * frameW, y: boxState.y / oldH * frameH,
        w: boxState.w / oldW * frameW, h: boxState.h / oldH * frameH
      });
    } else {
      setBox({ x: 0, y: 0, w: frameW, h: frameH });
    }
  }
  frameSizeSel.addEventListener('change', applyAspect);

  function toFramePx(clientX, clientY) {
    var r = stage.getBoundingClientRect();
    var relX = Math.min(Math.max(clientX - r.left, 0), r.width);
    var relY = Math.min(Math.max(clientY - r.top, 0), r.height);
    return { x: relX / r.width * frameW, y: relY / r.height * frameH };
  }

  // ---------- move existing box (mousedown on box body) ----------
  box.addEventListener('mousedown', function (e) {
    if (e.target.classList && e.target.classList.contains('handle')) return; // handled below
    e.stopPropagation();
    mode = 'move';
    interacted = false;
    hint.style.display = 'none';
    var p = toFramePx(e.clientX, e.clientY);
    dragStart = { x: p.x, y: p.y, boxX: boxState.x, boxY: boxState.y };
  });

  // ---------- resize via any of the 8 handles ----------
  handles.forEach(function (h) {
    h.addEventListener('mousedown', function (e) {
      e.stopPropagation();
      mode = 'resize';
      interacted = false;
      hint.style.display = 'none';
      activeHandle = {
        hx: parseFloat(h.getAttribute('data-hx')),
        hy: parseFloat(h.getAttribute('data-hy')),
        axis: h.getAttribute('data-axis') || 'both'
      };
      dragStart = {
        box: { x: boxState.x, y: boxState.y, w: boxState.w, h: boxState.h },
        anchor: {
          x: boxState.x + (1 - activeHandle.hx) * boxState.w,
          y: boxState.y + (1 - activeHandle.hy) * boxState.h
        }
      };
    });
  });

  window.addEventListener('mousemove', function (e) {
    if (!mode) return;
    var p = toFramePx(e.clientX, e.clientY);
    var frameAR = frameW / frameH;

    if (mode === 'move') {
      var dx = p.x - dragStart.x, dy = p.y - dragStart.y;
      if (Math.abs(dx) > 1 || Math.abs(dy) > 1) interacted = true;
      setBox({ x: dragStart.boxX + dx, y: dragStart.boxY + dy, w: boxState.w, h: boxState.h });

    } else if (mode === 'resize') {
      var anchor = dragStart.anchor, ax = activeHandle.hx, ay = activeHandle.hy;
      var newW, newH;
      if (activeHandle.axis === 'w') {
        newW = Math.max(20, Math.abs(p.x - anchor.x));
        newH = newW / frameAR;
      } else if (activeHandle.axis === 'h') {
        newH = Math.max(20, Math.abs(p.y - anchor.y));
        newW = newH * frameAR;
      } else {
        var wCandidate = Math.max(20, Math.abs(p.x - anchor.x));
        var hCandidate = Math.max(20, Math.abs(p.y - anchor.y));
        if (wCandidate / hCandidate > frameAR) { newH = hCandidate; newW = newH * frameAR; }
        else { newW = wCandidate; newH = newW / frameAR; }
      }
      interacted = true;
      // anchor stays fixed at its own corner/edge; box grows/shrinks from there
      var invAx = 1 - ax, invAy = 1 - ay;
      var newX = anchor.x - invAx * newW;
      var newY = anchor.y - invAy * newH;
      setBox({ x: newX, y: newY, w: newW, h: newH });
    }
  });

  window.addEventListener('mouseup', function () {
    var didInteract = interacted;
    mode = null; dragStart = null; activeHandle = null; interacted = false;
    if (didInteract) doApply();
  });
  window.addEventListener('resize', renderBoxOverlay);

  // ---------- numeric fields (typed precision input) ----------
  function onFieldChange() {
    var scale = Math.max(1, parseFloat(inScale.value) || 100);
    var posX = parseFloat(inPosX.value); if (isNaN(posX)) posX = frameW / 2;
    var posY = parseFloat(inPosY.value); if (isNaN(posY)) posY = frameH / 2;
    hint.style.display = 'none';
    setBox(boxFromValues(scale, posX, posY), true);
    doApply();
  }
  [inScale, inPosX, inPosY].forEach(function (el) {
    el.addEventListener('change', onFieldChange);
  });

  // ---------- 9-point position presets ----------
  function presetBox(h, v, sizePct) {
    var frac = Math.min(95, Math.max(10, sizePct)) / 100;
    var w = frameW * frac, hgt = frameH * frac;
    var x = h === 'left' ? 0 : h === 'right' ? frameW - w : (frameW - w) / 2;
    var y = v === 'top' ? 0 : v === 'bottom' ? frameH - hgt : (frameH - hgt) / 2;
    return { x: x, y: y, w: w, h: hgt };
  }
  presetGrid.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('.presetbtn') : null;
    if (!btn) return;
    hint.style.display = 'none';
    var sizePct = parseFloat(presetSizeInput.value) || 70;
    setBox(presetBox(btn.getAttribute('data-h'), btn.getAttribute('data-v'), sizePct));
    doApply();
  });

  // ---------- keyframe mode toggle ----------
  function setKeyMode(m) {
    keyMode = m;
    modeAnimateBtn.classList.toggle('on', m === 'animate');
    modeInstantBtn.classList.toggle('on', m === 'instant');
    durationInput.disabled = (m === 'instant');
  }
  modeAnimateBtn.addEventListener('click', function () { setKeyMode('animate'); });
  modeInstantBtn.addEventListener('click', function () { setKeyMode('instant'); });

  // ---------- save / return to last used (persisted in this panel's localStorage) ----------
  function currentSnapshot() {
    var v = valuesFromBox(boxState);
    return { scale: v.scale, posX: v.posX, posY: v.posY, frameW: frameW, frameH: frameH, duration: parseFloat(durationInput.value) || 1.5, keyMode: keyMode };
  }
  saveLastBtn.addEventListener('click', function () {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(currentSnapshot()));
      setStatus('Saved current Scale/Position/Size as last used.', 'ok');
    } catch (e) { setStatus('Could not save (local storage unavailable).', 'err'); }
  });
  loadLastBtn.addEventListener('click', function () { loadLastUsed(false); });

  function loadLastUsed(silent) {
    var raw;
    try { raw = localStorage.getItem(LS_KEY); } catch (e) { raw = null; }
    if (!raw) { if (!silent) setStatus('No saved settings yet — use "Save as last used" first.', 'err'); return; }
    var d;
    try { d = JSON.parse(raw); } catch (e) { return; }

    var match = d.frameW + 'x' + d.frameH;
    var opts = Array.prototype.slice.call(frameSizeSel.options).map(function (o) { return o.value; });
    if (opts.indexOf(match) !== -1) frameSizeSel.value = match;
    frameW = d.frameW; frameH = d.frameH;
    stage.style.setProperty('--ar', frameW + '/' + frameH);

    durationInput.value = d.duration || 1.5;
    if (d.keyMode) setKeyMode(d.keyMode);
    hint.style.display = 'none';
    setBox(boxFromValues(d.scale, d.posX, d.posY));
    if (!silent) setStatus('Loaded last used Scale ' + d.scale.toFixed(0) + '% / Position ' + d.posX.toFixed(0) + ', ' + d.posY.toFixed(0) + '.', 'ok');
  }

  // ---------- load current frame from Premiere as background ----------
  frameBtn.addEventListener('click', function () {
    setStatus('Grabbing current frame from Premiere…');
    frameBtn.disabled = true;
    csInterface.evalScript('exportCurrentFramePNG()', function (result) {
      frameBtn.disabled = false;
      var data;
      try { data = JSON.parse(result); } catch (e) {
        setStatus('Unexpected response from Premiere.', 'err'); return;
      }
      if (data.ok) {
        var url = 'file:///' + data.path.replace(/\\/g, '/') + '?t=' + Date.now();
        stageImg.onload = function () { stageImg.style.display = 'block'; };
        stageImg.onerror = function () { setStatus('Frame file couldn\'t be loaded into the panel.', 'err'); };
        stageImg.src = url;
        setStatus('Loaded current frame as preview.', 'ok');
      } else {
        setStatus(data.error, 'err');
      }
    });
  });

  // ---------- Premiere bridge: sequence sync ----------
  function syncFromSequence(silent) {
    csInterface.evalScript('getSequenceInfo()', function (result) {
      var data;
      try { data = JSON.parse(result); } catch (e) {
        setStatus('Could not reach Premiere. Is a project open?', 'err'); return;
      }
      if (!data.ok) { setStatus(data.error, 'err'); return; }

      var found = data.frameW + 'x' + data.frameH;
      var opts = Array.prototype.slice.call(frameSizeSel.options).map(function (o) { return o.value; });
      if (opts.indexOf(found) !== -1) {
        frameSizeSel.value = found;
      } else {
        // sequence uses a custom size not in the preset list — add it so pixel math stays exact
        var opt = document.createElement('option');
        opt.value = found; opt.textContent = data.frameW + ' × ' + data.frameH + ' (sequence)';
        frameSizeSel.appendChild(opt);
        frameSizeSel.value = found;
      }
      applyAspect();
      // reset the rectangle to full-frame ("Actual size") on a fresh sync, matching
      // Camtasia's default — the box always describes "what to zoom INTO from here",
      // not the clip's current transform.
      setBox({ x: 0, y: 0, w: frameW, h: frameH });
      hint.style.display = 'flex';

      if (!silent) {
        setStatus(
          data.hasSelectedClip
            ? 'Synced ' + data.frameW + '×' + data.frameH + '. Clip "' + data.clipName + '" selected.'
            : 'Synced ' + data.frameW + '×' + data.frameH + '. No clip selected yet.'
        );
      }
    });
  }
  syncBtn.addEventListener('click', function () { syncFromSequence(false); });

  // ---------- apply: box is sent as FRACTIONS of the current on-screen frame.
  // The host reads the clip's live Scale/Position and composes the transform,
  // so repeated zooms (zoom into a zoom) stay correct instead of compounding
  // into huge Position values / a black frame. ----------
  var applyInFlight = false;
  function doApply() {
    if (applyInFlight) return;
    var dur = parseFloat(durationInput.value) || 1.5;
    var bxFrac = boxState.x / frameW, byFrac = boxState.y / frameH;
    var bwFrac = boxState.w / frameW, bhFrac = boxState.h / frameH;

    applyInFlight = true;
    applyBtn.disabled = true;
    setStatus('Applying…');

    var script = 'applyDragZoom(' +
      bxFrac.toFixed(6) + ',' + byFrac.toFixed(6) + ',' + bwFrac.toFixed(6) + ',' + bhFrac.toFixed(6) + ',' +
      dur + ',' + JSON.stringify(keyMode) + ')';

    csInterface.evalScript(script, function (result) {
      applyInFlight = false;
      applyBtn.disabled = false;
      var data;
      try { data = JSON.parse(result); } catch (e) {
        setStatus('Unexpected response from Premiere.', 'err'); return;
      }
      if (data.ok) {
        var label = keyMode === 'instant' ? 'Instant pop' : ('Animated ' + dur + 's');
        setStatus(label + ' — Scale ' + data.scale.toFixed(0) + '%.', 'ok');
        try { localStorage.setItem(LS_KEY, JSON.stringify(currentSnapshot())); } catch (e) {}
      } else {
        setStatus(data.error, 'err');
      }
    });
  }
  applyBtn.addEventListener('click', function () { doApply(); });

  resetBtn.addEventListener('click', function () {
    setStatus('Resetting…');
    csInterface.evalScript('resetMotion(' + frameW + ',' + frameH + ')', function (result) {
      var data;
      try { data = JSON.parse(result); } catch (e) {
        setStatus('Unexpected response from Premiere.', 'err'); return;
      }
      if (data.ok) {
        setStatus('Motion reset to 100% / center.', 'ok');
        setBox({ x: 0, y: 0, w: frameW, h: frameH });
        hint.style.display = 'flex';
      } else setStatus(data.error, 'err');
    });
  });

  // init
  applyAspect();
  setKeyMode('animate');
  syncFromSequence(true);
})();
