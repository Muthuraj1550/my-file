function importClip(filePath) {
  try {
    if (!app.project) {
      return "No active project open.";
    }
    var ok = app.project.importFiles(
      [filePath],
      true,   // suppress UI
      app.project.rootItem,
      false
    );
    return ok ? "Imported into project bin: " + filePath : "Import failed for: " + filePath;
  } catch (e) {
    return "Error: " + e.toString();
  }
}
