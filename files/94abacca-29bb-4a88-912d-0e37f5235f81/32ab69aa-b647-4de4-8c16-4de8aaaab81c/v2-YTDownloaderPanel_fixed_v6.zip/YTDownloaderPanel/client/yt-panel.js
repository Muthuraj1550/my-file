// Requires CEP Node.js integration (enabled in manifest.xml via --enable-nodejs --mixed-context)
const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs');

const logEl = document.getElementById('log');
const goBtn = document.getElementById('go');

function log(line) {
  logEl.textContent += line + '\n';
  logEl.scrollTop = logEl.scrollHeight;
}

// Minimal wrapper around the CEP host bridge — avoids needing Adobe's full CSInterface.js file.
function evalScript(script, callback) {
  if (window.__adobe_cep__) {
    window.__adobe_cep__.evalScript(script, callback || function () {});
  } else {
    log('[warn] CEP bridge not found — running outside Premiere?');
  }
}

// Format selectors deliberately end in a permissive "/bv*+ba/b" tail. A
// selector that HARD-REQUIRES something (a height cap, or the old
// [protocol^=m3u8] filter) turns "this client returned fewer formats than
// usual" into a fatal "Requested format is not available" instead of just
// downloading whatever is actually there.
function getCookiesFile() {
  const el = document.getElementById('cookies');
  if (!el) return '';
  const p = el.value.trim();
  if (!p) return '';
  if (!fs.existsSync(p)) { log('[warn] cookies.txt path does not exist, ignoring: ' + p); return ''; }
  return p;
}

// Checks the environment as PREMIERE sees it, which is the part that trips
// people up: a CEP panel inherits Premiere's PATH, not the PATH your terminal
// has. yt-dlp working in cmd.exe says nothing about it working here, and a
// missing JS runtime is the single most common cause of an instant 403.
function checkEnvironment() {
  function probe(cmd, args, onResult) {
    let out = '';
    try {
      const p = spawn(cmd, args, { shell: false });
      p.stdout.on('data', (d) => { out += d.toString(); });
      p.on('error', () => onResult(null));
      p.on('close', (code) => onResult(code === 0 ? out.trim().split('\n')[0] : null));
    } catch (e) { onResult(null); }
  }

  probe('yt-dlp', ['--version'], (v) => {
    if (!v) { log('[error] yt-dlp is not reachable from Premiere\'s PATH.'); return; }
    log('[env] yt-dlp ' + v);
  });

  let pending = 3;
  let found = [];
  ['deno', 'node', 'bun'].forEach((rt) => {
    probe(rt, ['--version'], (v) => {
      if (v) found.push(rt);
      if (--pending === 0) {
        if (found.length) {
          log('[env] JavaScript runtime: ' + found.join(', '));
        } else {
          log('[warn] No JavaScript runtime (deno/node/bun) on Premiere\'s PATH.');
          log('[warn] yt-dlp needs one to solve YouTube\'s signature challenge. ' +
              'Without it most downloads 403 instantly. Install Deno or Node, then restart Premiere.');
        }
      }
    });
  });
}

function qualityArgs(q) {
  switch (q) {
    case '1080': return ['-f', 'bv*[height<=1080]+ba/b[height<=1080]/bv*+ba/b'];
    case '720': return ['-f', 'bv*[height<=720]+ba/b[height<=720]/bv*+ba/b'];
    case 'audio': return ['-f', 'ba/b', '-x', '--audio-format', 'm4a'];
    default: return ['-f', 'bv*+ba/b'];
  }
}

// YouTube rotates which player clients hand out downloadable URLs, so there is
// no single correct client — only a list to walk. Letting yt-dlp pick is first
// because its built-in default list is updated with every release; the pinned
// clients below are fallbacks for when the defaults are the broken ones.
const CLIENT_ATTEMPTS = [
  { label: 'yt-dlp default clients', args: [] },
  { label: 'tv_simply / tv clients', args: ['--extractor-args', 'youtube:player_client=tv_simply,tv'] },
  { label: 'android_vr client', args: ['--extractor-args', 'youtube:player_client=android_vr'] },
  { label: 'mweb client', args: ['--extractor-args', 'youtube:player_client=mweb'] },
  { label: 'web_safari client', args: ['--extractor-args', 'youtube:player_client=web_safari'] }
];

// ---- Preview player (YouTube IFrame API) ----
// Lets you scrub the video right in the panel and stamp the Start/End fields
// from the playhead instead of typing timecodes by hand.
const playerWrap = document.getElementById('player-wrap');
const playheadEl = document.getElementById('playhead');
let player = null;
let playerReady = false;
let currentVideoId = '';
let apiLoading = false;
let rangeStopAt = null;

function parseVideoId(url) {
  if (!url) return '';
  const m = url.match(/(?:v=|\/shorts\/|youtu\.be\/|\/embed\/)([A-Za-z0-9_-]{11})/);
  return m ? m[1] : (/^[A-Za-z0-9_-]{11}$/.test(url.trim()) ? url.trim() : '');
}

function toHms(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(Math.floor(sec / 3600))}:${pad(Math.floor((sec % 3600) / 60))}:${pad(sec % 60)}`;
}

function hmsToSec(str) {
  if (!str) return null;
  const parts = str.trim().split(':').map(Number);
  if (parts.some(isNaN)) return null;
  return parts.reduce((acc, p) => acc * 60 + p, 0);
}

function loadYouTubeApi(cb) {
  if (window.YT && window.YT.Player) return cb();
  const prev = window.onYouTubeIframeAPIReady;
  window.onYouTubeIframeAPIReady = function () { if (prev) prev(); cb(); };
  if (apiLoading) return;
  apiLoading = true;
  const s = document.createElement('script');
  s.src = 'https://www.youtube.com/iframe_api';
  s.onerror = () => log('[warn] Could not load the YouTube player (no internet access?).');
  document.head.appendChild(s);
}

function loadPreview(url) {
  const id = parseVideoId(url);
  if (!id) { playerWrap.style.display = 'none'; return; }
  if (id === currentVideoId && playerReady) return;
  currentVideoId = id;
  playerWrap.style.display = 'block';

  loadYouTubeApi(() => {
    if (player && playerReady) { player.loadVideoById(id); return; }
    player = new YT.Player('player', {
      videoId: id,
      playerVars: { rel: 0, modestbranding: 1, playsinline: 1 },
      events: {
        onReady: () => { playerReady = true; },
        onStateChange: (e) => {
          const playing = e.data === YT.PlayerState.PLAYING;
          document.getElementById('playPause').textContent = playing ? 'Pause' : 'Play';
        }
      }
    });
  });
}

// Keep the timecode readout live, and stop playback at the Out point when the
// user asked to preview just the selected range.
setInterval(() => {
  if (!player || !playerReady || !player.getCurrentTime) return;
  const t = player.getCurrentTime();
  playheadEl.textContent = toHms(t);
  if (rangeStopAt !== null && t >= rangeStopAt) { player.pauseVideo(); rangeStopAt = null; }
}, 250);

function seekTo(sec) {
  if (!player || !playerReady) return;
  player.seekTo(sec, true);
}

document.getElementById('playPause').addEventListener('click', () => {
  if (!player || !playerReady) return;
  rangeStopAt = null;
  if (player.getPlayerState() === YT.PlayerState.PLAYING) player.pauseVideo();
  else player.playVideo();
});

document.getElementById('setIn').addEventListener('click', () => {
  if (!player || !playerReady) return;
  document.getElementById('start').value = toHms(player.getCurrentTime());
  log('[in] ' + document.getElementById('start').value);
});

document.getElementById('setOut').addEventListener('click', () => {
  if (!player || !playerReady) return;
  document.getElementById('end').value = toHms(player.getCurrentTime());
  log('[out] ' + document.getElementById('end').value);
});

document.getElementById('goIn').addEventListener('click', () => {
  const s = hmsToSec(document.getElementById('start').value);
  if (s === null) { log('[warn] No valid In point set.'); return; }
  rangeStopAt = null;
  seekTo(s);
});

document.getElementById('goOut').addEventListener('click', () => {
  const e = hmsToSec(document.getElementById('end').value);
  if (e === null) { log('[warn] No valid Out point set.'); return; }
  rangeStopAt = null;
  seekTo(e);
});

document.getElementById('playRange').addEventListener('click', () => {
  const s = hmsToSec(document.getElementById('start').value) || 0;
  const e = hmsToSec(document.getElementById('end').value);
  if (!player || !playerReady) return;
  rangeStopAt = e !== null && e > s ? e : null;
  seekTo(s);
  player.playVideo();
});

const urlInput = document.getElementById('url');
urlInput.addEventListener('change', () => loadPreview(urlInput.value.trim()));
urlInput.addEventListener('paste', () => setTimeout(() => loadPreview(urlInput.value.trim()), 0));

// ---- Search ----

const searchInput = document.getElementById('search');
const searchBtn = document.getElementById('searchBtn');
const resultsEl = document.getElementById('results');

function fmtDuration(sec) {
  if (!sec && sec !== 0) return '';
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

function runSearch() {
  const query = searchInput.value.trim();
  if (!query) return;

  resultsEl.style.display = 'block';
  resultsEl.innerHTML = '<div class="result-item">Searching…</div>';
  searchBtn.disabled = true;

  // --flat-playlist keeps this fast (no per-video page fetch); -j prints one JSON object per line.
  const args = [
    `ytsearch12:${query}`,
    '--flat-playlist',
    '-j',
    '--no-warnings'
  ];

  const proc = spawn('yt-dlp', args, { shell: false });
  let out = '';
  let err = '';

  proc.stdout.on('data', (d) => { out += d.toString(); });
  proc.stderr.on('data', (d) => { err += d.toString(); });

  proc.on('error', (e) => {
    resultsEl.innerHTML = '';
    log('[error] Could not start yt-dlp for search — is it installed and on PATH? ' + e.message);
    searchBtn.disabled = false;
  });

  proc.on('close', () => {
    searchBtn.disabled = false;
    const lines = out.split('\n').map(l => l.trim()).filter(Boolean);
    const videos = [];
    lines.forEach(l => {
      try { videos.push(JSON.parse(l)); } catch (e) { /* skip non-JSON noise */ }
    });

    if (!videos.length) {
      resultsEl.innerHTML = '<div class="result-item">No results.</div>';
      if (err) log('[yt-dlp search] ' + err.trim());
      return;
    }

    resultsEl.innerHTML = '';
    videos.forEach(v => {
      const item = document.createElement('div');
      item.className = 'result-item';

      const thumb = document.createElement('img');
      thumb.src = v.thumbnails && v.thumbnails.length ? v.thumbnails[v.thumbnails.length - 1].url : '';
      item.appendChild(thumb);

      const meta = document.createElement('div');
      meta.className = 'result-meta';
      const title = document.createElement('div');
      title.className = 'result-title';
      title.textContent = v.title || '(untitled)';
      const sub = document.createElement('div');
      sub.className = 'result-sub';
      sub.textContent = [v.channel || v.uploader || '', fmtDuration(v.duration)].filter(Boolean).join(' · ');
      meta.appendChild(title);
      meta.appendChild(sub);
      item.appendChild(meta);

      item.addEventListener('click', () => {
        const videoUrl = v.webpage_url || (v.id ? `https://www.youtube.com/watch?v=${v.id}` : '');
        document.getElementById('url').value = videoUrl;
        resultsEl.style.display = 'none';
        resultsEl.innerHTML = '';
        log('Selected: ' + (v.title || videoUrl));
        loadPreview(videoUrl);
      });

      resultsEl.appendChild(item);
    });
  });
}

searchBtn.addEventListener('click', runSearch);
searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') runSearch(); });

// Runs yt-dlp, streaming output to the log. Calls back with (exitCode, finalPath).
function runYtdlp(args, done) {
  log('Running: yt-dlp ' + args.join(' '));

  const proc = spawn('yt-dlp', args, { shell: false });
  let finalPath = '';
  let stdoutBuf = '';
  let errText = '';

  // Process only complete lines. A chunk from 'data' is NOT guaranteed to end
  // on a line boundary, so a long path line (like the one --print
  // after_move:filepath emits) can be split across two chunks. Checking
  // fs.existsSync() on a half-line never matches, which is why the final
  // path could silently fail to be detected even though yt-dlp printed it.
  function handleLine(l) {
    const t = l.trim();
    if (!t) return;
    log(t);
    if (fs.existsSync(t)) finalPath = t;
  }

  proc.stdout.on('data', (d) => {
    stdoutBuf += d.toString();
    const lines = stdoutBuf.split('\n');
    stdoutBuf = lines.pop(); // keep the last (possibly incomplete) line buffered
    lines.forEach(handleLine);
  });

  proc.stderr.on('data', (d) => {
    const t = d.toString();
    errText += t;
    log('[yt-dlp] ' + t.trim());
  });

  proc.on('error', (err) => {
    log('[error] Could not start yt-dlp — is it installed and on PATH? ' + err.message);
    done(-1, '', err.message);
  });

  proc.on('close', (code) => {
    if (stdoutBuf) { handleLine(stdoutBuf); stdoutBuf = ''; } // flush trailing partial line
    if (!finalPath) {
      // Fallback: yt-dlp may not print the path when a section download is
      // stitched by ffmpeg, so pick the newest media file in the run folder.
      try {
        const dir = path.dirname(args[args.indexOf('-o') + 1]);
        const found = fs.readdirSync(dir)
          .filter((f) => !/\.(part|ytdl|temp)$/i.test(f))
          .map((f) => path.join(dir, f))
          .filter((p) => fs.statSync(p).isFile())
          .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
        if (found.length) finalPath = found[0];
      } catch (e) { /* ignore */ }
    }
    done(code, finalPath, errText);
  });
}

// Turns yt-dlp's stderr into the one thing worth doing next. These three
// failures all surface as "download failed" but have completely different
// causes, and guessing wrong costs a lot of retry time.
function diagnose(errText) {
  const e = errText || '';
  if (/Requested format is not available/i.test(e) || /Only images are available/i.test(e)) {
    return 'That client returned no playable formats (storyboard images only) — it was blocked at the extraction step, not the download step.';
  }
  if (/HTTP Error 403/i.test(e)) {
    return 'YouTube refused the media URLs (403). If this happened instantly at 0%, yt-dlp most likely has no JavaScript runtime and cannot sign the URLs correctly.';
  }
  if (/Sign in to confirm|not a bot|age-restricted|private video|members-only/i.test(e)) {
    return 'This video needs a signed-in session — set a cookies.txt file below.';
  }
  return '';
}

// Exact trim with a separate ffmpeg pass. Re-encoding (instead of stream copy)
// keeps the cut frame-accurate without yt-dlp's --force-keyframes-at-cuts,
// which is what crashes ffmpeg on fragmented YouTube streams.
function ffmpegTrim(input, start, end, done) {
  const out = input.replace(/(\.[^.]+)$/, '-trimmed$1');
  const args = ['-y', '-ss', start || '0'];
  if (end) args.push('-to', end);
  args.push('-i', input, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-c:a', 'aac', out);

  log('Running: ffmpeg ' + args.join(' '));
  const proc = spawn('ffmpeg', args, { shell: false });
  proc.stderr.on('data', (d) => {
    const t = d.toString().trim();
    if (/error|invalid|failed/i.test(t)) log('[ffmpeg] ' + t);
  });
  proc.on('error', (err) => {
    log('[error] Could not start ffmpeg — is it installed and on PATH? ' + err.message);
    done('');
  });
  proc.on('close', (code) => {
    if (code !== 0 || !fs.existsSync(out)) { log('[error] ffmpeg trim failed with code ' + code); return done(''); }
    done(out);
  });
}

function importToPremiere(finalPath) {
  log('Downloaded: ' + finalPath);
  log('Importing into Premiere project...');
  const escaped = finalPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  evalScript(`importClip("${escaped}")`, (result) => {
    log('[premiere] ' + result);
  });
}

goBtn.addEventListener('click', () => {
  const url = document.getElementById('url').value.trim();
  const start = document.getElementById('start').value.trim();
  const end = document.getElementById('end').value.trim();
  const quality = document.getElementById('quality').value;

  if (!url) { log('[error] Paste a YouTube URL first.'); return; }

  // Each run gets its own folder. Without this, a video downloaded once in
  // full gets cached under the same "title-id.ext" filename, so a later
  // request for a trimmed section of the SAME video finds that file already
  // exists and yt-dlp just reuses/skips it — silently returning the earlier
  // full-length download instead of cutting the new range.
  const runId = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
  const outDir = path.join(os.tmpdir(), 'yt-premiere-downloads', runId);
  fs.mkdirSync(outDir, { recursive: true });
  const outTemplate = path.join(outDir, '%(title).60s-%(id)s.%(ext)s');

  function baseArgs(attemptIdx) {
    const args = [
      url,
      '-o', outTemplate,
      '--no-playlist',
      '--merge-output-format', 'mp4',
      '--force-overwrites',
      '--retries', '3',
      '--fragment-retries', '3',
      '--retry-sleep', 'http:2',
      '--print', 'after_move:filepath'
    ];

    const cookies = getCookiesFile();
    if (cookies) args.push('--cookies', cookies);

    return args
      .concat(CLIENT_ATTEMPTS[attemptIdx].args)
      .concat(qualityArgs(quality));
  }

  // Walks the client ladder until one produces a file. Each rung is a genuinely
  // different extraction path, so a failure on one says nothing about the next.
  function runLadder(extraArgs, done, idx) {
    const i = idx || 0;
    const attempt = CLIENT_ATTEMPTS[i];
    log(`[info] Attempt ${i + 1}/${CLIENT_ATTEMPTS.length}: ${attempt.label}`);

    runYtdlp(baseArgs(i).concat(extraArgs || []), (code, finalPath, errText) => {
      if (code === 0 && finalPath) return done(0, finalPath);

      const why = diagnose(errText);
      if (why) log('[diag] ' + why);

      if (i + 1 < CLIENT_ATTEMPTS.length) {
        return runLadder(extraArgs, done, i + 1);
      }
      done(code || 1, '', errText);
    });
  }

  logEl.textContent = '';
  goBtn.disabled = true;
  const trimming = Boolean(start || end);

  function finish(pathOrEmpty) {
    goBtn.disabled = false;
    if (!pathOrEmpty) { log('[warn] Finished, but no usable output file.'); return; }
    importToPremiere(pathOrEmpty);
  }

  // Full download, then an exact ffmpeg cut. Slower than a section download but
  // it is the path that always works, so it doubles as the fallback.
  function downloadFullThenTrim() {
    function useDownloadedFile(finalPath) {
      if (!trimming) return finish(finalPath);
      ffmpegTrim(finalPath, start, end, (out) => {
        if (!out) {
          goBtn.disabled = false;
          log('[error] The download succeeded, but trimming failed. The full video was not imported.');
          return;
        }
        finish(out);
      });
    }

    runLadder([], (code, finalPath) => {
      if (code === 0 && finalPath) return useDownloadedFile(finalPath);
      goBtn.disabled = false;
      log('[error] Every player client failed.');
      log('[error] Next steps, in order: (1) update yt-dlp to the latest nightly, ' +
          '(2) make sure a JavaScript runtime (Deno or Node) is on PATH, ' +
          '(3) set a cookies.txt file below.');
    });
  }

  if (!trimming) return downloadFullThenTrim();

  // First try the fast path: let yt-dlp fetch only the requested section.
  // --force-keyframes-at-cuts is deliberately NOT used; it makes ffmpeg abort
  // (e.g. "ffmpeg exited with code 3436169992") on fragmented YouTube streams.
  const range = `*${start || '0'}-${end || 'inf'}`;
  log(`[info] Trimming to range ${range} (needs ffmpeg on PATH).`);
  runLadder(['--download-sections', range], (code, finalPath) => {
    if (code === 0 && finalPath) return finish(finalPath);
    log('[warn] Section download failed — retrying with a full download and an ffmpeg trim.');
    downloadFullThenTrim();
  });
});

// Remember the cookies path between sessions so it does not have to be
// re-entered every time Premiere restarts.
(function initCookiesField() {
  const el = document.getElementById('cookies');
  if (!el) return;
  try {
    const saved = localStorage.getItem('ytPanelCookiesPath');
    if (saved) el.value = saved;
  } catch (e) { /* storage unavailable */ }
  el.addEventListener('change', () => {
    try { localStorage.setItem('ytPanelCookiesPath', el.value.trim()); } catch (e) { /* ignore */ }
  });
})();

checkEnvironment();
