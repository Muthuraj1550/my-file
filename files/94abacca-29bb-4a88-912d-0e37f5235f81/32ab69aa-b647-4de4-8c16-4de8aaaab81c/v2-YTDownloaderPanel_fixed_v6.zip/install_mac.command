#!/bin/bash
set -e
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SRC="$DIR/YTDownloaderPanel"
DEST="/Library/Application Support/Adobe/CEP/extensions/YTDownloaderPanel"

echo "=== YT Downloader Panel installer ==="
if [ ! -d "$SRC" ]; then
  echo "ERROR: YTDownloaderPanel folder not found next to this installer."
  read -p "Press Enter to close..."
  exit 1
fi

echo "This needs your Mac password to copy files into /Library (sudo)."
sudo mkdir -p "/Library/Application Support/Adobe/CEP/extensions"
sudo rm -rf "$DEST"
sudo cp -R "$SRC" "$DEST"
echo "Copied to: $DEST"

echo ""
echo "=== Enabling unsigned-extension debug mode ==="
for v in 8 9 10 11 12; do
  defaults write com.adobe.CSXS.$v PlayerDebugMode 1
done
echo "Done."

echo ""
echo "=== Checking yt-dlp / ffmpeg ==="
if ! command -v yt-dlp >/dev/null 2>&1; then
  echo "yt-dlp not found. Install with: brew install yt-dlp"
else
  echo "yt-dlp OK."
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ffmpeg not found. Install with: brew install ffmpeg"
else
  echo "ffmpeg OK."
fi

echo ""
echo "============================================"
echo "  Install complete!"
echo "  Now: Restart Premiere Pro, then open"
echo "  Window > Extensions > YT Downloader"
echo "============================================"
read -p "Press Enter to close..."
