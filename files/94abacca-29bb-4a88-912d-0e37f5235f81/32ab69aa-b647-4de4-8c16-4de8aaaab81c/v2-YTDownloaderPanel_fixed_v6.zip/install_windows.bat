@echo off
setlocal enabledelayedexpansion
title YT Downloader Panel - Installer

:: --- Self-elevate to admin (needed to write into Program Files) ---
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Requesting administrator permission...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "SRC=%~dp0YTDownloaderPanel"
set "DEST=%CommonProgramFiles(x86)%\Adobe\CEP\extensions\YTDownloaderPanel"

echo.
echo === Copying panel files ===
if not exist "%SRC%" (
    echo ERROR: Could not find YTDownloaderPanel folder next to this installer.
    pause
    exit /b 1
)
xcopy /E /I /Y "%SRC%" "%DEST%" >nul
echo Copied to: %DEST%

echo.
echo === Enabling unsigned-extension debug mode ===
for %%v in (8 9 10 11 12) do (
    reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)
echo Done.

echo.
echo === Checking yt-dlp / ffmpeg ===
where yt-dlp >nul 2>&1
if errorlevel 1 (
    echo yt-dlp not found. Trying to install via winget...
    winget install -e --id yt-dlp.yt-dlp --accept-source-agreements --accept-package-agreements
) else (
    echo yt-dlp OK.
)

where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo ffmpeg not found. Trying to install via winget...
    winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
) else (
    echo ffmpeg OK.
)

echo.
echo ============================================
echo   Install complete!
echo   Now: Restart Premiere Pro, then open
echo   Window ^> Extensions ^> YT Downloader
echo ============================================
pause
