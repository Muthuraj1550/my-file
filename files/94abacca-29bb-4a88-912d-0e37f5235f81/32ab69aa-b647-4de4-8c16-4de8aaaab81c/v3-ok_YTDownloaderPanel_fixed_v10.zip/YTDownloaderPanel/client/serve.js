// ---- Local origin shim (background server only) ----
//
// Why this exists: CEP loads the panel from file://, which has no origin, so
// it sends no Referer header on the request to YouTube — and YouTube's
// embedded player now rejects that with "Error 153" (debug code
// embedder.identity.missing.referrer). referrerpolicy/meta-referrer tags
// don't help; there is no origin for them to forward in the first place.
// The fix is to give the *preview* an http origin.
//
// EARLIER VERSION OF THIS FILE navigated the whole panel from file:// to
// http://127.0.0.1 with location.replace(). That broke Node entirely:
// Adobe's own CEP node-integration has a long history of require()/fs/
// child_process going dead after any top-level navigation in mixed-context
// mode. That's why Search and Download stopped responding — the script that
// wires up those buttons runs its require() calls at the top and never got a
// working Node context after the reload, so none of the click handlers were
// ever attached.
//
// Fix: never navigate. The main panel stays on file:// for its entire life,
// so Node/require never breaks. Only a small, separate page (player.html —
// no Node code, no yt-dlp knowledge) is served over http://127.0.0.1 and
// embedded in an <iframe>. That iframe is the only thing that needs a real
// origin, and it gets one without disturbing anything else.
(function () {
  const http = require('http');
  const fs = require('fs');
  const path = require('path');

  // location.pathname for the file:// panel looks like
  // "/C:/Users/.../client/index.html" on Windows. Strip the leading slash
  // before the drive letter, then normalize so the separator style matches
  // what path.join()/path.normalize() produce everywhere else in this file —
  // comparing un-normalized vs normalized paths is what caused every request
  // to 403 in an earlier version of this file.
  const here = decodeURIComponent(window.location.pathname).replace(/^\/([A-Za-z]:)/, '$1');
  const root = path.normalize(path.dirname(here));
  const norm = (s) => (process.platform === 'win32' ? s.toLowerCase() : s);

  const MIME = {
    '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css',
    '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg',
    '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon'
  };

  const server = http.createServer((req, res) => {
    let rel = decodeURIComponent(req.url.split('?')[0]);
    if (rel === '/') rel = '/player.html';

    const file = path.normalize(path.join(root, path.normalize(rel)));
    const withinRoot = norm(file) === norm(root) || norm(file).indexOf(norm(root) + path.sep) === 0;
    if (!withinRoot) { res.writeHead(403); return res.end('forbidden'); }

    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404); return res.end('not found'); }
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
        'Referrer-Policy': 'strict-origin-when-cross-origin'
      });
      res.end(data);
    });
  });

  window.ytPanelPreviewBase = null; // set once the server is listening

  function listen(port, attemptsLeft) {
    server.once('error', (e) => {
      if (e.code === 'EADDRINUSE' && attemptsLeft > 0) return listen(port + 1, attemptsLeft - 1);
      document.addEventListener('DOMContentLoaded', () => {
        const el = document.getElementById('log');
        if (el) el.textContent += '[warn] Could not start the local preview server (' + e.code +
          '). Downloads still work; the in-panel preview will not.\n';
      });
    });

    server.listen(port, '127.0.0.1', () => {
      window.ytPanelPreviewBase = 'http://127.0.0.1:' + server.address().port;
      window.dispatchEvent(new Event('ytpanel-preview-ready'));
    });
  }

  listen(3777, 10);
})();
