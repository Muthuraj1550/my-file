// Requires CEP Node.js integration (enabled in manifest.xml via --enable-nodejs --mixed-context)
const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs');

const logEl = document.getElementById('log');
const goBtn = document.getElementById('go');

function log(line) {
  logEl.textContent += line + '\n';
  logEl.scrollTop = logEl.scrollHeight;
}

// Minimal wrapper around the CEP host bridge — avoids needing Adobe's full CSInterface.js file.
function evalScript(script, callback) {
  if (window.__adobe_cep__) {
    window.__adobe_cep__.evalScript(script, callback || function () {});
  } else {
    log('[warn] CEP bridge not found — running outside Premiere?');
  }
}

// Format selectors deliberately end in a permissive "/bv*+ba/b" tail. A
// selector that HARD-REQUIRES something (a height cap, or the old
// [protocol^=m3u8] filter) turns "this client returned fewer formats than
// usual" into a fatal "Requested format is not available" instead of just
// downloading whatever is actually there.
function getCookiesFile() {
  const el = document.getElementById('cookies');
  if (!el) return '';
  const p = el.value.trim();
  if (!p) return '';
  if (!fs.existsSync(p)) { log('[warn] cookies.txt path does not exist, ignoring: ' + p); return ''; }
  return p;
}

// Checks the environment as PREMIERE sees it, which is the part that trips
// people up: a CEP panel inherits Premiere's PATH, not the PATH your terminal
// has. yt-dlp working in cmd.exe says nothing about it working here, and a
// missing JS runtime is the single most common cause of an instant 403.
function checkEnvironment() {
  function probe(cmd, args, onResult) {
    let out = '';
    try {
      const p = spawn(cmd, args, { shell: false });
      p.stdout.on('data', (d) => { out += d.toString(); });
      p.on('error', () => onResult(null));
      p.on('close', (code) => onResult(code === 0 ? out.trim().split('\n')[0] : null));
    } catch (e) { onResult(null); }
  }

  probe('yt-dlp', ['--version'], (v) => {
    if (!v) { log('[error] yt-dlp is not reachable from Premiere\'s PATH.'); return; }
    log('[env] yt-dlp ' + v);
  });

  let pending = 3;
  let found = [];
  ['deno', 'node', 'bun'].forEach((rt) => {
    probe(rt, ['--version'], (v) => {
      if (v) found.push(rt);
      if (--pending === 0) {
        if (found.length) {
          log('[env] JavaScript runtime: ' + found.join(', '));
        } else {
          log('[warn] No JavaScript runtime (deno/node/bun) on Premiere\'s PATH.');
          log('[warn] yt-dlp needs one to solve YouTube\'s signature challenge. ' +
              'Without it most downloads 403 instantly. Install Deno or Node, then restart Premiere.');
        }
      }
    });
  });
}

// YouTube's highest-bitrate formats are VP9/AV1 video with Opus audio.
// --merge-output-format mp4 only changes the CONTAINER, not the codec inside
// it — Premiere (especially on Windows, with no extra codec packs) cannot
// decode VP9, AV1, or Opus even when they're wrapped in an .mp4 file, and
// fails on import with "The file has an unsupported compression type."
// So: ask for H.264 (avc1) video + AAC (mp4a) audio FIRST. YouTube keeps an
// H.264 encode at up to 720p for nearly every video, so this is normally a
// free win with no re-encoding. Only if no avc1/mp4a combination exists at
// all do we fall through to "whatever's there" — and importVerified() below
// catches that case and transcodes before Premiere ever sees the file.
function qualityArgs(q) {
  const h264 = (cap) => {
    const capFilter = cap ? `[height<=${cap}]` : '';
    return `bv*[vcodec^=avc1]${capFilter}+ba[acodec^=mp4a]/b[vcodec^=avc1]${capFilter}` +
           `/bv*${capFilter}+ba/b${capFilter}/bv*+ba/b`;
  };
  switch (q) {
    case '1080': return ['-f', h264(1080)];
    case '720': return ['-f', h264(720)];
    case 'audio': return ['-f', 'ba[acodec^=mp4a]/ba/b', '-x', '--audio-format', 'm4a'];
    default: return ['-f', h264()];
  }
}

// YouTube rotates which player clients hand out downloadable URLs, so there is
// no single correct client — only a list to walk. Letting yt-dlp pick is first
// because its built-in default list is updated with every release; the pinned
// clients below are fallbacks for when the defaults are the broken ones.
const CLIENT_ATTEMPTS = [
  { label: 'yt-dlp default clients', args: [] },
  { label: 'tv_simply / tv clients', args: ['--extractor-args', 'youtube:player_client=tv_simply,tv'] },
  { label: 'android_vr client', args: ['--extractor-args', 'youtube:player_client=android_vr'] },
  { label: 'mweb client', args: ['--extractor-args', 'youtube:player_client=mweb'] },
  { label: 'web_safari client', args: ['--extractor-args', 'youtube:player_client=web_safari'] }
];

// ---- Preview player (YouTube IFrame API, in an isolated iframe) ----
// Lets you scrub the video right in the panel and stamp the Start/End fields
// from the playhead instead of typing timecodes by hand.
//
// The player itself lives in client/player.html, served over
// http://127.0.0.1:<port> by serve.js — it needs a real origin or YouTube
// rejects it with Error 153. This document (the main panel) stays on
// file:// for its whole life and only talks to that iframe through
// postMessage; it never navigates itself. An earlier version pointed
// window.location at the http server directly, which broke Node/require for
// the whole panel (see serve.js) and took Search/Download down with it.
const playerWrap = document.getElementById('player-wrap');
const playerFrame = document.getElementById('player');
const playheadEl = document.getElementById('playhead');
let playerReady = false;
let currentVideoId = '';
let pendingVideoId = '';
let rangeStopAt = null;
let lastKnownTime = 0;
let lastKnownState = -1; // mirrors YT.PlayerState; -1 = unstarted

function parseVideoId(url) {
  if (!url) return '';
  const m = url.match(/(?:v=|\/shorts\/|youtu\.be\/|\/embed\/)([A-Za-z0-9_-]{11})/);
  return m ? m[1] : (/^[A-Za-z0-9_-]{11}$/.test(url.trim()) ? url.trim() : '');
}

function toHms(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(Math.floor(sec / 3600))}:${pad(Math.floor((sec % 3600) / 60))}:${pad(sec % 60)}`;
}

function hmsToSec(str) {
  if (!str) return null;
  const parts = str.trim().split(':').map(Number);
  if (parts.some(isNaN)) return null;
  return parts.reduce((acc, p) => acc * 60 + p, 0);
}

function toPlayer(msg) {
  if (playerFrame.contentWindow) playerFrame.contentWindow.postMessage(msg, '*');
}

function loadPreview(url) {
  const id = parseVideoId(url);
  if (!id) { playerWrap.style.display = 'none'; return; }
  if (id === currentVideoId) return;
  currentVideoId = id;
  playerWrap.style.display = 'block';

  if (!window.ytPanelPreviewBase) {
    // Server hasn't finished starting yet (or failed). Queue the id and
    // either pick it up on 'ytpanel-preview-ready' or stay queued if the
    // server never comes up — the rest of the panel keeps working either way.
    pendingVideoId = id;
    log('[preview] Waiting for the local preview server to start\u2026');
    return;
  }

  playerReady = false;
  if (!playerFrame.src) {
    playerFrame.src = window.ytPanelPreviewBase + '/player.html';
    pendingVideoId = id;
  } else {
    toPlayer({ type: 'load', videoId: id });
  }
}

window.addEventListener('ytpanel-preview-ready', () => {
  if (pendingVideoId) loadPreview.call(null, pendingVideoId); // re-check now that the base URL exists
});

window.addEventListener('message', (e) => {
  const msg = e.data || {};
  switch (msg.type) {
    case 'frameLoaded':
      if (pendingVideoId) { toPlayer({ type: 'load', videoId: pendingVideoId }); pendingVideoId = ''; }
      break;
    case 'ready':
      playerReady = true;
      break;
    case 'state':
      lastKnownState = msg.data;
      document.getElementById('playPause').textContent = msg.data === 1 /* PLAYING */ ? 'Pause' : 'Play';
      break;
    case 'time':
      lastKnownTime = msg.sec;
      playheadEl.textContent = toHms(msg.sec);
      if (rangeStopAt !== null && msg.sec >= rangeStopAt) { toPlayer({ type: 'pause' }); rangeStopAt = null; }
      break;
    case 'playerError': {
      const codes = {
        2: 'Invalid video ID.',
        5: 'The video cannot be played in an HTML5 player.',
        100: 'Video not found, private, or removed.',
        101: 'The uploader does not allow this video to be embedded.',
        150: 'The uploader does not allow this video to be embedded.',
        153: 'YouTube did not receive a Referer header. The local preview server may not be running.'
      };
      log('[preview] Player error ' + msg.data + ' \u2014 ' + (codes[msg.data] || 'unknown error.'));
      if (msg.data === 101 || msg.data === 150) {
        log('[preview] Embedding is blocked for this video, but downloading it may still work.');
      }
      break;
    }
    case 'apiError':
      log('[warn] Could not load the YouTube player (no internet access?).');
      break;
  }
});

// Poll the iframe for playhead position; it can't push this on its own
// without a timer on its side too, and keeping the timer here keeps
// player.html as dumb as possible.
setInterval(() => { if (playerReady) toPlayer({ type: 'getTime' }); }, 250);

function seekTo(sec) {
  if (!playerReady) return;
  toPlayer({ type: 'seekTo', sec });
}

document.getElementById('playPause').addEventListener('click', () => {
  if (!playerReady) return;
  rangeStopAt = null;
  toPlayer({ type: lastKnownState === 1 ? 'pause' : 'play' });
});

document.getElementById('setIn').addEventListener('click', () => {
  if (!playerReady) return;
  document.getElementById('start').value = toHms(lastKnownTime);
  log('[in] ' + document.getElementById('start').value);
});

document.getElementById('setOut').addEventListener('click', () => {
  if (!playerReady) return;
  document.getElementById('end').value = toHms(lastKnownTime);
  log('[out] ' + document.getElementById('end').value);
});

document.getElementById('goIn').addEventListener('click', () => {
  const s = hmsToSec(document.getElementById('start').value);
  if (s === null) { log('[warn] No valid In point set.'); return; }
  rangeStopAt = null;
  seekTo(s);
});

document.getElementById('goOut').addEventListener('click', () => {
  const e = hmsToSec(document.getElementById('end').value);
  if (e === null) { log('[warn] No valid Out point set.'); return; }
  rangeStopAt = null;
  seekTo(e);
});

document.getElementById('playRange').addEventListener('click', () => {
  const s = hmsToSec(document.getElementById('start').value) || 0;
  const e = hmsToSec(document.getElementById('end').value);
  if (!playerReady) return;
  rangeStopAt = e !== null && e > s ? e : null;
  seekTo(s);
  toPlayer({ type: 'play' });
});

const urlInput = document.getElementById('url');
urlInput.addEventListener('change', () => loadPreview(urlInput.value.trim()));
urlInput.addEventListener('paste', () => setTimeout(() => loadPreview(urlInput.value.trim()), 0));

// ---- Search ----

const searchInput = document.getElementById('search');
const searchBtn = document.getElementById('searchBtn');
const resultsEl = document.getElementById('results');

function fmtDuration(sec) {
  if (!sec && sec !== 0) return '';
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

function runSearch() {
  const query = searchInput.value.trim();
  if (!query) return;

  resultsEl.style.display = 'block';
  resultsEl.innerHTML = '<div class="result-item">Searching…</div>';
  searchBtn.disabled = true;

  // --flat-playlist keeps this fast (no per-video page fetch); -j prints one JSON object per line.
  const args = [
    `ytsearch12:${query}`,
    '--flat-playlist',
    '-j',
    '--no-warnings'
  ];

  const proc = spawn('yt-dlp', args, { shell: false });
  let out = '';
  let err = '';

  proc.stdout.on('data', (d) => { out += d.toString(); });
  proc.stderr.on('data', (d) => { err += d.toString(); });

  proc.on('error', (e) => {
    resultsEl.innerHTML = '';
    log('[error] Could not start yt-dlp for search — is it installed and on PATH? ' + e.message);
    searchBtn.disabled = false;
  });

  proc.on('close', () => {
    searchBtn.disabled = false;
    const lines = out.split('\n').map(l => l.trim()).filter(Boolean);
    const videos = [];
    lines.forEach(l => {
      try { videos.push(JSON.parse(l)); } catch (e) { /* skip non-JSON noise */ }
    });

    if (!videos.length) {
      resultsEl.innerHTML = '<div class="result-item">No results.</div>';
      if (err) log('[yt-dlp search] ' + err.trim());
      return;
    }

    resultsEl.innerHTML = '';
    videos.forEach(v => {
      const item = document.createElement('div');
      item.className = 'result-item';

      const thumb = document.createElement('img');
      thumb.src = v.thumbnails && v.thumbnails.length ? v.thumbnails[v.thumbnails.length - 1].url : '';
      item.appendChild(thumb);

      const meta = document.createElement('div');
      meta.className = 'result-meta';
      const title = document.createElement('div');
      title.className = 'result-title';
      title.textContent = v.title || '(untitled)';
      const sub = document.createElement('div');
      sub.className = 'result-sub';
      sub.textContent = [v.channel || v.uploader || '', fmtDuration(v.duration)].filter(Boolean).join(' · ');
      meta.appendChild(title);
      meta.appendChild(sub);
      item.appendChild(meta);

      item.addEventListener('click', () => {
        const videoUrl = v.webpage_url || (v.id ? `https://www.youtube.com/watch?v=${v.id}` : '');
        document.getElementById('url').value = videoUrl;
        resultsEl.style.display = 'none';
        resultsEl.innerHTML = '';
        log('Selected: ' + (v.title || videoUrl));
        loadPreview(videoUrl);
      });

      resultsEl.appendChild(item);
    });
  });
}

searchBtn.addEventListener('click', runSearch);
searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') runSearch(); });

// Runs yt-dlp, streaming output to the log. Calls back with (exitCode, finalPath).
function runYtdlp(args, done) {
  log('Running: yt-dlp ' + args.join(' '));

  const proc = spawn('yt-dlp', args, { shell: false });
  let finalPath = '';
  let stdoutBuf = '';
  let errText = '';

  // Process only complete lines. A chunk from 'data' is NOT guaranteed to end
  // on a line boundary, so a long path line (like the one --print
  // after_move:filepath emits) can be split across two chunks. Checking
  // fs.existsSync() on a half-line never matches, which is why the final
  // path could silently fail to be detected even though yt-dlp printed it.
  function handleLine(l) {
    const t = l.trim();
    if (!t) return;
    log(t);
    if (fs.existsSync(t)) finalPath = t;
  }

  proc.stdout.on('data', (d) => {
    stdoutBuf += d.toString();
    const lines = stdoutBuf.split('\n');
    stdoutBuf = lines.pop(); // keep the last (possibly incomplete) line buffered
    lines.forEach(handleLine);
  });

  proc.stderr.on('data', (d) => {
    const t = d.toString();
    errText += t;
    log('[yt-dlp] ' + t.trim());
  });

  proc.on('error', (err) => {
    log('[error] Could not start yt-dlp — is it installed and on PATH? ' + err.message);
    done(-1, '', err.message);
  });

  proc.on('close', (code) => {
    if (stdoutBuf) { handleLine(stdoutBuf); stdoutBuf = ''; } // flush trailing partial line
    if (!finalPath) {
      // Fallback: yt-dlp may not print the path when a section download is
      // stitched by ffmpeg, so pick the newest media file in the run folder.
      try {
        const dir = path.dirname(args[args.indexOf('-o') + 1]);
        const found = fs.readdirSync(dir)
          .filter((f) => !/\.(part|ytdl|temp)$/i.test(f))
          .map((f) => path.join(dir, f))
          .filter((p) => fs.statSync(p).isFile())
          .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
        if (found.length) finalPath = found[0];
      } catch (e) { /* ignore */ }
    }
    done(code, finalPath, errText);
  });
}

// Turns yt-dlp's stderr into the one thing worth doing next. These three
// failures all surface as "download failed" but have completely different
// causes, and guessing wrong costs a lot of retry time.
function diagnose(errText) {
  const e = errText || '';
  if (/Requested format is not available/i.test(e) || /Only images are available/i.test(e)) {
    return 'That client returned no playable formats (storyboard images only) — it was blocked at the extraction step, not the download step.';
  }
  if (/HTTP Error 403/i.test(e)) {
    return 'YouTube refused the media URLs (403). If this happened instantly at 0%, yt-dlp most likely has no JavaScript runtime and cannot sign the URLs correctly.';
  }
  if (/Sign in to confirm|not a bot|age-restricted|private video|members-only/i.test(e)) {
    return 'This video needs a signed-in session — set a cookies.txt file below.';
  }
  return '';
}

// Exact trim with a separate ffmpeg pass. Re-encoding (instead of stream copy)
// keeps the cut frame-accurate without yt-dlp's --force-keyframes-at-cuts,
// which is what crashes ffmpeg on fragmented YouTube streams.
function ffmpegTrim(input, start, end, done) {
  const out = input.replace(/(\.[^.]+)$/, '-trimmed$1');
  const args = ['-y', '-ss', start || '0'];
  if (end) args.push('-to', end);
  args.push('-i', input, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-c:a', 'aac', out);

  log('Running: ffmpeg ' + args.join(' '));
  const proc = spawn('ffmpeg', args, { shell: false });
  proc.stderr.on('data', (d) => {
    const t = d.toString().trim();
    if (/error|invalid|failed/i.test(t)) log('[ffmpeg] ' + t);
  });
  proc.on('error', (err) => {
    log('[error] Could not start ffmpeg — is it installed and on PATH? ' + err.message);
    done('');
  });
  proc.on('close', (code) => {
    if (code !== 0 || !fs.existsSync(out)) { log('[error] ffmpeg trim failed with code ' + code); return done(''); }
    done(out);
  });
}

// Codecs Premiere's Windows media engine decodes without extra codec packs.
// This is deliberately conservative — better to transcode a file that would
// have actually worked than to hand Premiere one that throws "unsupported
// compression type" after the download already took the time.
const PREMIERE_SAFE_VIDEO = ['h264', 'prores', 'dnxhd', 'mpeg2video', 'mpeg4'];
const PREMIERE_SAFE_AUDIO = ['aac', 'pcm_s16le', 'pcm_s24le', 'mp3'];

function ffprobeCodecs(file, done) {
  const proc = spawn('ffprobe', [
    '-v', 'error', '-select_streams', 'v:0,a:0',
    '-show_entries', 'stream=codec_type,codec_name',
    '-of', 'csv=p=0', file
  ], { shell: false });
  let out = '';
  proc.stdout.on('data', (d) => { out += d.toString(); });
  proc.on('error', () => done(null, null)); // ffprobe missing — skip the check, let Premiere decide
  proc.on('close', (code) => {
    if (code !== 0) return done(null, null);
    let v = null, a = null;
    out.trim().split('\n').forEach((line) => {
      const [type, name] = line.split(',');
      if (type === 'video') v = name;
      if (type === 'audio') a = name;
    });
    done(v, a);
  });
}

// Runs right before Premiere import. Only re-encodes when the codec actually
// needs it — most downloads already match PREMIERE_SAFE_* thanks to
// qualityArgs() and skip this entirely.
function importVerified(finalPath) {
  ffprobeCodecs(finalPath, (vcodec, acodec) => {
    const vOk = vcodec === null || PREMIERE_SAFE_VIDEO.includes(vcodec);
    const aOk = acodec === null || PREMIERE_SAFE_AUDIO.includes(acodec);
    if (vOk && aOk) return importToPremiere(finalPath);

    log(`[warn] Downloaded codec (${vcodec || '?'}/${acodec || '?'}) is not one Premiere reads natively — transcoding to H.264/AAC first.`);
    const out = finalPath.replace(/(\.[^.]+)$/, '-h264$1');
    const args = ['-y', '-i', finalPath];
    if (!vOk) args.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18');
    else args.push('-c:v', 'copy');
    if (!aOk) args.push('-c:a', 'aac', '-b:a', '192k');
    else args.push('-c:a', 'copy');
    args.push(out);

    log('Running: ffmpeg ' + args.join(' '));
    const proc = spawn('ffmpeg', args, { shell: false });
    proc.stderr.on('data', (d) => {
      const t = d.toString().trim();
      if (/error|invalid|failed/i.test(t)) log('[ffmpeg] ' + t);
    });
    proc.on('error', (err) => {
      log('[error] Could not start ffmpeg for the compatibility transcode — is it on PATH? ' + err.message);
      log('[warn] Importing the original file anyway; Premiere may reject it.');
      importToPremiere(finalPath);
    });
    proc.on('close', (code) => {
      if (code !== 0 || !fs.existsSync(out)) {
        log('[error] Compatibility transcode failed (code ' + code + '). Importing the original file anyway.');
        return importToPremiere(finalPath);
      }
      importToPremiere(out);
    });
  });
}

function importToPremiere(finalPath) {
  log('Downloaded: ' + finalPath);
  log('Importing into Premiere project...');
  const escaped = finalPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  evalScript(`importClip("${escaped}")`, (result) => {
    log('[premiere] ' + result);
  });
}

goBtn.addEventListener('click', () => {
  const url = document.getElementById('url').value.trim();
  const start = document.getElementById('start').value.trim();
  const end = document.getElementById('end').value.trim();
  const quality = document.getElementById('quality').value;

  if (!url) { log('[error] Paste a YouTube URL first.'); return; }

  // Each run gets its own folder. Without this, a video downloaded once in
  // full gets cached under the same "title-id.ext" filename, so a later
  // request for a trimmed section of the SAME video finds that file already
  // exists and yt-dlp just reuses/skips it — silently returning the earlier
  // full-length download instead of cutting the new range.
  const runId = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
  const outDir = path.join(os.tmpdir(), 'yt-premiere-downloads', runId);
  fs.mkdirSync(outDir, { recursive: true });
  const outTemplate = path.join(outDir, '%(title).60s-%(id)s.%(ext)s');

  function baseArgs(attemptIdx) {
    const args = [
      url,
      '-o', outTemplate,
      '--no-playlist',
      '--merge-output-format', 'mp4',
      '--force-overwrites',
      '--retries', '3',
      '--fragment-retries', '3',
      '--retry-sleep', 'http:2',
      '--print', 'after_move:filepath'
    ];

    const cookies = getCookiesFile();
    if (cookies) args.push('--cookies', cookies);

    return args
      .concat(CLIENT_ATTEMPTS[attemptIdx].args)
      .concat(qualityArgs(quality));
  }

  // Walks the client ladder until one produces a file. Each rung is a genuinely
  // different extraction path, so a failure on one says nothing about the next.
  function runLadder(extraArgs, done, idx) {
    const i = idx || 0;
    const attempt = CLIENT_ATTEMPTS[i];
    log(`[info] Attempt ${i + 1}/${CLIENT_ATTEMPTS.length}: ${attempt.label}`);

    runYtdlp(baseArgs(i).concat(extraArgs || []), (code, finalPath, errText) => {
      if (code === 0 && finalPath) return done(0, finalPath);

      const why = diagnose(errText);
      if (why) log('[diag] ' + why);

      if (i + 1 < CLIENT_ATTEMPTS.length) {
        return runLadder(extraArgs, done, i + 1);
      }
      done(code || 1, '', errText);
    });
  }

  logEl.textContent = '';
  goBtn.disabled = true;
  const trimming = Boolean(start || end);

  function finish(pathOrEmpty) {
    goBtn.disabled = false;
    if (!pathOrEmpty) { log('[warn] Finished, but no usable output file.'); return; }
    importVerified(pathOrEmpty);
  }

  // Full download, then an exact ffmpeg cut. Slower than a section download but
  // it is the path that always works, so it doubles as the fallback.
  function downloadFullThenTrim() {
    function useDownloadedFile(finalPath) {
      if (!trimming) return finish(finalPath);
      ffmpegTrim(finalPath, start, end, (out) => {
        if (!out) {
          goBtn.disabled = false;
          log('[error] The download succeeded, but trimming failed. The full video was not imported.');
          return;
        }
        finish(out);
      });
    }

    runLadder([], (code, finalPath) => {
      if (code === 0 && finalPath) return useDownloadedFile(finalPath);
      goBtn.disabled = false;
      log('[error] Every player client failed.');
      log('[error] Next steps, in order: (1) update yt-dlp to the latest nightly, ' +
          '(2) make sure a JavaScript runtime (Deno or Node) is on PATH, ' +
          '(3) set a cookies.txt file below.');
    });
  }

  if (!trimming) return downloadFullThenTrim();

  // First try the fast path: let yt-dlp fetch only the requested section.
  // --force-keyframes-at-cuts is deliberately NOT used; it makes ffmpeg abort
  // (e.g. "ffmpeg exited with code 3436169992") on fragmented YouTube streams.
  const range = `*${start || '0'}-${end || 'inf'}`;
  log(`[info] Trimming to range ${range} (needs ffmpeg on PATH).`);
  runLadder(['--download-sections', range], (code, finalPath) => {
    if (code === 0 && finalPath) return finish(finalPath);
    log('[warn] Section download failed — retrying with a full download and an ffmpeg trim.');
    downloadFullThenTrim();
  });
});

// Remember the cookies path between sessions so it does not have to be
// re-entered every time Premiere restarts.
(function initCookiesField() {
  const el = document.getElementById('cookies');
  if (!el) return;
  try {
    const saved = localStorage.getItem('ytPanelCookiesPath');
    if (saved) el.value = saved;
  } catch (e) { /* storage unavailable */ }
  el.addEventListener('change', () => {
    try { localStorage.setItem('ytPanelCookiesPath', el.value.trim()); } catch (e) { /* ignore */ }
  });
})();

checkEnvironment();
