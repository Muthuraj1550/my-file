# YT Downloader — Premiere Pro Panel

Paste a YouTube URL, optionally set a start/end trim range, click **Download & Import** —
it downloads only that range (via yt-dlp's `--download-sections`) and drops the clip
straight into your Premiere project bin.

## 1. Prerequisites
- **yt-dlp** and **ffmpeg** installed and on your system PATH.
  - Windows: `winget install yt-dlp` and `winget install ffmpeg` (or place `yt-dlp.exe`/`ffmpeg.exe` somewhere on PATH)
  - Mac: `brew install yt-dlp ffmpeg`
- Test in a terminal: `yt-dlp --version` should print a version, not "command not found".

## 2. Install the panel — easy way (recommended)

1. Unzip the download — you'll see `install_windows.bat`, `install_mac.command`, and the
   `YTDownloaderPanel` folder together in the same place. **Keep them together.**
2. **Windows:** double-click `install_windows.bat`. It will ask for admin permission
   (click Yes) — it copies the panel, turns on debug mode, and checks for yt-dlp/ffmpeg
   automatically.
3. **Mac:** right-click `install_mac.command` → **Open** (first time only, because it's
   unsigned) → **Open** again on the warning popup. Enter your Mac password when asked.
4. Restart Premiere Pro.
5. Open **Window → Extensions → YT Downloader**.

## 2b. Manual install (only if the script above doesn't work)

1. Copy the `YTDownloaderPanel` folder to your CEP extensions directory:
   - **Windows:** `C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\`
   - **Mac:** `/Library/Application Support/Adobe/CEP/extensions/`
2. Since this panel is unsigned, enable debug mode so Premiere will load it:
   - **Windows (Registry):** create/set these to `1` (String value) under
     `HKEY_CURRENT_USER\Software\Adobe\CSXS.9` (use `CSXS.10`/`CSXS.11` etc. matching your
     Premiere version if 9 doesn't work) — key name: `PlayerDebugMode`, value: `1`
   - **Mac (Terminal):**
     `defaults write com.adobe.CSXS.9 PlayerDebugMode 1`
     (adjust the CSXS version number to match your Premiere install)
3. Restart Premiere Pro.
4. Open **Window → Extensions → YT Downloader**.

## 3. Use it
- **Search:** type keywords in the Search box and hit Enter (or click Search) — results show
  thumbnail, title, channel, and duration. Click one to fill in the URL field automatically.
- Or paste a YouTube URL directly, skipping search.
- Leave Start/End blank for the full video, or fill both (e.g. `00:01:10` → `00:02:45`)
  to download just that segment — trimming happens during download, not after.
- Pick a quality.
- Click **Download & Import**. Progress streams into the log box; the clip lands in your
  Premiere project bin automatically when done.

Downloaded files are cached in your OS temp folder under `yt-premiere-downloads/`.

## Notes
- Respect YouTube's Terms of Service and copyright — only download videos you own, have
  rights to, or are otherwise permitted to use.
- If `evalScript` calls fail silently, double-check the `PlayerDebugMode` key matches the
  CSXS version your Premiere build actually uses (check other installed extensions'
  `manifest.xml` `RequiredRuntime` value for reference).
