// Requires CEP Node.js integration (enabled in manifest.xml via --enable-nodejs --mixed-context)
const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs');

const logEl = document.getElementById('log');
const goBtn = document.getElementById('go');

function log(line) {
  logEl.textContent += line + '\n';
  logEl.scrollTop = logEl.scrollHeight;
}

// Minimal wrapper around the CEP host bridge — avoids needing Adobe's full CSInterface.js file.
function evalScript(script, callback) {
  if (window.__adobe_cep__) {
    window.__adobe_cep__.evalScript(script, callback || function () {});
  } else {
    log('[warn] CEP bridge not found — running outside Premiere?');
  }
}

function qualityArgs(q) {
  switch (q) {
    case '1080': return ['-f', 'bv*[height<=1080]+ba/b[height<=1080]'];
    case '720': return ['-f', 'bv*[height<=720]+ba/b[height<=720]'];
    case 'audio': return ['-f', 'ba', '-x', '--audio-format', 'm4a'];
    default: return ['-f', 'bv*+ba/b'];
  }
}

// ---- Search ----
const searchInput = document.getElementById('search');
const searchBtn = document.getElementById('searchBtn');
const resultsEl = document.getElementById('results');

function fmtDuration(sec) {
  if (!sec && sec !== 0) return '';
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

function runSearch() {
  const query = searchInput.value.trim();
  if (!query) return;

  resultsEl.style.display = 'block';
  resultsEl.innerHTML = '<div class="result-item">Searching…</div>';
  searchBtn.disabled = true;

  // --flat-playlist keeps this fast (no per-video page fetch); -j prints one JSON object per line.
  const args = [
    `ytsearch12:${query}`,
    '--flat-playlist',
    '-j',
    '--no-warnings'
  ];

  const proc = spawn('yt-dlp', args, { shell: false });
  let out = '';
  let err = '';

  proc.stdout.on('data', (d) => { out += d.toString(); });
  proc.stderr.on('data', (d) => { err += d.toString(); });

  proc.on('error', (e) => {
    resultsEl.innerHTML = '';
    log('[error] Could not start yt-dlp for search — is it installed and on PATH? ' + e.message);
    searchBtn.disabled = false;
  });

  proc.on('close', () => {
    searchBtn.disabled = false;
    const lines = out.split('\n').map(l => l.trim()).filter(Boolean);
    const videos = [];
    lines.forEach(l => {
      try { videos.push(JSON.parse(l)); } catch (e) { /* skip non-JSON noise */ }
    });

    if (!videos.length) {
      resultsEl.innerHTML = '<div class="result-item">No results.</div>';
      if (err) log('[yt-dlp search] ' + err.trim());
      return;
    }

    resultsEl.innerHTML = '';
    videos.forEach(v => {
      const item = document.createElement('div');
      item.className = 'result-item';

      const thumb = document.createElement('img');
      thumb.src = v.thumbnails && v.thumbnails.length ? v.thumbnails[v.thumbnails.length - 1].url : '';
      item.appendChild(thumb);

      const meta = document.createElement('div');
      meta.className = 'result-meta';
      const title = document.createElement('div');
      title.className = 'result-title';
      title.textContent = v.title || '(untitled)';
      const sub = document.createElement('div');
      sub.className = 'result-sub';
      sub.textContent = [v.channel || v.uploader || '', fmtDuration(v.duration)].filter(Boolean).join(' · ');
      meta.appendChild(title);
      meta.appendChild(sub);
      item.appendChild(meta);

      item.addEventListener('click', () => {
        const videoUrl = v.webpage_url || (v.id ? `https://www.youtube.com/watch?v=${v.id}` : '');
        document.getElementById('url').value = videoUrl;
        resultsEl.style.display = 'none';
        resultsEl.innerHTML = '';
        log('Selected: ' + (v.title || videoUrl));
      });

      resultsEl.appendChild(item);
    });
  });
}

searchBtn.addEventListener('click', runSearch);
searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') runSearch(); });

goBtn.addEventListener('click', () => {
  const url = document.getElementById('url').value.trim();
  const start = document.getElementById('start').value.trim();
  const end = document.getElementById('end').value.trim();
  const quality = document.getElementById('quality').value;

  if (!url) { log('[error] Paste a YouTube URL first.'); return; }

  // Each run gets its own folder. Without this, a video downloaded once in
  // full gets cached under the same "title-id.ext" filename, so a later
  // request for a trimmed section of the SAME video finds that file already
  // exists and yt-dlp just reuses/skips it — silently returning the earlier
  // full-length download instead of cutting the new range.
  const runId = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
  const outDir = path.join(os.tmpdir(), 'yt-premiere-downloads', runId);
  fs.mkdirSync(outDir, { recursive: true });
  const outTemplate = path.join(outDir, '%(title).60s-%(id)s.%(ext)s');

  const args = [
    url,
    '-o', outTemplate,
    '--no-playlist',
    '--merge-output-format', 'mp4',
    '--force-overwrites',
    '--print', 'after_move:filepath'
  ];

  args.push(...qualityArgs(quality));

  // Partial download: trims via yt-dlp + ffmpeg, keyframe-aligned for accurate cuts.
  if (start || end) {
    const range = `*${start || '0'}-${end || 'inf'}`;
    args.push('--download-sections', range, '--force-keyframes-at-cuts');
    log(`[info] Trimming to range ${range} (needs ffmpeg on PATH to cut accurately).`);
  }

  logEl.textContent = '';
  log('Running: yt-dlp ' + args.join(' '));
  goBtn.disabled = true;

  const proc = spawn('yt-dlp', args, { shell: false });
  let finalPath = '';
  let stdoutBuf = '';

  // Process only complete lines. A chunk from 'data' is NOT guaranteed to end
  // on a line boundary, so a long path line (like the one --print
  // after_move:filepath emits) can be split across two chunks. Checking
  // fs.existsSync() on a half-line never matches, which is why the final
  // path could silently fail to be detected even though yt-dlp printed it.
  function handleLine(l) {
    const t = l.trim();
    if (!t) return;
    log(t);
    if (fs.existsSync(t)) finalPath = t;
  }

  proc.stdout.on('data', (d) => {
    stdoutBuf += d.toString();
    const lines = stdoutBuf.split('\n');
    stdoutBuf = lines.pop(); // keep the last (possibly incomplete) line buffered
    lines.forEach(handleLine);
  });

  proc.stderr.on('data', (d) => log('[yt-dlp] ' + d.toString().trim()));

  proc.on('error', (err) => {
    log('[error] Could not start yt-dlp — is it installed and on PATH? ' + err.message);
    goBtn.disabled = false;
  });

  proc.on('close', (code) => {
    if (stdoutBuf) { handleLine(stdoutBuf); stdoutBuf = ''; } // flush any trailing partial line
    goBtn.disabled = false;
    if (code !== 0) { log('[error] yt-dlp exited with code ' + code); return; }
    if (!finalPath) { log('[warn] Finished, but could not detect output file path.'); return; }

    log('Downloaded: ' + finalPath);
    log('Importing into Premiere project...');
    const escaped = finalPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    evalScript(`importClip("${escaped}")`, (result) => {
      log('[premiere] ' + result);
    });
  });
});
