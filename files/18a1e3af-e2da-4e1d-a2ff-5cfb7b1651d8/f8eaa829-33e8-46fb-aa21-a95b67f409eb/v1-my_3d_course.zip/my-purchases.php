<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

require_login();
$user = current_user();
check_and_expire_user($user);

$pageTitle = 'My Purchases';
include __DIR__ . '/includes/header.php';

$purchases = shop_tables_ready() ? my_purchased_products($user['id']) : [];
?>
<h1>My Purchases</h1>
<p style="color:var(--muted,#94a3b8);">Digital files &amp; video courses you've bought. Links stay available here anytime you're logged in.</p>

<?php if (!$purchases): ?>
  <div class="card">
    <p>You haven't purchased anything yet.</p>
    <a href="<?php echo SITE_URL; ?>/products.php" class="btn">Browse Shop</a>
  </div>
<?php else: ?>
  <div class="post-list">
    <?php foreach ($purchases as $p): ?>
      <div class="post-card<?php echo !empty($p['thumbnail']) ? ' post-card-has-thumb' : ''; ?>">
        <?php if (!empty($p['thumbnail'])): ?>
          <div class="post-thumb"><img src="<?php echo h($p['thumbnail']); ?>" alt="<?php echo h($p['title']); ?>" loading="lazy"></div>
        <?php endif; ?>
        <div class="post-card-body">
          <h2><?php echo h($p['title']); ?></h2>
          <div class="post-meta">Purchased <?php echo date('d M Y', strtotime($p['granted_at'])); ?></div>
          <?php if (!empty($p['delivery_link'])): ?>
            <p><a href="<?php echo h($p['delivery_link']); ?>" target="_blank" rel="noopener" class="btn">⬇️ Download / Open</a></p>
            <?php if (!empty($p['delivery_note'])): ?><p style="font-size:13px;color:var(--muted,#94a3b8);"><?php echo h($p['delivery_note']); ?></p><?php endif; ?>
          <?php else: ?>
            <p style="color:var(--muted,#94a3b8);">Download link not set yet - contact support, it'll be added shortly.</p>
          <?php endif; ?>

          <?php if (function_exists('course_license_ready') && course_license_ready() && !empty($p['license_site']) && $p['license_site'] !== 'none'):
            $license = get_user_license($user['id'], $p['id']);
            if ($license): ?>
            <div style="margin-top:12px;padding:12px;border-radius:8px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);">
              <p style="margin:0 0 6px;font-weight:600;">🔑 <?php echo h(license_site_label($license['site'])); ?> Login</p>
              <p style="margin:0;font-size:14px;">Username: <code><?php echo h($license['username']); ?></code></p>
              <p style="margin:2px 0 0;font-size:14px;">Password: <code><?php echo h($license['password']); ?></code></p>
              <p style="margin:6px 0 0;font-size:12px;color:var(--muted,#94a3b8);">Use this to unlock the tool on that site.</p>
            </div>
          <?php endif; endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
