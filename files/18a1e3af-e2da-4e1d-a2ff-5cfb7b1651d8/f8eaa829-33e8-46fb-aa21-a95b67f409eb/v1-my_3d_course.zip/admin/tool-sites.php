<?php
/**
 * Admin -> Tool Sites & Access
 *  - Ovvoru tool site kkum API ID + API key generate pannalaam
 *  - User list: entha user entha site kku access nu kaatum
 *  - Manual ah oru user kku site access kudukkalaam
 */
$adminTitle = 'Tool Sites & Access';
require_once __DIR__ . '/_layout_top.php';
$base = rtrim(SITE_URL, '/');
$msg = null; $err = null; $newKey = null;

if (!tool_sites_ready()) {
    echo '<div class="card"><h3>⚠️ Migration pending</h3><p style="color:var(--muted)">Import <code>migration-tool-sites.sql</code> in phpMyAdmin, then reload this page.</p></div>';
    require_once __DIR__ . '/_layout_bottom.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'add_site') {
        $s = tool_site_create($_POST['site_key'] ?? '', trim($_POST['name'] ?? ''), trim($_POST['site_url'] ?? ''));
        $msg = $s ? 'Site add aachu — API key keezha copy pannunga.' : null;
        $err = $s ? null : 'API ID / Name check pannunga (already irukkalaam).';
    } elseif ($do === 'update_site') {
        db()->prepare("UPDATE tool_sites SET name = ?, site_url = ?, status = ? WHERE site_key = ?")
            ->execute([trim($_POST['name'] ?? ''), trim($_POST['site_url'] ?? ''),
                       ($_POST['status'] ?? 'active') === 'active' ? 'active' : 'disabled', $_POST['site_key'] ?? '']);
        $msg = 'Site update aachu.';
    } elseif ($do === 'regen') {
        $newKey = tool_site_regenerate_key($_POST['site_key'] ?? '');
        $msg = 'Pudhu API key generate aachu — tool site la update pannunga.';
    } elseif ($do === 'delete_site') {
        db()->prepare("DELETE FROM tool_sites WHERE site_key = ?")->execute([$_POST['site_key'] ?? '']);
        $msg = 'Site delete aachu.';
    } elseif ($do === 'grant') {
        $uid = (int)($_POST['user_id'] ?? 0);
        $uname = trim($_POST['username'] ?? '');
        if ($uid && $uname === '') {
            $s = db()->prepare("SELECT username, name FROM users WHERE id = ?"); $s->execute([$uid]);
            $u = $s->fetch();
            $uname = $u['username'] ?? generate_username_from_name($u['name'] ?? ('user' . $uid));
        }
        $row = site_access_grant($_POST['site_key'] ?? '', $uname, trim($_POST['password'] ?? ''), $uid ?: null,
                                 trim($_POST['note'] ?? ''), $_POST['expires_at'] ?? null);
        $msg = $row ? 'Access kuduthaachu → ' . h($row['username']) . ' / ' . h($row['password']) : null;
        $err = $row ? null : 'Username / site select pannunga.';
    } elseif ($do === 'access_status') {
        site_access_set_status((int)($_POST['id'] ?? 0), $_POST['status'] ?? 'revoked');
        $msg = 'Status update aachu.';
    } elseif ($do === 'access_delete') {
        site_access_delete((int)($_POST['id'] ?? 0));
        $msg = 'Manual access remove aachu.';
    }
}

$sites  = tool_sites_all();
$filter = $_GET['site'] ?? 'all';
$users  = site_users_list($filter);
$manual = db()->query("SELECT a.*, u.name AS user_name FROM site_access a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC")->fetchAll();
$allUsers = db()->query("SELECT id, name, username, email FROM users ORDER BY name ASC")->fetchAll();
?>
<?php if ($msg): ?><div class="card" style="border-color:#14b8a6"><b><?php echo $msg; ?></b></div><?php endif; ?>
<?php if ($err): ?><div class="card" style="border-color:#f87171"><b><?php echo h($err); ?></b></div><?php endif; ?>
<?php if ($newKey): ?><div class="card"><b>New API key:</b> <code><?php echo h($newKey); ?></code></div><?php endif; ?>

<div class="card">
  <h3>🌐 Tool sites — API ID + API key</h3>
  <p style="color:var(--muted);font-size:14px;">Ovvoru site kkum thani API key. Antha key ah antha site oda settings la mattum podunga. Endpoints:
    <code><?php echo h($base); ?>/api/verify-license.php</code> · <code><?php echo h($base); ?>/api/license-users.php</code></p>
  <table>
    <tr><th>API ID (site)</th><th>Name</th><th>Site URL</th><th>API key</th><th>Status</th><th></th></tr>
    <?php foreach ($sites as $s): ?>
    <tr>
      <td><code><?php echo h($s['site_key']); ?></code></td>
      <td colspan="4">
        <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
          <input type="hidden" name="do" value="update_site"><input type="hidden" name="site_key" value="<?php echo h($s['site_key']); ?>">
          <input type="text" name="name" value="<?php echo h($s['name']); ?>" style="width:170px">
          <input type="text" name="site_url" value="<?php echo h($s['site_url']); ?>" placeholder="https://..." style="width:210px">
          <input type="text" value="<?php echo h($s['api_key']); ?>" readonly onclick="this.select()" style="width:290px;font-family:monospace;font-size:11px">
          <select name="status" style="width:110px">
            <option value="active" <?php echo $s['status']==='active'?'selected':''; ?>>active</option>
            <option value="disabled" <?php echo $s['status']==='disabled'?'selected':''; ?>>disabled</option>
          </select>
          <button class="btn btn-sm">Save</button>
        </form>
      </td>
      <td style="white-space:nowrap">
        <form method="post" style="display:inline" onsubmit="return confirm('Pudhu key generate panna, palaya key work aagathu. OK?')">
          <input type="hidden" name="do" value="regen"><input type="hidden" name="site_key" value="<?php echo h($s['site_key']); ?>">
          <button class="btn btn-sm">🔄 New key</button>
        </form>
        <form method="post" style="display:inline" onsubmit="return confirm('Delete site?')">
          <input type="hidden" name="do" value="delete_site"><input type="hidden" name="site_key" value="<?php echo h($s['site_key']); ?>">
          <button class="btn btn-sm" style="background:#7f1d1d">🗑</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>

  <h4 style="margin-top:18px;">➕ Pudhu site add pannu</h4>
  <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
    <input type="hidden" name="do" value="add_site">
    <input type="text" name="site_key" placeholder="API ID (e.g. balloon)" required style="width:190px">
    <input type="text" name="name" placeholder="Site name" required style="width:200px">
    <input type="text" name="site_url" placeholder="https://site.my3dgifts.com" style="width:240px">
    <button class="btn">Generate API key</button>
  </form>
</div>

<div class="card">
  <h3>👥 Users — entha site kku access</h3>
  <form method="get" style="margin-bottom:12px;display:flex;gap:8px;align-items:center;">
    <select name="site" style="width:220px" onchange="this.form.submit()">
      <option value="all">All sites</option>
      <?php foreach ($sites as $s): ?>
        <option value="<?php echo h($s['site_key']); ?>" <?php echo $filter===$s['site_key']?'selected':''; ?>><?php echo h($s['name']); ?></option>
      <?php endforeach; ?>
    </select>
    <span style="color:var(--muted);font-size:13px;"><?php echo count($users); ?> users</span>
  </form>
  <table>
    <tr><th>Login username</th><th>Name / Email</th><th>Course / Product</th><th>Access sites</th><th>Last used</th></tr>
    <?php foreach ($users as $u): ?>
    <tr>
      <td><code><?php echo h($u['username']); ?></code></td>
      <td><?php echo h($u['user_name'] ?: '-'); ?><br><span style="color:var(--muted);font-size:12px"><?php echo h($u['email'] ?? ''); ?></span></td>
      <td style="font-size:12.5px"><?php echo h(implode(', ', $u['products']) ?: '-'); ?></td>
      <td>
        <?php if (!$u['sites']): ?><span style="color:var(--muted)">— no access —</span><?php endif; ?>
        <?php foreach ($u['sites'] as $sk => $src): $sn = tool_site_get($sk); ?>
          <span style="display:inline-block;margin:2px;padding:2px 9px;border-radius:20px;font-size:11.5px;background:<?php echo $src==='manual'?'#3a2a12;color:#fbbf24':'#0f2f2b;color:#34d399'; ?>">
            <?php echo h($sn['name'] ?? $sk); ?> · <?php echo $src; ?>
          </span>
        <?php endforeach; ?>
      </td>
      <td style="color:var(--muted);font-size:12px"><?php echo h($u['last_verified_at'] ?: '-'); ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>

<div class="card">
  <h3>✋ Manual ah access kudu</h3>
  <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
    <input type="hidden" name="do" value="grant">
    <select name="site_key" required style="width:190px">
      <option value="">Site select…</option>
      <?php foreach ($sites as $s): ?><option value="<?php echo h($s['site_key']); ?>"><?php echo h($s['name']); ?></option><?php endforeach; ?>
    </select>
    <select name="user_id" style="width:230px">
      <option value="">(Member illa — username type pannunga)</option>
      <?php foreach ($allUsers as $u): ?>
        <option value="<?php echo (int)$u['id']; ?>"><?php echo h($u['name'] . ' — ' . ($u['username'] ?: $u['email'])); ?></option>
      <?php endforeach; ?>
    </select>
    <input type="text" name="username" placeholder="Login username (optional)" style="width:180px">
    <input type="text" name="password" placeholder="Password (blank = auto)" style="width:170px">
    <input type="text" name="note" placeholder="Note / reason" style="width:180px">
    <input type="date" name="expires_at" style="width:150px" title="Expiry (optional)">
    <button class="btn">Access kudu</button>
  </form>

  <table style="margin-top:16px">
    <tr><th>Site</th><th>Username</th><th>Password</th><th>Member</th><th>Note</th><th>Expires</th><th>Status</th><th></th></tr>
    <?php foreach ($manual as $m): $sn = tool_site_get($m['site_key']); ?>
    <tr>
      <td><?php echo h($sn['name'] ?? $m['site_key']); ?></td>
      <td><code><?php echo h($m['username']); ?></code></td>
      <td><code><?php echo h($m['password']); ?></code></td>
      <td><?php echo h($m['user_name'] ?: '-'); ?></td>
      <td style="font-size:12.5px"><?php echo h($m['note'] ?: '-'); ?></td>
      <td style="color:var(--muted);font-size:12px"><?php echo h($m['expires_at'] ?: '∞'); ?></td>
      <td><?php echo h($m['status']); ?></td>
      <td style="white-space:nowrap">
        <form method="post" style="display:inline">
          <input type="hidden" name="do" value="access_status"><input type="hidden" name="id" value="<?php echo (int)$m['id']; ?>">
          <input type="hidden" name="status" value="<?php echo $m['status']==='active'?'revoked':'active'; ?>">
          <button class="btn btn-sm"><?php echo $m['status']==='active'?'Revoke':'Activate'; ?></button>
        </form>
        <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
          <input type="hidden" name="do" value="access_delete"><input type="hidden" name="id" value="<?php echo (int)$m['id']; ?>">
          <button class="btn btn-sm" style="background:#7f1d1d">🗑</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
