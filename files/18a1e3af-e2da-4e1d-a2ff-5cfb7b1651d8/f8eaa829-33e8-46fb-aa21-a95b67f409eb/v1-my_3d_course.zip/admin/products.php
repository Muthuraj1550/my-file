<?php
$adminTitle = 'Products';
require_once __DIR__ . '/_layout_top.php';

if (!shop_tables_ready()) {
?>
  <div class="flash flash-error">
    The Shop isn't set up yet. Go to phpMyAdmin and import <code>migration-products-shop.sql</code>
    (safe on a live site - it only adds new tables, it won't touch your existing data). Then reload this page.
  </div>
<?php
  require_once __DIR__ . '/_layout_bottom.php';
  exit;
}

function admin_upload_image($field, $subdir = '') {
    if (empty($_FILES[$field]['name'])) return null;
    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return null;
    $newName = 'prod_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

/** Optional convenience: admin can also upload the actual deliverable file (STL/zip/etc) and we auto-fill delivery_link with its URL. */
function admin_upload_delivery_file() {
    if (empty($_FILES['delivery_file']['name'])) return null;
    $blocked = media_blocked_extensions();
    $ext = strtolower(pathinfo($_FILES['delivery_file']['name'], PATHINFO_EXTENSION));
    if ($ext === '' || in_array($ext, $blocked, true)) return null;
    $newName = 'file_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES['delivery_file']['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_product'])) {
    csrf_check();
    $title = trim($_POST['title']);
    $img = admin_upload_image('thumbnail_file');
    $deliveryFileUrl = admin_upload_delivery_file();
    $deliveryLink = $deliveryFileUrl ?: trim($_POST['delivery_link']);

    $price = (float) $_POST['price'];
    $salePriceRaw = trim($_POST['sale_price']);
    $salePrice = ($salePriceRaw === '') ? null : (float) $salePriceRaw;

    $data = [
        'title'          => $title,
        'slug'           => unique_slug('products', slugify($title), $_POST['edit_id'] ?: null),
        'type'           => in_array($_POST['type'], ['file','course','software','bundle']) ? $_POST['type'] : 'file',
        'category'       => trim($_POST['category']),
        'short_desc'     => trim($_POST['short_desc']),
        'description'    => trim($_POST['description']),
        'price'          => $price,
        'sale_price'     => $salePrice,
        'delivery_link'  => $deliveryLink,
        'delivery_note'  => trim($_POST['delivery_note']),
        'featured'       => isset($_POST['featured']) ? 1 : 0,
        'status'         => $_POST['status'] === 'published' ? 'published' : 'draft',
        'sort_order'     => (int) $_POST['sort_order'],
    ];

    if (course_license_ready()) {
        $courseId = trim($_POST['course_id'] ?? '');
        $data['course_id']   = $courseId !== '' ? (int)$courseId : null;
        $data['license_site'] = in_array($_POST['license_site'] ?? 'none', ['none','main_editor','litho','both']) ? $_POST['license_site'] : 'none';
    }

    $cols = array_keys($data);
    $setSql = implode(', ', array_map(fn($c) => "$c=?", $cols));

    if (!empty($_POST['edit_id'])) {
        if ($img) {
            db()->prepare("UPDATE products SET $setSql, thumbnail=? WHERE id=?")
                ->execute([...array_values($data), $img, (int)$_POST['edit_id']]);
        } else {
            db()->prepare("UPDATE products SET $setSql WHERE id=?")
                ->execute([...array_values($data), (int)$_POST['edit_id']]);
        }
    } else {
        $insertCols = implode(', ', $cols) . ', thumbnail';
        $placeholders = implode(',', array_fill(0, count($cols) + 1, '?'));
        db()->prepare("INSERT INTO products ($insertCols) VALUES ($placeholders)")
            ->execute([...array_values($data), $img]);
    }
    flash('Product saved.');
    redirect('/admin/products.php');
}

if (isset($_GET['del'])) {
    db()->prepare("DELETE FROM products WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Product deleted.');
    redirect('/admin/products.php');
}

$editProduct = null;
if (!empty($_GET['edit'])) {
    $editProduct = get_product((int)$_GET['edit']);
}
$products = ((($_GET['filter'] ?? '') === 'course'))
    ? db()->query("SELECT * FROM products WHERE type='course' ORDER BY created_at DESC")->fetchAll()
    : db()->query("SELECT * FROM products ORDER BY created_at DESC")->fetchAll();
$recentOrders = db()->query("SELECT po.*, u.name AS user_name, u.email AS user_email, p.title AS product_title
                              FROM product_orders po
                              LEFT JOIN users u ON u.id = po.user_id
                              LEFT JOIN products p ON p.id = po.product_id
                              ORDER BY po.created_at DESC LIMIT 30")->fetchAll();
?>
<div class="card" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
  <a href="?new=course" class="btn">🎓 Add New Course</a>
  <a href="?new=1" class="btn btn-outline">➕ Add New File/Product</a>
  <a href="?filter=course" class="btn btn-outline">📚 View All Courses</a>
  <?php if (!empty($_GET['filter'])): ?><a href="products.php" class="btn btn-outline">✕ Clear Filter</a><?php endif; ?>
</div>

<div class="card">
  <h3><?php echo $editProduct ? 'Edit Product' : (($_GET['new'] ?? '') === 'course' ? 'Add New Course' : 'Add New Product'); ?></h3>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editProduct ? (int)$editProduct['id'] : ''; ?>">

    <label>Title</label>
    <input type="text" name="title" value="<?php echo h($editProduct['title'] ?? ''); ?>" required>

    <label>Type</label>
    <select name="type">
      <?php $defaultType = $editProduct['type'] ?? (($_GET['new'] ?? '') === 'course' ? 'course' : 'file'); ?>
      <?php foreach (['file'=>'Digital File / STL','course'=>'Video Course','software'=>'Software / Tool','bundle'=>'Bundle Pack'] as $val=>$lbl): ?>
        <option value="<?php echo $val; ?>" <?php echo ($defaultType===$val)?'selected':''; ?>><?php echo $lbl; ?></option>
      <?php endforeach; ?>
    </select>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">"Video Course" type = a Course. Once saved, come back and edit any other file/product to attach it here via "Include this in a Course" below.</p>

    <label>Category (used for shop filter tabs, e.g. "3D Design", "Miniature")</label>
    <input type="text" name="category" value="<?php echo h($editProduct['category'] ?? ''); ?>">

    <label>Short Description (shown on shop grid card)</label>
    <input type="text" name="short_desc" value="<?php echo h($editProduct['short_desc'] ?? ''); ?>" maxlength="300">

    <label>Full Description</label>
    <textarea name="description" style="min-height:140px;"><?php echo h($editProduct['description'] ?? ''); ?></textarea>

    <label>Thumbnail Image</label>
    <input type="file" name="thumbnail_file" accept="image/*">
    <?php if (!empty($editProduct['thumbnail'])): ?>
      <img src="<?php echo h($editProduct['thumbnail']); ?>" style="max-width:160px;border-radius:8px;margin-bottom:16px;display:block;">
    <?php endif; ?>

    <div style="display:flex;gap:16px;flex-wrap:wrap;">
      <div style="flex:1;min-width:160px;">
        <label>Price (₹)</label>
        <input type="number" step="0.01" min="0" name="price" value="<?php echo h($editProduct['price'] ?? '0'); ?>" required>
      </div>
      <div style="flex:1;min-width:160px;">
        <label>Sale Price (₹) - optional, leave blank for no discount</label>
        <input type="number" step="0.01" min="0" name="sale_price" value="<?php echo h($editProduct['sale_price'] ?? ''); ?>">
      </div>
    </div>

    <?php if (course_license_ready()): ?>
    <label>Include this in a Course (optional)</label>
    <select name="course_id">
      <option value="">— Not part of a course —</option>
      <?php foreach (all_course_products($editProduct['id'] ?? null) as $c): ?>
        <option value="<?php echo (int)$c['id']; ?>" <?php echo ((int)($editProduct['course_id'] ?? 0) === (int)$c['id']) ? 'selected' : ''; ?>><?php echo h($c['title']); ?></option>
      <?php endforeach; ?>
    </select>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Select a "Video Course" type product here to auto-list this file/page as one of its included items (shows on that course's public page &amp; description, no need to retype it there).</p>

    <label>Site Password / License (auto-generate per buyer)</label>
    <select name="license_site">
      <?php foreach (['none'=>'— None —','main_editor'=>'Main Editor','litho'=>'Litho Studio','both'=>'Main Editor + Litho Studio'] as $val=>$lbl): ?>
        <option value="<?php echo $val; ?>" <?php echo (($editProduct['license_site'] ?? 'none')===$val)?'selected':''; ?>><?php echo $lbl; ?></option>
      <?php endforeach; ?>
    </select>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">If set, a unique username+password is auto-generated for each buyer the moment they get access (payment or free grant) and shown to them on My Purchases. Wire <code>api/verify-license.php</code> into that external site so it can check the password itself.</p>
    <?php else: ?>
    <div class="flash flash-error" style="margin-top:8px;">Course grouping + Site Password isn't set up yet — import <code>migration-course-license.sql</code> in phpMyAdmin, then reload this page.</div>
    <?php endif; ?>

    <h3 style="margin-top:24px;">Delivery (what the buyer gets after payment)</h3>
    <label>Delivery Link (MediaFire / Google Drive / any URL)</label>
    <input type="text" name="delivery_link" value="<?php echo h($editProduct['delivery_link'] ?? ''); ?>" placeholder="https://www.mediafire.com/file/...">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">— OR —</p>
    <label>Upload the file directly (overrides the link above if a file is chosen)</label>
    <input type="file" name="delivery_file">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Best for smaller files (STL/zip/PDF). For large video courses, use a MediaFire/Drive link above instead.</p>
    <label>Delivery Note (optional, e.g. "ZIP password: 1234")</label>
    <input type="text" name="delivery_note" value="<?php echo h($editProduct['delivery_note'] ?? ''); ?>">

    <div style="display:flex;gap:16px;flex-wrap:wrap;margin-top:16px;">
      <div style="flex:1;min-width:160px;">
        <label>Sort Order</label>
        <input type="number" name="sort_order" value="<?php echo h($editProduct['sort_order'] ?? '0'); ?>">
      </div>
      <div style="flex:1;min-width:160px;">
        <label>Status</label>
        <select name="status">
          <option value="published" <?php echo (($editProduct['status'] ?? 'published')==='published')?'selected':''; ?>>Published</option>
          <option value="draft" <?php echo (($editProduct['status'] ?? '')==='draft')?'selected':''; ?>>Draft</option>
        </select>
      </div>
    </div>
    <label style="margin-top:12px;"><input type="checkbox" name="featured" style="width:auto;display:inline-block;" <?php echo !empty($editProduct['featured']) ? 'checked' : ''; ?>> ⭐ Featured (shows first on Shop page)</label>

    <button type="submit" name="save_product" class="btn" style="margin-top:16px;">Save Product</button>
    <?php if ($editProduct): ?><a href="products.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<?php if ($editProduct && ($editProduct['type'] ?? '') === 'course' && course_license_ready()):
  $includedItems = course_included_items($editProduct['id']);
?>
<div class="card">
  <h3>📦 What's Included in this Course (<?php echo count($includedItems); ?>)</h3>
  <p style="color:var(--muted);font-size:13px;">This list is automatic — it shows every product where you picked <b><?php echo h($editProduct['title']); ?></b> in the "Include this in a Course" dropdown. It's also what shows on this course's public page description. To add more, edit that file/product and select this course there.</p>
  <?php if ($includedItems): ?>
    <table>
      <thead><tr><th>Title</th><th>Type</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($includedItems as $it): ?>
        <tr>
          <td><?php echo h($it['title']); ?></td>
          <td><?php echo h(ucfirst($it['type'])); ?></td>
          <td><span class="badge <?php echo $it['status']==='published'?'badge-active':'badge-expired'; ?>"><?php echo h($it['status']); ?></span></td>
          <td><a href="?edit=<?php echo (int)$it['id']; ?>" class="btn btn-sm btn-outline">Edit</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>Nothing included yet — nothing has been pointed at this course.</p>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="card">
  <h3><?php echo (($_GET['filter'] ?? '') === 'course') ? '📚 Courses' : 'All Products'; ?> (<?php echo count($products); ?>)</h3>
  <table>
    <thead><tr><th>Title</th><th>Type</th><th>Price</th><th>Sold</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($products as $p): ?>
      <tr>
        <td>
          <?php echo $p['featured'] ? '⭐ ' : ''; ?><?php echo h($p['title']); ?>
          <?php if (course_license_ready() && !empty($p['course_id'])): $parentCourse = get_product($p['course_id']); ?>
            <br><small style="color:var(--muted)">📦 in course: <?php echo h($parentCourse['title'] ?? '—'); ?></small>
          <?php endif; ?>
          <?php if (course_license_ready() && !empty($p['license_site']) && $p['license_site'] !== 'none'): ?>
            <br><small style="color:var(--muted)">🔑 <?php echo h(license_site_label($p['license_site'])); ?> password auto-generated on purchase</small>
          <?php endif; ?>
        </td>
        <td><?php echo h(ucfirst($p['type'])); ?></td>
        <td>
          <?php if (!empty($p['sale_price']) && (float)$p['sale_price'] < (float)$p['price']): ?>
            <s>₹<?php echo number_format($p['price'],0); ?></s> ₹<?php echo number_format($p['sale_price'],0); ?>
          <?php else: ?>
            ₹<?php echo number_format($p['price'],0); ?>
          <?php endif; ?>
        </td>
        <td><?php echo product_sales_count($p['id']); ?></td>
        <td><span class="badge <?php echo $p['status']==='published'?'badge-active':'badge-expired'; ?>"><?php echo h($p['status']); ?></span></td>
        <td>
          <a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($p['slug']); ?>" target="_blank" class="btn btn-sm btn-outline">View</a>
          <a href="?edit=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <a href="?del=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product? Buyers keep their existing access, but the product page will disappear.');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$products): ?><tr><td colspan="6">No products yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<div class="card">
  <h3>Recent Orders</h3>
  <table>
    <thead><tr><th>Date</th><th>Buyer</th><th>Product</th><th>Amount</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($recentOrders as $o): ?>
      <tr>
        <td><?php echo date('d M Y H:i', strtotime($o['created_at'])); ?></td>
        <td><?php echo h($o['user_name'] ?? '—'); ?><br><span style="color:var(--muted);font-size:12px;"><?php echo h($o['user_email'] ?? ''); ?></span></td>
        <td><?php echo h($o['product_title'] ?? '—'); ?></td>
        <td>₹<?php echo number_format($o['amount'],0); ?></td>
        <td><span class="badge <?php echo $o['status']==='paid'?'badge-active':'badge-expired'; ?>"><?php echo h($o['status']); ?></span></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$recentOrders): ?><tr><td colspan="5">No orders yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
