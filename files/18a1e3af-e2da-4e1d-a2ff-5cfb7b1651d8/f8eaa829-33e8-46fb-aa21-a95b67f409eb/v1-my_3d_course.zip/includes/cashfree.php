<?php
require_once __DIR__ . '/functions.php';

/**
 * Minimal Cashfree Payment Gateway (PG) wrapper using the Orders API.
 * Works in SANDBOX mode out of the box. Switch 'cashfree_mode' setting
 * to 'production' + add live keys in /admin/settings.php when you go live.
 *
 * NOTE: Cashfree occasionally updates their API version string. If order
 * creation fails, check https://docs.cashfree.com/reference/pg-new-apis-endpoint
 * and update 'cashfree_api_version' in Admin > Settings accordingly.
 */

function cashfree_base_url() {
    $mode = get_setting('cashfree_mode', 'sandbox');
    return $mode === 'production'
        ? 'https://api.cashfree.com/pg'
        : 'https://sandbox.cashfree.com/pg';
}

function cashfree_headers() {
    return [
        'Content-Type: application/json',
        'x-client-id: ' . get_setting('cashfree_app_id'),
        'x-client-secret: ' . get_setting('cashfree_secret_key'),
        'x-api-version: ' . get_setting('cashfree_api_version', '2023-08-01'),
    ];
}

/**
 * Create a Cashfree order and return the array response (includes
 * payment_session_id used by the Cashfree JS checkout on the frontend).
 */
function cashfree_create_order($order_id, $amount, $customer) {
    $payload = [
        'order_id'       => $order_id,
        'order_amount'   => (float) $amount,
        'order_currency' => 'INR',
        'customer_details' => [
            'customer_id'    => 'user_' . $customer['id'],
            'customer_name'  => $customer['name'],
            'customer_email' => $customer['email'],
            'customer_phone' => $customer['phone'] ?: '9999999999',
        ],
        'order_meta' => [
            'return_url'   => SITE_URL . '/payment-return.php?order_id={order_id}',
            'notify_url'   => SITE_URL . '/payment-webhook.php',
        ],
    ];

    $ch = curl_init(cashfree_base_url() . '/orders');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => cashfree_headers(),
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 20,
    ]);
    $response = curl_exec($ch);
    $err      = curl_error($ch);
    $code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($err) {
        return ['error' => 'cURL error: ' . $err];
    }
    $data = json_decode($response, true);
    if ($code >= 400) {
        return ['error' => $data['message'] ?? ('Cashfree API error (HTTP ' . $code . ')'), 'raw' => $data];
    }
    return $data;
}

/** Fetch order status directly from Cashfree (used on return_url + webhook verify) */
function cashfree_get_order($order_id) {
    $ch = curl_init(cashfree_base_url() . '/orders/' . urlencode($order_id));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => cashfree_headers(),
        CURLOPT_TIMEOUT        => 20,
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

/**
 * Verify an order directly with Cashfree and, if paid, activate the plan
 * for the user (extending from current expiry if still active, else from
 * today). Idempotent - safe to call multiple times (return_url + webhook
 * both call this; only the first successful call extends the expiry).
 */
function cashfree_verify_and_activate($cf_order_id) {
    $stmt = db()->prepare("SELECT * FROM orders WHERE cf_order_id = ? LIMIT 1");
    $stmt->execute([$cf_order_id]);
    $order = $stmt->fetch();
    if (!$order) {
        // Not a membership order — could be a Tripo coin-pack order (TRPC*)
        // or a digital-product/course order (PROD*).
        return cashfree_verify_and_credit_coins($cf_order_id);
    }

    if ($order['status'] === 'paid') {
        return ['ok' => true, 'msg' => 'Already processed', 'already' => true];
    }

    $cfOrder = cashfree_get_order($cf_order_id);
    $status  = $cfOrder['order_status'] ?? '';

    if ($status !== 'PAID') {
        if (in_array($status, ['EXPIRED', 'TERMINATED'])) {
            db()->prepare("UPDATE orders SET status='failed' WHERE id=?")->execute([$order['id']]);
        }
        return ['ok' => false, 'msg' => 'Order not paid yet (status: ' . $status . ')'];
    }

    // Mark order paid
    db()->prepare("UPDATE orders SET status='paid' WHERE id=?")->execute([$order['id']]);

    // Activate the plan on the user account
    $plan = get_plan($order['plan_id']);
    $stmtU = db()->prepare("SELECT * FROM users WHERE id=?");
    $stmtU->execute([$order['user_id']]);
    $user = $stmtU->fetch();
    if ($plan && $user) {
        $base = (has_active_plan($user) && $user['plan_name'] === $plan['plan_name'])
            ? strtotime($user['plan_expiry'])
            : strtotime(date('Y-m-d'));
        $newExpiry = date('Y-m-d', strtotime('+' . (int)$plan['validity_days'] . ' days', $base));
        db()->prepare("UPDATE users SET plan_id=?, plan_name=?, plan_expiry=? WHERE id=?")
            ->execute([$plan['id'], $plan['plan_name'], $newExpiry, $user['id']]);
        // RESET monthly plan coins — membership coins are a per-cycle
        // allowance, not stacked. Purchased tripo_coins are untouched.
        $bonus = (int)($plan['plan_bonus_coins'] ?? 0);
        db()->prepare("UPDATE users SET plan_coins = ? WHERE id=?")
            ->execute([$bonus, $user['id']]);
    }

    return ['ok' => true, 'msg' => 'Plan activated', 'plan' => $plan['plan_name'] ?? null];
}

/**
 * Verify a Tripo-coin-pack order with Cashfree and, if paid, credit coins
 * to the buyer's balance. Idempotent — only the first successful call
 * credits coins.
 */
function cashfree_verify_and_credit_coins($cf_order_id) {
    $stmt = db()->prepare("SELECT * FROM tripo_coin_orders WHERE cf_order_id = ? LIMIT 1");
    $stmt->execute([$cf_order_id]);
    $order = $stmt->fetch();
    if (!$order) {
        // Not a coin-pack order either — could be a digital-product/course order (PROD*).
        return cashfree_verify_and_grant_product($cf_order_id);
    }

    if ($order['status'] === 'paid') {
        return ['ok' => true, 'msg' => 'Already processed', 'already' => true];
    }

    $cfOrder = cashfree_get_order($cf_order_id);
    $status  = $cfOrder['order_status'] ?? '';
    if ($status !== 'PAID') {
        if (in_array($status, ['EXPIRED', 'TERMINATED'])) {
            db()->prepare("UPDATE tripo_coin_orders SET status='failed' WHERE id=?")->execute([$order['id']]);
        }
        return ['ok' => false, 'msg' => 'Coin order not paid yet (status: ' . $status . ')'];
    }

    // Mark paid + credit coins atomically.
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE tripo_coin_orders SET status='paid' WHERE id=? AND status<>'paid'")->execute([$order['id']]);
        $pdo->prepare("UPDATE users SET tripo_coins = tripo_coins + ? WHERE id=?")
            ->execute([(int)$order['coins'], (int)$order['user_id']]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return ['ok' => false, 'msg' => 'DB error: ' . $e->getMessage()];
    }

    return ['ok' => true, 'msg' => 'Coins credited', 'coins' => (int)$order['coins']];
}

/**
 * Verify a digital-product/course order (order_id starts with "PROD") with
 * Cashfree and, if paid, grant the buyer permanent access (user_products
 * row) so it shows up on my-purchases.php and unlocks any "buyers_only"
 * menu links tied to that product. Idempotent - safe to call more than once.
 */
function cashfree_verify_and_grant_product($cf_order_id) {
    if (!shop_tables_ready()) return ['ok' => false, 'msg' => 'Order not found locally'];

    $stmt = db()->prepare("SELECT * FROM product_orders WHERE cf_order_id = ? LIMIT 1");
    $stmt->execute([$cf_order_id]);
    $order = $stmt->fetch();
    if (!$order) return ['ok' => false, 'msg' => 'Order not found locally'];

    if ($order['status'] === 'paid') {
        return ['ok' => true, 'msg' => 'Already processed', 'already' => true];
    }

    $cfOrder = cashfree_get_order($cf_order_id);
    $status  = $cfOrder['order_status'] ?? '';
    if ($status !== 'PAID') {
        if (in_array($status, ['EXPIRED', 'TERMINATED'])) {
            db()->prepare("UPDATE product_orders SET status='failed' WHERE id=?")->execute([$order['id']]);
        }
        return ['ok' => false, 'msg' => 'Order not paid yet (status: ' . $status . ')'];
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE product_orders SET status='paid' WHERE id=? AND status<>'paid'")->execute([$order['id']]);
        $pdo->prepare("INSERT IGNORE INTO user_products (user_id, product_id, order_id) VALUES (?,?,?)")
            ->execute([(int)$order['user_id'], (int)$order['product_id'], (int)$order['id']]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return ['ok' => false, 'msg' => 'DB error: ' . $e->getMessage()];
    }

    // Auto-generate the Main Editor / Litho Studio login for this buyer, if this product needs one.
    generate_product_license_if_needed((int)$order['user_id'], (int)$order['product_id']);

    $p = get_product($order['product_id']);
    return ['ok' => true, 'msg' => 'Product access granted', 'product' => $p['title'] ?? null, 'product_id' => (int)$order['product_id']];
}
