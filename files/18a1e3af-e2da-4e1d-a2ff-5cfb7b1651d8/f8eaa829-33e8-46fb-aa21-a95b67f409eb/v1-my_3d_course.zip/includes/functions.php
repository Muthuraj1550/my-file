<?php
require_once __DIR__ . '/db.php';

function get_setting($key, $default = '') {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query("SELECT setting_key, setting_value FROM settings") as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function set_setting($key, $value) {
    $stmt = db()->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
                            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    $stmt->execute([$key, $value]);
}

function slugify($text) {
    $text = trim($text);
    // Keep Tamil/unicode letters, convert spaces to hyphens
    $text = preg_replace('/\s+/u', '-', $text);
    $text = preg_replace('/[^\p{L}\p{N}\-]/u', '', $text);
    $text = preg_replace('/-+/', '-', $text);
    $text = trim($text, '-');
    return $text !== '' ? mb_strtolower($text) : 'item-' . time();
}

function unique_slug($table, $base_slug, $ignore_id = null) {
    $slug = $base_slug;
    $i = 1;
    while (true) {
        $sql = "SELECT id FROM $table WHERE slug = ?" . ($ignore_id ? " AND id != ?" : "");
        $params = $ignore_id ? [$slug, $ignore_id] : [$slug];
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        if (!$stmt->fetch()) break;
        $i++;
        $slug = $base_slug . '-' . $i;
    }
    return $slug;
}

function h($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/** Whether the users.username column (migration-username-login.sql) is ready yet. */
function username_login_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT username FROM users LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Turn a member's name into a short lowercase username (letters/numbers only), unique in users.username. */
function generate_username_from_name($name) {
    $base = mb_strtolower(trim($name));
    $base = preg_replace('/[^a-z0-9]+/u', '', $base); // Tamil/unicode names fold to '' - handled below
    if ($base === '') $base = 'member';
    $base = mb_substr($base, 0, 16);
    $username = $base;
    $i = 0;
    while (true) {
        $stmt = db()->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if (!$stmt->fetch()) return $username;
        $i++;
        $username = $base . random_int(100, 999) . ($i > 1 ? $i : '');
    }
}

/** A random, easy-to-read password (no ambiguous 0/O/1/l/I) to hand a new member. */
function generate_random_password($length = 8) {
    $chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    $pass = '';
    for ($i = 0; $i < $length; $i++) $pass .= $chars[random_int(0, strlen($chars) - 1)];
    return $pass;
}

function redirect($path) {
    header('Location: ' . (strpos($path, 'http') === 0 ? $path : SITE_URL . $path));
    exit;
}

function flash($msg, $type = 'success') {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function all_plans() {
    return db()->query("SELECT * FROM plans ORDER BY sort_order ASC, price ASC")->fetchAll();
}

function get_plan($id) {
    $stmt = db()->prepare("SELECT * FROM plans WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function get_plan_by_name($name) {
    $stmt = db()->prepare("SELECT * FROM plans WHERE plan_name = ?");
    $stmt->execute([$name]);
    return $stmt->fetch();
}

/**
 * Downgrade a single user to Free plan if their plan_expiry has passed.
 * Called on login and dashboard load (lightweight, no cron needed on
 * shared hosting, but you can also wire this to a real cron hitting
 * /cron/expire.php for site-wide sweeps).
 */
function check_and_expire_user(&$user) {
    if (!$user || empty($user['plan_expiry'])) return;
    if (strtotime($user['plan_expiry']) < strtotime(date('Y-m-d'))) {
        $free = get_plan_by_name('Free');
        $stmt = db()->prepare("UPDATE users SET plan_id = ?, plan_name = 'Free', plan_expiry = ? WHERE id = ?");
        $stmt->execute([$free ? $free['id'] : null, date('Y-m-d', strtotime('+100 years')), $user['id']]);
        $user['plan_name']   = 'Free';
        $user['plan_expiry'] = date('Y-m-d', strtotime('+100 years'));
    }
}

/** Today's AI usage count for a logged-in user */
function ai_usage_today($user_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM ai_usage_log WHERE user_id = ? AND DATE(used_at) = CURDATE()");
    $stmt->execute([$user_id]);
    return (int) $stmt->fetch()['c'];
}

/** Today's AI usage count for an anonymous guest (tracked by cookie id) */
function ai_usage_today_guest($guest_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM ai_usage_log WHERE guest_id = ? AND user_id IS NULL AND DATE(used_at) = CURDATE()");
    $stmt->execute([$guest_id]);
    return (int) $stmt->fetch()['c'];
}

/** Daily AI limit for guests (not logged in), configurable in Admin > Settings */
function ai_daily_limit_guest() {
    return (int) get_setting('guest_ai_daily_limit', 2);
}

/** Log one AI generation - user_id if logged in, else guest_id */
function log_ai_usage($user_id, $guest_id, $prompt) {
    $stmt = db()->prepare("INSERT INTO ai_usage_log (user_id, guest_id, prompt, ip_address) VALUES (?,?,?,?)");
    $stmt->execute([$user_id ?: null, $user_id ? null : $guest_id, mb_substr(trim($prompt), 0, 500), $_SERVER['REMOTE_ADDR'] ?? '']);
}

/** Effective daily AI limit for a user (per-user override wins, else plan limit) */
function ai_daily_limit_for($user) {
    if (!empty($user['ai_limit_override'])) return (int) $user['ai_limit_override'];
    $plan = get_plan_by_name($user['plan_name']);
    return $plan ? (int) $plan['ai_daily_limit'] : 3;
}

function is_premium_designer_user($user) {
    if (!$user) return false;
    $plan = get_plan_by_name($user['plan_name']);
    return $plan && (int)$plan['premium_designer'] === 1 && has_active_plan($user);
}

/** Has this member purchased at least one "Course" type product? (grants full Designer access below) */
function user_has_course_access($user) {
    if (!$user || !shop_tables_ready()) return false;
    $stmt = db()->prepare("SELECT 1 FROM user_products up
                            JOIN products p ON p.id = up.product_id
                            WHERE up.user_id = ? AND p.type = 'course' LIMIT 1");
    $stmt->execute([(int)$user['id']]);
    return (bool) $stmt->fetch();
}

/** Full Designer access (premium templates, higher AI limit path) - paid plan OR a purchased course. */
function has_full_designer_access($user) {
    if (!$user) return false;
    return is_premium_designer_user($user) || user_has_course_access($user);
}

/* ---------------------------------------------------------
 * Cloud Project Save + Recovery (login-based, capped at 10MB/user)
 * --------------------------------------------------------- */

const CLOUD_PROJECT_STORAGE_CAP_BYTES = 10 * 1024 * 1024; // 10 MB total per user
const CLOUD_PROJECT_AUTO_SLOT = '__auto__';

/** How many EXTRA named "Save As" slots (beyond the always-on auto-save) this user's plan allows. */
function get_user_named_slot_limit($user) {
    if (!$user) return 0;
    if (!has_active_plan($user)) return 0;
    $plan = get_plan_by_name($user['plan_name']);
    return $plan ? (int)($plan['project_slots'] ?? 0) : 0;
}

/** Whether the saved_projects table (migration-cloud-projects.sql) has been set up yet. */
function cloud_projects_table_ready() {
    static $ready = null;
    if ($ready === null) {
        try {
            db()->query("SELECT 1 FROM saved_projects LIMIT 1");
            $ready = true;
        } catch (Exception $e) {
            $ready = false;
        }
    }
    return $ready;
}

/** Counts for Admin > Analytics: how many cloud-saved projects exist, by how many members, and total size. */
function cloud_project_stats() {
    if (!cloud_projects_table_ready()) {
        return ['total' => 0, 'auto' => 0, 'named' => 0, 'users' => 0, 'bytes' => 0];
    }
    $row = db()->query("SELECT
        COUNT(*) total,
        SUM(slot_name = '" . CLOUD_PROJECT_AUTO_SLOT . "') auto,
        SUM(slot_name != '" . CLOUD_PROJECT_AUTO_SLOT . "') named,
        COUNT(DISTINCT user_id) users,
        COALESCE(SUM(size_bytes),0) bytes
        FROM saved_projects")->fetch();
    return [
        'total' => (int)($row['total'] ?? 0),
        'auto'  => (int)($row['auto'] ?? 0),
        'named' => (int)($row['named'] ?? 0),
        'users' => (int)($row['users'] ?? 0),
        'bytes' => (int)($row['bytes'] ?? 0),
    ];
}

/* ---------------------------------------------------------
 * Analytics: post/page views + time spent
 * --------------------------------------------------------- */

/**
 * Classify an HTTP Referer URL into a human-friendly traffic source bucket,
 * e.g. 'Google Search', 'YouTube', 'Facebook / Instagram', 'Direct / App',
 * or the referring domain itself for anything else.
 */
function classify_referrer($refererUrl) {
    $refererUrl = trim((string)$refererUrl);
    if ($refererUrl === '') return 'Direct / App';
    $host = parse_url($refererUrl, PHP_URL_HOST);
    if (!$host) return 'Direct / App';
    $host = strtolower(preg_replace('/^www\./', '', $host));

    // Own site linking to itself shouldn't count as external traffic.
    $siteHost = strtolower(preg_replace('/^www\./', '', (string)parse_url(SITE_URL, PHP_URL_HOST)));
    if ($siteHost && $host === $siteHost) return 'Internal (same site)';

    $map = [
        'google.'      => 'Google Search',
        'bing.'        => 'Bing Search',
        'yahoo.'       => 'Yahoo Search',
        'duckduckgo.'  => 'DuckDuckGo Search',
        'youtube.'     => 'YouTube',
        'youtu.be'     => 'YouTube',
        'facebook.'    => 'Facebook / Instagram',
        'instagram.'   => 'Facebook / Instagram',
        'fb.'          => 'Facebook / Instagram',
        'wa.me'        => 'WhatsApp',
        'whatsapp.'    => 'WhatsApp',
        'twitter.'     => 'Twitter / X',
        'x.com'        => 'Twitter / X',
        't.co'         => 'Twitter / X',
        'linkedin.'    => 'LinkedIn',
        'pinterest.'   => 'Pinterest',
        'telegram.'    => 'Telegram',
        't.me'         => 'Telegram',
    ];
    foreach ($map as $needle => $label) {
        if (strpos($host, $needle) !== false) return $label;
    }
    return 'Other site: ' . $host;
}

/** Record a fresh view for a post/page/tool/etc and return the new row id (used to later update duration). */
function record_view($type, $content_id) {
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $source  = classify_referrer($referer);
    try {
        $stmt = db()->prepare("INSERT INTO content_views (content_type, content_id, ip_address, referrer_url, referrer_source) VALUES (?,?,?,?,?)");
        $stmt->execute([$type, $content_id, $_SERVER['REMOTE_ADDR'] ?? '', mb_substr($referer, 0, 500), $source]);
    } catch (Exception $e) {
        // referrer_url/referrer_source columns not migrated yet on this install -
        // fall back to the original columns so tracking still works.
        $stmt = db()->prepare("INSERT INTO content_views (content_type, content_id, ip_address) VALUES (?,?,?)");
        $stmt->execute([$type, $content_id, $_SERVER['REMOTE_ADDR'] ?? '']);
    }
    return db()->lastInsertId();
}

/** Record one click on a Tool Lab card (content_type='tool_click', content_id=tools.id). */
function record_tool_click($tool_id) {
    return record_view('tool_click', (int)$tool_id);
}

/** Click counts per tool: [tool_id => clicks] */
function tool_click_counts() {
    $stmt = db()->query("SELECT content_id, COUNT(*) c FROM content_views WHERE content_type='tool_click' GROUP BY content_id");
    $map = [];
    foreach ($stmt->fetchAll() as $r) $map[(int)$r['content_id']] = (int)$r['c'];
    return $map;
}

/** Total Tool Lab clicks across all tools */
function total_tool_clicks() {
    return (int) db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='tool_click'")->fetch()['c'];
}

/**
 * Traffic-source breakdown across all page views (post/page/designer/tool
 * page loads), grouped by classified source, most recent $days days
 * (0 = all time). Used by Admin > Analytics.
 */
function traffic_source_breakdown($days = 30) {
    if (!content_views_referrer_ready()) return [];
    $sql = "SELECT COALESCE(NULLIF(referrer_source,''),'Direct / App') AS source, COUNT(*) c
            FROM content_views
            WHERE content_type <> 'tool_click'";
    if ($days > 0) $sql .= " AND created_at >= NOW() - INTERVAL " . (int)$days . " DAY";
    $sql .= " GROUP BY source ORDER BY c DESC";
    return db()->query($sql)->fetchAll();
}

/** Whether content_views.referrer_source (migration-traffic-source.sql) has been added yet. */
function content_views_referrer_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT referrer_source FROM content_views LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Update how many seconds a visitor stayed on the page (called via sendBeacon on unload). */
function update_view_duration($view_id, $type, $seconds) {
    $seconds = max(0, min(3600, (int)$seconds)); // sanity clamp: 0 to 1 hour
    $stmt = db()->prepare("UPDATE content_views SET duration_seconds = ? WHERE id = ? AND content_type = ?");
    $stmt->execute([$seconds, (int)$view_id, $type]);
}

/** Total view count for one piece of content */
function view_count($type, $content_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM content_views WHERE content_type=? AND content_id=?");
    $stmt->execute([$type, $content_id]);
    return (int) $stmt->fetch()['c'];
}

/** Average minutes spent for one piece of content */
function avg_minutes($type, $content_id) {
    $stmt = db()->prepare("SELECT AVG(duration_seconds) a FROM content_views WHERE content_type=? AND content_id=? AND duration_seconds > 0");
    $stmt->execute([$type, $content_id]);
    $a = $stmt->fetch()['a'];
    return $a ? round($a / 60, 1) : 0;
}

/** Top posts or pages ranked by view count, with total minutes and avg minutes */
function top_content($type, $limit = 10) {
    $table = $type === 'post' ? 'posts' : 'pages';
    $sql = "SELECT c.title, c.slug,
                   COUNT(v.id) AS views,
                   COALESCE(SUM(v.duration_seconds), 0) AS total_seconds,
                   COALESCE(AVG(NULLIF(v.duration_seconds,0)), 0) AS avg_seconds
            FROM $table c
            LEFT JOIN content_views v ON v.content_type = ? AND v.content_id = c.id
            GROUP BY c.id
            ORDER BY views DESC, c.created_at DESC
            LIMIT " . (int)$limit;
    $stmt = db()->prepare($sql);
    $stmt->execute([$type]);
    return $stmt->fetchAll();
}

/** View counts map [content_id => views] for a whole table, used in admin list pages */
function view_counts_map($type) {
    $stmt = db()->prepare("SELECT content_id, COUNT(*) c FROM content_views WHERE content_type=? GROUP BY content_id");
    $stmt->execute([$type]);
    $map = [];
    foreach ($stmt->fetchAll() as $r) $map[$r['content_id']] = (int)$r['c'];
    return $map;
}

/** Aggregate usage stats for the 3D Designer page (content_id is always 0 - single page, no rows) */
function designer_analytics() {
    $total = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer'")->fetch()['c'];
    $last7 = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer' AND created_at >= NOW() - INTERVAL 7 DAY")->fetch()['c'];
    $today = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer' AND DATE(created_at)=CURDATE()")->fetch()['c'];
    $avgSec = db()->query("SELECT AVG(NULLIF(duration_seconds,0)) a FROM content_views WHERE content_type='designer'")->fetch()['a'];
    $totalSec = db()->query("SELECT COALESCE(SUM(duration_seconds),0) s FROM content_views WHERE content_type='designer'")->fetch()['s'];
    return [
        'total_views' => (int)$total,
        'views_7d'    => (int)$last7,
        'views_today' => (int)$today,
        'avg_seconds' => $avgSec ? (float)$avgSec : 0,
        'total_seconds' => (int)$totalSec,
    ];
}

/** Whether the posts.is_pinned column (migration-post-pin.sql) has been added yet. */
function posts_pin_column_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT is_pinned FROM posts LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/* ---------------------------------------------------------
 * Media / File Manager (admin/filemanager.php) - shared uploads/ folder
 * --------------------------------------------------------- */

/** File extensions the media manager will never allow (mirrors uploads/.htaccess deny list, plus other script types). */
function media_blocked_extensions() {
    return ['php','phtml','php3','php4','php5','php7','phar','pht','cgi','pl','py','exe','sh','asp','aspx','jsp','htaccess'];
}

/** Human-readable file size, e.g. "482 KB" / "1.3 MB". */
function format_file_size($bytes) {
    $bytes = (float)$bytes;
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 1) . ' GB';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024)       return round($bytes / 1024, 1) . ' KB';
    return $bytes . ' B';
}

/* ---------------------------------------------------------
 * Menu items (home page top navigation, admin-editable)
 * --------------------------------------------------------- */

function active_menu_items() {
    return db()->query("SELECT * FROM menu_items WHERE is_active = 1 ORDER BY sort_order ASC, id ASC")->fetchAll();
}

function all_menu_items() {
    return db()->query("SELECT * FROM menu_items ORDER BY sort_order ASC, id ASC")->fetchAll();
}

function get_menu_item($id) {
    $stmt = db()->prepare("SELECT * FROM menu_items WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/* ---------------------------------------------------------
 * Digital Products / Shop (products, product_orders, user_products)
 * --------------------------------------------------------- */

/** Whether the products-shop migration (migration-products-shop.sql) has run yet. */
function shop_tables_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT 1 FROM products LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

function all_products($onlyPublished = true, $category = null) {
    if (!shop_tables_ready()) return [];
    $sql = "SELECT * FROM products";
    $where = [];
    $params = [];
    if ($onlyPublished) $where[] = "status='published'";
    if ($category) { $where[] = "category = ?"; $params[] = $category; }
    if ($where) $sql .= " WHERE " . implode(' AND ', $where);
    $sql .= " ORDER BY featured DESC, sort_order ASC, created_at DESC";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function get_product($id) {
    $stmt = db()->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([(int)$id]);
    return $stmt->fetch();
}

function get_product_by_slug($slug) {
    $stmt = db()->prepare("SELECT * FROM products WHERE slug = ?");
    $stmt->execute([$slug]);
    return $stmt->fetch();
}

function product_categories() {
    if (!shop_tables_ready()) return [];
    return db()->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category <> '' ORDER BY category ASC")->fetchAll(PDO::FETCH_COLUMN);
}

/** The price to actually charge - sale_price if set and lower, else price. */
function product_effective_price($p) {
    if ($p['sale_price'] !== null && $p['sale_price'] !== '' && (float)$p['sale_price'] > 0 && (float)$p['sale_price'] < (float)$p['price']) {
        return (float)$p['sale_price'];
    }
    return (float)$p['price'];
}

/** Does this user already own (purchased / was granted) this product? */
function user_owns_product($user_id, $product_id) {
    if (!$user_id || !shop_tables_ready()) return false;
    $stmt = db()->prepare("SELECT 1 FROM user_products WHERE user_id = ? AND product_id = ? LIMIT 1");
    $stmt->execute([(int)$user_id, (int)$product_id]);
    return (bool) $stmt->fetch();
}

/** All products a member has purchased/been granted, most recent first. */
function my_purchased_products($user_id) {
    if (!$user_id || !shop_tables_ready()) return [];
    $stmt = db()->prepare("SELECT p.*, up.granted_at FROM user_products up
                            JOIN products p ON p.id = up.product_id
                            WHERE up.user_id = ? ORDER BY up.granted_at DESC");
    $stmt->execute([(int)$user_id]);
    return $stmt->fetchAll();
}

/** Grant a product to a user immediately (used for free products, and after payment confirms). Idempotent. */
function grant_product_to_user($user_id, $product_id, $order_id = null) {
    $stmt = db()->prepare("INSERT IGNORE INTO user_products (user_id, product_id, order_id) VALUES (?,?,?)");
    $stmt->execute([(int)$user_id, (int)$product_id, $order_id ? (int)$order_id : null]);
    // If this product is set up to unlock the Main Editor / Litho Studio site,
    // auto-generate that buyer's login for it (no-op if already generated, or
    // if migration-course-license.sql hasn't been run yet).
    generate_product_license_if_needed($user_id, $product_id);
}

/* ---------------------------------------------------------
 * Courses (a product with type='course' groups other products
 * as its "included items") + Site License (auto password for
 * Main Editor / Litho Studio) - migration-course-license.sql
 * --------------------------------------------------------- */

/** Whether migration-course-license.sql has been run yet. */
function course_license_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT course_id, license_site FROM products LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** All published products included inside a course (products whose course_id points at it). */
function course_included_items($course_product_id) {
    if (!course_license_ready()) return [];
    $stmt = db()->prepare("SELECT * FROM products WHERE course_id = ? ORDER BY sort_order ASC, created_at ASC");
    $stmt->execute([(int)$course_product_id]);
    return $stmt->fetchAll();
}

/** All products with type='course', for the "Include this in a course" dropdown. */
function all_course_products($ignore_id = null) {
    if (!course_license_ready()) return [];
    $sql = "SELECT id, title FROM products WHERE type = 'course'";
    $params = [];
    if ($ignore_id) { $sql .= " AND id != ?"; $params[] = (int)$ignore_id; }
    $sql .= " ORDER BY title ASC";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/** Label shown in admin for a product's license_site setting. */
function license_site_label($site) {
    $labels = ['none' => '—', 'main_editor' => 'Main Editor', 'litho' => 'Litho Studio', 'both' => 'Main Editor + Litho Studio'];
    return $labels[$site] ?? '—';
}

/** Existing license row for this user+product, if any. */
function get_user_license($user_id, $product_id) {
    if (!course_license_ready() || !$user_id) return null;
    $stmt = db()->prepare("SELECT * FROM product_licenses WHERE user_id = ? AND product_id = ? LIMIT 1");
    $stmt->execute([(int)$user_id, (int)$product_id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * If this product is flagged with a license_site (main_editor/litho/both),
 * auto-generate a unique username+password for this buyer so the Main
 * Editor / Litho Studio site can grant them access. Idempotent - only
 * generates once per user+product (UNIQUE KEY user_product).
 */
function generate_product_license_if_needed($user_id, $product_id) {
    if (!course_license_ready() || !$user_id) return null;
    $product = get_product($product_id);
    if (!$product || empty($product['license_site']) || $product['license_site'] === 'none') return null;

    $existing = get_user_license($user_id, $product_id);
    if ($existing) return $existing;

    $stmtU = db()->prepare("SELECT * FROM users WHERE id = ?");
    $stmtU->execute([(int)$user_id]);
    $user = $stmtU->fetch();
    if (!$user) return null;

    // Base the license username on the buyer's own username/name, fall back to a product-based one.
    $base = !empty($user['username'] ?? null) ? $user['username'] : generate_username_from_name($user['name'] ?? ('buyer' . $user_id));
    $licenseUsername = $base;
    $i = 0;
    while (true) {
        $stmt = db()->prepare("SELECT id FROM product_licenses WHERE username = ?");
        $stmt->execute([$licenseUsername]);
        if (!$stmt->fetch()) break;
        $i++;
        $licenseUsername = $base . $i;
    }
    $password = generate_random_password(10);

    db()->prepare("INSERT IGNORE INTO product_licenses (user_id, product_id, site, username, password) VALUES (?,?,?,?,?)")
        ->execute([(int)$user_id, (int)$product_id, $product['license_site'], $licenseUsername, $password]);

    return get_user_license($user_id, $product_id);
}

/** Verify a username+password against product_licenses for a given site ('main_editor' or 'litho'). Used by api/verify-license.php. */
function verify_product_license($username, $password, $site) {
    if (!course_license_ready()) return null;
    $stmt = db()->prepare("SELECT * FROM product_licenses
                            WHERE username = ? AND password = ? AND status = 'active'
                              AND (site = ? OR site = 'both') LIMIT 1");
    $stmt->execute([trim($username), trim($password), $site]);
    $row = $stmt->fetch();
    if ($row) {
        db()->prepare("UPDATE product_licenses SET last_verified_at = NOW() WHERE id = ?")->execute([$row['id']]);
    }
    return $row ?: null;
}

/** Count of paid orders for a product (used in admin listing). */
function product_sales_count($product_id) {
    if (!shop_tables_ready()) return 0;
    $stmt = db()->prepare("SELECT COUNT(*) c FROM user_products WHERE product_id = ?");
    $stmt->execute([(int)$product_id]);
    return (int) $stmt->fetch()['c'];
}

/* ---------------------------------------------------------
 * Menu visibility gating (Admin > Menu: everyone / members_only / buyers_only)
 * --------------------------------------------------------- */

/** Whether menu_items has the visibility/required_product_id columns yet. */
function menu_visibility_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT visibility, required_product_id FROM menu_items LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Filter a list of menu_items rows down to the ones this visitor (guest or logged-in $user) should see. */
function visible_menu_items($items, $user) {
    if (!menu_visibility_ready()) return $items; // migration not run yet - show everything (old behaviour)
    $out = [];
    foreach ($items as $m) {
        $vis = $m['visibility'] ?? 'everyone';
        if ($vis === 'everyone') {
            $out[] = $m;
        } elseif ($vis === 'members_only') {
            if ($user) $out[] = $m;
        } elseif ($vis === 'buyers_only') {
            if ($user && !empty($m['required_product_id']) && user_owns_product($user['id'], $m['required_product_id'])) {
                $out[] = $m;
            }
        } else {
            $out[] = $m;
        }
    }
    return $out;
}

/* ---------------------------------------------------------
 * Contact / enquiry form leads (admin/leads.php manages)
 * --------------------------------------------------------- */

function leads_table_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT 1 FROM form_submissions LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

function unread_leads_count() {
    if (!leads_table_ready()) return 0;
    return (int) db()->query("SELECT COUNT(*) c FROM form_submissions WHERE is_read = 0")->fetch()['c'];
}

/* ---------------------------------------------------------
 * Tool Sites (per-site API keys) + manual access grants
 * migration-tool-sites.sql
 * --------------------------------------------------------- */

/** Whether migration-tool-sites.sql has been run. */
function tool_sites_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT 1 FROM tool_sites LIMIT 1"); db()->query("SELECT 1 FROM site_access LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** All registered tool sites. */
function tool_sites_all($only_active = false) {
    if (!tool_sites_ready()) return [];
    $sql = "SELECT * FROM tool_sites" . ($only_active ? " WHERE status='active'" : "") . " ORDER BY name ASC";
    return db()->query($sql)->fetchAll();
}

function tool_site_get($site_key) {
    if (!tool_sites_ready()) return null;
    $stmt = db()->prepare("SELECT * FROM tool_sites WHERE site_key = ? LIMIT 1");
    $stmt->execute([trim((string)$site_key)]);
    return $stmt->fetch() ?: null;
}

/** New random API key for a tool site. */
function tool_site_new_api_key() {
    return bin2hex(random_bytes(24));
}

function tool_site_create($site_key, $name, $site_url = '') {
    $site_key = strtolower(preg_replace('/[^a-z0-9_\-]/i', '', (string)$site_key));
    if ($site_key === '' || $name === '') return null;
    db()->prepare("INSERT IGNORE INTO tool_sites (site_key, name, site_url, api_key) VALUES (?,?,?,?)")
        ->execute([$site_key, $name, $site_url, tool_site_new_api_key()]);
    return tool_site_get($site_key);
}

function tool_site_regenerate_key($site_key) {
    $key = tool_site_new_api_key();
    db()->prepare("UPDATE tool_sites SET api_key = ? WHERE site_key = ?")->execute([$key, $site_key]);
    return $key;
}

/**
 * Authenticate an incoming API call.
 * Returns the site_key the caller may use, or null.
 *  - APP_SECRET  -> master key, may ask about any site
 *  - a tool_sites.api_key -> locked to that one site
 */
function tool_site_auth($api_key, $requested_site = null) {
    $api_key = (string)$api_key;
    if ($api_key === '') return null;
    if (hash_equals(APP_SECRET, $api_key)) {
        return ['site' => $requested_site ?: 'all', 'master' => true];
    }
    if (!tool_sites_ready()) return null;
    $stmt = db()->prepare("SELECT * FROM tool_sites WHERE api_key = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$api_key]);
    $row = $stmt->fetch();
    if (!$row) return null;
    if ($requested_site && $requested_site !== 'all' && $requested_site !== $row['site_key']) return null;
    return ['site' => $row['site_key'], 'master' => false, 'row' => $row];
}

/** Expand a product_licenses.site value into a list of site keys. */
function license_sites_expand($site) {
    if ($site === 'both') return ['main_editor', 'litho'];
    return $site ? [$site] : [];
}

/** Manually grant a user access to a site. Returns the access row. */
function site_access_grant($site_key, $username, $password = null, $user_id = null, $note = '', $expires_at = null) {
    if (!tool_sites_ready()) return null;
    $username = trim((string)$username);
    if ($site_key === '' || $username === '') return null;
    $password = $password !== null && $password !== '' ? $password : generate_random_password(10);
    db()->prepare("INSERT INTO site_access (user_id, site_key, username, password, source, note, expires_at, status)
                   VALUES (?,?,?,?, 'manual', ?, ?, 'active')
                   ON DUPLICATE KEY UPDATE password = VALUES(password), note = VALUES(note),
                        expires_at = VALUES(expires_at), user_id = VALUES(user_id), status = 'active'")
        ->execute([$user_id ? (int)$user_id : null, $site_key, $username, $password, $note, $expires_at ?: null]);
    $stmt = db()->prepare("SELECT * FROM site_access WHERE site_key = ? AND username = ? LIMIT 1");
    $stmt->execute([$site_key, $username]);
    return $stmt->fetch() ?: null;
}

function site_access_set_status($id, $status) {
    if (!tool_sites_ready()) return;
    db()->prepare("UPDATE site_access SET status = ? WHERE id = ?")->execute([$status === 'active' ? 'active' : 'revoked', (int)$id]);
}

function site_access_delete($id) {
    if (!tool_sites_ready()) return;
    db()->prepare("DELETE FROM site_access WHERE id = ?")->execute([(int)$id]);
}

/**
 * Verify a login for any site key: manual grants first, then product licenses.
 * Returns ['username','name','product','site','source'] or null.
 */
function verify_site_login($username, $password, $site_key) {
    $username = trim((string)$username);
    $password = trim((string)$password);
    if ($username === '' || $password === '' || $site_key === '') return null;

    if (tool_sites_ready()) {
        $stmt = db()->prepare("SELECT * FROM site_access
                                WHERE site_key = ? AND username = ? AND password = ? AND status = 'active'
                                  AND (expires_at IS NULL OR expires_at >= CURDATE()) LIMIT 1");
        $stmt->execute([$site_key, $username, $password]);
        if ($row = $stmt->fetch()) {
            db()->prepare("UPDATE site_access SET last_verified_at = NOW() WHERE id = ?")->execute([$row['id']]);
            $name = $row['username'];
            if (!empty($row['user_id'])) {
                $s = db()->prepare("SELECT name FROM users WHERE id = ?"); $s->execute([(int)$row['user_id']]);
                $u = $s->fetch(); if ($u) $name = $u['name'];
            }
            return ['username'=>$row['username'], 'name'=>$name, 'product'=>$row['note'] ?: 'Manual access',
                    'site'=>$site_key, 'source'=>'manual', 'user_id'=>$row['user_id'] ? (int)$row['user_id'] : null];
        }
    }

    $lic = verify_product_license($username, $password, $site_key);
    if ($lic) {
        $product = get_product($lic['product_id']);
        $s = db()->prepare("SELECT name FROM users WHERE id = ?"); $s->execute([(int)$lic['user_id']]);
        $u = $s->fetch();
        return ['username'=>$lic['username'], 'name'=>$u['name'] ?? $lic['username'],
                'product'=>$product['title'] ?? 'Course', 'site'=>$site_key, 'source'=>'product',
                'user_id'=>(int)$lic['user_id']];
    }
    return null;
}

/**
 * One row per login (username) with the list of sites it can access.
 * $filter_site: a site key to only return users having that site, or 'all'.
 */
function site_users_list($filter_site = 'all') {
    $users = [];

    if (course_license_ready()) {
        $sql = "SELECT l.*, u.name AS user_name, u.email, p.title AS product
                  FROM product_licenses l
                  LEFT JOIN users u ON u.id = l.user_id
                  LEFT JOIN products p ON p.id = l.product_id
                 ORDER BY l.created_at DESC";
        foreach (db()->query($sql)->fetchAll() as $r) {
            $k = strtolower($r['username']);
            if (!isset($users[$k])) {
                $users[$k] = ['username'=>$r['username'], 'user_name'=>$r['user_name'], 'email'=>$r['email'],
                              'products'=>[], 'sites'=>[], 'status'=>$r['status'], 'source'=>'product',
                              'created_at'=>$r['created_at'], 'last_verified_at'=>$r['last_verified_at']];
            }
            if ($r['product']) $users[$k]['products'][] = $r['product'];
            if ($r['status'] === 'active') {
                foreach (license_sites_expand($r['site']) as $s) $users[$k]['sites'][$s] = 'product';
            }
            if ($r['last_verified_at'] > ($users[$k]['last_verified_at'] ?? '')) $users[$k]['last_verified_at'] = $r['last_verified_at'];
        }
    }

    if (tool_sites_ready()) {
        $sql = "SELECT a.*, u.name AS user_name, u.email FROM site_access a
                  LEFT JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC";
        foreach (db()->query($sql)->fetchAll() as $r) {
            $k = strtolower($r['username']);
            if (!isset($users[$k])) {
                $users[$k] = ['username'=>$r['username'], 'user_name'=>$r['user_name'], 'email'=>$r['email'],
                              'products'=>[], 'sites'=>[], 'status'=>$r['status'], 'source'=>'manual',
                              'created_at'=>$r['created_at'], 'last_verified_at'=>$r['last_verified_at']];
            }
            if ($r['note']) $users[$k]['products'][] = $r['note'];
            if ($r['status'] === 'active') $users[$k]['sites'][$r['site_key']] = 'manual';
            if ($r['last_verified_at'] > ($users[$k]['last_verified_at'] ?? '')) $users[$k]['last_verified_at'] = $r['last_verified_at'];
        }
    }

    $out = [];
    foreach ($users as $u) {
        if ($filter_site !== 'all' && $filter_site !== '' && !isset($u['sites'][$filter_site])) continue;
        $u['products'] = array_values(array_unique(array_filter($u['products'])));
        $out[] = $u;
    }
    return $out;
}


/**
 * Tool site kku anupura plan / feature limit info.
 * Editor site ithai vachu premium templates + limits set panniykkum.
 */
function site_login_plan_info($user_id) {
    $info = [
        'plan_name'        => null,
        'plan_expiry'      => null,
        'premium_designer' => 1,   // course vaangunavanga default-a premium
        'ai_daily_limit'   => 0,   // 0 = tool site oda own default
        'project_slots'    => 0,
    ];
    if (!$user_id) return $info;
    try {
        $st = db()->prepare("SELECT plan_id, plan_name, plan_expiry FROM users WHERE id = ? LIMIT 1");
        $st->execute([(int)$user_id]);
        $u = $st->fetch();
        if (!$u) return $info;
        $info['plan_name']   = $u['plan_name'];
        $info['plan_expiry'] = $u['plan_expiry'];
        if (!empty($u['plan_name'])) {
            $plan = get_plan_by_name($u['plan_name']);
            if ($plan) {
                $info['premium_designer'] = (int)($plan['premium_designer'] ?? 1);
                $info['ai_daily_limit']   = (int)($plan['ai_daily_limit'] ?? 0);
                $info['project_slots']    = (int)($plan['project_slots'] ?? 0);
            }
        }
    } catch (Exception $e) { /* keep defaults */ }
    return $info;
}
