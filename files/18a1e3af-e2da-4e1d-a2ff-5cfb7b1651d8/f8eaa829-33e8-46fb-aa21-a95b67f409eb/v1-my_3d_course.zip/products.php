<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$user = current_user();
$category = trim($_GET['cat'] ?? '');
$notReady = !shop_tables_ready();

$pageTitle = 'Shop - Digital Files & Video Courses';
include __DIR__ . '/includes/header.php';

if (!$notReady) {
    $products = all_products(true, $category ?: null);
    $cats = product_categories();
}
?>
<div class="hero" style="padding-top:20px;">
  <h1>Shop</h1>
  <p>3D design files, templates &amp; video courses - instant access after purchase.</p>
</div>

<?php if ($notReady): ?>
  <div class="flash flash-error">The Shop isn't set up yet. Please import <code>migration-products-shop.sql</code> in phpMyAdmin, then add products from Admin &gt; Products.</div>
<?php else: ?>

<?php if ($cats): ?>
<div style="margin-bottom:20px;">
  <a href="products.php" class="btn btn-sm <?php echo $category==='' ? '' : 'btn-outline'; ?>">All</a>
  <?php foreach ($cats as $c): ?>
    <a href="?cat=<?php echo urlencode($c); ?>" class="btn btn-sm <?php echo $category===$c ? '' : 'btn-outline'; ?>"><?php echo h($c); ?></a>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="plans-grid" style="grid-template-columns:repeat(auto-fill,minmax(230px,1fr));">
  <?php foreach ($products as $p): ?>
    <?php
      $eff = product_effective_price($p);
      $onSale = $eff < (float)$p['price'];
      $owns = $user && user_owns_product($user['id'], $p['id']);
    ?>
    <div class="plan-card" style="text-align:left;padding:0;overflow:hidden;">
      <a href="product.php?slug=<?php echo h($p['slug']); ?>" style="display:block;">
        <?php if (!empty($p['thumbnail'])): ?>
          <img src="<?php echo h($p['thumbnail']); ?>" alt="<?php echo h($p['title']); ?>" style="width:100%;height:170px;object-fit:cover;display:block;">
        <?php else: ?>
          <div style="width:100%;height:170px;background:linear-gradient(135deg,#1e293b,#0f172a);display:flex;align-items:center;justify-content:center;font-size:40px;">🗂️</div>
        <?php endif; ?>
      </a>
      <div style="padding:16px;">
        <?php if (!empty($p['category'])): ?><div style="font-size:11px;color:var(--muted,#94a3b8);text-transform:uppercase;letter-spacing:.5px;"><?php echo h($p['category']); ?></div><?php endif; ?>
        <h3 style="margin:6px 0;font-size:16px;"><a href="product.php?slug=<?php echo h($p['slug']); ?>" style="color:inherit;text-decoration:none;"><?php echo h($p['title']); ?></a></h3>
        <?php if (!empty($p['short_desc'])): ?><p style="font-size:13px;color:var(--muted,#94a3b8);margin:0 0 10px;"><?php echo h($p['short_desc']); ?></p><?php endif; ?>
        <div style="margin-bottom:12px;">
          <?php if ($onSale): ?>
            <span style="text-decoration:line-through;color:var(--muted,#94a3b8);font-size:13px;">₹<?php echo number_format($p['price'],0); ?></span>
            <strong style="font-size:18px;color:#22c55e;margin-left:6px;">₹<?php echo number_format($eff,0); ?></strong>
          <?php else: ?>
            <strong style="font-size:18px;"><?php echo $eff > 0 ? '₹' . number_format($eff,0) : 'Free'; ?></strong>
          <?php endif; ?>
        </div>
        <?php if ($owns): ?>
          <a href="my-purchases.php" class="btn btn-block btn-outline">✅ Owned - View</a>
        <?php else: ?>
          <a href="product.php?slug=<?php echo h($p['slug']); ?>" class="btn btn-block">View / Buy</a>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (!$products): ?><p>No products published yet.</p><?php endif; ?>
</div>

<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
