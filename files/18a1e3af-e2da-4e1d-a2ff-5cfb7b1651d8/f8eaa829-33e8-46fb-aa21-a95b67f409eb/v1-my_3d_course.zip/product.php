<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cashfree.php';

if (!shop_tables_ready()) {
    header('Location: ' . SITE_URL . '/products.php');
    exit;
}

$slug = trim($_GET['slug'] ?? '');
$product = $slug ? get_product_by_slug($slug) : null;
if (!$product || $product['status'] !== 'published') {
    header('HTTP/1.0 404 Not Found');
    $pageTitle = 'Product Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="card"><h2>Product not found</h2><a href="' . SITE_URL . '/products.php" class="btn">Back to Shop</a></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$user = current_user();
$owns = $user && user_owns_product($user['id'], $product['id']);
$eff  = product_effective_price($product);
$checkoutSessionId = null;
$checkoutError = null;

// ---- Buy button ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_product'])) {
    csrf_check();
    if (!$user) {
        redirect('/register.php?next=' . urlencode('/product.php?slug=' . $product['slug']));
    }
    if ($owns) {
        redirect('/my-purchases.php');
    }
    if ($eff <= 0) {
        // Free product - grant instantly, no payment needed.
        grant_product_to_user($user['id'], $product['id']);
        flash('You now have access to "' . $product['title'] . '".');
        redirect('/my-purchases.php');
    }
    $orderId = 'PROD' . $user['id'] . 'P' . $product['id'] . 'T' . time();
    $cfResp = cashfree_create_order($orderId, $eff, $user);
    if (!empty($cfResp['error'])) {
        $checkoutError = 'Payment gateway error: ' . $cfResp['error'] . ' (Check Cashfree keys in Admin > Settings)';
    } elseif (!empty($cfResp['payment_session_id'])) {
        db()->prepare("INSERT INTO product_orders (user_id, product_id, cf_order_id, amount, status) VALUES (?,?,?,?,'created')")
            ->execute([$user['id'], $product['id'], $orderId, $eff]);
        $checkoutSessionId = $cfResp['payment_session_id'];
    } else {
        $checkoutError = 'Could not create payment order. Please try again shortly.';
    }
}

$pageTitle = $product['title'];
$metaTitle = $product['title'];
$metaDescription = $product['short_desc'] ?? '';
include __DIR__ . '/includes/header.php';
?>

<?php if ($checkoutError): ?>
  <div class="flash flash-error"><?php echo h($checkoutError); ?></div>
<?php endif; ?>

<?php if ($checkoutSessionId): ?>
  <div class="card" style="text-align:center;">
    <h2>Redirecting to secure payment...</h2>
    <p>Please wait, do not close this window.</p>
  </div>
  <script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
  <script>
    const cashfree = Cashfree({ mode: "<?php echo get_setting('cashfree_mode','sandbox') === 'production' ? 'production' : 'sandbox'; ?>" });
    cashfree.checkout({
      paymentSessionId: "<?php echo h($checkoutSessionId); ?>",
      redirectTarget: "_self"
    });
  </script>
<?php else: ?>

<div class="card" style="display:flex;gap:28px;flex-wrap:wrap;align-items:flex-start;">
  <div style="flex:1;min-width:260px;">
    <?php if (!empty($product['thumbnail'])): ?>
      <img src="<?php echo h($product['thumbnail']); ?>" alt="<?php echo h($product['title']); ?>" style="width:100%;border-radius:12px;">
    <?php else: ?>
      <div style="width:100%;aspect-ratio:1/1;background:linear-gradient(135deg,#1e293b,#0f172a);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:60px;">🗂️</div>
    <?php endif; ?>
  </div>
  <div style="flex:1.3;min-width:280px;">
    <?php if (!empty($product['category'])): ?><div style="font-size:12px;color:var(--muted,#94a3b8);text-transform:uppercase;letter-spacing:.5px;"><?php echo h($product['category']); ?></div><?php endif; ?>
    <h1 style="margin:6px 0 14px;"><?php echo h($product['title']); ?></h1>

    <div style="margin-bottom:18px;">
      <?php if ($eff < (float)$product['price']): ?>
        <span style="text-decoration:line-through;color:var(--muted,#94a3b8);font-size:16px;">₹<?php echo number_format($product['price'],0); ?></span>
        <strong style="font-size:28px;color:#22c55e;margin-left:8px;">₹<?php echo number_format($eff,0); ?></strong>
      <?php else: ?>
        <strong style="font-size:28px;"><?php echo $eff > 0 ? '₹' . number_format($eff,0) : 'Free'; ?></strong>
      <?php endif; ?>
    </div>

    <?php if ($owns): ?>
      <div class="flash flash-success">✅ You already own this <?php echo $product['type'] === 'course' ? 'course' : 'file'; ?>.</div>
      <a href="<?php echo SITE_URL; ?>/my-purchases.php" class="btn">Go to My Purchases &amp; Download</a>
    <?php else: ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" name="buy_product" value="1" class="btn" style="font-size:16px;padding:14px 26px;">
          <?php echo $eff > 0 ? 'Buy Now - ₹' . number_format($eff,0) : 'Get Free Access'; ?>
        </button>
      </form>
      <?php if (!$user): ?><p style="color:var(--muted,#94a3b8);font-size:13px;margin-top:10px;">You'll be asked to login/register before checkout.</p><?php endif; ?>
    <?php endif; ?>

    <?php if (!empty($product['description'])): ?>
      <div style="margin-top:24px;line-height:1.7;"><?php echo nl2br(h($product['description'])); ?></div>
    <?php endif; ?>

    <?php if ($product['type'] === 'course' && function_exists('course_license_ready') && course_license_ready()):
      $includedItems = course_included_items($product['id']);
      if ($includedItems): ?>
      <div style="margin-top:24px;">
        <h3 style="margin-bottom:10px;">📦 What's Included</h3>
        <ul style="line-height:1.9;padding-left:20px;">
          <?php foreach ($includedItems as $it): ?>
            <li><?php echo h($it['title']); ?><?php if (!empty($it['short_desc'])): ?> — <span style="color:var(--muted,#94a3b8);"><?php echo h($it['short_desc']); ?></span><?php endif; ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; endif; ?>
  </div>
</div>

<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
