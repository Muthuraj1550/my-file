<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cashfree.php';

$orderId = $_GET['order_id'] ?? '';

// Guest Main Editor plan payments never have a course-site login — handle
// them first and bounce straight back to Main Editor, no login wall.
if ($orderId !== '') {
    $meStmt = db()->prepare("SELECT id FROM main_editor_plan_orders WHERE cf_order_id = ? LIMIT 1");
    $meStmt->execute([$orderId]);
    if ($meStmt->fetch()) {
        $result = cashfree_verify_and_activate_main_editor_plan($orderId);
        $back = $result['return_url'] ?? 'https://my3dgifts.com/membership.php';
        $sep  = (strpos($back, '?') !== false) ? '&' : '?';
        redirect($back . $sep . 'payment=' . ($result['ok'] ? 'success' : 'pending'));
    }
}

require_login();

$result = $orderId ? cashfree_verify_and_activate($orderId) : ['ok' => false, 'msg' => 'Missing order id'];

$pageTitle = 'Payment Status';
include __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:520px;margin:30px auto;text-align:center;">
  <?php if ($result['ok']): ?>
    <h1 style="color:#22c55e;">✅ Payment Successful</h1>
    <?php if (!empty($result['product'])): ?>
      <p>You now have access to <strong><?php echo h($result['product']); ?></strong>. Enjoy!</p>
    <?php elseif (!empty($result['coins'])): ?>
      <p><?php echo (int)$result['coins']; ?> coins have been credited to your account.</p>
    <?php else: ?>
      <p>Your plan has been activated. Enjoy your upgraded membership!</p>
    <?php endif; ?>
  <?php else: ?>
    <h1 style="color:#f59e0b;">⏳ Payment Processing</h1>
    <p>We couldn't confirm your payment yet (<?php echo h($result['msg']); ?>). If money was
    deducted, please wait a minute and refresh this page - it updates automatically once
    Cashfree confirms the payment. Contact support if this persists.</p>
  <?php endif; ?>
  <?php if (!empty($result['product_id']) && !empty($result['product_slug'])): ?>
    <a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo urlencode($result['product_slug']); ?>" class="btn">Go to <?php echo h($result['product'] ?? 'Product'); ?></a>
    <p style="margin-top:10px;"><a href="<?php echo SITE_URL; ?>/my-purchases.php" style="font-size:13px;color:var(--muted,#94a3b8);">or view all My Purchases</a></p>
  <?php elseif (!empty($result['product_id'])): ?>
    <a href="<?php echo SITE_URL; ?>/my-purchases.php" class="btn">Go to My Purchases</a>
  <?php else: ?>
    <a href="<?php echo SITE_URL; ?>/dashboard.php" class="btn">Go to Dashboard</a>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
