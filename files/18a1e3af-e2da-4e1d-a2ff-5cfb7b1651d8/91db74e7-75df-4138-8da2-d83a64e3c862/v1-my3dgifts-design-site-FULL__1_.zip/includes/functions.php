<?php
require_once __DIR__ . '/db.php';

function get_setting($key, $default = '') {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query("SELECT setting_key, setting_value FROM settings") as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function set_setting($key, $value) {
    $stmt = db()->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
                            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    $stmt->execute([$key, $value]);
}

/** WhatsApp number configured in Admin -> Settings, digits only (country code, no + or spaces). Empty string if not set. */
function whatsapp_number() {
    return preg_replace('/[^0-9]/', '', (string) get_setting('whatsapp_number', ''));
}

/** Build a wa.me link with an optional pre-filled message. Returns null if no WhatsApp number is configured (caller should hide the button). */
function whatsapp_link($message = '') {
    $number = whatsapp_number();
    if ($number === '') return null;
    $url = 'https://wa.me/' . $number;
    if (trim($message) !== '') $url .= '?text=' . rawurlencode($message);
    return $url;
}

function slugify($text) {
    $text = trim($text);
    // Keep Tamil/unicode letters, convert spaces to hyphens
    $text = preg_replace('/\s+/u', '-', $text);
    $text = preg_replace('/[^\p{L}\p{N}\-]/u', '', $text);
    $text = preg_replace('/-+/', '-', $text);
    $text = trim($text, '-');
    return $text !== '' ? mb_strtolower($text) : 'item-' . time();
}

function unique_slug($table, $base_slug, $ignore_id = null) {
    $slug = $base_slug;
    $i = 1;
    while (true) {
        $sql = "SELECT id FROM $table WHERE slug = ?" . ($ignore_id ? " AND id != ?" : "");
        $params = $ignore_id ? [$slug, $ignore_id] : [$slug];
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        if (!$stmt->fetch()) break;
        $i++;
        $slug = $base_slug . '-' . $i;
    }
    return $slug;
}

function h($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/** Whether the users.username column (migration-username-login.sql) is ready yet. */
function username_login_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT username FROM users LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Turn a member's name into a short lowercase username (letters/numbers only), unique in users.username. */
function generate_username_from_name($name) {
    $base = mb_strtolower(trim($name));
    $base = preg_replace('/[^a-z0-9]+/u', '', $base); // Tamil/unicode names fold to '' - handled below
    if ($base === '') $base = 'member';
    $base = mb_substr($base, 0, 16);
    $username = $base;
    $i = 0;
    while (true) {
        $stmt = db()->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if (!$stmt->fetch()) return $username;
        $i++;
        $username = $base . random_int(100, 999) . ($i > 1 ? $i : '');
    }
}

/** A random, easy-to-read password (no ambiguous 0/O/1/l/I) to hand a new member. */
function generate_random_password($length = 8) {
    $chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    $pass = '';
    for ($i = 0; $i < $length; $i++) $pass .= $chars[random_int(0, strlen($chars) - 1)];
    return $pass;
}

function redirect($path) {
    header('Location: ' . (strpos($path, 'http') === 0 ? $path : SITE_URL . $path));
    exit;
}

function flash($msg, $type = 'success') {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function all_plans() {
    return db()->query("SELECT * FROM plans ORDER BY sort_order ASC, price ASC")->fetchAll();
}

function get_plan($id) {
    $stmt = db()->prepare("SELECT * FROM plans WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function get_plan_by_name($name) {
    $stmt = db()->prepare("SELECT * FROM plans WHERE plan_name = ?");
    $stmt->execute([$name]);
    return $stmt->fetch();
}

/**
 * Downgrade a single user to Free plan if their plan_expiry has passed.
 * Called on login and dashboard load (lightweight, no cron needed on
 * shared hosting, but you can also wire this to a real cron hitting
 * /cron/expire.php for site-wide sweeps).
 */
function check_and_expire_user(&$user) {
    if (!$user || empty($user['plan_expiry'])) return;
    if (strtotime($user['plan_expiry']) < strtotime(date('Y-m-d'))) {
        $free = get_plan_by_name('Free');
        $stmt = db()->prepare("UPDATE users SET plan_id = ?, plan_name = 'Free', plan_expiry = ? WHERE id = ?");
        $stmt->execute([$free ? $free['id'] : null, date('Y-m-d', strtotime('+100 years')), $user['id']]);
        $user['plan_name']   = 'Free';
        $user['plan_expiry'] = date('Y-m-d', strtotime('+100 years'));
    }
}

/** Today's AI usage count for a logged-in user */
function ai_usage_today($user_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM ai_usage_log WHERE user_id = ? AND DATE(used_at) = CURDATE()");
    $stmt->execute([$user_id]);
    return (int) $stmt->fetch()['c'];
}

/** Today's AI usage count for an anonymous guest (tracked by cookie id) */
function ai_usage_today_guest($guest_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM ai_usage_log WHERE guest_id = ? AND user_id IS NULL AND DATE(used_at) = CURDATE()");
    $stmt->execute([$guest_id]);
    return (int) $stmt->fetch()['c'];
}

/** Daily AI limit for guests (not logged in), configurable in Admin > Settings */
function ai_daily_limit_guest() {
    return (int) get_setting('guest_ai_daily_limit', 2);
}

/** Log one AI generation - user_id if logged in, else guest_id */
function log_ai_usage($user_id, $guest_id, $prompt) {
    $stmt = db()->prepare("INSERT INTO ai_usage_log (user_id, guest_id, prompt, ip_address) VALUES (?,?,?,?)");
    $stmt->execute([$user_id ?: null, $user_id ? null : $guest_id, mb_substr(trim($prompt), 0, 500), $_SERVER['REMOTE_ADDR'] ?? '']);
}

/** Effective daily AI limit for a user (per-user override wins, else plan limit) */
function ai_daily_limit_for($user) {
    if (!empty($user['ai_limit_override'])) return (int) $user['ai_limit_override'];
    $plan = get_plan_by_name($user['plan_name']);
    return $plan ? (int) $plan['ai_daily_limit'] : 3;
}

function is_premium_designer_user($user) {
    if (!$user) return false;
    $plan = get_plan_by_name($user['plan_name']);
    return $plan && (int)$plan['premium_designer'] === 1 && has_active_plan($user);
}

/** Has this member purchased at least one "Course" type product? (grants full Designer access below) */
function user_has_course_access($user) {
    if (!$user || !shop_tables_ready()) return false;
    $stmt = db()->prepare("SELECT 1 FROM user_products up
                            JOIN products p ON p.id = up.product_id
                            WHERE up.user_id = ? AND p.type = 'course' LIMIT 1");
    $stmt->execute([(int)$user['id']]);
    return (bool) $stmt->fetch();
}

/** Full Designer access (premium templates, higher AI limit path) - paid plan OR a purchased course. */
function has_full_designer_access($user) {
    if (!$user) return false;
    return is_premium_designer_user($user) || user_has_course_access($user);
}

/* ---------------------------------------------------------
 * Cloud Project Save + Recovery (login-based, capped at 10MB/user)
 * --------------------------------------------------------- */

const CLOUD_PROJECT_STORAGE_CAP_BYTES = 10 * 1024 * 1024; // 10 MB total per user
const CLOUD_PROJECT_AUTO_SLOT = '__auto__';

/** How many EXTRA named "Save As" slots (beyond the always-on auto-save) this user's plan allows. */
function get_user_named_slot_limit($user) {
    if (!$user) return 0;
    if (!has_active_plan($user)) return 0;
    $plan = get_plan_by_name($user['plan_name']);
    return $plan ? (int)($plan['project_slots'] ?? 0) : 0;
}

/** Whether the saved_projects table (migration-cloud-projects.sql) has been set up yet. */
function cloud_projects_table_ready() {
    static $ready = null;
    if ($ready === null) {
        try {
            db()->query("SELECT 1 FROM saved_projects LIMIT 1");
            $ready = true;
        } catch (Exception $e) {
            $ready = false;
        }
    }
    return $ready;
}

/** Counts for Admin > Analytics: how many cloud-saved projects exist, by how many members, and total size. */
function cloud_project_stats() {
    if (!cloud_projects_table_ready()) {
        return ['total' => 0, 'auto' => 0, 'named' => 0, 'users' => 0, 'bytes' => 0];
    }
    $row = db()->query("SELECT
        COUNT(*) total,
        SUM(slot_name = '" . CLOUD_PROJECT_AUTO_SLOT . "') auto,
        SUM(slot_name != '" . CLOUD_PROJECT_AUTO_SLOT . "') named,
        COUNT(DISTINCT user_id) users,
        COALESCE(SUM(size_bytes),0) bytes
        FROM saved_projects")->fetch();
    return [
        'total' => (int)($row['total'] ?? 0),
        'auto'  => (int)($row['auto'] ?? 0),
        'named' => (int)($row['named'] ?? 0),
        'users' => (int)($row['users'] ?? 0),
        'bytes' => (int)($row['bytes'] ?? 0),
    ];
}

/* ---------------------------------------------------------
 * Analytics: post/page views + time spent
 * --------------------------------------------------------- */

/**
 * Classify an HTTP Referer URL into a human-friendly traffic source bucket,
 * e.g. 'Google Search', 'YouTube', 'Facebook / Instagram', 'Direct / App',
 * or the referring domain itself for anything else.
 */
function classify_referrer($refererUrl) {
    $refererUrl = trim((string)$refererUrl);
    if ($refererUrl === '') return 'Direct / App';
    $host = parse_url($refererUrl, PHP_URL_HOST);
    if (!$host) return 'Direct / App';
    $host = strtolower(preg_replace('/^www\./', '', $host));

    // Own site linking to itself shouldn't count as external traffic.
    $siteHost = strtolower(preg_replace('/^www\./', '', (string)parse_url(SITE_URL, PHP_URL_HOST)));
    if ($siteHost && $host === $siteHost) return 'Internal (same site)';

    $map = [
        'google.'      => 'Google Search',
        'bing.'        => 'Bing Search',
        'yahoo.'       => 'Yahoo Search',
        'duckduckgo.'  => 'DuckDuckGo Search',
        'youtube.'     => 'YouTube',
        'youtu.be'     => 'YouTube',
        'facebook.'    => 'Facebook / Instagram',
        'instagram.'   => 'Facebook / Instagram',
        'fb.'          => 'Facebook / Instagram',
        'wa.me'        => 'WhatsApp',
        'whatsapp.'    => 'WhatsApp',
        'twitter.'     => 'Twitter / X',
        'x.com'        => 'Twitter / X',
        't.co'         => 'Twitter / X',
        'linkedin.'    => 'LinkedIn',
        'pinterest.'   => 'Pinterest',
        'telegram.'    => 'Telegram',
        't.me'         => 'Telegram',
    ];
    foreach ($map as $needle => $label) {
        if (strpos($host, $needle) !== false) return $label;
    }
    return 'Other site: ' . $host;
}

/** Record a fresh view for a post/page/tool/etc and return the new row id (used to later update duration). */
function record_view($type, $content_id) {
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $source  = classify_referrer($referer);
    try {
        $stmt = db()->prepare("INSERT INTO content_views (content_type, content_id, ip_address, referrer_url, referrer_source) VALUES (?,?,?,?,?)");
        $stmt->execute([$type, $content_id, $_SERVER['REMOTE_ADDR'] ?? '', mb_substr($referer, 0, 500), $source]);
    } catch (Exception $e) {
        // referrer_url/referrer_source columns not migrated yet on this install -
        // fall back to the original columns so tracking still works.
        $stmt = db()->prepare("INSERT INTO content_views (content_type, content_id, ip_address) VALUES (?,?,?)");
        $stmt->execute([$type, $content_id, $_SERVER['REMOTE_ADDR'] ?? '']);
    }
    return db()->lastInsertId();
}

/** Record one click on a Tool Lab card (content_type='tool_click', content_id=tools.id). */
function record_tool_click($tool_id) {
    return record_view('tool_click', (int)$tool_id);
}

/** Click counts per tool: [tool_id => clicks] */
function tool_click_counts() {
    $stmt = db()->query("SELECT content_id, COUNT(*) c FROM content_views WHERE content_type='tool_click' GROUP BY content_id");
    $map = [];
    foreach ($stmt->fetchAll() as $r) $map[(int)$r['content_id']] = (int)$r['c'];
    return $map;
}

/** Total Tool Lab clicks across all tools */
function total_tool_clicks() {
    return (int) db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='tool_click'")->fetch()['c'];
}

/**
 * Traffic-source breakdown across all page views (post/page/designer/tool
 * page loads), grouped by classified source, most recent $days days
 * (0 = all time). Used by Admin > Analytics.
 */
function traffic_source_breakdown($days = 30) {
    if (!content_views_referrer_ready()) return [];
    $sql = "SELECT COALESCE(NULLIF(referrer_source,''),'Direct / App') AS source, COUNT(*) c
            FROM content_views
            WHERE content_type <> 'tool_click'";
    if ($days > 0) $sql .= " AND created_at >= NOW() - INTERVAL " . (int)$days . " DAY";
    $sql .= " GROUP BY source ORDER BY c DESC";
    return db()->query($sql)->fetchAll();
}

/** Whether content_views.referrer_source (migration-traffic-source.sql) has been added yet. */
function content_views_referrer_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT referrer_source FROM content_views LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Update how many seconds a visitor stayed on the page (called via sendBeacon on unload). */
function update_view_duration($view_id, $type, $seconds) {
    $seconds = max(0, min(3600, (int)$seconds)); // sanity clamp: 0 to 1 hour
    $stmt = db()->prepare("UPDATE content_views SET duration_seconds = ? WHERE id = ? AND content_type = ?");
    $stmt->execute([$seconds, (int)$view_id, $type]);
}

/** Total view count for one piece of content */
function view_count($type, $content_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM content_views WHERE content_type=? AND content_id=?");
    $stmt->execute([$type, $content_id]);
    return (int) $stmt->fetch()['c'];
}

/** Average minutes spent for one piece of content */
function avg_minutes($type, $content_id) {
    $stmt = db()->prepare("SELECT AVG(duration_seconds) a FROM content_views WHERE content_type=? AND content_id=? AND duration_seconds > 0");
    $stmt->execute([$type, $content_id]);
    $a = $stmt->fetch()['a'];
    return $a ? round($a / 60, 1) : 0;
}

/** Top posts or pages ranked by view count, with total minutes and avg minutes */
function top_content($type, $limit = 10) {
    $table = $type === 'post' ? 'posts' : 'pages';
    $sql = "SELECT c.title, c.slug,
                   COUNT(v.id) AS views,
                   COALESCE(SUM(v.duration_seconds), 0) AS total_seconds,
                   COALESCE(AVG(NULLIF(v.duration_seconds,0)), 0) AS avg_seconds
            FROM $table c
            LEFT JOIN content_views v ON v.content_type = ? AND v.content_id = c.id
            GROUP BY c.id
            ORDER BY views DESC, c.created_at DESC
            LIMIT " . (int)$limit;
    $stmt = db()->prepare($sql);
    $stmt->execute([$type]);
    return $stmt->fetchAll();
}

/** View counts map [content_id => views] for a whole table, used in admin list pages */
function view_counts_map($type) {
    $stmt = db()->prepare("SELECT content_id, COUNT(*) c FROM content_views WHERE content_type=? GROUP BY content_id");
    $stmt->execute([$type]);
    $map = [];
    foreach ($stmt->fetchAll() as $r) $map[$r['content_id']] = (int)$r['c'];
    return $map;
}

/**
 * Extract the visible heading blocks from stored block-builder content, for
 * the "Topics Covered" summary shown near the top of a post/page/product.
 * A heading is skipped when the admin toggled its 👁 to 🙈 in the block
 * editor (admin/_content_builder.php). Returns [['level'=>2,'text'=>'...'], ...].
 */
function extract_toc_headings($content) {
    $out = [];
    if (!$content) return $out;
    if (!preg_match_all('/<!--BLOCK:heading(?::([^>]*))?-->(.*?)<!--\/BLOCK-->/s', $content, $matches, PREG_SET_ORDER)) {
        return $out;
    }
    foreach ($matches as $m) {
        $meta = $m[1] ?? '';
        $inner = $m[2] ?? '';
        $parts = $meta === '' ? [] : explode(':', $meta);
        $level = (isset($parts[0]) && in_array($parts[0], ['1', '2', '3'], true)) ? (int)$parts[0] : 2;
        $vis = $parts[1] ?? 'show';
        if ($vis === 'hide') continue; // admin hid this sub-heading from the Topics list
        $text = trim(html_entity_decode(strip_tags($inner), ENT_QUOTES, 'UTF-8'));
        if ($text === '') continue;
        $out[] = ['level' => $level, 'text' => $text];
    }
    return $out;
}

/**
 * Render the collapsible "Topics Covered" box (main title stays outside as
 * the page's own <h1>; expanding this shows the visible sub-headings) for a
 * post/page/product. Returns '' when there are no visible headings to list.
 */
function render_toc_block($content) {
    $headings = extract_toc_headings($content);
    if (!$headings) return '';
    ob_start();
    ?>
    <details class="toc-box">
      <summary>📋 Topics Covered (<?php echo count($headings); ?>)</summary>
      <ul class="toc-list">
        <?php foreach ($headings as $h): ?>
          <li class="toc-level-<?php echo (int)$h['level']; ?>"><?php echo h($h['text']); ?></li>
        <?php endforeach; ?>
      </ul>
    </details>
    <?php
    return ob_get_clean();
}

/** Aggregate usage stats for the 3D Designer page (content_id is always 0 - single page, no rows) */
function designer_analytics() {
    $total = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer'")->fetch()['c'];
    $last7 = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer' AND created_at >= NOW() - INTERVAL 7 DAY")->fetch()['c'];
    $today = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer' AND DATE(created_at)=CURDATE()")->fetch()['c'];
    $avgSec = db()->query("SELECT AVG(NULLIF(duration_seconds,0)) a FROM content_views WHERE content_type='designer'")->fetch()['a'];
    $totalSec = db()->query("SELECT COALESCE(SUM(duration_seconds),0) s FROM content_views WHERE content_type='designer'")->fetch()['s'];
    return [
        'total_views' => (int)$total,
        'views_7d'    => (int)$last7,
        'views_today' => (int)$today,
        'avg_seconds' => $avgSec ? (float)$avgSec : 0,
        'total_seconds' => (int)$totalSec,
    ];
}

/** Whether the posts.is_pinned column (migration-post-pin.sql) has been added yet. */
function posts_pin_column_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT is_pinned FROM posts LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Whether the pages.show_in_footer column (migration-page-footer-menu.sql) has been added yet. */
function page_footer_menu_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT show_in_footer FROM pages LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/* ---------------------------------------------------------
 * Media / File Manager (admin/filemanager.php) - shared uploads/ folder
 * --------------------------------------------------------- */

/** File extensions the media manager will never allow (mirrors uploads/.htaccess deny list, plus other script types). */
function media_blocked_extensions() {
    return ['php','phtml','php3','php4','php5','php7','phar','pht','cgi','pl','py','exe','sh','asp','aspx','jsp','htaccess'];
}

/** Human-readable file size, e.g. "482 KB" / "1.3 MB". */
function format_file_size($bytes) {
    $bytes = (float)$bytes;
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 1) . ' GB';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024)       return round($bytes / 1024, 1) . ' KB';
    return $bytes . ' B';
}

/* ---------------------------------------------------------
 * Menu items (home page top navigation, admin-editable)
 * --------------------------------------------------------- */

function active_menu_items() {
    return db()->query("SELECT * FROM menu_items WHERE is_active = 1 ORDER BY sort_order ASC, id ASC")->fetchAll();
}

function all_menu_items() {
    return db()->query("SELECT * FROM menu_items ORDER BY sort_order ASC, id ASC")->fetchAll();
}

function get_menu_item($id) {
    $stmt = db()->prepare("SELECT * FROM menu_items WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/* ---------------------------------------------------------
 * Digital Products / Shop (products, product_orders, user_products)
 * --------------------------------------------------------- */

/** Whether the products-shop migration (migration-products-shop.sql) has run yet. */
function shop_tables_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT 1 FROM products LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

function all_products($onlyPublished = true, $category = null, $level = null) {
    if (!shop_tables_ready()) return [];
    $sql = "SELECT * FROM products";
    $where = [];
    $params = [];
    if ($onlyPublished) $where[] = "status='published'";
    if ($category) { $where[] = "category = ?"; $params[] = $category; }
    if ($level && course_level_ready()) {
        // A level filter only makes sense for Courses (files/software/bundles have no level).
        $where[] = "type='course' AND level = ?";
        $params[] = $level;
    }
    if ($where) $sql .= " WHERE " . implode(' AND ', $where);
    $sql .= " ORDER BY featured DESC, sort_order ASC, created_at DESC";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function get_product($id) {
    $stmt = db()->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([(int)$id]);
    return $stmt->fetch();
}

function get_product_by_slug($slug) {
    $stmt = db()->prepare("SELECT * FROM products WHERE slug = ?");
    $stmt->execute([$slug]);
    return $stmt->fetch();
}

/**
 * Top products ranked by view count (content_views.content_type='product').
 * Pass $type = 'course' for courses only, 'other' for everything except
 * courses, or null for all product types combined. Used by Admin > Analytics.
 */
function top_products($limit = 10, $type = null) {
    if (!shop_tables_ready()) return [];
    $where = '';
    if ($type === 'course')      $where = "WHERE p.type = 'course'";
    elseif ($type === 'other')   $where = "WHERE p.type <> 'course'";
    $sql = "SELECT p.id, p.title, p.slug, p.type,
                   COUNT(v.id) AS views,
                   COALESCE(SUM(v.duration_seconds), 0) AS total_seconds,
                   COALESCE(AVG(NULLIF(v.duration_seconds,0)), 0) AS avg_seconds
            FROM products p
            LEFT JOIN content_views v ON v.content_type = 'product' AND v.content_id = p.id
            $where
            GROUP BY p.id
            ORDER BY views DESC, p.created_at DESC
            LIMIT " . (int)$limit;
    return db()->query($sql)->fetchAll();
}

/** Product order count + revenue (product_orders, status='paid' only) for a date range. */
function product_order_stats($fromDate, $toDate) {
    if (!shop_tables_ready()) return ['orders' => 0, 'revenue' => 0];
    try {
        $stmt = db()->prepare("SELECT COUNT(*) orders, COALESCE(SUM(amount),0) revenue
                                FROM product_orders
                                WHERE status = 'paid'
                                AND created_at >= ? AND created_at < DATE_ADD(?, INTERVAL 1 DAY)");
        $stmt->execute([$fromDate, $toDate]);
        $r = $stmt->fetch();
        return ['orders' => (int)$r['orders'], 'revenue' => (float)$r['revenue']];
    } catch (Exception $e) {
        return ['orders' => 0, 'revenue' => 0];
    }
}

function product_categories() {
    if (!shop_tables_ready()) return [];
    return db()->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category <> '' ORDER BY category ASC")->fetchAll(PDO::FETCH_COLUMN);
}

/** The price to actually charge - sale_price if set and lower, else price. */
function product_effective_price($p) {
    if ($p['sale_price'] !== null && $p['sale_price'] !== '' && (float)$p['sale_price'] > 0 && (float)$p['sale_price'] < (float)$p['price']) {
        return (float)$p['sale_price'];
    }
    return (float)$p['price'];
}

/** Does this user already own (purchased / was granted) this product? */
function user_owns_product($user_id, $product_id) {
    if (!$user_id || !shop_tables_ready()) return false;
    $stmt = db()->prepare("SELECT 1 FROM user_products WHERE user_id = ? AND product_id = ? LIMIT 1");
    $stmt->execute([(int)$user_id, (int)$product_id]);
    return (bool) $stmt->fetch();
}

/**
 * Does this user own this product for ACCESS purposes - either they bought
 * this exact product directly, OR this product is included inside a Course
 * (products.course_id points at the parent course) and they own that parent
 * course. Use this (not user_owns_product) anywhere you decide whether to
 * show "Buy Now" vs unlocked content for a product.
 */
function user_effectively_owns_product($user_id, $product) {
    if (!$user_id || !$product) return false;
    if (user_owns_product($user_id, $product['id'])) return true;
    if (function_exists('product_multi_course_ready') && product_multi_course_ready()) {
        foreach (product_course_ids($product['id']) as $cid) {
            if (user_owns_product($user_id, $cid)) return true;
        }
        return false;
    }
    if (course_license_ready() && !empty($product['course_id'])) {
        return user_owns_product($user_id, (int)$product['course_id']);
    }
    return false;
}

/** All products a member has purchased/been granted, most recent first. */
function my_purchased_products($user_id) {
    if (!$user_id || !shop_tables_ready()) return [];
    $stmt = db()->prepare("SELECT p.*, up.granted_at FROM user_products up
                            JOIN products p ON p.id = up.product_id
                            WHERE up.user_id = ? ORDER BY up.granted_at DESC");
    $stmt->execute([(int)$user_id]);
    return $stmt->fetchAll();
}

/** Grant a product to a user immediately (used for free products, and after payment confirms). Idempotent. */
function grant_product_to_user($user_id, $product_id, $order_id = null) {
    $stmt = db()->prepare("INSERT IGNORE INTO user_products (user_id, product_id, order_id) VALUES (?,?,?)");
    $stmt->execute([(int)$user_id, (int)$product_id, $order_id ? (int)$order_id : null]);
    // If this product is set up to unlock the Main Editor / Litho Studio site,
    // auto-generate that buyer's login for it (no-op if already generated, or
    // if migration-course-license.sql hasn't been run yet).
    generate_product_license_if_needed($user_id, $product_id);
}

/** Remove a manually-granted product access from a user (admin action). Does not touch/refund any order. */
function revoke_product_from_user($user_id, $product_id) {
    $stmt = db()->prepare("DELETE FROM user_products WHERE user_id = ? AND product_id = ?");
    $stmt->execute([(int)$user_id, (int)$product_id]);
}

/* ---------------------------------------------------------
 * Courses (a product with type='course' groups other products
 * as its "included items") + Site License (auto password for
 * Main Editor / Litho Studio) - migration-course-license.sql
 * --------------------------------------------------------- */

/** Whether migration-course-license.sql has been run yet. */
function course_license_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT course_id, license_site FROM products LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Whether migration-course-level.sql has been run yet (products.level). */
function course_level_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT level FROM products LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Label + emoji shown to visitors for each course level. */
function course_level_label($level) {
    $map = [
        'beginner'     => '🔰 Beginner',
        'intermediate' => '🎯 Intermediate',
        'advanced'     => '🚀 Advanced',
    ];
    return $map[$level] ?? '';
}

/** One-line hint shown under the level dropdown in Admin, so the level chosen is accurate. */
function course_level_hint($level) {
    $map = [
        'beginner'     => 'Zero 3D design background (e.g. non-mechanical/non-design students). Explain every click, every button, step by step.',
        'intermediate' => 'Already knows the basics of the software - can move around, just needs the workflow / techniques.',
        'advanced'     => 'Wants software features only, fast-paced. Skip button-by-button hand-holding - it will feel too slow for them.',
    ];
    return $map[$level] ?? '';
}

/** Distinct levels currently used by published courses - so the public filter only shows tabs that have content. */
function course_levels_in_use() {
    if (!shop_tables_ready() || !course_level_ready()) return [];
    return db()->query("SELECT DISTINCT level FROM products WHERE type='course' AND status='published' AND level IS NOT NULL ORDER BY FIELD(level,'beginner','intermediate','advanced')")->fetchAll(PDO::FETCH_COLUMN);
}

/** Whether migration-content-item-level.sql has been run yet (posts.level). */
function post_level_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT level FROM posts LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Same, for pages.level. */
function page_level_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT level FROM pages LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Whether migration-course-content-gating.sql has been run yet (posts.show_in_course). */
function post_course_gating_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT show_in_course FROM posts LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Same, for pages.show_in_course. */
function page_course_gating_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT show_in_course FROM pages LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Whether migration-course-content-links.sql has been run yet (posts.course_id). */
function post_course_link_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT course_id FROM posts LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Same, for pages.course_id. */
function page_course_link_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT course_id FROM pages LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/**
 * Pulls out every "+ Text Link" block a post/page's content was built with
 * (e.g. individual STL download links inside one lesson), so the course
 * curriculum list can show each one as a sub-item under the lesson title.
 * Returns [['text'=>...,'url'=>...], ...] in the order they appear.
 */
function extract_content_links($content) {
    $links = [];
    if (!$content) return $links;
    if (preg_match_all('/<!--BLOCK:link-->(.*?)<!--\/BLOCK-->/s', $content, $blockMatches)) {
        foreach ($blockMatches[1] as $blockHtml) {
            if (preg_match('/<a\s+[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/is', $blockHtml, $m)) {
                $url = html_entity_decode($m[1], ENT_QUOTES);
                $text = trim(strip_tags(html_entity_decode($m[2], ENT_QUOTES)));
                if ($url !== '') {
                    $links[] = ['text' => $text !== '' ? $text : $url, 'url' => $url];
                }
            }
        }
    }
    return $links;
}

/**
 * The full curriculum of a course - every product, post, and page whose
 * course_id points at it, merged into one normalized list:
 * ['id','type' => product|post|page,'title','short_desc','status','url','sort_order','created_at','show_in_course','sub_links'].
 * $onlyPublished = true is what the public course page + My Purchases should use
 * (drafts never show to buyers); admin passes false to see everything, including drafts.
 * $onlyVisible = true additionally drops items whose "Show on course page"
 * checkbox is unchecked (show_in_course = 0) - use this for the public
 * "What's Covered" list; admin passes false to still manage hidden items.
 */
function course_included_items($course_product_id, $onlyPublished = false, $onlyVisible = false) {
    if (!course_license_ready()) return [];
    $items = [];

    // Products don't currently have a show_in_course toggle - always visible when linked.
    // Once migration-product-multi-course.sql is in, a product can belong to
    // several courses at once, each with its own curriculum sort_order.
    if (product_multi_course_ready()) {
        $stmt = db()->prepare("SELECT p.*, pc.sort_order AS course_sort_order FROM products p
                                JOIN product_courses pc ON pc.product_id = p.id
                                WHERE pc.course_id = ?" . ($onlyPublished ? " AND p.status='published'" : "") . "
                                ORDER BY pc.sort_order ASC, p.created_at ASC");
        $stmt->execute([(int)$course_product_id]);
    } else {
        $stmt = db()->prepare("SELECT *, sort_order AS course_sort_order FROM products WHERE course_id = ?" . ($onlyPublished ? " AND status='published'" : "") . " ORDER BY sort_order ASC, created_at ASC");
        $stmt->execute([(int)$course_product_id]);
    }
    foreach ($stmt->fetchAll() as $p) {
        $items[] = [
            'id' => (int)$p['id'], 'type' => 'product', 'title' => $p['title'],
            'short_desc' => $p['short_desc'] ?? '', 'status' => $p['status'],
            'url' => SITE_URL . '/product.php?slug=' . $p['slug'],
            'sort_order' => (int)$p['course_sort_order'], 'created_at' => $p['created_at'],
            'level' => course_level_ready() ? ($p['level'] ?? null) : null,
            'show_in_course' => true,
            'sub_links' => [],
            'sub_topics' => extract_toc_headings($p['description'] ?? ''),
        ];
    }

    if (post_course_link_ready()) {
        $gatingReady = post_course_gating_ready();
        if (post_multi_course_ready()) {
            $stmt = db()->prepare("SELECT p.*, pc.sort_order AS link_sort_order FROM posts p
                                    JOIN post_courses pc ON pc.post_id = p.id
                                    WHERE pc.course_id = ?" . ($onlyPublished ? " AND p.status='published'" : "") . ($onlyVisible && $gatingReady ? " AND p.show_in_course=1" : "") . "
                                    ORDER BY pc.sort_order ASC, p.created_at ASC");
            $stmt->execute([(int)$course_product_id]);
        } else {
            $stmt = db()->prepare("SELECT *, course_sort_order AS link_sort_order FROM posts WHERE course_id = ?" . ($onlyPublished ? " AND status='published'" : "") . ($onlyVisible && $gatingReady ? " AND show_in_course=1" : "") . " ORDER BY course_sort_order ASC, created_at ASC");
            $stmt->execute([(int)$course_product_id]);
        }
        foreach ($stmt->fetchAll() as $row) {
            $items[] = [
                'id' => (int)$row['id'], 'type' => 'post', 'title' => $row['title'],
                'short_desc' => $row['excerpt'] ?? '', 'status' => $row['status'],
                'url' => SITE_URL . '/post.php?slug=' . $row['slug'],
                'sort_order' => (int)($row['link_sort_order'] ?? 0), 'created_at' => $row['created_at'],
                'level' => post_level_ready() ? ($row['level'] ?? null) : null,
                'show_in_course' => $gatingReady ? (bool)$row['show_in_course'] : true,
                'sub_links' => extract_content_links($row['content'] ?? ''),
                'sub_topics' => extract_toc_headings($row['content'] ?? ''),
            ];
        }
    }

    if (page_course_link_ready()) {
        $gatingReady = page_course_gating_ready();
        if (page_multi_course_ready()) {
            $stmt = db()->prepare("SELECT p.*, pc.sort_order AS link_sort_order FROM pages p
                                    JOIN page_courses pc ON pc.page_id = p.id
                                    WHERE pc.course_id = ?" . ($onlyPublished ? " AND p.status='published'" : "") . ($onlyVisible && $gatingReady ? " AND p.show_in_course=1" : "") . "
                                    ORDER BY pc.sort_order ASC, p.created_at ASC");
            $stmt->execute([(int)$course_product_id]);
        } else {
            $stmt = db()->prepare("SELECT *, course_sort_order AS link_sort_order FROM pages WHERE course_id = ?" . ($onlyPublished ? " AND status='published'" : "") . ($onlyVisible && $gatingReady ? " AND show_in_course=1" : "") . " ORDER BY course_sort_order ASC, created_at ASC");
            $stmt->execute([(int)$course_product_id]);
        }
        foreach ($stmt->fetchAll() as $row) {
            $items[] = [
                'id' => (int)$row['id'], 'type' => 'page', 'title' => $row['title'],
                'short_desc' => '', 'status' => $row['status'],
                'url' => SITE_URL . '/page.php?slug=' . $row['slug'],
                'sort_order' => (int)($row['link_sort_order'] ?? 0), 'created_at' => $row['created_at'],
                'level' => page_level_ready() ? ($row['level'] ?? null) : null,
                'show_in_course' => $gatingReady ? (bool)$row['show_in_course'] : true,
                'sub_links' => extract_content_links($row['content'] ?? ''),
                'sub_topics' => extract_toc_headings($row['content'] ?? ''),
            ];
        }
    }

    usort($items, function($a, $b) {
        if ($a['sort_order'] !== $b['sort_order']) return $a['sort_order'] <=> $b['sort_order'];
        return strcmp($a['created_at'], $b['created_at']);
    });
    return $items;
}

/**
 * Does this user have paid/unlocked access to a course's lesson content
 * (the actual post/page bodies), not just the course's sales page?
 * Used by post.php / page.php to gate direct URL access to curriculum
 * items - being logged in isn't enough, they must also own the course.
 */
function user_can_access_course_content($course_product_id) {
    if (!$course_product_id) return true; // not part of any course - normal public content
    $user = current_user();
    if (!$user) return false;
    return user_owns_product($user['id'], (int)$course_product_id);
}

/* ---------------------------------------------------------
 * Shareable content links (generate a link that unlocks one
 * post/page for anyone who has it) - migration-share-links.sql
 * --------------------------------------------------------- */

/** Whether migration-share-links.sql has been run yet. */
function share_links_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT id FROM share_links LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Create a new share link for a post/page. $expiresAt = 'Y-m-d' string or null (never expires). */
function create_share_link($contentType, $contentId, $expiresAt = null) {
    $token = bin2hex(random_bytes(16));
    $stmt = db()->prepare("INSERT INTO share_links (token, content_type, content_id, expires_at, created_by) VALUES (?,?,?,?,?)");
    $user = function_exists('current_user') ? current_user() : null;
    $stmt->execute([
        $token,
        $contentType === 'page' ? 'page' : 'post',
        (int)$contentId,
        $expiresAt ? $expiresAt . ' 23:59:59' : null,
        $user ? $user['id'] : null,
    ]);
    return $token;
}

/** Fetch a share link row by token, or null if it doesn't exist / has expired. */
function get_share_link($token) {
    if (!share_links_ready() || !$token) return null;
    $stmt = db()->prepare("SELECT * FROM share_links WHERE token = ? LIMIT 1");
    $stmt->execute([$token]);
    $link = $stmt->fetch();
    if (!$link) return null;
    if (!empty($link['expires_at']) && strtotime($link['expires_at']) < time()) return null; // expired
    return $link;
}

/** All share links, most recent first, with the linked post/page title joined in. */
function list_share_links() {
    if (!share_links_ready()) return [];
    $links = db()->query("SELECT * FROM share_links ORDER BY created_at DESC")->fetchAll();
    foreach ($links as &$l) {
        if ($l['content_type'] === 'post') {
            $stmt = db()->prepare("SELECT title, slug, status FROM posts WHERE id = ?");
        } else {
            $stmt = db()->prepare("SELECT title, slug, status FROM pages WHERE id = ?");
        }
        $stmt->execute([$l['content_id']]);
        $content = $stmt->fetch();
        $l['content_title'] = $content['title'] ?? '(deleted)';
        $l['content_status'] = $content['status'] ?? null;
        $l['is_expired'] = !empty($l['expires_at']) && strtotime($l['expires_at']) < time();
    }
    return $links;
}

function delete_share_link($id) {
    $stmt = db()->prepare("DELETE FROM share_links WHERE id = ?");
    $stmt->execute([(int)$id]);
}

/* ---------------------------------------------------------
 * WordPress legacy password support (used only for members
 * imported from an old WordPress/WooCommerce site via Admin >
 * Import/Export > Import Users). Their old WordPress password
 * keeps working - verified against the original WP hash format
 * on login, then transparently upgraded to a normal bcrypt hash
 * so this check is only ever needed once per member.
 * --------------------------------------------------------- */

/** Verify a plain password against a WordPress-style hash ($P$/$H$ phpass, or newer $wp$-wrapped bcrypt). */
function wp_legacy_password_verify($password, $hash) {
    if (strpos($hash, '$wp$') === 0) {
        // WordPress 6.8+ stores "$wp$" + (a normal bcrypt hash with its own leading "$" removed),
        // e.g. a bcrypt hash "$2y$10$abc..." is stored as "$wp$2y$10$abc..." - so to verify it we
        // put that "$" back on before handing it to password_verify(), not just strip the "$wp$".
        return password_verify($password, '$' . substr($hash, 4));
    }
    if (strpos($hash, '$P$') === 0 || strpos($hash, '$H$') === 0) {
        return wp_phpass_verify($password, $hash);
    }
    return false;
}

/** Portable PHP password hashing framework (phpass) check - what WordPress used before 6.8. */
function wp_phpass_verify($password, $storedHash) {
    $itoa64 = './0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    if (strlen($storedHash) !== 34) return false;
    $countLog2 = strpos($itoa64, $storedHash[3]);
    if ($countLog2 === false || $countLog2 < 7 || $countLog2 > 30) return false;
    $salt = substr($storedHash, 4, 8);
    if (strlen($salt) !== 8) return false;

    $count = 1 << $countLog2;
    $hash = md5($salt . $password, true);
    do { $hash = md5($hash . $password, true); } while (--$count);

    $output = substr($storedHash, 0, 12) . wp_phpass_encode64($hash, 16, $itoa64);
    return hash_equals($storedHash, $output);
}

function wp_phpass_encode64($input, $count, $itoa64) {
    $output = '';
    $i = 0;
    do {
        $value = ord($input[$i++]);
        $output .= $itoa64[$value & 0x3f];
        if ($i < $count) $value |= ord($input[$i]) << 8;
        $output .= $itoa64[($value >> 6) & 0x3f];
        if ($i++ >= $count) break;
        if ($i < $count) $value |= ord($input[$i]) << 16;
        $output .= $itoa64[($value >> 12) & 0x3f];
        if ($i++ >= $count) break;
        $output .= $itoa64[($value >> 18) & 0x3f];
    } while ($i < $count);
    return $output;
}

/**
 * Check a member's login password - handles both normal bcrypt hashes
 * (password_hash/password_verify) and a raw WordPress hash left over
 * from a CSV user import. On a successful WordPress-hash login, the
 * hash is transparently upgraded to bcrypt so this only runs once.
 */
function verify_member_password($userId, $password, $storedHash) {
    if (password_verify($password, $storedHash)) return true;
    if (wp_legacy_password_verify($password, $storedHash)) {
        db()->prepare("UPDATE users SET password_hash=? WHERE id=?")
            ->execute([password_hash($password, PASSWORD_DEFAULT), (int)$userId]);
        return true;
    }
    return false;
}

/** All products with type='course', for the "Include this in a course" dropdown. */
function all_course_products($ignore_id = null) {
    if (!course_license_ready()) return [];
    $sql = "SELECT id, title FROM products WHERE type = 'course'";
    $params = [];
    if ($ignore_id) { $sql .= " AND id != ?"; $params[] = (int)$ignore_id; }
    $sql .= " ORDER BY title ASC";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/* ---------------------------------------------------------
 * Multi-Course product links (a product can now belong to
 * MORE than one Course) - migration-product-multi-course.sql.
 * The old single products.course_id column is kept around and
 * kept in sync with the first selected course, purely so any
 * older code path that still reads it directly doesn't break;
 * every current read path below prefers the product_courses
 * table once it exists.
 * --------------------------------------------------------- */

/** Whether migration-product-multi-course.sql has been run yet. */
function product_multi_course_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT product_id, course_id FROM product_courses LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Every course id a product is linked to (multi-course table only). */
function product_course_ids($product_id) {
    if (!product_multi_course_ready() || !$product_id) return [];
    $stmt = db()->prepare("SELECT course_id FROM product_courses WHERE product_id = ? ORDER BY id ASC");
    $stmt->execute([(int)$product_id]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/**
 * Every course (id + title) a product is linked to - reads the multi-course
 * table when it's ready, otherwise falls back to the legacy single
 * products.course_id column. Use this anywhere you want to DISPLAY which
 * course(s) a product belongs to (admin list badges, etc).
 */
function product_courses_list($product_id) {
    if (!$product_id) return [];
    if (product_multi_course_ready()) {
        $stmt = db()->prepare("SELECT c.id, c.title FROM product_courses pc
                                JOIN products c ON c.id = pc.course_id
                                WHERE pc.product_id = ? ORDER BY c.title ASC");
        $stmt->execute([(int)$product_id]);
        return $stmt->fetchAll();
    }
    if (!course_license_ready()) return [];
    $p = get_product($product_id);
    if ($p && !empty($p['course_id'])) {
        $c = get_product($p['course_id']);
        return $c ? [$c] : [];
    }
    return [];
}

/** Highest current curriculum sort_order inside a course (for appending new items at the end). */
function product_courses_max_sort_order($course_id) {
    $stmt = db()->prepare("SELECT COALESCE(MAX(sort_order),0) FROM product_courses WHERE course_id = ?");
    $stmt->execute([(int)$course_id]);
    return (int) $stmt->fetchColumn();
}

/**
 * Replace a product's course links with exactly $courseIds (from the admin
 * "Include this in a Course" checkboxes). A link that already existed keeps
 * its old sort_order (so re-saving the product doesn't reshuffle a course's
 * curriculum order); a brand new link is appended to the end of that
 * course's list.
 */
function set_product_courses($product_id, array $courseIds) {
    if (!product_multi_course_ready() || !$product_id) return;
    $product_id = (int)$product_id;
    $courseIds = array_values(array_unique(array_filter(array_map('intval', $courseIds))));

    $existing = [];
    $stmt = db()->prepare("SELECT course_id, sort_order FROM product_courses WHERE product_id = ?");
    $stmt->execute([$product_id]);
    foreach ($stmt->fetchAll() as $row) $existing[(int)$row['course_id']] = (int)$row['sort_order'];

    db()->prepare("DELETE FROM product_courses WHERE product_id = ?")->execute([$product_id]);

    $ins = db()->prepare("INSERT INTO product_courses (product_id, course_id, sort_order) VALUES (?,?,?)");
    foreach ($courseIds as $cid) {
        $order = $existing[$cid] ?? (product_courses_max_sort_order($cid) + 1);
        $ins->execute([$product_id, $cid, $order]);
    }
}

/* ---------------------------------------------------------
 * Multi-Course links for Posts AND Pages (a post/page can now
 * belong to MORE than one Course too) - same idea as the
 * Product multi-course table above, via
 * migration-content-multi-course.sql. The old single
 * posts.course_id / pages.course_id columns are kept around
 * and kept in sync with the first ticked course, purely as a
 * fallback for any older code path that still reads them
 * directly. course_sort_order / show_in_course / level stay as
 * single per-post/page fields (they apply the same way inside
 * every course the item is linked to).
 * --------------------------------------------------------- */

function post_multi_course_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT post_id, course_id FROM post_courses LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

function page_multi_course_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT page_id, course_id FROM page_courses LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Every course id a post is linked to - multi-course table if ready, else the legacy single column. */
function post_course_ids($post_id) {
    if (!$post_id) return [];
    if (post_multi_course_ready()) {
        $stmt = db()->prepare("SELECT course_id FROM post_courses WHERE post_id = ? ORDER BY id ASC");
        $stmt->execute([(int)$post_id]);
        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }
    if (!post_course_link_ready()) return [];
    $stmt = db()->prepare("SELECT course_id FROM posts WHERE id = ?");
    $stmt->execute([(int)$post_id]);
    $cid = $stmt->fetchColumn();
    return $cid ? [(int)$cid] : [];
}

/** Same, for pages. */
function page_course_ids($page_id) {
    if (!$page_id) return [];
    if (page_multi_course_ready()) {
        $stmt = db()->prepare("SELECT course_id FROM page_courses WHERE page_id = ? ORDER BY id ASC");
        $stmt->execute([(int)$page_id]);
        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }
    if (!page_course_link_ready()) return [];
    $stmt = db()->prepare("SELECT course_id FROM pages WHERE id = ?");
    $stmt->execute([(int)$page_id]);
    $cid = $stmt->fetchColumn();
    return $cid ? [(int)$cid] : [];
}

/** Every course (id + title) a post is linked to - for admin badge display. */
function post_courses_list($post_id) {
    $ids = post_course_ids($post_id);
    if (!$ids) return [];
    $in = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare("SELECT id, title FROM products WHERE id IN ($in) ORDER BY title ASC");
    $stmt->execute($ids);
    return $stmt->fetchAll();
}

/** Same, for pages. */
function page_courses_list($page_id) {
    $ids = page_course_ids($page_id);
    if (!$ids) return [];
    $in = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare("SELECT id, title FROM products WHERE id IN ($in) ORDER BY title ASC");
    $stmt->execute($ids);
    return $stmt->fetchAll();
}

function post_courses_max_sort_order($course_id) {
    $stmt = db()->prepare("SELECT COALESCE(MAX(sort_order),0) FROM post_courses WHERE course_id = ?");
    $stmt->execute([(int)$course_id]);
    return (int) $stmt->fetchColumn();
}

function page_courses_max_sort_order($course_id) {
    $stmt = db()->prepare("SELECT COALESCE(MAX(sort_order),0) FROM page_courses WHERE course_id = ?");
    $stmt->execute([(int)$course_id]);
    return (int) $stmt->fetchColumn();
}

/** Replace a post's course links with exactly $courseIds. Keeps existing per-course order; new links append to the end of that course's curriculum. */
function set_post_courses($post_id, array $courseIds) {
    if (!post_multi_course_ready() || !$post_id) return;
    $post_id = (int)$post_id;
    $courseIds = array_values(array_unique(array_filter(array_map('intval', $courseIds))));

    $existing = [];
    $stmt = db()->prepare("SELECT course_id, sort_order FROM post_courses WHERE post_id = ?");
    $stmt->execute([$post_id]);
    foreach ($stmt->fetchAll() as $row) $existing[(int)$row['course_id']] = (int)$row['sort_order'];

    db()->prepare("DELETE FROM post_courses WHERE post_id = ?")->execute([$post_id]);

    $ins = db()->prepare("INSERT INTO post_courses (post_id, course_id, sort_order) VALUES (?,?,?)");
    foreach ($courseIds as $cid) {
        $order = $existing[$cid] ?? (post_courses_max_sort_order($cid) + 1);
        $ins->execute([$post_id, $cid, $order]);
    }
}

/** Same, for pages. */
function set_page_courses($page_id, array $courseIds) {
    if (!page_multi_course_ready() || !$page_id) return;
    $page_id = (int)$page_id;
    $courseIds = array_values(array_unique(array_filter(array_map('intval', $courseIds))));

    $existing = [];
    $stmt = db()->prepare("SELECT course_id, sort_order FROM page_courses WHERE page_id = ?");
    $stmt->execute([$page_id]);
    foreach ($stmt->fetchAll() as $row) $existing[(int)$row['course_id']] = (int)$row['sort_order'];

    db()->prepare("DELETE FROM page_courses WHERE page_id = ?")->execute([$page_id]);

    $ins = db()->prepare("INSERT INTO page_courses (page_id, course_id, sort_order) VALUES (?,?,?)");
    foreach ($courseIds as $cid) {
        $order = $existing[$cid] ?? (page_courses_max_sort_order($cid) + 1);
        $ins->execute([$page_id, $cid, $order]);
    }
}

/**
 * Does this user have paid/unlocked access to a piece of lesson content that
 * may be linked to SEVERAL courses at once - true if it's linked to no
 * course (normal public content), or they own at least one of the linked
 * courses. Use this (not the single-course user_can_access_course_content)
 * anywhere a post/page can belong to more than one course.
 */
function user_can_access_course_content_any(array $course_ids) {
    if (!$course_ids) return true; // not part of any course - normal public content
    $user = current_user();
    if (!$user) return false;
    foreach ($course_ids as $cid) {
        if (user_owns_product($user['id'], (int)$cid)) return true;
    }
    return false;
}

/** Label shown in admin for a product's license_site setting (CSV of tool_sites.site_key). */
function license_site_label($site) {
    $keys = license_sites_expand($site);
    if (!$keys) return '—';
    $names = [];
    foreach ($keys as $k) {
        $s = tool_site_get($k);
        $names[] = $s['name'] ?? $k;
    }
    return $names ? implode(' + ', $names) : '—';
}

/** Existing license row for this user+product, if any. */
function get_user_license($user_id, $product_id) {
    if (!course_license_ready() || !$user_id) return null;
    $stmt = db()->prepare("SELECT * FROM product_licenses WHERE user_id = ? AND product_id = ? LIMIT 1");
    $stmt->execute([(int)$user_id, (int)$product_id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * If this product is flagged with a license_site (main_editor/litho/both),
 * auto-generate a unique username+password for this buyer so the Main
 * Editor / Litho Studio site can grant them access. Idempotent - only
 * generates once per user+product (UNIQUE KEY user_product).
 */
function generate_product_license_if_needed($user_id, $product_id) {
    if (!course_license_ready() || !$user_id) return null;
    $product = get_product($product_id);
    if (!$product || empty(license_sites_expand($product['license_site'] ?? ''))) return null;

    $existing = get_user_license($user_id, $product_id);
    if ($existing) return $existing;

    $stmtU = db()->prepare("SELECT * FROM users WHERE id = ?");
    $stmtU->execute([(int)$user_id]);
    $user = $stmtU->fetch();
    if (!$user) return null;

    // Base the license username on the buyer's own username/name, fall back to a product-based one.
    $base = !empty($user['username'] ?? null) ? $user['username'] : generate_username_from_name($user['name'] ?? ('buyer' . $user_id));
    $licenseUsername = $base;
    $i = 0;
    while (true) {
        $stmt = db()->prepare("SELECT id FROM product_licenses WHERE username = ?");
        $stmt->execute([$licenseUsername]);
        if (!$stmt->fetch()) break;
        $i++;
        $licenseUsername = $base . $i;
    }
    $password = generate_random_password(10);

    db()->prepare("INSERT IGNORE INTO product_licenses (user_id, product_id, site, username, password) VALUES (?,?,?,?,?)")
        ->execute([(int)$user_id, (int)$product_id, $product['license_site'], $licenseUsername, $password]);

    return get_user_license($user_id, $product_id);
}

/** Verify a username+password against product_licenses for a given site ('main_editor' or 'litho'). Used by api/verify-license.php. */
function verify_product_license($username, $password, $site) {
    if (!course_license_ready()) return null;
    $stmt = db()->prepare("SELECT * FROM product_licenses
                            WHERE username = ? AND password = ? AND status = 'active'
                              AND FIND_IN_SET(?, site) LIMIT 1");
    $stmt->execute([trim($username), trim($password), trim((string)$site)]);
    $row = $stmt->fetch();
    if ($row) {
        db()->prepare("UPDATE product_licenses SET last_verified_at = NOW() WHERE id = ?")->execute([$row['id']]);
    }
    return $row ?: null;
}

/** Count of paid orders for a product (used in admin listing). */
function product_sales_count($product_id) {
    if (!shop_tables_ready()) return 0;
    $stmt = db()->prepare("SELECT COUNT(*) c FROM user_products WHERE product_id = ?");
    $stmt->execute([(int)$product_id]);
    return (int) $stmt->fetch()['c'];
}

/* ---------------------------------------------------------
 * Menu visibility gating (Admin > Menu: everyone / members_only / buyers_only)
 * --------------------------------------------------------- */

/** Whether menu_items has the visibility/required_product_id columns yet. */
function menu_visibility_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT visibility, required_product_id FROM menu_items LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Filter a list of menu_items rows down to the ones this visitor (guest or logged-in $user) should see. */
function visible_menu_items($items, $user) {
    if (!menu_visibility_ready()) return $items; // migration not run yet - show everything (old behaviour)
    $out = [];
    foreach ($items as $m) {
        $vis = $m['visibility'] ?? 'everyone';
        if ($vis === 'everyone') {
            $out[] = $m;
        } elseif ($vis === 'members_only') {
            if ($user) $out[] = $m;
        } elseif ($vis === 'buyers_only') {
            if ($user && !empty($m['required_product_id']) && user_owns_product($user['id'], $m['required_product_id'])) {
                $out[] = $m;
            }
        } else {
            $out[] = $m;
        }
    }
    return $out;
}

/* ---------------------------------------------------------
 * Contact / enquiry form leads (admin/leads.php manages)
 * --------------------------------------------------------- */

function leads_table_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT 1 FROM form_submissions LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

function unread_leads_count() {
    if (!leads_table_ready()) return 0;
    return (int) db()->query("SELECT COUNT(*) c FROM form_submissions WHERE is_read = 0")->fetch()['c'];
}

/**
 * A user with an active membership plan here needs to be able to log
 * into Main Editor (it has no payment gateway of its own — billing
 * happens here, on membership.php). This gives them a main_editor
 * site_access login the first time they get a plan, and reuses the
 * same one on every renewal (password doesn't change under them).
 * Safe no-op if the 'main_editor' tool site isn't registered yet.
 */
function generate_main_editor_login_if_needed($user_id) {
    if (!tool_sites_ready() || !$user_id) return null;
    if (!tool_site_get('main_editor')) return null; // site not registered in Tool Sites & Access yet

    $stmt = db()->prepare("SELECT * FROM site_access WHERE user_id = ? AND site_key = 'main_editor' LIMIT 1");
    $stmt->execute([(int)$user_id]);
    $existing = $stmt->fetch();
    if ($existing) {
        if ($existing['status'] !== 'active') site_access_set_status($existing['id'], 'active');
        return $existing;
    }

    $stmtU = db()->prepare("SELECT * FROM users WHERE id = ?");
    $stmtU->execute([(int)$user_id]);
    $user = $stmtU->fetch();
    if (!$user) return null;

    $base = !empty($user['username'] ?? null) ? $user['username'] : generate_username_from_name($user['name'] ?? ('member' . $user_id));
    $username = $base;
    $i = 0;
    while (true) {
        $s = db()->prepare("SELECT id FROM site_access WHERE site_key = 'main_editor' AND username = ?");
        $s->execute([$username]);
        if (!$s->fetch()) break;
        $i++;
        $username = $base . $i;
    }

    return site_access_grant('main_editor', $username, null, (int)$user_id, 'Membership plan');
}

/** Existing Main Editor login for this user, if any (for display on dashboard/membership pages). */
function get_main_editor_login($user_id) {
    if (!tool_sites_ready() || !$user_id) return null;
    $stmt = db()->prepare("SELECT * FROM site_access WHERE user_id = ? AND site_key = 'main_editor' AND status = 'active' LIMIT 1");
    $stmt->execute([(int)$user_id]);
    return $stmt->fetch() ?: null;
}

/* ---------------------------------------------------------
 * Main Editor <-> Course Site signed handoff
 * (reuses the SAME api_key already stored in tool_sites for
 *  'main_editor' as a shared secret — no new key exchange needed)
 * --------------------------------------------------------- */

/** The main_editor tool site's api_key, used as our shared HMAC secret. */
function main_editor_shared_secret() {
    $site = tool_site_get('main_editor');
    return $site['api_key'] ?? '';
}

/** Verify an inbound signed request from Main Editor (main-editor-pay.php). */
function main_editor_verify_sig(array $params, $sig) {
    $secret = main_editor_shared_secret();
    if ($secret === '' || $sig === '' || $sig === null) return false;
    unset($params['sig']);
    ksort($params);
    $expected = hash_hmac('sha256', http_build_query($params), $secret);
    return hash_equals($expected, (string) $sig);
}

/**
 * After a Main Editor plan payment succeeds here, push the activation
 * over to Main Editor so it applies to that user's account there.
 * Returns true only on a confirmed 'ok' response from Main Editor.
 */
function main_editor_notify_activate($email, $planName, $days, $coins) {
    $baseUrl = rtrim((string) get_setting('main_editor_url', 'https://my3dgifts.com'), '/');
    $secret  = main_editor_shared_secret();
    if ($baseUrl === '' || $secret === '') return ['ok' => false, 'msg' => 'Main Editor not configured'];

    $params = [
        'email'     => $email,
        'plan_name' => $planName,
        'days'      => (int) $days,
        'coins'     => (int) $coins,
        'ts'        => time(),
    ];
    // IMPORTANT: Main Editor's api/activate-plan.php verifies this signature
    // with course_site_sign(), which ksort()s the params before hashing.
    // We MUST sort the same way here or every signature check fails silently
    // (this was the exact bug causing "payment OK but member access never
    // activates" — the checkout link the OTHER direction already ksorts via
    // course_site_sign()/main_editor_verify_sig(), so only this push-back
    // direction was missing it).
    $sigParams = $params;
    ksort($sigParams);
    $params['sig'] = hash_hmac('sha256', http_build_query($sigParams), $secret);

    $ch = curl_init($baseUrl . '/api/activate-plan.php');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($params),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 15,
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err) return ['ok' => false, 'msg' => 'Network error: ' . $err];
    $data = json_decode((string) $resp, true);
    return is_array($data) ? $data : ['ok' => false, 'msg' => 'Bad response from Main Editor'];
}

/**
 * After a Main Editor COIN purchase succeeds here, push an ADDITIVE
 * coin credit over to Main Editor. Unlike plan activation, this never
 * touches plan_name/plan_expiry — just adds to tripo_coins there.
 */
function main_editor_notify_credit_coins($email, $coins) {
    $baseUrl = rtrim((string) get_setting('main_editor_url', 'https://my3dgifts.com'), '/');
    $secret  = main_editor_shared_secret();
    if ($baseUrl === '' || $secret === '') return ['ok' => false, 'msg' => 'Main Editor not configured'];

    $params = ['email' => $email, 'coins' => (int) $coins, 'ts' => time()];
    // Same ksort requirement as main_editor_notify_activate() above — Main
    // Editor's api/credit-coins.php verifies with the sorted-params convention.
    $sigParams = $params;
    ksort($sigParams);
    $params['sig'] = hash_hmac('sha256', http_build_query($sigParams), $secret);

    $ch = curl_init($baseUrl . '/api/credit-coins.php');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($params),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 15,
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err) return ['ok' => false, 'msg' => 'Network error: ' . $err];
    $data = json_decode((string) $resp, true);
    return is_array($data) ? $data : ['ok' => false, 'msg' => 'Bad response from Main Editor'];
}

/* ---------------------------------------------------------
 * Tool Sites (per-site API keys) + manual access grants
 * migration-tool-sites.sql
 * --------------------------------------------------------- */

/** Whether migration-tool-sites.sql has been run. */
function tool_sites_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT 1 FROM tool_sites LIMIT 1"); db()->query("SELECT 1 FROM site_access LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** All registered tool sites. */
function tool_sites_all($only_active = false) {
    if (!tool_sites_ready()) return [];
    $sql = "SELECT * FROM tool_sites" . ($only_active ? " WHERE status='active'" : "") . " ORDER BY name ASC";
    return db()->query($sql)->fetchAll();
}

function tool_site_get($site_key) {
    if (!tool_sites_ready()) return null;
    $stmt = db()->prepare("SELECT * FROM tool_sites WHERE site_key = ? LIMIT 1");
    $stmt->execute([trim((string)$site_key)]);
    return $stmt->fetch() ?: null;
}

/** New random API key for a tool site. */
function tool_site_new_api_key() {
    return bin2hex(random_bytes(24));
}

function tool_site_create($site_key, $name, $site_url = '') {
    $site_key = strtolower(preg_replace('/[^a-z0-9_\-]/i', '', (string)$site_key));
    if ($site_key === '' || $name === '') return null;
    db()->prepare("INSERT IGNORE INTO tool_sites (site_key, name, site_url, api_key) VALUES (?,?,?,?)")
        ->execute([$site_key, $name, $site_url, tool_site_new_api_key()]);
    return tool_site_get($site_key);
}

function tool_site_regenerate_key($site_key) {
    $key = tool_site_new_api_key();
    db()->prepare("UPDATE tool_sites SET api_key = ? WHERE site_key = ?")->execute([$key, $site_key]);
    return $key;
}

/**
 * Authenticate an incoming API call.
 * Returns the site_key the caller may use, or null.
 *  - APP_SECRET  -> master key, may ask about any site
 *  - a tool_sites.api_key -> locked to that one site
 */
function tool_site_auth($api_key, $requested_site = null) {
    $api_key = (string)$api_key;
    if ($api_key === '') return null;
    if (hash_equals(APP_SECRET, $api_key)) {
        return ['site' => $requested_site ?: 'all', 'master' => true];
    }
    if (!tool_sites_ready()) return null;
    $stmt = db()->prepare("SELECT * FROM tool_sites WHERE api_key = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$api_key]);
    $row = $stmt->fetch();
    if (!$row) return null;
    if ($requested_site && $requested_site !== 'all' && $requested_site !== $row['site_key']) return null;
    return ['site' => $row['site_key'], 'master' => false, 'row' => $row];
}

/** Expand a product_licenses.site / products.license_site value (CSV of tool_sites.site_key) into a list of site keys. */
function license_sites_expand($site) {
    $site = trim((string)$site);
    if ($site === '' || $site === 'none') return [];
    if ($site === 'both') return ['main_editor', 'litho']; // backward compat, pre-migration rows
    $keys = array_filter(array_map('trim', explode(',', $site)), fn($k) => $k !== '');
    return array_values(array_unique($keys));
}

/** Manually grant a user access to a site. Returns the access row. */
function site_access_grant($site_key, $username, $password = null, $user_id = null, $note = '', $expires_at = null) {
    if (!tool_sites_ready()) return null;
    $username = trim((string)$username);
    if ($site_key === '' || $username === '') return null;
    $password = $password !== null && $password !== '' ? $password : generate_random_password(10);
    db()->prepare("INSERT INTO site_access (user_id, site_key, username, password, source, note, expires_at, status)
                   VALUES (?,?,?,?, 'manual', ?, ?, 'active')
                   ON DUPLICATE KEY UPDATE password = VALUES(password), note = VALUES(note),
                        expires_at = VALUES(expires_at), user_id = VALUES(user_id), status = 'active'")
        ->execute([$user_id ? (int)$user_id : null, $site_key, $username, $password, $note, $expires_at ?: null]);
    $stmt = db()->prepare("SELECT * FROM site_access WHERE site_key = ? AND username = ? LIMIT 1");
    $stmt->execute([$site_key, $username]);
    return $stmt->fetch() ?: null;
}

function site_access_set_status($id, $status) {
    if (!tool_sites_ready()) return;
    db()->prepare("UPDATE site_access SET status = ? WHERE id = ?")->execute([$status === 'active' ? 'active' : 'revoked', (int)$id]);
}

function site_access_delete($id) {
    if (!tool_sites_ready()) return;
    db()->prepare("DELETE FROM site_access WHERE id = ?")->execute([(int)$id]);
}

/**
 * Verify a login for any site key: manual grants first, then product licenses.
 * Returns ['username','name','product','site','source'] or null.
 */
function verify_site_login($username, $password, $site_key) {
    $username = trim((string)$username);
    $password = trim((string)$password);
    if ($username === '' || $password === '' || $site_key === '') return null;

    if (tool_sites_ready()) {
        $stmt = db()->prepare("SELECT * FROM site_access
                                WHERE site_key = ? AND username = ? AND password = ? AND status = 'active'
                                  AND (expires_at IS NULL OR expires_at >= CURDATE()) LIMIT 1");
        $stmt->execute([$site_key, $username, $password]);
        if ($row = $stmt->fetch()) {
            db()->prepare("UPDATE site_access SET last_verified_at = NOW() WHERE id = ?")->execute([$row['id']]);
            $name = $row['username'];
            if (!empty($row['user_id'])) {
                $s = db()->prepare("SELECT name FROM users WHERE id = ?"); $s->execute([(int)$row['user_id']]);
                $u = $s->fetch(); if ($u) $name = $u['name'];
            }
            return ['username'=>$row['username'], 'name'=>$name, 'product'=>$row['note'] ?: 'Manual access',
                    'site'=>$site_key, 'source'=>'manual', 'user_id'=>$row['user_id'] ? (int)$row['user_id'] : null];
        }
    }

    $lic = verify_product_license($username, $password, $site_key);
    if ($lic) {
        $product = get_product($lic['product_id']);
        $s = db()->prepare("SELECT name FROM users WHERE id = ?"); $s->execute([(int)$lic['user_id']]);
        $u = $s->fetch();
        return ['username'=>$lic['username'], 'name'=>$u['name'] ?? $lic['username'],
                'product'=>$product['title'] ?? 'Course', 'site'=>$site_key, 'source'=>'product',
                'user_id'=>(int)$lic['user_id']];
    }
    return null;
}

/**
 * One row per login (username) with the list of sites it can access.
 * $filter_site: a site key to only return users having that site, or 'all'.
 */
function site_users_list($filter_site = 'all') {
    $users = [];

    if (course_license_ready()) {
        $sql = "SELECT l.*, u.name AS user_name, u.email, p.title AS product
                  FROM product_licenses l
                  LEFT JOIN users u ON u.id = l.user_id
                  LEFT JOIN products p ON p.id = l.product_id
                 ORDER BY l.created_at DESC";
        foreach (db()->query($sql)->fetchAll() as $r) {
            $k = strtolower($r['username']);
            if (!isset($users[$k])) {
                $users[$k] = ['username'=>$r['username'], 'user_name'=>$r['user_name'], 'email'=>$r['email'],
                              'products'=>[], 'sites'=>[], 'status'=>$r['status'], 'source'=>'product',
                              'created_at'=>$r['created_at'], 'last_verified_at'=>$r['last_verified_at']];
            }
            if ($r['product']) $users[$k]['products'][] = $r['product'];
            if ($r['status'] === 'active') {
                foreach (license_sites_expand($r['site']) as $s) $users[$k]['sites'][$s] = 'product';
            }
            if ($r['last_verified_at'] > ($users[$k]['last_verified_at'] ?? '')) $users[$k]['last_verified_at'] = $r['last_verified_at'];
        }
    }

    if (tool_sites_ready()) {
        $sql = "SELECT a.*, u.name AS user_name, u.email FROM site_access a
                  LEFT JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC";
        foreach (db()->query($sql)->fetchAll() as $r) {
            $k = strtolower($r['username']);
            if (!isset($users[$k])) {
                $users[$k] = ['username'=>$r['username'], 'user_name'=>$r['user_name'], 'email'=>$r['email'],
                              'products'=>[], 'sites'=>[], 'status'=>$r['status'], 'source'=>'manual',
                              'created_at'=>$r['created_at'], 'last_verified_at'=>$r['last_verified_at']];
            }
            if ($r['note']) $users[$k]['products'][] = $r['note'];
            if ($r['status'] === 'active') $users[$k]['sites'][$r['site_key']] = 'manual';
            if ($r['last_verified_at'] > ($users[$k]['last_verified_at'] ?? '')) $users[$k]['last_verified_at'] = $r['last_verified_at'];
        }
    }

    $out = [];
    foreach ($users as $u) {
        if ($filter_site !== 'all' && $filter_site !== '' && !isset($u['sites'][$filter_site])) continue;
        $u['products'] = array_values(array_unique(array_filter($u['products'])));
        $out[] = $u;
    }
    return $out;
}


/**
 * Tool site kku anupura plan / feature limit info.
 * Editor site ithai vachu premium templates + limits set panniykkum.
 */
function site_login_plan_info($user_id) {
    $info = [
        'plan_name'        => null,
        'plan_expiry'      => null,
        'premium_designer' => 1,   // course vaangunavanga default-a premium
        'ai_daily_limit'   => 0,   // 0 = tool site oda own default
        'project_slots'    => 0,
        'plan_bonus_coins' => 0,   // how many coins Main Editor should give this user
    ];
    if (!$user_id) return $info;
    try {
        $st = db()->prepare("SELECT plan_id, plan_name, plan_expiry FROM users WHERE id = ? LIMIT 1");
        $st->execute([(int)$user_id]);
        $u = $st->fetch();
        if (!$u) return $info;
        $info['plan_name']   = $u['plan_name'];
        $info['plan_expiry'] = $u['plan_expiry'];
        if (!empty($u['plan_name'])) {
            $plan = get_plan_by_name($u['plan_name']);
            if ($plan) {
                $info['premium_designer'] = (int)($plan['premium_designer'] ?? 1);
                $info['ai_daily_limit']   = (int)($plan['ai_daily_limit'] ?? 0);
                $info['project_slots']    = (int)($plan['project_slots'] ?? 0);
                $info['plan_bonus_coins'] = (int)($plan['plan_bonus_coins'] ?? 0);
            }
        }
    } catch (Exception $e) { /* keep defaults */ }
    return $info;
}

/* ---------------------------------------------------------
 * Site access extras: optional Gmail/email on manual grants,
 * multi-site grants, edit support, and per-user access list.
 * migration-site-access-email.sql
 * --------------------------------------------------------- */

/** Whether site_access.email column exists (migration-site-access-email.sql). */
function site_access_email_ready() {
    static $ready = null;
    if ($ready === null) {
        if (!tool_sites_ready()) return false;
        try { db()->query("SELECT email FROM site_access LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** One manual access row. */
function site_access_get($id) {
    if (!tool_sites_ready()) return null;
    $st = db()->prepare("SELECT * FROM site_access WHERE id = ? LIMIT 1");
    $st->execute([(int)$id]);
    return $st->fetch() ?: null;
}

/** Save the optional email/gmail on a manual access row. */
function site_access_set_email($site_key, $username, $email) {
    if (!site_access_email_ready()) return;
    db()->prepare("UPDATE site_access SET email = ? WHERE site_key = ? AND username = ?")
        ->execute([$email !== '' ? $email : null, $site_key, $username]);
}

/**
 * Grant one username access to MANY sites at once (tick-box flow).
 * Returns ['username','password','sites'=>[names]] or null.
 */
function site_access_grant_multi(array $site_keys, $username, $password = null, $user_id = null,
                                 $note = '', $expires_at = null, $email = '') {
    if (!tool_sites_ready()) return null;
    $username = trim((string)$username);
    $valid = array_values(array_intersect($site_keys, array_column(tool_sites_all(), 'site_key')));
    if ($username === '' || !$valid) return null;
    $password = ($password !== null && $password !== '') ? $password : generate_random_password(10);
    $done = [];
    foreach ($valid as $sk) {
        $row = site_access_grant($sk, $username, $password, $user_id, $note, $expires_at);
        if ($row) {
            site_access_set_email($sk, $username, trim((string)$email));
            $s = tool_site_get($sk);
            $done[] = $s['name'] ?? $sk;
        }
    }
    return $done ? ['username' => $username, 'password' => $password, 'sites' => $done] : null;
}

/**
 * Update one manual access row (edit option in admin).
 * Passing $site_keys replaces the whole set of sites for this username.
 */
function site_access_update($id, array $fields, ?array $site_keys = null) {
    if (!tool_sites_ready()) return null;
    $row = site_access_get($id);
    if (!$row) return null;

    $username = trim((string)($fields['username'] ?? $row['username']));
    if ($username === '') $username = $row['username'];
    $password = trim((string)($fields['password'] ?? '')) !== '' ? trim($fields['password']) : $row['password'];
    $note     = array_key_exists('note', $fields) ? trim((string)$fields['note']) : $row['note'];
    $expires  = array_key_exists('expires_at', $fields) ? ($fields['expires_at'] ?: null) : $row['expires_at'];
    $status   = ($fields['status'] ?? $row['status']) === 'revoked' ? 'revoked' : 'active';
    $userId   = array_key_exists('user_id', $fields) ? ($fields['user_id'] ? (int)$fields['user_id'] : null) : ($row['user_id'] ?: null);
    $email    = array_key_exists('email', $fields) ? trim((string)$fields['email']) : (string)($row['email'] ?? '');

    // Sites this login currently has (manual grants only), keyed by site.
    $st = db()->prepare("SELECT * FROM site_access WHERE username = ? AND source = 'manual'");
    $st->execute([$row['username']]);
    $current = $st->fetchAll();

    $target = $site_keys === null
        ? array_column($current, 'site_key')
        : array_values(array_intersect($site_keys, array_column(tool_sites_all(), 'site_key')));
    if (!$target) $target = [$row['site_key']];

    // Remove sites that were unticked.
    foreach ($current as $c) {
        if (!in_array($c['site_key'], $target, true)) {
            db()->prepare("DELETE FROM site_access WHERE id = ?")->execute([(int)$c['id']]);
        }
    }
    // Upsert every ticked site with the new details.
    foreach ($target as $sk) {
        db()->prepare("INSERT INTO site_access (user_id, site_key, username, password, source, note, expires_at, status)
                       VALUES (?,?,?,?, 'manual', ?, ?, ?)
                       ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), password = VALUES(password),
                            note = VALUES(note), expires_at = VALUES(expires_at), status = VALUES(status)")
            ->execute([$userId, $sk, $username, $password, $note, $expires, $status]);
        site_access_set_email($sk, $username, $email);
    }
    // Username changed -> clear the old rows.
    if (strcasecmp($username, $row['username']) !== 0) {
        db()->prepare("DELETE FROM site_access WHERE username = ? AND source = 'manual'")->execute([$row['username']]);
    }
    return ['username' => $username, 'password' => $password, 'sites' => $target];
}

/** All manual grants for one login username. */
function site_access_sites_for_username($username) {
    if (!tool_sites_ready()) return [];
    $st = db()->prepare("SELECT site_key FROM site_access WHERE username = ? AND source = 'manual'");
    $st->execute([(string)$username]);
    return array_column($st->fetchAll(), 'site_key');
}

/**
 * Every tool site a logged-in member can access, with the login to use.
 * Sources: manual grants (site_access) + purchased course/product licenses.
 * Returns list of ['site_key','name','site_url','username','password','source','expires_at','via'].
 */
function user_site_access($user_id) {
    $user_id = (int)$user_id;
    if (!$user_id || !tool_sites_ready()) return [];
    $out = [];

    $st = db()->prepare("SELECT * FROM site_access WHERE user_id = ? AND status = 'active'
                          AND (expires_at IS NULL OR expires_at >= CURDATE())");
    $st->execute([$user_id]);
    foreach ($st->fetchAll() as $r) {
        $s = tool_site_get($r['site_key']);
        if (!$s || $s['status'] !== 'active') continue;
        $out[$r['site_key']] = [
            'site_key' => $r['site_key'], 'name' => $s['name'], 'site_url' => $s['site_url'],
            'username' => $r['username'], 'password' => $r['password'], 'source' => 'manual',
            'expires_at' => $r['expires_at'], 'via' => $r['note'] ?: 'Granted by admin',
        ];
    }

    if (course_license_ready()) {
        $sql = "SELECT l.*, p.title AS product_title FROM product_licenses l
                  LEFT JOIN products p ON p.id = l.product_id
                 WHERE l.user_id = ? AND l.status = 'active'";
        $st = db()->prepare($sql);
        $st->execute([$user_id]);
        foreach ($st->fetchAll() as $r) {
            foreach (license_sites_expand($r['site']) as $sk) {
                if (isset($out[$sk])) continue;
                $s = tool_site_get($sk);
                if (!$s || $s['status'] !== 'active') continue;
                $out[$sk] = [
                    'site_key' => $sk, 'name' => $s['name'], 'site_url' => $s['site_url'],
                    'username' => $r['username'], 'password' => $r['password'], 'source' => 'product',
                    'expires_at' => $r['expires_at'] ?? null, 'via' => $r['product_title'] ?: 'Purchase',
                ];
            }
        }
    }

    return array_values($out);
}
