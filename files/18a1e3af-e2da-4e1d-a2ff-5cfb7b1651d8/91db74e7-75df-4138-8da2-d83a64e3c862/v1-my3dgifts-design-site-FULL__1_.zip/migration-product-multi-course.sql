-- Lets a Product be ticked into MORE THAN ONE Course under "Include this in
-- a Course" (previously it was a single-select, one course per product).
-- Safe to run on a live site: only adds one new table and copies existing
-- single-course links into it. Nothing existing is deleted or altered -
-- the old products.course_id column is left in place and kept in sync with
-- the first ticked course, purely as a fallback for any old code path.

CREATE TABLE IF NOT EXISTS product_courses (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  product_id INT UNSIGNED NOT NULL,
  course_id INT UNSIGNED NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_product_course (product_id, course_id),
  KEY idx_product_id (product_id),
  KEY idx_course_id (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Carry over every product that was already linked to a single course
-- (its old sort_order becomes that course's curriculum order).
INSERT IGNORE INTO product_courses (product_id, course_id, sort_order)
SELECT id, course_id, sort_order FROM products WHERE course_id IS NOT NULL;
