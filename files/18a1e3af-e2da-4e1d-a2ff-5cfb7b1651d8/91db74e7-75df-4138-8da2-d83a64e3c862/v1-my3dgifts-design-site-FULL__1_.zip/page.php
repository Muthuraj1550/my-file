<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$slug = $_GET['slug'] ?? '';
$stmt = db()->prepare("SELECT * FROM pages WHERE slug = ? AND status='published' LIMIT 1");
$stmt->execute([$slug]);
$page = $stmt->fetch();

if (!$page) {
    http_response_code(404);
    $pageTitle = 'Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="card"><h1>Page not found</h1></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

// Course curriculum items (linked to 1+ courses) are paid lesson content -
// gate the actual body behind login + owning at least one linked course,
// and keep them out of Google.
$linkedCourseIds = function_exists('page_course_link_ready') && page_course_link_ready() ? page_course_ids($page['id']) : [];
$isCourseContent = !empty($linkedCourseIds);
$courseProducts = [];
$courseProduct = null; // first linked course - used for the single "return to course" link
$hasCourseAccess = true;
if ($isCourseContent) {
    foreach ($linkedCourseIds as $cid) {
        $cp = get_product($cid);
        if ($cp) $courseProducts[] = $cp;
    }
    $courseProduct = $courseProducts[0] ?? null;
    $hasCourseAccess = user_can_access_course_content_any($linkedCourseIds);
}

$pageTitle = $page['title'];
$metaTitle = $page['meta_title'] ?: null;
$metaDescription = $page['meta_description'] ?: null;
$noIndex = $isCourseContent; // paid lesson content shouldn't rank/be indexed
$viewId = $hasCourseAccess ? record_view('page', $page['id']) : 0;
// Only show a "return to course" link when the visitor actually came here from
// that course's curriculum list (not on every lesson, every time).
$showReturnToCourse = $isCourseContent && $hasCourseAccess && $courseProduct && (($_GET['from'] ?? '') === 'course');
include __DIR__ . '/includes/header.php';
?>
<?php if ($showReturnToCourse): ?>
<p style="margin-bottom:10px;"><a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($courseProduct['slug']); ?>">← Return to Course Content</a></p>
<?php endif; ?>
<?php if ($isCourseContent && !$hasCourseAccess): ?>
<article class="card">
  <h1><?php echo h($page['title']); ?></h1>
  <div class="flash flash-error" style="margin-top:10px;">
    🔒 This lesson is part of <?php echo $courseProducts ? implode(' or ', array_map(fn($c) => '"' . h($c['title']) . '"', $courseProducts)) : 'a paid course'; ?> and is locked.
    <?php echo current_user() ? 'You need to purchase ' . (count($courseProducts) > 1 ? 'one of these courses' : 'this course') . ' to unlock it.' : 'Please login and purchase ' . (count($courseProducts) > 1 ? 'one of these courses' : 'this course') . ' to unlock it.'; ?>
  </div>
  <p style="margin-top:16px;">
    <?php if (!current_user()): ?>
      <a href="<?php echo SITE_URL; ?>/login.php?next=<?php echo urlencode('/page.php?slug=' . $page['slug']); ?>" class="btn">Login</a>
    <?php endif; ?>
    <?php foreach ($courseProducts as $cp): ?>
      <a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($cp['slug']); ?>" class="btn <?php echo current_user() ? '' : 'btn-outline'; ?>">View <?php echo count($courseProducts) > 1 ? '"' . h($cp['title']) . '"' : 'Course'; ?> &amp; Buy</a>
    <?php endforeach; ?>
  </p>
</article>
<?php else: ?>
<article class="card">
  <h1><?php echo h($page['title']); ?></h1>
  <div class="post-content"><?php echo $page['content']; /* trusted admin HTML content */ ?></div>
  <?php if (!empty($page['button_text']) && !empty($page['button_url'])): ?>
    <p style="margin-top:20px;">
      <a href="<?php echo (strpos($page['button_url'],'http')===0) ? h($page['button_url']) : SITE_URL . h($page['button_url']); ?>"
         class="btn" <?php echo $page['button_new_tab'] ? 'target="_blank" rel="noopener"' : ''; ?>><?php echo h($page['button_text']); ?></a>
    </p>
  <?php endif; ?>
</article>
<?php endif; ?>
<script>
(function(){
  var viewId = <?php echo (int)$viewId; ?>;
  var start = Date.now();
  function sendDuration(){
    var seconds = Math.round((Date.now() - start) / 1000);
    var payload = JSON.stringify({ view_id: viewId, type: 'page', seconds: seconds });
    if (navigator.sendBeacon) {
      navigator.sendBeacon('<?php echo SITE_URL; ?>/api/track-view.php', new Blob([payload], {type:'application/json'}));
    }
  }
  window.addEventListener('pagehide', sendDuration);
  document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') sendDuration(); });
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
