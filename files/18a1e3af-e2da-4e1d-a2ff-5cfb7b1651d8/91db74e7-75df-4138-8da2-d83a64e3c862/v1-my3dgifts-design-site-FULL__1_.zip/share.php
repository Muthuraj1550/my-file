<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$token = trim($_GET['token'] ?? '');
$link = $token ? get_share_link($token) : null;

if (!$link) {
    http_response_code(404);
    $pageTitle = 'Link Not Available';
    include __DIR__ . '/includes/header.php';
    echo '<div class="card"><h1>This link is invalid or has expired</h1><p style="color:var(--muted,#94a3b8);">Please ask for a fresh link.</p></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

if ($link['content_type'] === 'post') {
    $stmt = db()->prepare("SELECT * FROM posts WHERE id = ? LIMIT 1");
} else {
    $stmt = db()->prepare("SELECT * FROM pages WHERE id = ? LIMIT 1");
}
$stmt->execute([$link['content_id']]);
$content = $stmt->fetch();

if (!$content) {
    http_response_code(404);
    $pageTitle = 'Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="card"><h1>This content no longer exists</h1></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = $content['title'];
$metaTitle = $content['meta_title'] ?? null;
$metaDescription = $content['meta_description'] ?? ($content['excerpt'] ?? null);
$noIndex = true; // shared links should never be indexed by search engines
include __DIR__ . '/includes/header.php';
?>
<article class="card">
  <?php if ($content['status'] !== 'published'): ?>
    <div class="flash flash-success" style="margin-bottom:14px;">👁️ Shared preview — this content is still a draft.</div>
  <?php endif; ?>
  <h1><?php echo h($content['title']); ?></h1>
  <?php if ($link['content_type'] === 'post' && !empty($content['featured_image'])): ?>
    <img src="<?php echo h($content['featured_image']); ?>" style="max-width:100%;border-radius:10px;margin:16px 0;">
  <?php endif; ?>
  <div class="post-content"><?php echo $content['content']; /* trusted admin HTML content */ ?></div>
  <?php if (!empty($content['button_text']) && !empty($content['button_url'])): ?>
    <p style="margin-top:20px;">
      <a href="<?php echo (strpos($content['button_url'],'http')===0) ? h($content['button_url']) : SITE_URL . h($content['button_url']); ?>"
         class="btn" <?php echo !empty($content['button_new_tab']) ? 'target="_blank" rel="noopener"' : ''; ?>><?php echo h($content['button_text']); ?></a>
    </p>
  <?php endif; ?>
  <?php if (!empty($link['expires_at'])): ?>
    <p style="margin-top:22px;color:var(--muted,#94a3b8);font-size:12px;">🔗 This shared link expires on <?php echo date('d M Y', strtotime($link['expires_at'])); ?>.</p>
  <?php endif; ?>
</article>
<?php include __DIR__ . '/includes/footer.php'; ?>
