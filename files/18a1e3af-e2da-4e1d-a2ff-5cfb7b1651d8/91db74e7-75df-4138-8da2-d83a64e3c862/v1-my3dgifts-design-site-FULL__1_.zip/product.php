<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cashfree.php';

if (!shop_tables_ready()) {
    header('Location: ' . SITE_URL . '/products.php');
    exit;
}

$slug = trim($_GET['slug'] ?? '');
$product = $slug ? get_product_by_slug($slug) : null;
if (!$product || $product['status'] !== 'published') {
    header('HTTP/1.0 404 Not Found');
    $pageTitle = 'Product Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="card"><h2>Product not found</h2><a href="' . SITE_URL . '/products.php" class="btn">Back to Shop</a></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$user = current_user();
$owns = $user && user_effectively_owns_product($user['id'], $product);
$eff  = product_effective_price($product);
$checkoutSessionId = null;
$checkoutError = null;

// ---- Buy button ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_product'])) {
    csrf_check();
    if (!$user) {
        redirect('/register.php?next=' . urlencode('/product.php?slug=' . $product['slug']));
    }
    if ($owns) {
        redirect('/my-purchases.php');
    }
    if ($eff <= 0) {
        // Free product - grant instantly, no payment needed.
        grant_product_to_user($user['id'], $product['id']);
        flash('You now have access to "' . $product['title'] . '".');
        redirect('/my-purchases.php');
    }
    $orderId = 'PROD' . $user['id'] . 'P' . $product['id'] . 'T' . time();
    $cfResp = cashfree_create_order($orderId, $eff, $user);
    if (!empty($cfResp['error'])) {
        $checkoutError = 'Payment gateway error: ' . $cfResp['error'] . ' (Check Cashfree keys in Admin > Settings)';
    } elseif (!empty($cfResp['payment_session_id'])) {
        db()->prepare("INSERT INTO product_orders (user_id, product_id, cf_order_id, amount, status) VALUES (?,?,?,?,'created')")
            ->execute([$user['id'], $product['id'], $orderId, $eff]);
        $checkoutSessionId = $cfResp['payment_session_id'];
    } else {
        $checkoutError = 'Could not create payment order. Please try again shortly.';
    }
}

$pageTitle = $product['title'];
$metaTitle = $product['title'];
$metaDescription = $product['short_desc'] ?? '';
$viewId = record_view('product', $product['id']);
include __DIR__ . '/includes/header.php';
?>

<?php if ($checkoutError): ?>
  <div class="flash flash-error"><?php echo h($checkoutError); ?></div>
<?php endif; ?>

<?php if ($checkoutSessionId): ?>
  <div class="card" style="text-align:center;">
    <h2>Redirecting to secure payment...</h2>
    <p>Please wait, do not close this window.</p>
  </div>
  <script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
  <script>
    const cashfree = Cashfree({ mode: "<?php echo get_setting('cashfree_mode','sandbox') === 'production' ? 'production' : 'sandbox'; ?>" });
    cashfree.checkout({
      paymentSessionId: "<?php echo h($checkoutSessionId); ?>",
      redirectTarget: "_self"
    });
  </script>
<?php else: ?>

<div class="card" style="display:flex;gap:28px;flex-wrap:wrap;align-items:flex-start;">
  <div style="flex:1;min-width:260px;">
    <?php if (!empty($product['thumbnail'])): ?>
      <img src="<?php echo h($product['thumbnail']); ?>" alt="<?php echo h($product['title']); ?>" style="width:100%;border-radius:12px;">
    <?php else: ?>
      <div style="width:100%;aspect-ratio:1/1;background:linear-gradient(135deg,#1e293b,#0f172a);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:60px;">🗂️</div>
    <?php endif; ?>
  </div>
  <div style="flex:1.3;min-width:280px;">
    <?php if ($product['type'] === 'course' && !empty($product['level']) && function_exists('course_level_label')): ?>
      <span class="badge badge-gold" style="margin-bottom:6px;display:inline-block;font-size:12px;"><?php echo h(course_level_label($product['level'])); ?></span>
    <?php endif; ?>
    <?php if (!empty($product['category'])): ?><div style="font-size:12px;color:var(--muted,#94a3b8);text-transform:uppercase;letter-spacing:.5px;"><?php echo h($product['category']); ?></div><?php endif; ?>
    <h1 style="margin:6px 0 14px;"><?php echo h($product['title']); ?></h1>

    <div style="margin-bottom:18px;">
      <?php if ($eff < (float)$product['price']): ?>
        <span style="text-decoration:line-through;color:var(--muted,#94a3b8);font-size:16px;">₹<?php echo number_format($product['price'],0); ?></span>
        <strong style="font-size:28px;color:#22c55e;margin-left:8px;">₹<?php echo number_format($eff,0); ?></strong>
      <?php else: ?>
        <strong style="font-size:28px;"><?php echo $eff > 0 ? '₹' . number_format($eff,0) : 'Free'; ?></strong>
      <?php endif; ?>
    </div>

    <?php if ($owns): ?>
      <div class="flash flash-success">✅ You already own this <?php echo $product['type'] === 'course' ? 'course' : 'file'; ?>.</div>
      <?php if ($product['type'] !== 'course'): ?>
        <?php if (!empty($product['delivery_link'])): ?>
          <a href="<?php echo h($product['delivery_link']); ?>" target="_blank" rel="noopener" class="btn" style="font-size:16px;padding:14px 26px;">⬇️ Download / Open</a>
          <?php if (!empty($product['delivery_note'])): ?><p style="font-size:13px;color:var(--muted,#94a3b8);margin-top:8px;"><?php echo h($product['delivery_note']); ?></p><?php endif; ?>
        <?php else: ?>
          <p style="color:var(--muted,#94a3b8);">Download link not set yet - contact support, it'll be added shortly.</p>
        <?php endif; ?>
        <?php if (function_exists('course_license_ready') && course_license_ready() && !empty($product['license_site']) && $product['license_site'] !== 'none'):
          $license = generate_product_license_if_needed($user['id'], $product['id']);
          if ($license): ?>
          <div style="margin-top:16px;padding:12px;border-radius:8px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);">
            <p style="margin:0 0 6px;font-weight:600;">🔑 <?php echo h(license_site_label($license['site'])); ?> Login</p>
            <p style="margin:0;font-size:14px;">Username: <code><?php echo h($license['username']); ?></code></p>
            <p style="margin:2px 0 0;font-size:14px;">Password: <code><?php echo h($license['password']); ?></code></p>
          </div>
        <?php endif; endif; ?>
      <?php endif; ?>
      <p style="margin-top:12px;"><a href="<?php echo SITE_URL; ?>/my-purchases.php" class="btn btn-outline">Go to My Purchases</a></p>
    <?php else: ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" name="buy_product" value="1" class="btn" style="font-size:16px;padding:14px 26px;">
          <?php echo $eff > 0 ? 'Buy Now - ₹' . number_format($eff,0) : 'Get Free Access'; ?>
        </button>
      </form>
      <?php if (!$user): ?><p style="color:var(--muted,#94a3b8);font-size:13px;margin-top:10px;">You'll be asked to login/register before checkout.</p><?php endif; ?>
    <?php endif; ?>

    <?php if (!empty($product['description'])): ?>
      <?php echo render_toc_block($product['description']); ?>
      <div class="post-content" style="margin-top:16px;line-height:1.7;">
        <?php if (strpos($product['description'], '<!--BLOCK:') !== false): ?>
          <?php echo $product['description']; /* trusted admin HTML content, block-builder output */ ?>
        <?php else: ?>
          <?php echo nl2br(h($product['description'])); /* legacy plain-text description, saved before the block editor */ ?>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <?php if ($product['type'] === 'course' && function_exists('course_license_ready') && course_license_ready()):
      $includedItems = course_included_items($product['id'], true, true);
      if ($includedItems):
        $typeIcon = ['post' => '📝', 'page' => '📄', 'product' => '🗂️'];
        $levelLabels = ['beginner' => '🔰 Beginner', 'intermediate' => '🎯 Intermediate', 'advanced' => '🚀 Advanced'];
        $itemLevelsInUse = array_values(array_unique(array_filter(array_column($includedItems, 'level'))));
        $itemLevelsInUse = array_intersect(['beginner','intermediate','advanced'], $itemLevelsInUse); // keep fixed order
      ?>
      <div style="margin-top:24px;">
        <h3 style="margin-bottom:6px;">📦 What's Covered in This Course</h3>
        <p style="color:var(--muted,#94a3b8);font-size:13px;margin-top:0;">
          <?php echo $owns ? 'You have access — click any topic to open it.' : "Here's what you'll learn. Buy the course to unlock every lesson below."; ?>
        </p>

        <?php if ($itemLevelsInUse): ?>
        <div style="margin-bottom:14px;">
          <div style="font-size:12px;color:var(--muted,#94a3b8);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;">Already know some 3D design? Pick your level to skip ahead:</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button type="button" class="btn btn-sm course-level-filter-btn active" data-level="all">All Topics</button>
            <?php foreach ($itemLevelsInUse as $lv): ?>
              <button type="button" class="btn btn-sm btn-outline course-level-filter-btn" data-level="<?php echo h($lv); ?>"><?php echo $levelLabels[$lv] ?? ucfirst($lv); ?></button>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>

        <ul style="line-height:2;padding-left:20px;list-style:none;margin-left:0;" id="courseContentList">
          <?php foreach ($includedItems as $it): ?>
            <li style="margin-bottom:4px;" data-level="<?php echo h($it['level'] ?? ''); ?>">
              <?php if ($owns): ?>
                <a href="<?php echo h($it['url']); ?><?php echo (strpos($it['url'], '?') !== false ? '&' : '?') . 'from=course'; ?>"><?php echo $typeIcon[$it['type']] ?? ''; ?> <?php echo h($it['title']); ?></a>
              <?php else: ?>
                <span style="color:var(--muted,#94a3b8);">🔒 <?php echo h($it['title']); ?></span>
              <?php endif; ?>
              <?php if (!empty($it['level']) && isset($levelLabels[$it['level']])): ?>
                <span class="badge" style="font-size:10px;margin-left:6px;"><?php echo h($levelLabels[$it['level']]); ?></span>
              <?php endif; ?>
              <?php if (!empty($it['short_desc'])): ?> — <span style="color:var(--muted,#94a3b8);font-size:13px;"><?php echo h($it['short_desc']); ?></span><?php endif; ?>
              <?php if (!empty($it['sub_topics'])): ?>
                <details class="toc-box" style="margin:6px 0 0 22px;padding:8px 12px;">
                  <summary style="font-size:13px;">📋 Topics covered (<?php echo count($it['sub_topics']); ?>)</summary>
                  <ul class="toc-list" style="font-size:13px;">
                    <?php foreach ($it['sub_topics'] as $st): ?>
                      <li class="toc-level-<?php echo (int)$st['level']; ?>"><?php echo h($st['text']); ?></li>
                    <?php endforeach; ?>
                  </ul>
                </details>
              <?php endif; ?>
              <?php if (!empty($it['sub_links'])): ?>
                <ul style="list-style:none;padding-left:22px;margin:2px 0 0;line-height:1.8;">
                  <?php foreach ($it['sub_links'] as $sl): ?>
                    <li style="font-size:13px;">
                      <?php if ($owns): ?>
                        <a href="<?php echo h($sl['url']); ?>" target="_blank" rel="noopener">🔗 <?php echo h($sl['text']); ?></a>
                      <?php else: ?>
                        <span style="color:var(--muted,#94a3b8);">🔒 <?php echo h($sl['text']); ?></span>
                      <?php endif; ?>
                    </li>
                  <?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>

        <?php if ($itemLevelsInUse): ?>
        <script>
        (function(){
          var btns = document.querySelectorAll('.course-level-filter-btn');
          var items = document.querySelectorAll('#courseContentList > li');
          btns.forEach(function(btn){
            btn.addEventListener('click', function(){
              btns.forEach(function(b){ b.classList.remove('active'); b.classList.add('btn-outline'); });
              btn.classList.add('active'); btn.classList.remove('btn-outline');
              var lvl = btn.getAttribute('data-level');
              items.forEach(function(li){
                var itemLevel = li.getAttribute('data-level');
                var show = (lvl === 'all') || !itemLevel || (itemLevel === lvl);
                li.style.display = show ? '' : 'none';
              });
            });
          });
        })();
        </script>
        <?php endif; ?>
      </div>
    <?php endif; endif; ?>
  </div>
</div>

<?php endif; ?>
<script>
(function(){
  var viewId = <?php echo (int)$viewId; ?>;
  var start = Date.now();
  function sendDuration(){
    var seconds = Math.round((Date.now() - start) / 1000);
    var payload = JSON.stringify({ view_id: viewId, type: 'product', seconds: seconds });
    if (navigator.sendBeacon) {
      navigator.sendBeacon('<?php echo SITE_URL; ?>/api/track-view.php', new Blob([payload], {type:'application/json'}));
    }
  }
  window.addEventListener('pagehide', sendDuration);
  document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') sendDuration(); });
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
