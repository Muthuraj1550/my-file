# My 3D Gifts - Standalone Platform (WordPress இல்லாமல்)

இது உங்க my3dgifts.com-க்கு WordPress இல்லாமல் இயங்கும் full PHP + MySQL website.
Login/Register, Membership Plans (Cashfree payment), Admin Panel (Posts/Pages/Plans/Members),
AI Usage Control, மற்றும் உங்க 3D Designer tool எல்லாம் இதுல ஒன்றாக integrate ஆகி இருக்கு.

---

## 1. Hosting Requirements (cPanel/shared hosting-ல் இருக்கணும்)

- PHP 7.4 அல்லது அதுக்கு மேல (8.x recommended)
- MySQL / MariaDB database
- PHP extensions: `pdo_mysql`, `curl`, `mbstring` (எல்லா cPanel hosting-லயும் default-ஆ இருக்கும்)
- SSL (https) - Cashfree-க்கு https அவசியம்

## 2. Database Setup

1. cPanel → **MySQL Databases** → புது database create பண்ணுங்க (e.g. `my3dgifts_db`)
2. புது DB user create பண்ணி, அந்த DB-க்கு "All Privileges" கொடுங்க
3. cPanel → **phpMyAdmin** → அந்த database-ஐ select பண்ணி → **Import** → `db.sql` file-ஐ upload பண்ணுங்க

இது தானாகவே create பண்ணும்:
- Default Free/Silver/Gold membership plans
- Default admin login: **admin@my3dgifts.com / Admin@123** ⚠️ **உடனே இதை மாத்துங்க**
Admin Panel → **My Account** page-ல் இருந்தே name/email/password மாத்திடலாம் (SQL edit தேவை இல்ல).

> **ஏற்கனவே இந்த site-ஐ ஒரு தடவை live பண்ணி db.sql import பண்ணி இருந்தீங்கன்னா** (இப்போ Analytics
> feature புதுசா சேர்த்திருக்கேன்), முழுசா `db.sql`-ஐ மறுபடியும் import பண்ண வேண்டாம் — அதனால old data
> போயிடும். அதுக்கு பதிலா `migration-content-views.sql` file-ஐ மட்டும் phpMyAdmin-ல் import பண்ணுங்க,
> அது `content_views` table-ஐ மட்டும் புதுசா add பண்ணும்.
>
> **Designer usage tracking + admin-editable menu புதுசா சேர்த்திருக்கேன்னா** (இந்த round-ல),
> `migration-designer-menu.sql`-ஐயும் இதே மாதிரி import பண்ணுங்க — இது `content_views.content_type`
> column-ஐ 'designer' track பண்ண widen பண்ணும், மற்றும் `menu_items` table-ஐ (existing menu-ஐ
> அப்படியே seed பண்ணி) புதுசா add பண்ணும்.
>
> **Guest Designer access + Homepage Customizer + SEO/Button fields புதுசா சேர்த்திருக்கேன்னா**
> (இந்த round-ல), `migration-guest-seo-homepage.sql`-ஐ import பண்ணுங்க — இது:
> - `ai_usage_log.user_id`-ஐ nullable ஆக்கி `guest_id` column சேர்க்கும் (login இல்லாம designer use பண்ணுறவங்களுக்கு)
> - `posts` / `pages` table-ல SEO (meta title/description) + CTA button fields சேர்க்கும்
> - Homepage customizer settings (hero title/buttons/custom HTML/SEO) seed பண்ணும்
>
> ⚠️ இந்த migration file-ல `ADD COLUMN IF NOT EXISTS` syntax பயன்படுத்தி இருக்கேன் — பழைய MySQL
> (5.7-க்கு கீழ) version-ல இது வேலை செய்யாம போகலாம். Error வந்தா, அந்த ஒரு line-ல இருந்து
> "IF NOT EXISTS" வார்த்தையை மட்டும் நீக்கிட்டு மறுபடியும் run பண்ணுங்க.
>
> **Popup Notification + Top Scrolling Text புதுசா சேர்த்திருக்கேன்னா** (இந்த round-ல),
> `migration-announcements.sql`-ஐ import பண்ணுங்க — இது settings-ல் புது keys மட்டும் seed பண்ணும்
> (existing data-ஐ தொடாது, safe).
>
> **Course Content Gating (login/payment-la lock pannradhu + noindex + show/hide) புதுசா
> சேர்த்திருக்கேன்னா** (இந்த round-ல), `migration-course-content-gating.sql`-ஐ import பண்ணுங்க
> (இது `migration-course-content-links.sql` run பண்ணின பிறகு தான் வேலை செய்யும்) — இது:
> - `posts` / `pages` table-ல `show_in_course` column சேர்க்கும் (default 1 = shown)
> - இதுக்கு அப்புறம், course-ல் link பண்ண post/page-ஐ யாராவது login/purchase இல்லாம நேரடியா அதோட
>   URL-ஐ type பண்ணி பார்த்தாலும், content lock ஆகி "buy this course" message காட்டும்
>   (Admin > Posts/Pages-ல் course pick பண்ணின உடனே இது automatic-ஆ apply ஆகும்)
> - அந்த lesson pages-க்கு தானாகவே `noindex` meta tag வரும் (Google rank ஆகாது) — ஆனா course-ஓட
>   product/sale page (product.php) SEO-க்கு திறந்தே இருக்கும்
> - Admin > Posts/Pages edit screen-ல் ஒவ்வொரு lesson-க்கும் "Show title & link on the course's
>   public curriculum list" checkbox வரும் — uncheck பண்ணா அந்த lesson course-ல் இருந்தாலும்
>   (access control அப்படியே இருக்கும்), course page-ல title/link மட்டும் காட்டாது

## 3. File Upload

1. இந்த zip-ல உள்ள எல்லா files/folders-ஐயும் உங்க domain-ன public_html (அல்லது subdomain folder) க்குள் FTP/File Manager மூலம் upload பண்ணுங்க.
2. `/uploads/` folder-க்கு **write permission (755 அல்லது 775)** கொடுங்க — post/page featured images இங்க save ஆகும்.

## 4. config.php Edit பண்ணுங்க

`config.php` file-ல் நீங்க கொடுத்த DB credentials (`mydgifts_editor` DB name/user, password) ஏற்கனவே
நான் போட்டு வச்சிருக்கேன், மேலும் ஒரு புது random `APP_SECRET` generate பண்ணி வச்சிருக்கேன் — கூடுதலா
நீங்க எதுவும் மாத்த வேண்டியதில்ல. மட்டும் இதை சரிபாருங்க:

```php
define('DB_HOST', 'localhost');   // உங்க hosting-ல வேற மாதிரி இருந்தா மாத்துங்க
define('SITE_URL', 'https://my3dgifts.com');   // trailing slash வேண்டாம்

define('APP_DEBUG', false);   // site live ஆனதும் (testing முடிஞ்சதும்) false ஆ மாத்துங்க
```

## 5. Cashfree Payment Setup (Sandbox முதலில்)

1. https://merchant.cashfree.com/ - இல் account create பண்ணுங்க (already இருந்தா login)
2. **Developers → API Keys → Test/Sandbox keys** எடுங்க (App ID + Secret Key)
3. Site-ல் `/admin/settings.php` க்கு போய் அந்த keys-ஐ paste பண்ணுங்க, Mode: **Sandbox**
4. Cashfree Dashboard-ல் **Webhooks** section-ல் இந்த URL-ஐ add பண்ணுங்க:
   `https://my3dgifts.com/payment-webhook.php`
5. Sandbox mode-ல ஒரு test plan வாங்கி பாருங்க (Cashfree test cards: https://docs.cashfree.com/docs/test-credit-card-details)
6. எல்லாம் சரியா வேலை செஞ்சா, Cashfree-ல் **Live/Production keys** வாங்கி, Mode: **Production**-ஆ மாத்துங்க

## 6. Gemini AI Key (உங்க Designer tool-க்கு)

`/admin/settings.php` → "Gemini API Key" field-ல் உங்க Google Gemini API key-ஐ (AIza... எண்ணுல ஆரம்பிக்கும்) போடுங்க.
இது Designer tool-க்கு பின்னணியில automatic-ஆ pass ஆகும் (உங்க HTML file-ல key hardcode பண்ண வேண்டாம்).

## 7. இது என்ன பண்ணுது (Features Overview)

| Feature | File(s) | Notes |
|---|---|---|
| Homepage (customizable) | `index.php`, `admin/homepage.php` | Hero text/buttons, optional custom HTML block, and SEO tags - all editable in Admin > Homepage; recent blog posts show below |
| Register/Login | `register.php`, `login.php` | Session-based auth, bcrypt password |
| Membership Plans + Payment | `membership.php`, `payment-return.php`, `payment-webhook.php` | Cashfree Orders API v3 |
| Member Dashboard | `dashboard.php` | Plan status, renew reminder, password change |
| 3D Designer (open to everyone, full-screen) | `designer.php`, `engine-stream.php`, `protected/engine.html` | **No login required** - opens full-screen (no site header/footer) for guests and members alike; premium templates + higher AI limits unlock with a paid plan; has its own 🏠 Home button to return to the site |
| AI Usage Limits | `api/ai-usage.php` | Guests get a small free daily quota (cookie-tracked); logged-in members get their plan's limit; resets at midnight |
| Blog | `blog.php`, `post.php` | Public posts, with optional SEO tags + a CTA button per post |
| Static Pages | `page.php` | About/Contact etc, auto-shown in top menu, with optional SEO tags + a CTA button per page |
| Admin Panel | `/admin/*` | Homepage, Plans, Members, Posts, Pages, Menu, Analytics, AI Logs, Settings, My Account |
| Analytics (views + time on page) | `admin/analytics.php`, `api/track-view.php` | Top posts/pages by views, total & avg minutes spent, plus 3D Designer usage (sessions + time spent, guests included) |
| Home Page Menu (admin-editable) | `admin/menu.php` | Add/edit/reorder/hide top navigation links, no code editing needed |
| Admin Account Settings | `admin/account.php` | Change admin name/email/password from the panel itself |
| Clean URLs for uploaded .html files | root `.htaccess` | Upload any `page.html` via FTP, link to it as `/page` (no extension) anywhere - `/page.html` auto-redirects to `/page` |
| Popup Notification (offer/announcement) | `admin/announcements.php` | Centered popup with title/message/image/button, configurable delay + repeat frequency |
| Top Scrolling Text (marquee) | `admin/announcements.php` | Thin scrolling announcement bar at the top of every public page, with optional link + custom colors |

## 8. Designer Tool Security Note

உங்க upload பண்ண `.html` designer file-ஐ `/protected/engine.html` -ல் வச்சிருக்கேன்.
அந்த folder-ல `.htaccess` (Apache) மூலம் **direct URL access block** பண்ணி இருக்கேன் —
`engine-stream.php` மூலமா மட்டும் தான் அந்த file serve ஆகும்.

**Designer இப்போ login இல்லாமலேயே எல்லாருக்கும் திறந்திருக்கு** (guest access):
- Login இல்லாதவங்க: Free templates + சின்ன daily AI quota (default 2/day, Admin > Settings-ல் மாத்தலாம் - cookie மூலம் track ஆகும்)
- Login பண்ணி premium plan வாங்கினவங்க: Premium templates + அவங்க plan-ஓட AI limit
இதனால designer page-ஐ யாரும் use பண்ணலாம், ஆனா premium features + அதிக AI generations-க்கு
login/upgrade பண்ணணும்-ன்னு prompt வரும்.

**⚠️ இது Apache/cPanel hosting (.htaccess support) இருந்தா தான் வேலை செய்யும்.** உங்க hosting
Nginx-ஆ இருந்தா, `.htaccess` இல் உள்ள rules-ஐ Nginx config-ல் manually add பண்ணணும்
(உங்க hosting provider support-ஐ கேளுங்க).

## 8.5. Homepage Customizer + SEO/Button fields (புதுசு)

- **Admin → Homepage**: Hero title/subtitle, இரண்டு hero buttons (text+URL தனித்தனியா மாத்தலாம்),
  ஒரு optional custom HTML block (banner/embed/எதுவும் paste பண்ணலாம்), மற்றும் homepage-க்கான
  SEO title/description — எல்லாம் code touch பண்ணாம admin panel-ல் இருந்தே மாத்தலாம்.
- **Admin → Posts / Pages**: ஒவ்வொரு post/page-க்கும் தனியா SEO Title + Meta Description,
  மற்றும் ஒரு Call-to-Action button (text + URL + new tab option) சேர்க்கலாம் — அது content-க்கு
  கீழ ஒரு button-ஆ காட்டும்.
- Homepage-ல் "AI" prominent-ஆ highlight பண்ணாம மாத்தி இருக்கேன் (AI option இன்னும் fully polish
  ஆகாததால) — hero section-ல் இப்போ neutral wording தான் இருக்கு, Admin > Homepage-ல் எப்போ வேணும்னாலும் மாத்தலாம்.

## 8.6. Menu/Button-ல் .html file link கொடுக்கும் போது (clean URL)

Menu item-ஆ இருந்தாலும், Post/Page CTA button-ஆ இருந்தாலும், ஒரு plain `.html` file-ஐ (உங்க own
static promo page, template preview, etc.) நேரடியா FTP/File Manager மூலம் site-ன் root
folder-க்கு (அல்லது எந்த folder-க்கும்) upload பண்ணிட்டு:

1. அந்த file-ஐ `offer.html` -ன்னு பெயர் வச்சு upload பண்ணுங்க
2. Menu/Button URL field-ல் `.html` **இல்லாம** `/offer`-ன்னு மட்டும் போடுங்க

இப்போ யாராவது `/offer` visit பண்ணா `offer.html`-ஐ காட்டும், `.html` extension address bar-ல
தெரியாது. யாராவது தப்பா `/offer.html`-ன்னு direct URL type பண்ணினாலும், அதை தானாகவே `/offer`-க்கு
redirect பண்ணிடும் (root `.htaccess`-ல் இந்த rule சேர்த்திருக்கேன்).

**⚠️ இதுவும் Apache/cPanel hosting (.htaccess + mod_rewrite) இருந்தா தான் வேலை செய்யும்.**

## 8.7. Popup Notification + Top Scrolling Text (Admin → Announcements)

- **Popup Notification**: Title, message, optional image, optional button (text+URL), எவ்வளவு
  நேரம் கழிச்சு காட்டணும் (delay), மற்றும் ஒரு visitor-க்கு எத்தனை மணி நேரத்துக்கு repeat ஆகக்கூடாது
  (frequency) - எல்லாம் admin panel-ல் set பண்ணலாம். Full-screen Designer page-ல் இது காட்டாது.
- **Top Scrolling Text**: ஒரு thin marquee bar site-ன் top-ல், text/link/background color/text
  color/scroll speed எல்லாம் admin panel-ல் மாத்தலாம்.
- இரண்டுமே **default-ஆ OFF** — Admin → Announcements-ல் "Enable" checkbox tick பண்ணி Save
  பண்ணினா தான் site-ல் தெரியும்.

## 9. உங்க Original WordPress Plugins vs இது — என்ன simplify பண்ணி இருக்கேன்

- **Renew/Upgrade logic**: ஒரே plan-ஐ renew பண்ணா, remaining days-ல இருந்து extend ஆகும்.
  வேற plan-க்கு upgrade/downgrade பண்ணா, இன்னிக்கு இருந்து புது validity start ஆகும்
  (partial-day proration இல்ல — உங்க business rule வேற மாதிரி வேணும்னா சொல்லுங்க, மாத்தி தரேன்).
- **GitHub XML Premium Templates**: உங்க designer HTML file-லயே already built-in ஆ
  GitHub free/paid repos-ல இருந்து fetch பண்ணும் logic இருக்கு (`GH_CONFIG.repoUrl` /
  `premiumRepoUrl`). நான் வெறும் `hasAccess: true/false` flag-ஐ மட்டும் அனுப்புறேன் plan-ஐ பொறுத்து —
  repo URLs-ஐ மாத்தணும்னா `designer.php`-ல `hasAccess` flag அனுப்புற இடத்துல
  `repoUrl`/`premiumRepoUrl` fields-ஐயும் சேர்த்து அனுப்பலாம்.
- **Cron-based daily expiry sweep**: தற்போது ஒவ்வொரு login/dashboard/membership visit-லயும்
  அந்த ஒரு user-க்கு expiry check நடக்குது (lightweight, cron தேவை இல்ல). Site-wide daily
  sweep வேணும்னா, cPanel → Cron Jobs-ல ஒரு simple `cron/expire-all.php` file எழுதி
  தினமும் ஓட வைக்கலாம் (கேட்டா அதையும் சேர்த்து தரேன்).


## 10. Next Steps பரிந்துரை

1. Sandbox-ல எல்லாம் test பண்ணுங்க (register → buy plan → dashboard-ல plan update ஆகுதான்னு பாருங்க)
2. Default admin password மாத்துங்க
3. Blog posts/pages உங்க content போட்டு publish பண்ணுங்க
4. Live-ஆனதும் Cashfree production keys + APP_DEBUG=false மாத்துங்க

## 11. இந்த Round-ல Fix + புது Features (Bug fixes, Cloud Save, Theme, Mobile, Tripo AI)

**⚠️ இதுக்கு 2 migration files run பண்ணணும் (phpMyAdmin-ல, ஏற்கனவே இருக்கும் data பாதிக்காது):**
1. `migration-guest-seo-homepage.sql` — ஏற்கனவே சேர்த்திருந்தது, ஆனா run ஆகாததால `admin/usage.php` fatal error கொடுத்துச்சு. இப்போ run பண்ணலனாலும் crash ஆகாது (auto-fallback பண்ணும்), ஆனா guest unique-visitor count சரியா வர இதை run பண்ணுங்க.
2. `migration-cloud-projects.sql` — புதுசு, Cloud Project Save/Recovery-க்காக.

- **AI Usage Logs fatal error** – Fixed. Migration run ஆகாதவரை "Migration Pending" notice மட்டும் காட்டும், crash ஆகாது.
- **Gold + Purple Theme** – `assets/css/style.css` முழுசா recolor (site + admin panel), Cinzel/Poppins fonts.
- **Mobile Designer fix** – Toggle/lock buttons screen-ன் middle-ல இருந்து top corners-க்கு மாத்தி, 3D view rotate பண்ணும்போது கை படாம பாத்துக்கிட்டேன். Long-press native "shortcut" popup mobile-ல disable பண்ணிருக்கேன்.
- **Cloud Project Save/Recovery** (login-based, 10MB/account cap):
  - Login பண்ணினா last project auto-ஆ cloud-ல save ஆகும் (`saved_projects` table), வேற device/browser-ல login பண்ணும்போதும் recover ஆகும்.
  - Free plan: auto-recovery மட்டும். Silver: 5 named "Save As" slots. Gold: 20 named slots (Admin > Membership Plans-ல plan edit பண்ணும்போது `project_slots` column மாத்தலாம்).
  - Guests (login இல்லாதவங்க): ஏற்கனவே இருந்த local-browser-only recovery அப்படியே தொடரும்.
- **🤖 Tripo AI (Text → 3D)** – Import Tools section-ல் **கடைசி item**-ஆ சேர்த்திருக்கேன். வேலை செய்ய `/admin/settings.php` → "Tripo AI API Key" field-ல் உங்க key போடணும் (இல்லனா "key not set up" error காட்டும்). Key [developers.tripo3d.ai/en/keys](https://developers.tripo3d.ai/en/keys)-ல வாங்கலாம். இது ஏற்கனவே இருக்கிற daily AI quota-வையே (Gemini-ஓட) share பண்ணும்.

## 12. 🛒 Digital Products / Video Course Shop (புதுசு - this round)

இது `design.my3dgifts.com` மாதிரி individual digital files (STL/templates) மற்றும் video courses-ஐ
**ஒவ்வொன்றா தனித்தனியா** (subscription இல்லாம, one-time payment-ல்) விக்க வைக்கிற ஒரு முழு Shop module.
Membership Plans (section 2-7) இதற்கு பதிலா இல்ல — **கூடவே** இயங்கும் (உங்களுக்கு plan-based designer
access + product-based file/course sales, ரெண்டும் வேணும்-ன்னு சொன்னீங்க, அதுதான் இது).

### 12.1 Setup (ஒரே ஒரு migration)

phpMyAdmin-ல் உங்க database-ஐ select பண்ணி → **Import** → `migration-products-shop.sql`-ஐ upload
பண்ணுங்க. இது safe-ஆ புது tables மட்டும் add பண்ணும் (`products`, `product_orders`, `user_products`,
`form_submissions`), `menu_items`-ல ரெண்டு புது column சேர்க்கும், மற்றும் top menu-ல ஒரு "Shop" link
தானாகவே seed பண்ணும். Existing data எதுவும் தொடாது.

### 12.2 என்ன Files புதுசா வந்திருக்கு

| File | Purpose |
|---|---|
| `admin/products.php` | Products add/edit/delete — title, type (File/Course/Software/Bundle), category, price + sale price, thumbnail, description, **delivery link** (MediaFire/Drive URL அல்லது நேரடியா file upload), status (draft/published), featured. Recent Orders list-உம் இங்கயே கீழ காட்டும். |
| `products.php` | Public Shop page (grid, category filter tabs, sale price strike-through). |
| `product.php?slug=...` | Single product page + "Buy Now" → Cashfree checkout (membership.php-ல இருக்கிற அதே pattern). |
| `my-purchases.php` | Login பண்ணின member-க்கு அவங்க வாங்கின எல்லா files/courses-ஓட download/MediaFire link இங்க தெரியும் (login-ல் எப்போ வேணும்னாலும் திரும்ப பாக்கலாம்). |
| `contact.php` | Simple enquiry/contact form (name, email, phone, message) → `admin/leads.php`-ல் admin பாக்கலாம். |
| `admin/leads.php` | Contact form-ல் வந்த messages எல்லாம் இங்க தெரியும் (read/delete). |

### 12.3 Product ஒன்னு எப்படி Add பண்றது

1. Admin → **Products (Shop)** → "Add New Product"
2. Title, Type (File/Course/etc), Category, Price/Sale Price போடுங்க
3. **Delivery** section-ல் — MediaFire/Google Drive link paste பண்ணலாம், அல்லது சின்ன file (STL/zip/PDF)
   ஆனா நேரடியா "Upload the file directly" மூலம் upload பண்ணலாம் (பெரிய video course files-க்கு
   MediaFire/Drive link recommend பண்றோம், hosting storage மேல load ஆகாம இருக்க)
4. Status: **Published** ஆக்கி Save பண்ணுங்க → உடனே `/products.php` shop page-ல் காட்டும்

பணம் கட்டினதும் (Cashfree via `product.php`) buyer-க்கு access தானா grant ஆகி, அவங்க
`my-purchases.php`-ல் அந்த Delivery Link-ஐ பாக்க முடியும்.

### 12.4 Menu Item ஒன்னை "Course வாங்கினவங்களுக்கு மட்டும்" காட்டறது (Hide/Show gating)

Admin → **Menu** → item add/edit பண்ணும்போது **"Who can see this link?"** dropdown-ல்:
- **Everyone** — எல்லாருக்கும் தெரியும் (default)
- **Logged-in members only** — login பண்ணினவங்களுக்கு மட்டும்
- **Only members who bought a specific product** — dropdown-ல் அந்த Product-ஐ select பண்ணுங்க;
  அந்த ஒரு product-ஐ வாங்கினவங்களுக்கு மட்டும் தான் அந்த menu link தெரியும் (மத்தவங்களுக்கு
  அந்த link-ஏ காட்டாது). இப்படி "Course வாங்குனவங்க மட்டும்" ஒரு private designer/resources page-க்கு
  link வைக்கலாம்.

### 12.5 Cashfree — Shop-க்கும் அதே Setup

Section 5-ல் போட்ட அதே Cashfree App ID/Secret Key/Webhook URL (`/payment-webhook.php`) Shop
orders-க்கும் தானா வேலை செய்யும் — தனியா ஒரு setup தேவை இல்ல. Order-ID prefix (`PROD...`) வச்சு
system தானா தெரிஞ்சிக்கும் இது membership plan-ஆ, Tripo coin pack-ஆ, அல்லது ஒரு Product order-ஆ-ன்னு.

### 12.6 Note

- ஒரு product delete பண்ணா, ஏற்கனவே அதை வாங்கின members-க்கு access போகாது (`my-purchases.php`-ல்
  தொடர்ந்து தெரியும்), ஆனா shop page-ல் இருந்து மட்டும் மறையும்.
- Free product (price = ₹0) ஆனா, "Buy Now" click பண்ணதும் payment இல்லாம உடனே access கிடைக்கும்.


## 13. 🆕 இந்த Round-ல புது Features (Course-based Designer Access, Admin Member Create, Cloud Project Count)

**⚠️ இதுக்கு 1 புது migration file run பண்ணணும்** (phpMyAdmin, Import → `migration-username-login.sql`) —
இது `users` table-ல ஒரு புது nullable `username` column மட்டும் சேர்க்கும், existing data-ஐ தொடாது.

### 13.1 3D Designer Full Access — Course வாங்கினவங்களுக்கும்

இதுவரை Designer-ல Premium templates + higher AI limit, **paid membership plan** (Silver/Gold)
இருக்கிறவங்களுக்கு மட்டும் தான் திறந்திருந்துச்சு. இப்போ **Shop-ல் ஒரு "Course" type product வாங்கின
எந்த member-க்கும்** அதே full access தானா கிடைக்கும் (plan வேணும்-ன்னு கட்டாயம் இல்ல) —
`admin/products.php`-ல் product type-ஐ **Course**-ஆ set பண்ணி இருந்தா போதும்.

### 13.2 Admin → Members → "Add New Member" (Name மட்டும் கொடுத்தா, Username + Password auto-generate)

`admin/members.php`-ல் இப்போ ஒரு புது "➕ Add New Member" form இருக்கு — Member-ஓட **பெயரை மட்டும்**
type பண்ணி "Create Member" click பண்ணா:
- ஒரு unique **username** (பெயரை வச்சு, தேவைப்பட்டா எண்ணுகள் சேர்த்து) தானா உருவாகும்
- ஒரு random, படிக்க எளிதான **password** (0/O/1/l போன்ற குழப்பமான எழுத்துக்கள் இல்லாம) தானா உருவாகும்
- இந்த username/password ஒரு தடவை மட்டும் பச்சை நிற box-ல் காட்டப்படும் (page refresh ஆனா மறைஞ்சிடும்,
  password DB-ல hash ஆகவே save ஆகுது, அதனால திரும்ப பாக்க முடியாது) — உடனே அந்த member-க்கு கொடுத்துடுங்க
- Member login பண்ணும்போது Email field-ல **username-ஐயும் type பண்ணலாம்** (email அல்லது username, ரெண்டுமே வேலை செய்யும்)

### 13.3 Admin → Analytics → Cloud Projects Count

Analytics page-ல் ஒரு புது "☁️ Cloud Projects" card சேர்த்திருக்கேன் — total saved projects, auto-save
vs named "Save As" slots split, எத்தனை members-க்கு saved project இருக்கு, மற்றும் total storage
(MB/KB) எல்லாம் ஒரே பார்வையில் தெரியும்.

## 14. 🆕 Homepage — Coin Animation OFF by default + Admin-Controlled Banner

இது ஒரு **digital file / video course selling site** homepage-ஆனதால:

- **🪙 Coin Spin Animation** — இப்போ **default-ஆ OFF** (முழு coin widget-ஏ homepage-ல தெரியாது).
  Admin → Homepage → "🪙 3D Coin Spin Animation" section-ல் **"Show coin animation on homepage"**
  checkbox tick பண்ணி Save பண்ணா எப்போ வேணும்னாலும் திரும்ப ON பண்ணலாம்.
- **🖼️ Homepage Banner** (புதுசு) — Admin → Homepage → "🖼️ Homepage Banner" section-ல் ஒரு image
  upload பண்ணி, "Enable banner on homepage" tick பண்ணி Save பண்ணா, Hero section-க்கு கீழ ஒரு
  full-width banner தெரியும் (course offer/sale banner போன்றவற்றுக்கு). Optional link URL + new-tab
  option + alt text எல்லாம் கொடுக்கலாம். Default-ஆ OFF, tick பண்ணும் வரை homepage-ல தெரியாது.

## 15. 🆕 Course Grouping + Main Editor / Litho Studio Auto-Password (இந்த Round)

**⚠️ 1 புது migration file run பண்ணணும்**: phpMyAdmin → Import → `migration-course-license.sql`
(safe — `products` table-ல ரெண்டு புது column (`course_id`, `license_site`) சேர்க்கும், மற்றும்
`product_licenses` எனும் புது table add பண்ணும். Existing data எதுவும் தொடாது.)

### 15.1 Course-ஆ Products-ஐ Group பண்றது

- Admin → Products → எந்த file/product-ஐயும் add/edit பண்ணும்போது, **"Include this in a Course"**
  dropdown-ல் ஒரு "Video Course" type product-ஐ select பண்ணுங்க.
- இப்படி select பண்ணினதும், அந்த file/product தானாகவே அந்த Course-ஓட **"📦 What's Included"** list-ல்
  சேர்ந்திரும் — Course-ஓட admin edit page-லயும் (products.php-ல் course product-ஐ edit பண்ணும்போது
  கீழ ஒரு "What's Included" table தெரியும்), மற்றும் அந்த Course-ஓட public product page
  (`product.php?slug=...`) description-க்கு கீழயும் இந்த list தானா தெரியும்.
- இதுக்காக தனியா ஒரு "Courses" section வேணாம் — **Course-ன்னா type='course'-ஆ இருக்கிற ஒரு
  Product தான்** (ஏற்கனவே section 13.1-ல் சொன்ன மாதிரி, அதை வாங்கினவங்களுக்கு Designer full access
  கிடைக்கும்).

### 15.2 Main Editor / Litho Studio Site Password Auto-Generate

- Admin → Products → எந்த product edit பண்ணும்போதும் **"Site Password / License"** dropdown-ல்
  "Main Editor", "Litho Studio", அல்லது "Main Editor + Litho Studio" select பண்ணலாம்.
- இப்படி set பண்ணின product-ஐ ஒருத்தர் வாங்கினதும் (payment அல்லது free grant), அந்த buyer-க்கு
  **தானாகவே ஒரு unique username + password** உருவாகி `product_licenses` table-ல் save ஆகும்,
  அது அவங்க **My Purchases** page-ல் ஒரு பச்சை box-ல் தெரியும்.
- உங்க Main Editor / Litho Studio site-ல் இருந்து `api/verify-license.php`-ஐ (server-side POST,
  browser JS-ல இருந்து அல்ல) இந்த params-ஓட call பண்ணி password சரியான்னு check பண்ணலாம்:
  `api_key` (உங்க `config.php`-ல உள்ள `APP_SECRET` அதே value), `site` (`main_editor` அல்லது `litho`),
  `username`, `password`. Response: `{"valid":true,"product":"...","user_name":"..."}` அல்லது
  `{"valid":false,"reason":"..."}`.
- ஒவ்வொரு buyer-க்கும் ஒரு product-க்கும் ஒரு தடவை தான் password generate ஆகும் (already இருந்தா
  மறுபடியும் generate ஆகாது, அதே password-ஏ My Purchases-ல் தொடர்ந்து தெரியும்).

## 16. 🆕 Homepage Redesign — Course/Design-File Selling Focus

- **🎓 Featured Courses section** — homepage-ல் Hero/Banner-க்கு கீழ, "Video Course" type-ல் உள்ள
  முதல் 3 published products (featured முதலில்) தனியா ஒரு prominent grid-ல் காட்டப்படும் —
  ஒவ்வொரு course card-லயும் எத்தனை items அதுக்குள் இருக்கு-ன்னு (📦 badge) தானா தெரியும்.
  Course இல்லாம இருந்தா இந்த section தானா மறையும்.
- General Shop grid அப்படியே தொடரும் (courses section இருந்தா, heading "More Design Files &amp;
  Templates"-ஆ மாறும்).
- **💬 Testimonials section** — Admin → Homepage → "💬 Testimonials" card-ல் (max 3) buyer name,
  role/context, quote, star rating (0-5) கொடுக்கலாம். Text காலியா விட்டா அந்த card தானா மறையும்.
  Default-ஆ ON, checkbox மூலம் OFF பண்ணலாம்.

## 17. 🆕 Course-Covered Product Fix + Member Product Access + Share Links (இந்த Round)

**⚠️ இதுக்கு 1 புது migration file run பண்ணணும்**: phpMyAdmin → Import → `migration-share-links.sql`
(safe — `share_links` எனும் புது table மட்டும் add பண்ணும். Existing data எதுவும் தொடாது.)

### 17.1 Bug Fix — Course-ல் Cover ஆன Product, தனியா Unlock ஆகாத Problem

இதுவரை ஒரு product-ஐ ("Include this in a Course" மூலம்) ஒரு Course-க்குள் சேர்த்தாலும், அந்த
product-ஓட **தனி product page**-க்கு (`product.php?slug=...`) யாராவது நேரடியா போனா, Course
வாங்கி இருந்தாலும் price/"Buy Now" தான் காட்டிச்சு (அந்த member இந்த ஒரு product-ஐ தனியா
வாங்கலைன்னு system நினைச்சுச்சு). இப்போ **Fix ஆகிடுச்சு** — Course வாங்கின எவரும் அதுக்குள்
சேர்க்கப்பட்ட எந்த product-ஐயும் (product page-ல் நேரடியா போனாலும் சரி) தானா unlocked-ஆ பாப்பாங்க,
வேற எந்த setup-உம் தேவை இல்ல.

### 17.2 Admin → Members → "🔓 Products" (Member ஒருத்தருக்கு எந்த Product/Course வேணும்-ன்னு தேர்ந்தெடுக்கிற Option)

- **➕ Add New Member** form-லயே இப்போ ஒரு product/course checklist தெரியும் — Name-ஓட கூட எந்த
  product(s)/course(s)-க்கு access கொடுக்கணும்-ன்னு tick பண்ணி Create Member பண்ணலாம் (optional).
- ஏற்கனவே இருக்கிற எந்த member-க்காவது, Admin → Members list-ல் அவங்க row-ல் இருக்கிற
  **"🔓 Products"** button click பண்ணா ஒரு தனி page வரும் — எல்லா products/courses-உம்
  checkbox-ஆ தெரியும் (already owned-ஆ இருக்கிறது tick ஆகி இருக்கும்). Tick/untick பண்ணி Save
  Access பண்ணா, உடனே access கொடுக்கப்படும்/எடுக்கப்படும் — payment எதுவும் தேவை இல்ல.
- Course tick பண்ணா, அந்த Course-ஓட உள்ள எல்லா lessons/products-உக்கும் access தானா கிடைக்கும்
  (section 17.1 fix படி).

### 17.3 Admin → Posts / Pages → "🔗 Share" (Draft அல்லது Course Lesson-க்கு Special Link)

- Admin → Posts அல்லது Pages list-ல் ஒவ்வொரு row-லயும் இப்போ ஒரு **"🔗 Share"** button இருக்கு —
  அதை click பண்ணா **Admin → Share Links** page-க்கு போய், அந்த post/page ஏற்கனவே தேர்ந்தெடுக்கப்பட்டு
  காட்டும்.
- Share Links page-ல் ஒரு தனி **generate கூடிய link** (unique URL, `/share.php?token=...`) create
  பண்ணலாம் — இந்த link வச்சு யாராவது open பண்ணா, login/purchase எதுவும் இல்லாம அந்த content
  (draft ஆ இருந்தாலும், Course-க்குள் lock ஆன lesson ஆ இருந்தாலும்) நேரடியா தெரியும்.
- Optional **Expiry date** கொடுக்கலாம் — அந்த தேதி கழிச்சா link தானா வேலை செய்யாது ("invalid or
  expired" message காட்டும்). Expiry date காலியா விட்டா, link என்றும் expire ஆகாது.
- ஒவ்வொரு link-உம் Share Links page-ல் listed-ஆ இருக்கும் — Copy பண்ணலாம், **Delete** பண்ணா அந்த
  link உடனே வேலை செய்யாது (content-க்கு எந்த மாற்றமும் வராது, அந்த ஒரு link மட்டும் disable ஆகும்).
- இந்த shared link-கள் Google-ல் index ஆகாது (`noindex` தானா add ஆகும்), private-ஆ ஒருத்தருக்கு
  மட்டும் share பண்றதுக்கு ஏத்தமாதிரி.

## 18. 🆕 Product → ஒண்ணுக்கு மேற்பட்ட Course-ல் Include பண்றது (இந்த Round)

**⚠️ 1 புது migration file run பண்ணணும்**: phpMyAdmin → Import → `migration-product-multi-course.sql`
(safe — `product_courses` எனும் புது table மட்டும் add பண்ணும், ஏற்கனவே இருக்கிற single-course
links-ஐ அதுக்குள் தானா copy பண்ணும். Existing data எதுவும் delete/மாற்றம் ஆகாது.)

- இதுவரை Admin → Products → **"Include this in a Course"**-ல் **ஒரே ஒரு** Course தான் select
  பண்ண முடியும் (dropdown). இப்போ அது **checkboxes-ஆ** மாறிடுச்சு — ஒரு product-ஐ **ஒண்ணுக்கு
  மேற்பட்ட Courses-ல** ஒரே நேரத்துல tick பண்ணி include பண்ணலாம் (உதாரணமா, ஒரு "Intro to
  Boolean" file-ஐ Beginner Course-லயும் Advanced Course-லயும் ரெண்டு இடத்திலயும் காட்டலாம்).
- Tick பண்ண courses எல்லாம் அந்தந்த course-ஓட **"📦 What's Included"** curriculum list-ல் தானா
  சேர்ந்திரும் (course-க்கு course தனி ordering, drag-reorder அப்படியே வேலை செய்யும்).
- Products list-ல் ஒவ்வொரு row-லயும் இப்போ **"📦 in courses: ..."** அப்படின்னு எல்லா linked
  courses பேரும் தெரியும்.
- ஒரு Course-ஐ வாங்கினவங்களுக்கு, அந்த Course-ல் include ஆன product எல்லாம் (எத்தனை Course-ல்
  include ஆனாலும் சரி) தானா unlock ஆகும் — access check logic-உம் இதுக்கு ஏத்தமாதிரி update
  ஆகிடுச்சு.
- Migration file run பண்ணாத வரைக்கும், பழைய single-select dropdown-ஏ தெரியும் (product ஒரு
  course-க்கு மட்டும் தான் போகும்) — எதுவும் break ஆகாது, migration run பண்ணின உடனே மேலே
  சொன்ன multi-select checkboxes-ஆ மாறிடும்.

### 18.1 Posts / Pages-உம் இப்போ ஒண்ணுக்கு மேற்பட்ட Course-ல் Include ஆகும்

**⚠️ இதுக்கு தனி migration file**: phpMyAdmin → Import → `migration-content-multi-course.sql`
(safe — `post_courses` மற்றும் `page_courses` எனும் ரெண்டு புது table மட்டும் add பண்ணும்,
ஏற்கனவே இருக்கிற single-course links-ஐ தானா copy பண்ணும்.)

- Admin → Posts / Pages → "🎓 Course Curriculum" section-ல் இப்போ **checkboxes** — ஒரு
  lesson (post/page)-ஐ ஒண்ணுக்கு மேற்பட்ட Courses-ல ஒரே நேரத்துல tick பண்ணலாம்.
  Tick பண்ண courses-ல எதையாவது ஒண்ணு வாங்கினாலும் அந்த lesson unlock ஆகும்.
  "Order within course", "Show on course page", "Level" settings எல்லா linked
  courses-க்கும் ஒரே மாதிரி apply ஆகும் (course-க்கு course தனி வெவேற settings இல்ல, single
  set of settings தான்).
- Public lesson page (post.php/page.php) இப்போ lock ஆன lesson-ஐ பாத்தா, அது எந்தெந்த
  courses-ல இருக்கோ அத்தனையும் பேரையும் "View Course & Buy" button-ஓட காட்டும்.
- Migration run பண்ணாத வரைக்கும் பழைய single-select-ஏ தெரியும், எதுவும் break ஆகாது.
