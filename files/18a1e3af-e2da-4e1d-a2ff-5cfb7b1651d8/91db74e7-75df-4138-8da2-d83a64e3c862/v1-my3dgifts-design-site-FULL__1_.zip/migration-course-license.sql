-- =========================================================
--  My3DGifts Standalone Platform - Course Grouping + Site
--  License (auto password for Main Editor / Litho Studio)
--  Import this file in phpMyAdmin AFTER migration-products-shop.sql.
--  Safe on a live site - only ADDS new columns/tables, existing
--  data is not touched.
-- =========================================================

SET NAMES utf8mb4;

-- ---------- Which "Course" (a product with type='course') this file/product belongs to ----------
ALTER TABLE products ADD COLUMN IF NOT EXISTS course_id INT UNSIGNED DEFAULT NULL AFTER type;

-- ---------- Auto-generate a site login (username+password) for this product on purchase ----------
-- none         -> normal product, no site password generated
-- main_editor  -> generates a password for the Main Editor tool subdomain
-- litho        -> generates a password for the Lithophane Studio subdomain
-- both         -> generates one password usable for both tools
ALTER TABLE products ADD COLUMN IF NOT EXISTS license_site ENUM('none','main_editor','litho','both') NOT NULL DEFAULT 'none' AFTER delivery_note;

-- ---------- Generated per-buyer login for the external tool site(s) ----------
CREATE TABLE IF NOT EXISTS product_licenses (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED NOT NULL,
    product_id      INT UNSIGNED NOT NULL,
    site            ENUM('main_editor','litho','both') NOT NULL,
    username         VARCHAR(60) NOT NULL,
    password        VARCHAR(40) NOT NULL,
    status          ENUM('active','revoked') NOT NULL DEFAULT 'active',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_verified_at DATETIME DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY user_product (user_id, product_id),
    KEY username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- NOTE: if your MySQL version is older than 8.0 / MariaDB 10.5 and the
-- "ADD COLUMN IF NOT EXISTS" lines above give a syntax error, just remove
-- the words "IF NOT EXISTS" from those two lines and run again.
