<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$user = current_user();
$errors = [];
$sent = false;
$productId = (int)($_GET['product_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_enquiry'])) {
    csrf_check();
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $pid = (int)($_POST['product_id'] ?? 0);

    if ($name === '') $errors[] = 'Name is required.';
    if ($email === '' && $phone === '') $errors[] = 'Please provide an email or phone number.';
    if ($message === '') $errors[] = 'Message is required.';

    if (!$errors && leads_table_ready()) {
        db()->prepare("INSERT INTO form_submissions (name, email, phone, message, product_id, source) VALUES (?,?,?,?,?,'contact')")
            ->execute([$name, $email ?: null, $phone ?: null, $message, $pid ?: null]);
        $sent = true;
    } elseif (!$errors) {
        $errors[] = 'The contact form is not fully set up yet - please import migration-products-shop.sql.';
    }
}

$pageTitle = 'Contact Us';
include __DIR__ . '/includes/header.php';
?>
<h1>Contact Us</h1>
<p style="color:var(--muted,#94a3b8);">Questions about a product, course, or your order? Send us a message.</p>

<?php if ($sent): ?>
  <div class="flash flash-success">Thanks! Your message has been sent - we'll get back to you soon.</div>
<?php else: ?>
  <?php foreach ($errors as $e): ?><div class="flash flash-error"><?php echo h($e); ?></div><?php endforeach; ?>
  <div class="card" style="max-width:520px;">
    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="product_id" value="<?php echo (int)$productId; ?>">
      <label>Name</label>
      <input type="text" name="name" value="<?php echo h($user['name'] ?? ''); ?>" required>
      <label>Email</label>
      <input type="email" name="email" value="<?php echo h($user['email'] ?? ''); ?>">
      <label>Phone</label>
      <input type="text" name="phone" value="<?php echo h($user['phone'] ?? ''); ?>">
      <label>Message</label>
      <textarea name="message" style="min-height:120px;" required></textarea>
      <button type="submit" name="send_enquiry" class="btn btn-block">Send Message</button>
    </form>
  </div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
