-- =========================================================
--  My3DGifts Standalone Platform - Link Posts & Pages to a
--  Course (curriculum / "what's covered" list on the course
--  page, becoming clickable once the buyer has paid).
--
--  Import this file in phpMyAdmin AFTER migration-products-shop.sql
--  and migration-course-license.sql. Safe on a live site - only
--  ADDS new columns, no existing data is touched.
-- =========================================================

SET NAMES utf8mb4;

-- ---------- Which Course (a product with type='course') this post/page belongs to ----------
ALTER TABLE posts ADD COLUMN IF NOT EXISTS course_id INT UNSIGNED DEFAULT NULL AFTER status;
ALTER TABLE pages ADD COLUMN IF NOT EXISTS course_id INT UNSIGNED DEFAULT NULL AFTER status;

-- ---------- Optional manual ordering of curriculum items inside a course ----------
ALTER TABLE posts ADD COLUMN IF NOT EXISTS course_sort_order INT NOT NULL DEFAULT 0 AFTER course_id;
ALTER TABLE pages ADD COLUMN IF NOT EXISTS course_sort_order INT NOT NULL DEFAULT 0 AFTER course_id;

ALTER TABLE posts ADD KEY IF NOT EXISTS idx_course_id (course_id);
ALTER TABLE pages ADD KEY IF NOT EXISTS idx_course_id (course_id);

-- NOTE: if your MySQL version is older than 8.0 / MariaDB 10.5 and the
-- "ADD COLUMN IF NOT EXISTS" / "ADD KEY IF NOT EXISTS" lines above give a
-- syntax error, just remove the words "IF NOT EXISTS" from those lines
-- and run again (safe to re-run either way, it's non-destructive).
