<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) redirect('/dashboard.php');

$errors = [];
$next = $_GET['next'] ?? ($_POST['next'] ?? '/dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $login = trim(strtolower($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';

    if (username_login_ready()) {
        $stmt = db()->prepare("SELECT * FROM users WHERE (email = ? OR username = ?) AND role='member' LIMIT 1");
        $stmt->execute([$login, $login]);
    } else {
        $stmt = db()->prepare("SELECT * FROM users WHERE email = ? AND role='member' LIMIT 1");
        $stmt->execute([$login]);
    }
    $u = $stmt->fetch();

    if (!$u || !verify_member_password($u['id'], $pass, $u['password_hash'])) {
        $errors[] = 'Incorrect email/username or password.';
    } elseif ($u['status'] === 'blocked') {
        $errors[] = 'This account has been blocked. Please contact support.';
    } else {
        log_user_in($u['id']);
        redirect($next ?: '/dashboard.php');
    }
}

$pageTitle = 'Login';
include __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:420px;margin:30px auto;">
  <h1 style="text-align:center;">Member Login</h1>
  <?php foreach ($errors as $e): ?>
    <div class="flash flash-error"><?php echo h($e); ?></div>
  <?php endforeach; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="next" value="<?php echo h($next); ?>">
    <label>Email or Username</label>
    <input type="text" name="email" required>
    <label>Password</label>
    <input type="password" name="password" required>
    <button type="submit" class="btn btn-block">Login</button>
  </form>
  <p style="text-align:center;margin-top:16px;">New member? <a href="<?php echo SITE_URL; ?>/register.php">Register here</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
