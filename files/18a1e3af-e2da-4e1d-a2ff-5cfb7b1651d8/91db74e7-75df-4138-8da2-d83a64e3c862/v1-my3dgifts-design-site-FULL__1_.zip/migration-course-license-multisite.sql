-- =========================================================
--  My3DGifts Platform - Make Course "Site Password / License"
--  dynamic + synced with Tool Sites & Access.
--
--  BEFORE this file: import migration-course-license.sql and
--  migration-tool-sites.sql (in that order) if you haven't already.
--
--  What this changes:
--   - products.license_site: ENUM('none','main_editor','litho','both')
--       -> VARCHAR(255) holding a comma-separated list of tool_sites.site_key
--          e.g. "litho,balloon" (empty string = none)
--     This lets a course be tied to ANY site you add in Admin -> Tool
--     Sites & Access, not just the original two, and to more than one.
--   - product_licenses.site: ENUM('main_editor','litho','both')
--       -> VARCHAR(255), same comma-separated format. The buyer's
--          generated login is then only valid on the site(s) their
--          course actually covers.
--   - Existing data is converted, not lost: 'both' -> 'main_editor,litho',
--     'none' -> '' (empty).
--
--  Safe to import on a live site - only alters these two columns and
--  rewrites their existing values, no rows are deleted.
-- =========================================================

SET NAMES utf8mb4;

-- ---------- products.license_site: ENUM -> VARCHAR(255), CSV of site_key ----------
ALTER TABLE products CHANGE license_site license_site_old ENUM('none','main_editor','litho','both') NULL;
ALTER TABLE products ADD COLUMN license_site VARCHAR(255) NOT NULL DEFAULT '' AFTER license_site_old;

UPDATE products SET license_site = CASE license_site_old
    WHEN 'both'        THEN 'main_editor,litho'
    WHEN 'main_editor'  THEN 'main_editor'
    WHEN 'litho'        THEN 'litho'
    ELSE ''
END;

ALTER TABLE products DROP COLUMN license_site_old;

-- ---------- product_licenses.site: ENUM -> VARCHAR(255), CSV of site_key ----------
ALTER TABLE product_licenses CHANGE site site_old ENUM('main_editor','litho','both') NULL;
ALTER TABLE product_licenses ADD COLUMN site VARCHAR(255) NOT NULL DEFAULT '' AFTER site_old;

UPDATE product_licenses SET site = CASE site_old
    WHEN 'both'        THEN 'main_editor,litho'
    WHEN 'main_editor'  THEN 'main_editor'
    WHEN 'litho'        THEN 'litho'
    ELSE ''
END;

ALTER TABLE product_licenses DROP COLUMN site_old;
