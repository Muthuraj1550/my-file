<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'Home';
$metaTitle = get_setting('seo_home_title', '') ?: null;
$metaDescription = get_setting('seo_home_description', '') ?: get_setting('site_tagline', '');
include __DIR__ . '/includes/header.php';

$recentPosts = db()->query("SELECT title, slug, excerpt, created_at FROM posts WHERE status='published' ORDER BY created_at DESC LIMIT 3")->fetchAll();

$heroTitle    = get_setting('home_hero_title', 'Design. Print. Gift.');
$heroSubtitle = get_setting('home_hero_subtitle', get_setting('site_tagline', ''));
$btn1Text = get_setting('home_hero_btn1_text', 'Open 3D Designer');
$btn1Url  = get_setting('home_hero_btn1_url', '/designer.php');
$btn2Text = get_setting('home_hero_btn2_text', 'View Plans');
$btn2Url  = get_setting('home_hero_btn2_url', '/membership.php');
$customHtml = get_setting('home_custom_html', '');

$bannerEnabled = get_setting('home_banner_enabled', '0') === '1';
$bannerImage   = get_setting('home_banner_image', '');
$bannerUrl     = get_setting('home_banner_url', '');
$bannerNewTab  = get_setting('home_banner_new_tab') === '1';
$bannerAlt     = get_setting('home_banner_alt', 'Banner');

$coinWidgetEnabled = get_setting('coin_widget_enabled', '0') === '1';

$coin = [
    ['img' => get_setting('coin_face1_image', ''), 'emoji' => '🎁', 'text' => get_setting('coin_face1_text', 'Buy 3D Print Gift'),      'url' => get_setting('coin_face1_url', '/membership.php'), 'newTab' => get_setting('coin_face1_new_tab') === '1'],
    ['img' => get_setting('coin_face2_image', ''), 'emoji' => '🧩', 'text' => get_setting('coin_face2_text', 'Buy 3D Design Template'), 'url' => get_setting('coin_face2_url', '/designer.php'),   'newTab' => get_setting('coin_face2_new_tab') === '1'],
];

function nav_url($url) {
    return (strpos($url, 'http') === 0) ? $url : SITE_URL . $url;
}
foreach ($coin as &$c) { $c['url'] = nav_url($c['url']); }
unset($c);

$tossEnabled    = get_setting('coin_toss_enabled', '1') === '1';
$tossStartDelay = max(0, (int)get_setting('coin_toss_start_delay', 3));
$tossRepeatCount = max(0, (int)get_setting('coin_toss_repeat_count', 3));
$tossGap        = max(1, (int)get_setting('coin_toss_gap', 6));

$testimonialsEnabled = get_setting('home_testimonials_enabled', '1') === '1';
$testimonials = [];
for ($i = 1; $i <= 3; $i++) {
    $text = trim(get_setting("testimonial{$i}_text", ''));
    if ($text === '') continue;
    $testimonials[] = [
        'name'   => get_setting("testimonial{$i}_name", ''),
        'role'   => get_setting("testimonial{$i}_role", ''),
        'text'   => $text,
        'rating' => max(0, min(5, (int)get_setting("testimonial{$i}_rating", 5))),
    ];
}
?>
<section class="hero">
  <h1><?php echo h($heroTitle); ?></h1>
  <p><?php echo h($heroSubtitle); ?></p>
  <?php if ($btn1Text && $btn1Url): ?>
    <a href="<?php echo h(nav_url($btn1Url)); ?>" class="btn"><?php echo h($btn1Text); ?></a>
  <?php endif; ?>
  &nbsp;
  <?php if ($btn2Text && $btn2Url): ?>
    <a href="<?php echo h(nav_url($btn2Url)); ?>" class="btn btn-outline"><?php echo h($btn2Text); ?></a>
  <?php endif; ?>
</section>

<?php if ($bannerEnabled && $bannerImage): ?>
<section style="margin:20px 0;">
  <?php if ($bannerUrl): ?>
    <a href="<?php echo h(nav_url($bannerUrl)); ?>" <?php echo $bannerNewTab ? 'target="_blank" rel="noopener"' : ''; ?>>
      <img src="<?php echo h($bannerImage); ?>" alt="<?php echo h($bannerAlt); ?>" style="width:100%;border-radius:10px;display:block;">
    </a>
  <?php else: ?>
    <img src="<?php echo h($bannerImage); ?>" alt="<?php echo h($bannerAlt); ?>" style="width:100%;border-radius:10px;display:block;">
  <?php endif; ?>
</section>
<?php endif; ?>

<?php if ($coinWidgetEnabled): ?>
<div class="coin-flip-wrap" id="coinFlipWrap">
  <div class="coin-toss-carrier" id="coinTossCarrier">
    <a id="coinFlip" class="coin-flip" href="<?php echo h($coin[0]['url']); ?>" <?php echo $coin[0]['newTab'] ? 'target="_blank" rel="noopener"' : ''; ?>>
      <span class="coin-flip-circle" id="coinFlipCircle">
        <?php if ($coin[0]['img']): ?>
          <img id="coinFlipImg" src="<?php echo h($coin[0]['img']); ?>" alt="">
        <?php else: ?>
          <span id="coinFlipEmoji" class="coin-flip-emoji"><?php echo $coin[0]['emoji']; ?></span>
        <?php endif; ?>
      </span>
      <span class="coin-caption" id="coinFlipCaption"><?php echo h($coin[0]['text']); ?></span>
    </a>
  </div>
</div>
<script>
(function(){
  var faces = <?php echo json_encode($coin, JSON_UNESCAPED_SLASHES); ?>;
  var idx = 0;
  var el = document.getElementById('coinFlip');
  var circle = document.getElementById('coinFlipCircle');
  var caption = document.getElementById('coinFlipCaption');
  if (!el || faces.length < 2) return;
  var isTossing = false;

  // --- Face-swap flip (runs continuously, pauses mid-air during a toss) ---
  setInterval(function(){
    if (isTossing) return;
    el.classList.add('flipping');
    setTimeout(function(){
      idx = 1 - idx;
      var f = faces[idx];
      circle.innerHTML = f.img
        ? '<img id="coinFlipImg" src="' + f.img + '" alt="">'
        : '<span class="coin-flip-emoji">' + f.emoji + '</span>';
      caption.textContent = f.text;
      el.setAttribute('href', f.url);
      if (f.newTab) { el.setAttribute('target', '_blank'); el.setAttribute('rel', 'noopener'); }
      else { el.removeAttribute('target'); el.removeAttribute('rel'); }
      el.classList.remove('flipping');
    }, 300);
  }, 3500);

  // --- Toss-across-the-screen animation (admin-controlled timing/repeat) ---
  var tossEnabled     = <?php echo $tossEnabled ? 'true' : 'false'; ?>;
  var tossStartDelay  = <?php echo $tossStartDelay * 1000; ?>;
  var tossRepeatCount = <?php echo $tossRepeatCount; ?>; // 0 = forever
  var tossGap         = <?php echo $tossGap * 1000; ?>;
  var wrap = document.getElementById('coinFlipWrap');
  var carrier = document.getElementById('coinTossCarrier');
  var tossesDone = 0;

  function runToss(){
    if (tossRepeatCount > 0 && tossesDone >= tossRepeatCount) return;
    tossesDone++;
    isTossing = true;
    wrap.classList.add('coin-tossing');
    carrier.addEventListener('animationend', function handler(){
      carrier.removeEventListener('animationend', handler);
      wrap.classList.remove('coin-tossing');
      isTossing = false;
      if (tossRepeatCount === 0 || tossesDone < tossRepeatCount) {
        setTimeout(runToss, tossGap);
      }
    });
  }

  if (tossEnabled && wrap && carrier) {
    setTimeout(runToss, tossStartDelay);
  }
})();
</script>
<?php endif; ?>

<?php
  $__courses = [];
  if (shop_tables_ready() && function_exists('course_license_ready') && course_license_ready()) {
      $__courses = array_slice(array_values(array_filter(all_products(true), fn($pp) => $pp['type'] === 'course')), 0, 3);
  }
?>
  <?php if ($__courses): ?>
  <section style="margin:40px 0 8px;">
    <div style="display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:8px;">
      <h2 style="margin:0;">🎓 Featured Courses</h2>
      <a href="<?php echo SITE_URL; ?>/products.php" class="btn btn-sm btn-outline">View All →</a>
    </div>
    <div class="plans-grid" style="grid-template-columns:repeat(auto-fill,minmax(240px,1fr));margin-top:16px;">
      <?php foreach ($__courses as $cp):
        $__ceff = product_effective_price($cp);
        $__conSale = $__ceff < (float)$cp['price'];
        $__itemCount = count(course_included_items($cp['id'], true, true));
      ?>
        <a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($cp['slug']); ?>" class="plan-card" style="text-align:left;padding:0;overflow:hidden;text-decoration:none;color:inherit;display:block;">
          <?php if (!empty($cp['thumbnail'])): ?>
            <img src="<?php echo h($cp['thumbnail']); ?>" alt="<?php echo h($cp['title']); ?>" style="width:100%;height:160px;object-fit:cover;display:block;">
          <?php else: ?>
            <div style="width:100%;height:160px;background:linear-gradient(135deg,#1e293b,#0f172a);display:flex;align-items:center;justify-content:center;font-size:40px;">🎓</div>
          <?php endif; ?>
          <div style="padding:14px;">
            <span class="badge badge-gold" style="margin-bottom:6px;display:inline-block;">🎓 Course<?php echo $__itemCount ? ' · ' . $__itemCount . ' item' . ($__itemCount > 1 ? 's' : '') : ''; ?></span>
            <?php if (!empty($cp['level']) && function_exists('course_level_label')): ?>
              <span class="badge" style="margin:0 0 6px 4px;display:inline-block;"><?php echo h(course_level_label($cp['level'])); ?></span>
            <?php endif; ?>
            <h3 style="margin:4px 0 8px;font-size:16px;line-height:1.3;"><?php echo h($cp['title']); ?></h3>
            <?php if (!empty($cp['short_desc'])): ?><p style="margin:0 0 8px;font-size:13px;color:var(--muted,#94a3b8);"><?php echo h($cp['short_desc']); ?></p><?php endif; ?>
            <?php if ($__conSale): ?>
              <span style="text-decoration:line-through;color:var(--muted,#94a3b8);font-size:13px;">₹<?php echo number_format($cp['price'],0); ?></span>
              <strong style="font-size:17px;color:#22c55e;margin-left:4px;">₹<?php echo number_format($__ceff,0); ?></strong>
            <?php else: ?>
              <strong style="font-size:17px;"><?php echo $__ceff > 0 ? '₹' . number_format($__ceff,0) : 'Free'; ?></strong>
            <?php endif; ?>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

<?php if (shop_tables_ready()): ?>
  <?php
    $__showcase = all_products(true);
    $__showcase = array_slice($__showcase, 0, 8); // featured first (all_products already orders featured DESC)
  ?>
  <?php if ($__showcase): ?>
  <section style="margin:36px 0 8px;">
    <div style="display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:8px;">
      <h2 style="margin:0;"><?php echo $__courses ? 'More Design Files & Templates' : 'Shop - Design Files & Video Courses'; ?></h2>
      <a href="<?php echo SITE_URL; ?>/products.php" class="btn btn-sm btn-outline">View All →</a>
    </div>
    <div class="plans-grid" style="grid-template-columns:repeat(auto-fill,minmax(200px,1fr));margin-top:16px;">
      <?php foreach ($__showcase as $sp): ?>
        <?php
          $__eff = product_effective_price($sp);
          $__onSale = $__eff < (float)$sp['price'];
        ?>
        <a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($sp['slug']); ?>" class="plan-card" style="text-align:left;padding:0;overflow:hidden;text-decoration:none;color:inherit;display:block;">
          <?php if (!empty($sp['thumbnail'])): ?>
            <img src="<?php echo h($sp['thumbnail']); ?>" alt="<?php echo h($sp['title']); ?>" style="width:100%;height:140px;object-fit:cover;display:block;">
          <?php else: ?>
            <div style="width:100%;height:140px;background:linear-gradient(135deg,#1e293b,#0f172a);display:flex;align-items:center;justify-content:center;font-size:32px;">🗂️</div>
          <?php endif; ?>
          <div style="padding:12px;">
            <?php if ($sp['featured']): ?><span class="badge badge-gold" style="margin-bottom:6px;display:inline-block;">⭐ Featured</span><?php endif; ?>
            <h3 style="margin:4px 0 8px;font-size:14px;line-height:1.3;"><?php echo h($sp['title']); ?></h3>
            <?php if ($__onSale): ?>
              <span style="text-decoration:line-through;color:var(--muted,#94a3b8);font-size:12px;">₹<?php echo number_format($sp['price'],0); ?></span>
              <strong style="font-size:15px;color:#22c55e;margin-left:4px;">₹<?php echo number_format($__eff,0); ?></strong>
            <?php else: ?>
              <strong style="font-size:15px;"><?php echo $__eff > 0 ? '₹' . number_format($__eff,0) : 'Free'; ?></strong>
            <?php endif; ?>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>
<?php endif; ?>

<div class="card">
  <h2>Why My 3D Gifts?</h2>
  <div class="stat-row">
    <div class="stat-box"><div class="num">🎨</div><div class="lbl">Design your own 3D models in the browser</div></div>
    <div class="stat-box"><div class="num">✂️</div><div class="lbl">Model cutting &amp; export tools</div></div>
    <div class="stat-box"><div class="num">🖼️</div><div class="lbl">Lithophane &amp; photo lamp generator</div></div>
    <div class="stat-box"><div class="num">👑</div><div class="lbl">Premium templates for members</div></div>
  </div>
</div>

<?php if ($testimonialsEnabled && $testimonials): ?>
<section style="margin:36px 0 8px;">
  <h2 style="margin-bottom:16px;">💬 What Buyers Say</h2>
  <div class="plans-grid" style="grid-template-columns:repeat(auto-fill,minmax(240px,1fr));">
    <?php foreach ($testimonials as $t): ?>
      <div class="plan-card" style="text-align:left;">
        <?php if ($t['rating'] > 0): ?><div style="color:#f5b301;font-size:14px;margin-bottom:8px;"><?php echo str_repeat('★', $t['rating']) . str_repeat('☆', 5 - $t['rating']); ?></div><?php endif; ?>
        <p style="font-style:italic;line-height:1.6;margin:0 0 12px;">“<?php echo h($t['text']); ?>”</p>
        <?php if ($t['name']): ?><div style="font-weight:600;"><?php echo h($t['name']); ?></div><?php endif; ?>
        <?php if ($t['role']): ?><div style="font-size:12px;color:var(--muted,#94a3b8);"><?php echo h($t['role']); ?></div><?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if (trim($customHtml) !== ''): ?>
<div class="card">
  <?php echo $customHtml; /* trusted admin HTML, set in Admin > Homepage */ ?>
</div>
<?php endif; ?>

<?php if ($recentPosts): ?>
<h2>Latest from the Blog</h2>
<div class="post-list">
  <?php foreach ($recentPosts as $p): ?>
    <div class="post-card">
      <h2><a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo h($p['slug']); ?>"><?php echo h($p['title']); ?></a></h2>
      <div class="post-meta"><?php echo date('d M Y', strtotime($p['created_at'])); ?></div>
      <p><?php echo h($p['excerpt']); ?></p>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php $waLink = whatsapp_link('Hi, I have a question about my3dgifts.'); if ($waLink): ?>
  <a href="<?php echo h($waLink); ?>" target="_blank" rel="noopener" title="Chat on WhatsApp"
     style="position:fixed;right:18px;bottom:18px;width:44px;height:44px;background:#25D366;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 3px 10px rgba(0,0,0,.3);z-index:500;font-size:22px;line-height:1;text-decoration:none;">💬</a>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
