<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$slug = $_GET['slug'] ?? '';
$stmt = db()->prepare("SELECT * FROM posts WHERE slug = ? AND status='published' LIMIT 1");
$stmt->execute([$slug]);
$post = $stmt->fetch();

if (!$post) {
    http_response_code(404);
    $pageTitle = 'Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="card"><h1>Post not found</h1><p><a href="' . SITE_URL . '/blog.php">Back to blog</a></p></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

// Course curriculum items (linked to 1+ courses) are paid lesson content -
// gate the actual body behind login + owning at least one linked course,
// and keep them out of Google.
$linkedCourseIds = function_exists('post_course_link_ready') && post_course_link_ready() ? post_course_ids($post['id']) : [];
$isCourseContent = !empty($linkedCourseIds);
$courseProducts = [];
$courseProduct = null; // first linked course - used for the single "return to course" link
$hasCourseAccess = true;
if ($isCourseContent) {
    foreach ($linkedCourseIds as $cid) {
        $cp = get_product($cid);
        if ($cp) $courseProducts[] = $cp;
    }
    $courseProduct = $courseProducts[0] ?? null;
    $hasCourseAccess = user_can_access_course_content_any($linkedCourseIds);
}

$pageTitle = $post['title'];
$metaTitle = $post['meta_title'] ?: null;
$metaDescription = $post['meta_description'] ?: $post['excerpt'];
$noIndex = $isCourseContent; // paid lesson content shouldn't rank/be indexed
$viewId = $hasCourseAccess ? record_view('post', $post['id']) : 0;
// Only show a "return to course" link when the visitor actually came here from
// that course's curriculum list (not on every lesson, every time).
$showReturnToCourse = $isCourseContent && $hasCourseAccess && $courseProduct && (($_GET['from'] ?? '') === 'course');
include __DIR__ . '/includes/header.php';
?>
<?php if ($showReturnToCourse): ?>
<p style="margin-bottom:10px;"><a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($courseProduct['slug']); ?>">← Return to Course Content</a></p>
<?php endif; ?>
<?php if ($isCourseContent && !$hasCourseAccess): ?>
<article class="card">
  <h1><?php echo h($post['title']); ?></h1>
  <div class="flash flash-error" style="margin-top:10px;">
    🔒 This lesson is part of <?php echo $courseProducts ? implode(' or ', array_map(fn($c) => '"' . h($c['title']) . '"', $courseProducts)) : 'a paid course'; ?> and is locked.
    <?php echo current_user() ? 'You need to purchase ' . (count($courseProducts) > 1 ? 'one of these courses' : 'this course') . ' to unlock it.' : 'Please login and purchase ' . (count($courseProducts) > 1 ? 'one of these courses' : 'this course') . ' to unlock it.'; ?>
  </div>
  <p style="margin-top:16px;">
    <?php if (!current_user()): ?>
      <a href="<?php echo SITE_URL; ?>/login.php?next=<?php echo urlencode('/post.php?slug=' . $post['slug']); ?>" class="btn">Login</a>
    <?php endif; ?>
    <?php foreach ($courseProducts as $cp): ?>
      <a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($cp['slug']); ?>" class="btn <?php echo current_user() ? '' : 'btn-outline'; ?>">View <?php echo count($courseProducts) > 1 ? '"' . h($cp['title']) . '"' : 'Course'; ?> &amp; Buy</a>
    <?php endforeach; ?>
  </p>
</article>
<?php else: ?>
<article class="card">
  <h1><?php echo h($post['title']); ?></h1>
  <div class="post-meta"><?php echo date('d M Y', strtotime($post['created_at'])); ?> · 👁 <?php echo view_count('post', $post['id']); ?> views</div>
  <?php if ($post['featured_image']): ?>
    <img src="<?php echo h($post['featured_image']); ?>" style="max-width:100%;border-radius:10px;margin:16px 0;">
  <?php endif; ?>
  <div class="post-content"><?php echo $post['content']; /* trusted admin HTML content */ ?></div>
  <?php if (!empty($post['button_text']) && !empty($post['button_url'])): ?>
    <p style="margin-top:20px;">
      <a href="<?php echo (strpos($post['button_url'],'http')===0) ? h($post['button_url']) : SITE_URL . h($post['button_url']); ?>"
         class="btn" <?php echo $post['button_new_tab'] ? 'target="_blank" rel="noopener"' : ''; ?>><?php echo h($post['button_text']); ?></a>
    </p>
  <?php endif; ?>
  <?php $waLink = whatsapp_link('Hi, I have a question about "' . $post['title'] . '"'); if ($waLink): ?>
    <div style="margin-top:22px;padding:14px 16px;border:1px solid var(--border,#27324a);border-radius:10px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
      <span style="color:var(--muted,#94a3b8);font-size:14px;">Have doubts about this? We're happy to clarify.</span>
      <a href="<?php echo h($waLink); ?>" target="_blank" rel="noopener" class="btn" style="background:#25D366;margin-left:auto;">💬 Ask on WhatsApp</a>
    </div>
  <?php endif; ?>
</article>
<?php endif; ?>
<p><a href="<?php echo SITE_URL; ?>/blog.php">← Back to blog</a></p>
<script>
(function(){
  var viewId = <?php echo (int)$viewId; ?>;
  var start = Date.now();
  function sendDuration(){
    var seconds = Math.round((Date.now() - start) / 1000);
    var payload = JSON.stringify({ view_id: viewId, type: 'post', seconds: seconds });
    if (navigator.sendBeacon) {
      navigator.sendBeacon('<?php echo SITE_URL; ?>/api/track-view.php', new Blob([payload], {type:'application/json'}));
    }
  }
  window.addEventListener('pagehide', sendDuration);
  document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') sendDuration(); });
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
