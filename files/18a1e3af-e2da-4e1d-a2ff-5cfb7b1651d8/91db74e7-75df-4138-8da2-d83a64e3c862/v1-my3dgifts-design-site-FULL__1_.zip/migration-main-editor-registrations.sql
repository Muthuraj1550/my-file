-- =========================================================
--  My3DGifts Platform - Main Editor Registration Sync
--
--  When Main Editor's Admin -> Course Site Access ->
--  "sync_registration_to_course_site" is turned ON, every new
--  Main Editor registration gets pushed here (name, phone, email,
--  and optionally the plain-text password) so Admin -> Main Editor
--  Members can show it for support/lookup purposes.
--
--  Safe to import on a live site - only adds one new table.
-- =========================================================

CREATE TABLE IF NOT EXISTS main_editor_registrations (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(120) NOT NULL,
  email          VARCHAR(190) NOT NULL,
  phone          VARCHAR(30)  NOT NULL DEFAULT '',
  address        VARCHAR(255) NOT NULL DEFAULT '',
  password_plain VARCHAR(255) NOT NULL DEFAULT '',
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
