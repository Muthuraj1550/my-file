-- =========================================================
--  Adds a "Show in footer" option for Pages, independent of
--  the existing "Show in top menu" (show_in_menu) option.
--  Import this file in phpMyAdmin AFTER db.sql (safe on an
--  existing site - it only adds one column, no data touched).
-- =========================================================

SET NAMES utf8mb4;

ALTER TABLE pages
    ADD COLUMN show_in_footer TINYINT(1) NOT NULL DEFAULT 0 AFTER show_in_menu;
