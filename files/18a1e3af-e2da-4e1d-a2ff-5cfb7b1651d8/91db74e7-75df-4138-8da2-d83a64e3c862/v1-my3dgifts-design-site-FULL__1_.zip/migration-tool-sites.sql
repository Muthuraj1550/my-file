-- =========================================================
--  My3DGifts Platform - Tool Sites (per-site API keys) +
--  Manual site access grants.
--  Import AFTER migration-course-license.sql. Only ADDS things.
-- =========================================================

SET NAMES utf8mb4;

-- ---------- Each external tool site gets its own API id + API key ----------
CREATE TABLE IF NOT EXISTS tool_sites (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    site_key   VARCHAR(40)  NOT NULL,            -- api id, e.g. 'litho', 'main_editor', 'balloon'
    name       VARCHAR(120) NOT NULL,
    site_url   VARCHAR(255) DEFAULT NULL,
    api_key    VARCHAR(80)  NOT NULL,
    status     ENUM('active','disabled') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY site_key (site_key),
    KEY api_key (api_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Manually granted (or extra) access for a user on a site ----------
CREATE TABLE IF NOT EXISTS site_access (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    INT UNSIGNED DEFAULT NULL,
    site_key   VARCHAR(40) NOT NULL,
    username   VARCHAR(60) NOT NULL,
    password   VARCHAR(40) NOT NULL,
    source     ENUM('manual','product') NOT NULL DEFAULT 'manual',
    note       VARCHAR(190) DEFAULT NULL,
    status     ENUM('active','revoked') NOT NULL DEFAULT 'active',
    expires_at DATE DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_verified_at DATETIME DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY site_user (site_key, username),
    KEY username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Default two sites (api keys are random; regenerate any time in admin) ----------
INSERT IGNORE INTO tool_sites (site_key, name, site_url, api_key)
VALUES ('litho', 'Lithophane Studio', '', SHA2(CONCAT(RAND(), UUID()), 256));
INSERT IGNORE INTO tool_sites (site_key, name, site_url, api_key)
VALUES ('main_editor', 'Main Editor', '', SHA2(CONCAT(RAND(), UUID()), 256));
