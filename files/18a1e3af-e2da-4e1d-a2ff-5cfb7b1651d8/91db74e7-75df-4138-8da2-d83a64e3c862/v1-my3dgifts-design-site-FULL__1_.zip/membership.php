<?php
/**
 * Both membership plans AND coins are now bought starting on Main
 * Editor (it has the browsing UI + the user's account). This page's
 * only job is to be the "come back here" landing spot after payment —
 * see main-editor-pay.php for the actual guest checkout.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$mainEditorUrl = rtrim((string) get_setting('main_editor_url', 'https://my3dgifts.com'), '/');
$pageTitle = 'Main Editor Membership';
include __DIR__ . '/includes/header.php';
?>
<div class="hero" style="padding-top:20px;">
  <h1>Main Editor Membership &amp; Coins</h1>
  <p>Plans and coins are managed on Main Editor now — pick what you need there, then come back here only for payment.</p>
</div>

<?php if (isset($_GET['payment']) && $_GET['payment'] === 'success'): ?>
  <div class="flash flash-success">✅ Payment received — head back to Main Editor, it's already updated.</div>
<?php elseif (isset($_GET['payment']) && $_GET['payment'] === 'pending'): ?>
  <div class="flash">⏳ Payment received, activation is in progress — check Main Editor in a minute.</div>
<?php endif; ?>

<div class="card" style="max-width:420px;margin:0 auto 24px;text-align:center;">
  <h3 style="margin-top:0;">🚀 Membership Plan</h3>
  <p style="color:#94a3b8;font-size:13px;">Choose a plan, register, and use it — all on Main Editor. You'll only be sent back here for the payment step.</p>
  <a href="<?php echo h($mainEditorUrl); ?>/membership.php" class="btn btn-block">Go to Main Editor ↗</a>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
