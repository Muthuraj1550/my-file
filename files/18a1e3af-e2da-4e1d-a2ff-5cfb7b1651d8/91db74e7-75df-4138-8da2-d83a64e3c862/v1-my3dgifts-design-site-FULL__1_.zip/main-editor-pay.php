<?php
/**
 * Main Editor has no payment gateway. A user there registers, picks a
 * plan OR a coin amount, and gets sent HERE (signed link) to actually
 * pay. No course-site account is needed — this is a plain guest
 * checkout. On success we call Main Editor's api/activate-plan.php
 * (plans, replaces) or api/credit-coins.php (coins, additive), then
 * send the browser back.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/cashfree.php';

$checkoutSessionId = null;
$checkoutError = null;

function m3d_pay_guest_customer($email) {
    return ['id' => 'me_' . substr(md5($email), 0, 12), 'name' => $email, 'email' => $email, 'phone' => ''];
}

// --- Resume an in-progress order (Cashfree SDK reload / back button) ---
$resumeId = $_GET['resume'] ?? '';
if ($resumeId !== '') {
    $stmt = db()->prepare("SELECT * FROM main_editor_plan_orders WHERE cf_order_id = ? LIMIT 1");
    $stmt->execute([$resumeId]);
    $existing = $stmt->fetch();
    if ($existing && $existing['status'] === 'created') {
        $cfResp = cashfree_create_order($existing['cf_order_id'], (float) $existing['amount'], m3d_pay_guest_customer($existing['email']));
        if (!empty($cfResp['payment_session_id'])) {
            $checkoutSessionId = $cfResp['payment_session_id'];
        } else {
            $checkoutError = 'Could not resume payment. Please go back to Main Editor and try again.';
        }
    } else {
        $checkoutError = 'This payment link has already been used or has expired.';
    }
}

// --- Fresh signed request from Main Editor ---
if (!$checkoutSessionId && !$checkoutError) {
    $kind      = ($_GET['kind'] ?? 'plan') === 'coins' ? 'coins' : 'plan';
    $email     = trim((string) ($_GET['email'] ?? ''));
    $returnUrl = trim((string) ($_GET['return_url'] ?? ''));
    $ts        = (int) ($_GET['ts'] ?? 0);
    $sig       = (string) ($_GET['sig'] ?? '');

    if ($kind === 'coins') {
        $coinsQty = max(0, (int) ($_GET['coins_qty'] ?? 0));
        $sigParams = ['kind' => 'coins', 'email' => $email, 'coins_qty' => $coinsQty, 'return_url' => $returnUrl, 'ts' => $ts];
        $minBuy = max(1, (int) get_setting('coin_min_purchase', '10'));
        $rate   = max(0.01, (float) get_setting('coin_price_inr', '1'));

        if ($email === '' || $coinsQty < $minBuy) {
            $checkoutError = 'Invalid payment link.';
        } elseif (abs(time() - $ts) > 900) {
            $checkoutError = 'This payment link has expired. Please go back to Main Editor and try again.';
        } elseif (!main_editor_verify_sig($sigParams, $sig)) {
            $checkoutError = 'This payment link could not be verified.';
        } else {
            $amount  = round($coinsQty * $rate, 2);
            $orderId = 'MEPL' . substr(md5($email . $ts), 0, 10) . time();
            $cfResp  = cashfree_create_order($orderId, $amount, m3d_pay_guest_customer($email));
            if (!empty($cfResp['error'])) {
                $checkoutError = 'Payment gateway error: ' . $cfResp['error'];
            } elseif (!empty($cfResp['payment_session_id'])) {
                $ins = db()->prepare("INSERT INTO main_editor_plan_orders (cf_order_id, kind, email, plan_name, amount, days, coins, return_url, status) VALUES (?,'coins',?,'',?,0,?,?,'created')");
                $ins->execute([$orderId, $email, $amount, $coinsQty, $returnUrl]);
                $checkoutSessionId = $cfResp['payment_session_id'];
            } else {
                $checkoutError = 'Could not create payment order. Please try again shortly.';
            }
        }
    } else {
        $planName = trim((string) ($_GET['plan_name'] ?? ''));
        $price    = (float) ($_GET['price'] ?? 0);
        $days     = max(1, (int) ($_GET['days'] ?? 30));
        $coins    = max(0, (int) ($_GET['coins'] ?? 0));
        $sigParams = ['email' => $email, 'plan_name' => $planName, 'price' => $price, 'days' => $days, 'coins' => $coins, 'return_url' => $returnUrl, 'ts' => $ts];

        if ($email === '' || $planName === '' || $price <= 0) {
            $checkoutError = 'Invalid payment link.';
        } elseif (abs(time() - $ts) > 900) {
            $checkoutError = 'This payment link has expired. Please go back to Main Editor and try again.';
        } elseif (!main_editor_verify_sig($sigParams, $sig)) {
            $checkoutError = 'This payment link could not be verified.';
        } else {
            $orderId = 'MEPL' . substr(md5($email . $ts), 0, 10) . time();
            $cfResp  = cashfree_create_order($orderId, $price, m3d_pay_guest_customer($email));
            if (!empty($cfResp['error'])) {
                $checkoutError = 'Payment gateway error: ' . $cfResp['error'];
            } elseif (!empty($cfResp['payment_session_id'])) {
                $ins = db()->prepare("INSERT INTO main_editor_plan_orders (cf_order_id, kind, email, plan_name, amount, days, coins, return_url, status) VALUES (?,'plan',?,?,?,?,?,?,'created')");
                $ins->execute([$orderId, $email, $planName, $price, $days, $coins, $returnUrl]);
                $checkoutSessionId = $cfResp['payment_session_id'];
            } else {
                $checkoutError = 'Could not create payment order. Please try again shortly.';
            }
        }
    }
}

$pageTitle = 'Main Editor — Payment';
include __DIR__ . '/includes/header.php';
?>
<div class="hero" style="padding-top:20px;">
  <h1>Main Editor Payment</h1>
  <p>Secure payment for your Main Editor plan or coins.</p>
</div>

<?php if ($checkoutError): ?>
  <div class="card" style="max-width:480px;margin:20px auto;text-align:center;">
    <h2 style="color:#f59e0b;">⚠️ <?php echo h($checkoutError); ?></h2>
    <a href="https://my3dgifts.com/membership.php" class="btn" style="margin-top:10px;">Back to Main Editor</a>
  </div>
<?php elseif ($checkoutSessionId): ?>
  <div class="card" style="text-align:center;">
    <h2>Redirecting to secure payment...</h2>
    <p>Please wait, do not close this window.</p>
  </div>
  <script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
  <script>
    const cashfree = Cashfree({ mode: "<?php echo get_setting('cashfree_mode','sandbox') === 'production' ? 'production' : 'sandbox'; ?>" });
    cashfree.checkout({
      paymentSessionId: "<?php echo h($checkoutSessionId); ?>",
      redirectTarget: "_self"
    });
  </script>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
