-- =========================================================
--  Optional Gmail / email on manual site access grants.
--  Import AFTER migration-tool-sites.sql. Only ADDS a column.
-- =========================================================
SET NAMES utf8mb4;

ALTER TABLE site_access ADD COLUMN email VARCHAR(190) DEFAULT NULL AFTER password;
