-- Lets a Post or Page be ticked into MORE THAN ONE Course under "🎓 Course
-- Curriculum" (previously it was a single-select, one course per lesson) -
-- same idea as migration-product-multi-course.sql, for posts/pages.
-- Safe to run on a live site: only adds two new tables and copies existing
-- single-course links into them. Nothing existing is deleted or altered -
-- the old posts.course_id / pages.course_id columns are left in place and
-- kept in sync with the first ticked course, purely as a fallback.

CREATE TABLE IF NOT EXISTS post_courses (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id INT UNSIGNED NOT NULL,
  course_id INT UNSIGNED NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_post_course (post_id, course_id),
  KEY idx_post_id (post_id),
  KEY idx_course_id (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS page_courses (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  page_id INT UNSIGNED NOT NULL,
  course_id INT UNSIGNED NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_page_course (page_id, course_id),
  KEY idx_page_id (page_id),
  KEY idx_course_id (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Carry over every post/page that was already linked to a single course
-- (its old course_sort_order becomes that course's curriculum order).
INSERT IGNORE INTO post_courses (post_id, course_id, sort_order)
SELECT id, course_id, course_sort_order FROM posts WHERE course_id IS NOT NULL;

INSERT IGNORE INTO page_courses (page_id, course_id, sort_order)
SELECT id, course_id, course_sort_order FROM pages WHERE course_id IS NOT NULL;
