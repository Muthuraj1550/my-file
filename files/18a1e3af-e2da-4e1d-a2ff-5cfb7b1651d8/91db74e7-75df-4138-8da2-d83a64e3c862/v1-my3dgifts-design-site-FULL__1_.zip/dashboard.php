<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

require_login();
$user = current_user();
check_and_expire_user($user);

$pwdErrors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    csrf_check();
    $newPwd = $_POST['new_pwd'] ?? '';
    $confPwd = $_POST['conf_pwd'] ?? '';
    if (strlen($newPwd) < 6) {
        $pwdErrors[] = 'New password must be at least 6 characters.';
    } elseif ($newPwd !== $confPwd) {
        $pwdErrors[] = 'Passwords do not match.';
    } else {
        db()->prepare("UPDATE users SET password_hash=? WHERE id=?")
            ->execute([password_hash($newPwd, PASSWORD_DEFAULT), $user['id']]);
        flash('Password updated successfully.');
        redirect('/dashboard.php');
    }
}

$daysLeft  = plan_days_left($user);
$renewDays = (int) get_setting('renew_days_before', 5);
$mySites = function_exists('user_site_access') ? user_site_access($user['id']) : [];

$pageTitle = 'My Dashboard';
include __DIR__ . '/includes/header.php';
?>
<h1>Welcome, <?php echo h($user['name']); ?></h1>

<div class="stat-row">
  <div class="stat-box"><div class="num"><?php echo h($user['plan_name'] ?: 'Free'); ?></div><div class="lbl">Current Plan</div></div>
  <div class="stat-box"><div class="num"><?php echo $daysLeft >= 0 ? $daysLeft . 'd' : 'Expired'; ?></div><div class="lbl">Days Remaining</div></div>
  <div class="stat-box"><div class="num"><?php echo count($mySites); ?></div><div class="lbl">Sites You Can Access</div></div>
</div>

<?php if ($daysLeft >= 0 && $daysLeft <= $renewDays): ?>
  <div class="flash flash-error">Your plan expires in <?php echo $daysLeft; ?> day(s). <a href="<?php echo SITE_URL; ?>/membership.php">Renew now</a> to avoid interruption.</div>
<?php endif; ?>

<div class="card">
  <h3>🔓 Sites You Can Access</h3>
  <p style="color:var(--muted,#94a3b8);font-size:13px;margin-top:-6px;">Your membership &amp; purchases unlock these tool sites. Use the login shown for each site.</p>
  <?php if (!$mySites): ?>
    <p style="margin:0;">No tool site access yet. <a href="<?php echo SITE_URL; ?>/products.php">Browse courses &amp; products</a> to unlock a site.</p>
  <?php else: ?>
    <table>
      <tr><th>Site</th><th>Login</th><th>Password</th><th>Unlocked by</th><th>Valid till</th><th></th></tr>
      <?php foreach ($mySites as $s): ?>
      <tr>
        <td><strong><?php echo h($s['name']); ?></strong></td>
        <td><code><?php echo h($s['username']); ?></code></td>
        <td><code><?php echo h($s['password']); ?></code></td>
        <td style="font-size:12.5px;color:var(--muted,#94a3b8)"><?php echo h($s['via']); ?></td>
        <td style="font-size:12.5px;color:var(--muted,#94a3b8)"><?php echo h($s['expires_at'] ?: 'No expiry'); ?></td>
        <td><?php if (!empty($s['site_url'])): ?><a class="btn btn-sm btn-outline" href="<?php echo h($s['site_url']); ?>" target="_blank" rel="noopener">Open ↗</a><?php endif; ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>

<div class="card">
  <h3>Manage Membership</h3>
  <p>Plan expiry date: <strong><?php echo h($user['plan_expiry']); ?></strong></p>
  <a href="<?php echo SITE_URL; ?>/membership.php" class="btn">View / Upgrade Plans</a>
  &nbsp;
  <a href="<?php echo SITE_URL; ?>/designer.php" class="btn btn-outline">Open 3D Designer (Main Editor) ↗</a>
</div>

<?php $mainEditorLogin = function_exists('get_main_editor_login') ? get_main_editor_login($user['id']) : null; ?>
<?php if ($mainEditorLogin): ?>
<div class="card" style="max-width:420px;border:1px solid rgba(34,197,94,.35);background:rgba(34,197,94,.06);">
  <h3>🔑 Main Editor Login</h3>
  <p style="color:var(--muted,#94a3b8);font-size:13px;margin-top:-6px;">Use this to log into the 3D Designer on Main Editor. Your plan &amp; coins carry over automatically.</p>
  <p style="margin:0;">Username: <code><?php echo h($mainEditorLogin['username']); ?></code></p>
  <p style="margin:2px 0 0;">Password: <code><?php echo h($mainEditorLogin['password']); ?></code></p>
</div>
<?php endif; ?>

<div class="card" style="max-width:420px;">
  <h3>Change Password</h3>
  <?php foreach ($pwdErrors as $e): ?><div class="flash flash-error"><?php echo h($e); ?></div><?php endforeach; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>New Password</label>
    <input type="password" name="new_pwd" required>
    <label>Confirm New Password</label>
    <input type="password" name="conf_pwd" required>
    <button type="submit" name="change_password" class="btn btn-block">Update Password</button>
  </form>
</div>

<p><a href="<?php echo SITE_URL; ?>/logout.php" class="btn btn-danger btn-sm">Logout</a></p>

<?php include __DIR__ . '/includes/footer.php'; ?>
