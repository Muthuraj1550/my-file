-- =========================================================
--  My3DGifts Platform - Main Editor plan payment handoff
--
--  Main Editor has no payment gateway of its own. Flow:
--   1. User registers + picks a plan on Main Editor.
--   2. Main Editor sends them HERE (main-editor-pay.php) with a
--      signed request (plan name/price/days/coins + their email).
--   3. This site collects payment via Cashfree (no course-site
--      account needed — pure guest checkout).
--   4. On payment success, this site calls Main Editor's
--      api/activate-plan.php to activate the plan on THAT
--      Main Editor account, then sends the browser back there.
--
--  Safe to import on a live site - only adds one new table.
-- =========================================================

CREATE TABLE IF NOT EXISTS main_editor_plan_orders (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  cf_order_id  VARCHAR(64) NOT NULL,
  email        VARCHAR(190) NOT NULL,
  plan_name    VARCHAR(120) NOT NULL,
  amount       DECIMAL(10,2) NOT NULL DEFAULT 0,
  days         INT NOT NULL DEFAULT 30,
  coins        INT NOT NULL DEFAULT 0,
  return_url   VARCHAR(500) NOT NULL DEFAULT '',
  status       ENUM('created','paid','activated','failed') NOT NULL DEFAULT 'created',
  activate_note VARCHAR(255) NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_cf_order (cf_order_id),
  KEY idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
