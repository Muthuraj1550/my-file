-- =========================================================
--  Support "buy coins" orders (not just plans) through the same
--  Main Editor <-> Course Site payment handoff.
--
--  Import AFTER migration-main-editor-plan-orders.sql.
-- =========================================================

ALTER TABLE main_editor_plan_orders
  ADD COLUMN kind ENUM('plan','coins') NOT NULL DEFAULT 'plan' AFTER cf_order_id,
  MODIFY COLUMN plan_name VARCHAR(120) NOT NULL DEFAULT '',
  MODIFY COLUMN days INT NOT NULL DEFAULT 0;
