<?php
/**
 * The 3D Designer used to run locally here, but we now maintain ONE
 * editor on Main Editor (my3dgifts.com) instead of upgrading it twice.
 * Anything that used to link to /designer.php (buttons, homepage tiles,
 * old bookmarks, ?load_xml= share links) gets sent there instead.
 *
 * Course buyers log into Main Editor with the username/password shown
 * on My Purchases (see includes/functions.php: generate_product_license_if_needed).
 */
require_once __DIR__ . '/includes/functions.php';

$target = rtrim((string) get_setting('main_editor_url', 'https://my3dgifts.com'), '/') . '/designer';

$loadXml = isset($_GET['load_xml']) ? (string) $_GET['load_xml'] : '';
if ($loadXml !== '') {
    $target .= '?load_xml=' . rawurlencode($loadXml);
}

header('Location: ' . $target, true, 302);
exit;
