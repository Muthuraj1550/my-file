-- =========================================================
--  My3DGifts Standalone Platform - Shareable Content Links
--  Import this file in phpMyAdmin (safe - only ADDS a new
--  table, no existing data is touched).
--
--  Lets Admin generate a special link for any Post or Page
--  (published OR draft, including paid course lessons) that
--  opens it for anyone who has the link - no login, no
--  purchase needed - until the link is deleted or its
--  optional expiry date passes.
-- =========================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS share_links (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    token           VARCHAR(64) NOT NULL,
    content_type    ENUM('post','page') NOT NULL,
    content_id      INT UNSIGNED NOT NULL,
    expires_at      DATETIME DEFAULT NULL,   -- NULL = never expires
    created_by      INT UNSIGNED DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY token (token),
    KEY content_lookup (content_type, content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
