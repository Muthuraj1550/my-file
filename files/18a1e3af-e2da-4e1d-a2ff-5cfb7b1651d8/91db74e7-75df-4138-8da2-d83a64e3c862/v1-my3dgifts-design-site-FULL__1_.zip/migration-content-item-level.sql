-- =========================================================
--  My3DGifts Course Content Level Tags (Beginner / Intermediate / Advanced)
--  Import this file in phpMyAdmin AFTER migration-course-content-links.sql
--  and migration-course-level.sql. Safe on a live site - only ADDS
--  columns, no existing data is touched or deleted.
--
--  Purpose: tag each individual lesson (post / page / product) that
--  is part of a course with a level, so on that course's public page
--  a visitor can pick their level (e.g. "Intermediate") and see only
--  the lessons meant for them, instead of the whole curriculum.
--  (products.level already exists from migration-course-level.sql -
--  this file just adds the same column to posts and pages.)
-- =========================================================

SET NAMES utf8mb4;

ALTER TABLE posts ADD COLUMN IF NOT EXISTS level ENUM('beginner','intermediate','advanced') DEFAULT NULL AFTER course_sort_order;
ALTER TABLE pages ADD COLUMN IF NOT EXISTS level ENUM('beginner','intermediate','advanced') DEFAULT NULL AFTER course_sort_order;

-- NOTE: if your MySQL version is older than 8.0 / MariaDB 10.5 and the
-- "ADD COLUMN IF NOT EXISTS" lines above give a syntax error, just remove
-- the words "IF NOT EXISTS" from those two lines and run again.
-- NOTE: this needs migration-course-content-links.sql to have been run
-- first (it adds the course_sort_order column these lines are AFTER).
