<?php
$adminTitle = 'Analytics';
require_once __DIR__ . '/_layout_top.php';

/* ============ Visitor stats + date range ============ */
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));

$preset = $_GET['preset'] ?? '';
if ($preset === 'today')       { $from = $today;                              $to = $today; }
elseif ($preset === 'yesterday'){ $from = $yesterday;                          $to = $yesterday; }
elseif ($preset === '7d')      { $from = date('Y-m-d', strtotime('-6 days')); $to = $today; }
elseif ($preset === '30d')     { $from = date('Y-m-d', strtotime('-29 days'));$to = $today; }
else {
    $from = $_GET['from'] ?? date('Y-m-d', strtotime('-6 days'));
    $to   = $_GET['to']   ?? $today;
}
// sanitise
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = date('Y-m-d', strtotime('-6 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   $to   = $today;
if ($from > $to) { $tmp=$from; $from=$to; $to=$tmp; }

function _visitor_stats($fromDate, $toDate) {
    $stmt = db()->prepare("SELECT COUNT(*) views, COUNT(DISTINCT ip_address) visitors,
                            COALESCE(SUM(duration_seconds),0) total_seconds,
                            AVG(NULLIF(duration_seconds,0)) avg_seconds
                            FROM content_views
                            WHERE content_type <> 'tool_click'
                            AND created_at >= ? AND created_at < DATE_ADD(?, INTERVAL 1 DAY)");
    $stmt->execute([$fromDate, $toDate]);
    return $stmt->fetch();
}
function _visitor_stats_day($day) { return _visitor_stats($day, $day); }

$rangeStats     = _visitor_stats($from, $to);
$todayStats     = _visitor_stats_day($today);
$yesterdayStats = _visitor_stats_day($yesterday);
$allVisitors    = db()->query("SELECT COUNT(DISTINCT ip_address) v FROM content_views WHERE content_type <> 'tool_click'")->fetch()['v'];

// daily breakdown for the selected range
$dailyStmt = db()->prepare("SELECT DATE(created_at) d, COUNT(*) views, COUNT(DISTINCT ip_address) visitors,
                             COALESCE(SUM(duration_seconds),0) total_seconds,
                             AVG(NULLIF(duration_seconds,0)) avg_seconds
                             FROM content_views
                             WHERE content_type <> 'tool_click'
                             AND created_at >= ? AND created_at < DATE_ADD(?, INTERVAL 1 DAY)
                             GROUP BY DATE(created_at) ORDER BY d DESC");
$dailyStmt->execute([$from, $to]);
$dailyRows = $dailyStmt->fetchAll();

/* ============ Content analytics by type ============ */
$topPosts    = top_content('post', 15);
$topPages    = top_content('page', 15);
$topCourses  = top_products(15, 'course');   // products.type = 'course'
$topProducts = top_products(15, 'other');    // file / software / bundle (everything except courses)

/* ============ Orders (course/product purchases via product_orders) ============ */
$rangeOrderStats     = product_order_stats($from, $to);
$todayOrderStats     = product_order_stats($today, $today);
$yesterdayOrderStats = product_order_stats($yesterday, $yesterday);

/* ============ Traffic sources ============ */
$trafficAll = traffic_source_breakdown(0);
$traffic30d = traffic_source_breakdown(30);
$trafficTotal = array_sum(array_column($trafficAll, 'c')) ?: 1;

/* ============ SEO Traffic Breakdown (Google, Bing, Yahoo, Baidu, DuckDuckGo) ============ */
function _seo_traffic_breakdown($days = 30) {
    if (!content_views_referrer_ready()) return ['google' => 0, 'yahoo' => 0, 'bing' => 0, 'baidu' => 0, 'duckduckgo' => 0, 'other_search' => 0];

    $sql = "SELECT
            SUM(CASE WHEN referrer_source LIKE '%Google%' THEN 1 ELSE 0 END) as google_count,
            SUM(CASE WHEN referrer_source LIKE '%Yahoo%' THEN 1 ELSE 0 END) as yahoo_count,
            SUM(CASE WHEN referrer_source LIKE '%Bing%' THEN 1 ELSE 0 END) as bing_count,
            SUM(CASE WHEN referrer_source LIKE '%Baidu%' THEN 1 ELSE 0 END) as baidu_count,
            SUM(CASE WHEN referrer_source LIKE '%DuckDuckGo%' THEN 1 ELSE 0 END) as duckduckgo_count,
            SUM(CASE WHEN referrer_source REGEXP 'Google|Yahoo|Bing|Baidu|DuckDuckGo' THEN 0 ELSE 1 END) as other_search_count
            FROM content_views
            WHERE content_type <> 'tool_click' AND referrer_source IS NOT NULL";

    if ($days > 0) $sql .= " AND created_at >= NOW() - INTERVAL " . (int)$days . " DAY";

    $result = db()->query($sql)->fetch();

    return [
        'google'       => (int)($result['google_count'] ?? 0),
        'yahoo'        => (int)($result['yahoo_count'] ?? 0),
        'bing'         => (int)($result['bing_count'] ?? 0),
        'baidu'        => (int)($result['baidu_count'] ?? 0),
        'duckduckgo'   => (int)($result['duckduckgo_count'] ?? 0),
        'other_search' => (int)($result['other_search_count'] ?? 0),
    ];
}

$seoTrafficAll   = _seo_traffic_breakdown(0);
$seoTraffic30d   = _seo_traffic_breakdown(30);
$seoTraffic7d    = _seo_traffic_breakdown(7);
$seoTrafficTotal = array_sum($seoTrafficAll);

function fmt_minutes($seconds) {
    if (!$seconds) return '0m';
    $m = $seconds / 60;
    return $m < 1 ? round($seconds) . 's' : round($m, 1) . 'm';
}

function fmt_currency($amount) {
    return '₹' . number_format((float)$amount, 2);
}
?>

<style>
.date-filter { margin-bottom: 20px; padding: 15px; background: var(--bg-alt); border-radius: 6px; }
.date-filter input, .date-filter button { padding: 8px 12px; margin-right: 8px; border: 1px solid var(--border); border-radius: 4px; }
.date-filter button { background: var(--primary); color: white; cursor: pointer; border: none; }
.date-filter button:hover { opacity: 0.9; }
</style>

<!-- Date Range Selector -->
<div class="date-filter">
    <strong>Date Range:</strong>
    <button onclick="location.href='?preset=today'">Today</button>
    <button onclick="location.href='?preset=yesterday'">Yesterday</button>
    <button onclick="location.href='?preset=7d'">Last 7 Days</button>
    <button onclick="location.href='?preset=30d'">Last 30 Days</button>
    <span style="margin: 0 15px;">or</span>
    <form method="GET" style="display: inline-block;">
        <input type="date" name="from" value="<?php echo h($from); ?>" />
        <input type="date" name="to" value="<?php echo h($to); ?>" />
        <button type="submit">Filter</button>
    </form>
</div>

<!-- Visitor Stats Header -->
<div class="card">
    <h3>📊 Visitor Summary</h3>
    <div class="stat-row">
        <div class="stat-box"><div class="num"><?php echo (int)$rangeStats['views']; ?></div><div class="lbl">Views (<?php echo h($from); ?> to <?php echo h($to); ?>)</div></div>
        <div class="stat-box"><div class="num"><?php echo (int)$rangeStats['visitors']; ?></div><div class="lbl">Unique Visitors (range)</div></div>
        <div class="stat-box"><div class="num"><?php echo fmt_minutes($rangeStats['avg_seconds']); ?></div><div class="lbl">Avg. Time on Page (range)</div></div>
        <div class="stat-box"><div class="num"><?php echo (int)$allVisitors; ?></div><div class="lbl">All-Time Unique Visitors</div></div>
    </div>
    <div class="stat-row" style="margin-top:10px;">
        <div class="stat-box"><div class="num"><?php echo (int)$todayStats['views']; ?></div><div class="lbl">Views Today</div></div>
        <div class="stat-box"><div class="num"><?php echo (int)$yesterdayStats['views']; ?></div><div class="lbl">Views Yesterday</div></div>
    </div>
</div>

<!-- Daily Breakdown -->
<div class="card">
    <h3>📅 Daily Breakdown (<?php echo h($from); ?> to <?php echo h($to); ?>)</h3>
    <table>
        <thead><tr><th>Date</th><th>Views</th><th>Unique Visitors</th><th>Total Time</th><th>Avg. Time / View</th></tr></thead>
        <tbody>
        <?php foreach ($dailyRows as $row): ?>
          <tr>
            <td><?php echo h($row['d']); ?></td>
            <td><?php echo (int)$row['views']; ?></td>
            <td><?php echo (int)$row['visitors']; ?></td>
            <td><?php echo fmt_minutes($row['total_seconds']); ?></td>
            <td><?php echo fmt_minutes($row['avg_seconds']); ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$dailyRows): ?><tr><td colspan="5">No data for this date range.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Traffic Sources -->
<div class="card">
  <h3>🌐 Traffic Sources — எப்படி வருகிறார்கள்?</h3>
  <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Visitors classified by where they clicked in from — Google search, YouTube, Facebook/Instagram, another site, or came directly. Based on the browser's Referer header, so some visitors are counted as "Direct / App".</p>
  <table>
    <thead><tr><th>Source</th><th>Views (All Time)</th><th>%</th><th>Views (Last 30 Days)</th></tr></thead>
    <tbody>
    <?php
      $traffic30dMap = [];
      foreach ($traffic30d as $r) $traffic30dMap[$r['source']] = (int)$r['c'];
    ?>
    <?php foreach ($trafficAll as $row): $pct = round(($row['c'] / $trafficTotal) * 100, 1); ?>
      <tr>
        <td><?php echo h($row['source']); ?></td>
        <td><?php echo (int)$row['c']; ?></td>
        <td><?php echo $pct; ?>%</td>
        <td><?php echo (int)($traffic30dMap[$row['source']] ?? 0); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$trafficAll): ?><tr><td colspan="4">No views tracked yet, or <code>migration-traffic-source.sql</code> not imported.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<!-- SEO Search Engine Traffic -->
<div class="card">
  <h3>🔍 SEO Traffic by Search Engine</h3>
  <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Visitors arriving from Google, Bing, Yahoo, Baidu, DuckDuckGo and other search engines.</p>
  <table>
    <thead><tr><th>Search Engine</th><th>Views (All Time)</th><th>Views (30d)</th><th>Views (7d)</th><th>% of SEO Traffic</th></tr></thead>
    <tbody>
    <?php
      $engines = [
        ['name' => 'Google', 'key' => 'google', 'icon' => '🔵'],
        ['name' => 'Bing', 'key' => 'bing', 'icon' => '🔷'],
        ['name' => 'Yahoo', 'key' => 'yahoo', 'icon' => '🟣'],
        ['name' => 'Baidu', 'key' => 'baidu', 'icon' => '🇨🇳'],
        ['name' => 'DuckDuckGo', 'key' => 'duckduckgo', 'icon' => '🦆'],
        ['name' => 'Other Search', 'key' => 'other_search', 'icon' => '⚪'],
      ];
      foreach ($engines as $eng):
        $allTime = (int)$seoTrafficAll[$eng['key']];
        $last30  = (int)$seoTraffic30d[$eng['key']];
        $last7   = (int)$seoTraffic7d[$eng['key']];
        $pct     = $seoTrafficTotal > 0 ? round(($allTime / $seoTrafficTotal) * 100, 1) : 0;
    ?>
      <tr>
        <td><?php echo $eng['icon']; ?> <?php echo h($eng['name']); ?></td>
        <td><?php echo $allTime; ?></td>
        <td><?php echo $last30; ?></td>
        <td><?php echo $last7; ?></td>
        <td><?php echo $pct; ?>%</td>
      </tr>
    <?php endforeach; ?>
    <tr style="background-color:rgba(56,189,248,0.1); font-weight:bold;">
      <td>Total SEO Traffic</td>
      <td><?php echo $seoTrafficTotal; ?></td>
      <td><?php echo array_sum($seoTraffic30d); ?></td>
      <td><?php echo array_sum($seoTraffic7d); ?></td>
      <td>100%</td>
    </tr>
    <?php if (!content_views_referrer_ready()): ?>
      <tr><td colspan="5">Run <code>migration-traffic-source.sql</code> in phpMyAdmin to enable referrer/SEO tracking.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Orders -->
<div class="card">
    <h3>💰 Order Summary (Courses + Products)</h3>
    <?php if (!shop_tables_ready()): ?>
      <p style="color:var(--muted);font-size:12px;">Run <code>migration-products-shop.sql</code> in phpMyAdmin to enable order tracking.</p>
    <?php else: ?>
    <div class="stat-row">
        <div class="stat-box"><div class="num"><?php echo (int)$rangeOrderStats['orders']; ?></div><div class="lbl">Paid Orders (<?php echo h($from); ?> to <?php echo h($to); ?>)</div></div>
        <div class="stat-box"><div class="num"><?php echo fmt_currency($rangeOrderStats['revenue']); ?></div><div class="lbl">Revenue (range)</div></div>
        <div class="stat-box"><div class="num"><?php echo (int)$todayOrderStats['orders']; ?></div><div class="lbl">Orders Today</div></div>
        <div class="stat-box"><div class="num"><?php echo fmt_currency($todayOrderStats['revenue']); ?></div><div class="lbl">Revenue Today</div></div>
    </div>
    <div class="stat-row" style="margin-top:10px;">
        <div class="stat-box"><div class="num"><?php echo (int)$yesterdayOrderStats['orders']; ?></div><div class="lbl">Orders Yesterday</div></div>
        <div class="stat-box"><div class="num"><?php echo fmt_currency($yesterdayOrderStats['revenue']); ?></div><div class="lbl">Revenue Yesterday</div></div>
    </div>
    <p style="color:var(--muted);font-size:12px;">Counts only <code>product_orders</code> rows with status = "paid" (created/failed orders excluded).</p>
    <?php endif; ?>
</div>

<!-- Top Courses -->
<div class="card">
  <h3>🎓 Top Courses (by views)</h3>
  <?php if (!shop_tables_ready()): ?>
    <p style="color:var(--muted);font-size:12px;">Run <code>migration-products-shop.sql</code> to enable course/product listing.</p>
  <?php endif; ?>
  <table>
    <thead><tr><th>#</th><th>Title</th><th>Views</th><th>Total Time</th><th>Avg. Time / View</th></tr></thead>
    <tbody>
    <?php foreach ($topCourses as $i => $c): ?>
      <tr>
        <td><?php echo $i + 1; ?></td>
        <td><a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($c['slug']); ?>" target="_blank"><?php echo h($c['title']); ?></a></td>
        <td><?php echo (int)$c['views']; ?></td>
        <td><?php echo fmt_minutes($c['total_seconds']); ?></td>
        <td><?php echo fmt_minutes($c['avg_seconds']); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$topCourses): ?><tr><td colspan="5">No courses yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Top Products (non-course) -->
<div class="card">
  <h3>🛍️ Top Products (by views)</h3>
  <table>
    <thead><tr><th>#</th><th>Title</th><th>Views</th><th>Total Time</th><th>Avg. Time / View</th></tr></thead>
    <tbody>
    <?php foreach ($topProducts as $i => $p): ?>
      <tr>
        <td><?php echo $i + 1; ?></td>
        <td><a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($p['slug']); ?>" target="_blank"><?php echo h($p['title']); ?></a></td>
        <td><?php echo (int)$p['views']; ?></td>
        <td><?php echo fmt_minutes($p['total_seconds']); ?></td>
        <td><?php echo fmt_minutes($p['avg_seconds']); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$topProducts): ?><tr><td colspan="5">No products yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Top Posts -->
<div class="card">
  <h3>🏆 Top Posts (by views)</h3>
  <table>
    <thead><tr><th>#</th><th>Title</th><th>Views</th><th>Total Time</th><th>Avg. Time / View</th></tr></thead>
    <tbody>
    <?php foreach ($topPosts as $i => $p): ?>
      <tr>
        <td><?php echo $i + 1; ?></td>
        <td><a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo h($p['slug']); ?>" target="_blank"><?php echo h($p['title']); ?></a></td>
        <td><?php echo (int)$p['views']; ?></td>
        <td><?php echo fmt_minutes($p['total_seconds']); ?></td>
        <td><?php echo fmt_minutes($p['avg_seconds']); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$topPosts): ?><tr><td colspan="5">No posts yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Top Pages -->
<div class="card">
  <h3>🏆 Top Pages (by views)</h3>
  <table>
    <thead><tr><th>#</th><th>Title</th><th>Views</th><th>Total Time</th><th>Avg. Time / View</th></tr></thead>
    <tbody>
    <?php foreach ($topPages as $i => $p): ?>
      <tr>
        <td><?php echo $i + 1; ?></td>
        <td><a href="<?php echo SITE_URL; ?>/page.php?slug=<?php echo h($p['slug']); ?>" target="_blank"><?php echo h($p['title']); ?></a></td>
        <td><?php echo (int)$p['views']; ?></td>
        <td><?php echo fmt_minutes($p['total_seconds']); ?></td>
        <td><?php echo fmt_minutes($p['avg_seconds']); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$topPages): ?><tr><td colspan="5">No pages yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
  <p style="color:var(--muted);font-size:12px;">"Avg. Time / View" only counts visits where we successfully measured
  time spent (some visitors leave before the browser can report it, so this is a good estimate, not exact).</p>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
