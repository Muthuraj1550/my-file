<?php
$adminTitle = 'Orders';
require_once __DIR__ . '/_layout_top.php';

/**
 * Unified Orders view — merges FOUR separate payment logs into one list:
 *   1. orders                 → Membership Plan purchases on THIS (Design) site
 *   2. tripo_coin_orders      → Tripo AI coin-pack purchases on THIS site
 *   3. product_orders         → Digital Product / course purchases on THIS site
 *   4. main_editor_plan_orders → Plan/coin purchases made HERE on behalf of the
 *                                 Main Editor site (guest checkout, cross-site push)
 * Each source is queried separately and wrapped in try/catch so a
 * not-yet-imported migration just means that source is skipped, never a
 * fatal error (self-healing — matches the rest of the admin panel).
 */

$rows = [];

// ---------- 1. Membership Plan orders (Design Site) ----------
try {
    $stmt = db()->query("SELECT o.created_at, o.amount, o.status, u.name, u.email, p.plan_name
                          FROM orders o
                          JOIN users u ON u.id = o.user_id
                          LEFT JOIN plans p ON p.id = o.plan_id
                          ORDER BY o.created_at DESC LIMIT 300");
    foreach ($stmt->fetchAll() as $r) {
        $rows[] = [
            'date'     => $r['created_at'],
            'site'     => 'Design Site',
            'type'     => 'Membership Plan',
            'customer' => $r['name'],
            'email'    => $r['email'],
            'item'     => $r['plan_name'] ?: '—',
            'amount'   => (float) $r['amount'],
            'status'   => $r['status'],
            'note'     => null,
        ];
    }
} catch (Throwable $e) { /* orders table always exists in db.sql, but stay safe */ }

// ---------- 2. Tripo AI coin-pack orders (Design Site) ----------
try {
    $stmt = db()->query("SELECT t.created_at, t.amount, t.status, t.coins, u.name, u.email, tp.pack_name
                          FROM tripo_coin_orders t
                          JOIN users u ON u.id = t.user_id
                          LEFT JOIN tripo_coin_packs tp ON tp.id = t.pack_id
                          ORDER BY t.created_at DESC LIMIT 300");
    foreach ($stmt->fetchAll() as $r) {
        $rows[] = [
            'date'     => $r['created_at'],
            'site'     => 'Design Site',
            'type'     => 'Coin Pack',
            'customer' => $r['name'],
            'email'    => $r['email'],
            'item'     => ($r['pack_name'] ?: 'Coin Pack') . ' (' . (int)$r['coins'] . ' coins)',
            'amount'   => (float) $r['amount'],
            'status'   => $r['status'],
            'note'     => null,
        ];
    }
} catch (Throwable $e) { /* migration-tripo-coins.sql not imported yet — skip */ }

// ---------- 3. Digital Product / course orders (Design Site) ----------
if (function_exists('shop_tables_ready') && shop_tables_ready()) {
    try {
        $stmt = db()->query("SELECT po.created_at, po.amount, po.status, u.name, u.email, pr.title
                              FROM product_orders po
                              JOIN users u ON u.id = po.user_id
                              LEFT JOIN products pr ON pr.id = po.product_id
                              ORDER BY po.created_at DESC LIMIT 300");
        foreach ($stmt->fetchAll() as $r) {
            $rows[] = [
                'date'     => $r['created_at'],
                'site'     => 'Design Site',
                'type'     => 'Digital Product',
                'customer' => $r['name'],
                'email'    => $r['email'],
                'item'     => $r['title'] ?: '—',
                'amount'   => (float) $r['amount'],
                'status'   => $r['status'],
                'note'     => null,
            ];
        }
    } catch (Throwable $e) { /* skip */ }
}

// ---------- 4. Main Editor plan/coin orders (guest checkout, cross-site push) ----------
try {
    $stmt = db()->query("SELECT created_at, amount, status, kind, email, plan_name, days, coins, activate_note
                          FROM main_editor_plan_orders
                          ORDER BY created_at DESC LIMIT 300");
    foreach ($stmt->fetchAll() as $r) {
        $isCoins = ($r['kind'] ?? 'plan') === 'coins';
        $item = $isCoins
            ? ((int)$r['coins'] . ' coins')
            : ($r['plan_name'] ?: '—') . ' (' . (int)$r['days'] . ' days)';
        // status here tracks BOTH payment and the cross-site push:
        // created -> paid -> activated (fully done), or 'paid' stuck = pushed but
        // Main Editor didn't confirm (activate_note has the reason).
        $rows[] = [
            'date'     => $r['created_at'],
            'site'     => 'Main Editor',
            'type'     => $isCoins ? 'Coin Pack' : 'Membership Plan',
            'customer' => $r['email'], // guest checkout — no local account/name
            'email'    => $r['email'],
            'item'     => $item,
            'amount'   => (float) $r['amount'],
            'status'   => $r['status'],
            'note'     => $r['activate_note'] ?: null,
        ];
    }
} catch (Throwable $e) { /* migration-main-editor-plan-orders.sql not imported yet — skip */ }

// ---------- Merge, filter, sort ----------
usort($rows, fn($a, $b) => strtotime($b['date']) <=> strtotime($a['date']));

$fSite   = $_GET['site'] ?? '';
$fType   = $_GET['type'] ?? '';
$fStatus = $_GET['status'] ?? '';
$search  = trim($_GET['q'] ?? '');

if ($fSite !== '')   $rows = array_values(array_filter($rows, fn($r) => $r['site'] === $fSite));
if ($fType !== '')   $rows = array_values(array_filter($rows, fn($r) => $r['type'] === $fType));
if ($fStatus !== '') $rows = array_values(array_filter($rows, fn($r) => $r['status'] === $fStatus));
if ($search !== '') {
    $needle = mb_strtolower($search);
    $rows = array_values(array_filter($rows, function ($r) use ($needle) {
        return str_contains(mb_strtolower($r['customer'] ?? ''), $needle)
            || str_contains(mb_strtolower($r['email'] ?? ''), $needle)
            || str_contains(mb_strtolower($r['item'] ?? ''), $needle);
    }));
}

$totalPaidAmount = array_sum(array_map(fn($r) => in_array($r['status'], ['paid', 'activated'], true) ? $r['amount'] : 0, $rows));
$grandTotal = count($rows);
$rows = array_slice($rows, 0, 200); // display cap — filters narrow this down for older records
?>
<div class="stat-row">
  <div class="stat-box"><div class="num"><?php echo $grandTotal; ?></div><div class="lbl">Orders (filtered)</div></div>
  <div class="stat-box"><div class="num">₹<?php echo number_format($totalPaidAmount, 0); ?></div><div class="lbl">Paid Revenue (filtered)</div></div>
</div>

<div class="card">
  <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;margin-bottom:4px;">
    <div>
      <label style="font-size:12px;color:var(--muted);">Search</label>
      <input type="text" name="q" placeholder="Name, email or item" value="<?php echo h($search); ?>" style="min-width:200px;">
    </div>
    <div>
      <label style="font-size:12px;color:var(--muted);">Site</label>
      <select name="site">
        <option value="">All Sites</option>
        <option value="Design Site" <?php echo $fSite==='Design Site'?'selected':''; ?>>Design Site</option>
        <option value="Main Editor" <?php echo $fSite==='Main Editor'?'selected':''; ?>>Main Editor</option>
      </select>
    </div>
    <div>
      <label style="font-size:12px;color:var(--muted);">Type</label>
      <select name="type">
        <option value="">All Types</option>
        <option value="Membership Plan" <?php echo $fType==='Membership Plan'?'selected':''; ?>>Membership Plan</option>
        <option value="Coin Pack" <?php echo $fType==='Coin Pack'?'selected':''; ?>>Coin Pack</option>
        <option value="Digital Product" <?php echo $fType==='Digital Product'?'selected':''; ?>>Digital Product</option>
      </select>
    </div>
    <div>
      <label style="font-size:12px;color:var(--muted);">Status</label>
      <select name="status">
        <option value="">All Statuses</option>
        <option value="paid" <?php echo $fStatus==='paid'?'selected':''; ?>>Paid</option>
        <option value="activated" <?php echo $fStatus==='activated'?'selected':''; ?>>Activated</option>
        <option value="created" <?php echo $fStatus==='created'?'selected':''; ?>>Created (unpaid)</option>
        <option value="failed" <?php echo $fStatus==='failed'?'selected':''; ?>>Failed</option>
      </select>
    </div>
    <button type="submit" class="btn btn-sm">Filter</button>
    <?php if ($fSite || $fType || $fStatus || $search): ?><a href="orders.php" class="btn btn-sm btn-outline">Clear</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <h3>Orders <span style="color:var(--muted);font-weight:400;font-size:13px;">(latest 200 shown — narrow with filters for older records)</span></h3>
  <table>
    <thead><tr><th>Date</th><th>Customer</th><th>Item</th><th>Site</th><th>Type</th><th>Amount</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $o): ?>
      <tr>
        <td><?php echo date('d M Y H:i', strtotime($o['date'])); ?></td>
        <td><?php echo h($o['customer']); ?><br><small style="color:var(--muted)"><?php echo h($o['email']); ?></small></td>
        <td><?php echo h($o['item']); ?></td>
        <td><span class="badge <?php echo $o['site']==='Main Editor'?'badge-active':''; ?>"><?php echo h($o['site']); ?></span></td>
        <td><?php echo h($o['type']); ?></td>
        <td>₹<?php echo number_format($o['amount'], 2); ?></td>
        <td>
          <span class="badge <?php echo in_array($o['status'],['paid','activated'],true)?'badge-active':'badge-expired'; ?>"><?php echo h($o['status']); ?></span>
          <?php if ($o['note']): ?>
            <br><small style="color:#f59e0b;" title="Why the cross-site activation push didn't complete"><?php echo h($o['note']); ?></small>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="7">No orders match these filters.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
