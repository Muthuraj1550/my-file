<?php
$adminTitle = 'Share Links';
require_once __DIR__ . '/_layout_top.php';

if (!share_links_ready()) {
    echo '<div class="card" style="border:1px solid #f59e0b;background:#fffbeb;"><b>⚠ Migration Pending:</b> run <code>migration-share-links.sql</code> in phpMyAdmin to enable this page.</div>';
    require_once __DIR__ . '/_layout_bottom.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_link'])) {
    csrf_check();
    $type = $_POST['content_type'] === 'page' ? 'page' : 'post';
    $id = (int)$_POST['content_id'];
    $expires = trim($_POST['expires_at'] ?? '');
    if (!$id) {
        flash('Pick a post or page first.', 'error');
    } else {
        create_share_link($type, $id, $expires !== '' ? $expires : null);
        flash('Share link created.');
    }
    redirect('/admin/share-links.php');
}

if (isset($_GET['del'])) {
    delete_share_link((int)$_GET['del']);
    flash('Share link deleted.');
    redirect('/admin/share-links.php');
}

// Pre-fill the create form when arriving from a "🔗 Share" button on Posts/Pages.
$prefType = ($_GET['type'] ?? '') === 'page' ? 'page' : 'post';
$prefId = (int)($_GET['id'] ?? 0);

$posts = db()->query("SELECT id, title, status FROM posts ORDER BY title ASC")->fetchAll();
$pages = db()->query("SELECT id, title, status FROM pages ORDER BY title ASC")->fetchAll();
$links = list_share_links();
?>
<div class="card" style="max-width:560px;margin-bottom:16px;">
  <h3 style="margin-top:0;">➕ Generate a New Share Link</h3>
  <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Works for any Post or Page, including drafts and paid course lessons — anyone with the link can open it without logging in or buying, until you delete it or its expiry date passes.</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label style="font-size:13px;">Type</label>
    <select name="content_type" id="slContentType" onchange="slToggleList()">
      <option value="post" <?php echo $prefType==='post'?'selected':''; ?>>Post</option>
      <option value="page" <?php echo $prefType==='page'?'selected':''; ?>>Page</option>
    </select>

    <label style="font-size:13px;">Which one?</label>
    <select name="content_id" id="slPostList" style="<?php echo $prefType==='page'?'display:none;':''; ?>">
      <option value="">— select a post —</option>
      <?php foreach ($posts as $p): ?>
        <option value="<?php echo (int)$p['id']; ?>" <?php echo ($prefType==='post' && $prefId===(int)$p['id'])?'selected':''; ?>><?php echo h($p['title']); ?><?php echo $p['status']!=='published' ? ' (draft)' : ''; ?></option>
      <?php endforeach; ?>
    </select>
    <select name="content_id" id="slPageList" style="<?php echo $prefType==='page'?'':'display:none;'; ?>" <?php echo $prefType==='page'?'':'disabled'; ?>>
      <option value="">— select a page —</option>
      <?php foreach ($pages as $p): ?>
        <option value="<?php echo (int)$p['id']; ?>" <?php echo ($prefType==='page' && $prefId===(int)$p['id'])?'selected':''; ?>><?php echo h($p['title']); ?><?php echo $p['status']!=='published' ? ' (draft)' : ''; ?></option>
      <?php endforeach; ?>
    </select>

    <label style="font-size:13px;">Expiry date (optional — leave blank for a link that never expires)</label>
    <input type="date" name="expires_at">

    <button type="submit" name="create_link" class="btn" style="margin-top:10px;">Generate Link</button>
  </form>
</div>

<script>
function slToggleList(){
  var type = document.getElementById('slContentType').value;
  var postSel = document.getElementById('slPostList');
  var pageSel = document.getElementById('slPageList');
  if (type === 'page') {
    postSel.style.display = 'none'; postSel.disabled = true; postSel.name = '';
    pageSel.style.display = ''; pageSel.disabled = false; pageSel.name = 'content_id';
  } else {
    pageSel.style.display = 'none'; pageSel.disabled = true; pageSel.name = '';
    postSel.style.display = ''; postSel.disabled = false; postSel.name = 'content_id';
  }
}
slToggleList();
</script>

<div class="card">
  <h3>All Share Links</h3>
  <table>
    <thead><tr><th>Content</th><th>Type</th><th>Link</th><th>Expiry</th><th>Created</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($links as $l): ?>
      <?php $shareUrl = SITE_URL . '/share.php?token=' . $l['token']; ?>
      <tr>
        <td><?php echo h($l['content_title']); ?><?php if ($l['content_status'] && $l['content_status'] !== 'published'): ?> <span class="badge badge-expired">draft</span><?php endif; ?></td>
        <td><?php echo $l['content_type'] === 'post' ? '📝 Post' : '📄 Page'; ?></td>
        <td>
          <input type="text" readonly value="<?php echo h($shareUrl); ?>" onclick="this.select();" style="width:220px;font-size:12px;margin:0;">
          <button type="button" class="btn btn-sm btn-outline" onclick="navigator.clipboard.writeText('<?php echo h($shareUrl); ?>');this.textContent='Copied!';">Copy</button>
        </td>
        <td>
          <?php if ($l['is_expired']): ?>
            <span class="badge badge-expired">Expired</span>
          <?php elseif ($l['expires_at']): ?>
            <?php echo date('d M Y', strtotime($l['expires_at'])); ?>
          <?php else: ?>
            <span style="color:var(--muted);">Never</span>
          <?php endif; ?>
        </td>
        <td><?php echo date('d M Y', strtotime($l['created_at'])); ?></td>
        <td><a href="?del=<?php echo (int)$l['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this share link? The URL will stop working immediately.');">Delete</a></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$links): ?><tr><td colspan="6">No share links generated yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
