<?php
/** Admin -> Courses: save the drag/arrow re-order of a course's curriculum
 *  (posts, pages, products linked via course_id) back to the DB. */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['csrf']) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Security check failed.']);
    exit;
}

$courseId = (int) ($_POST['course_id'] ?? 0);
$itemsRaw = $_POST['items'] ?? '';
$items = json_decode($itemsRaw, true);

if (!$courseId || !is_array($items) || !$items) {
    echo json_encode(['ok' => false, 'error' => 'Nothing to reorder.']);
    exit;
}

// Only ever touch rows that actually belong to this course - never trust the
// posted type/id blindly.
$order = 1;
foreach ($items as $item) {
    $type = $item['type'] ?? '';
    $id = (int) ($item['id'] ?? 0);
    if (!$id) continue;

    if ($type === 'post' && function_exists('post_course_link_ready') && post_course_link_ready()) {
        if (function_exists('post_multi_course_ready') && post_multi_course_ready()) {
            $stmt = db()->prepare("UPDATE post_courses SET sort_order = ? WHERE post_id = ? AND course_id = ?");
            $stmt->execute([$order, $id, $courseId]);
        } else {
            $stmt = db()->prepare("UPDATE posts SET course_sort_order = ? WHERE id = ? AND course_id = ?");
            $stmt->execute([$order, $id, $courseId]);
        }
    } elseif ($type === 'page' && function_exists('page_course_link_ready') && page_course_link_ready()) {
        if (function_exists('page_multi_course_ready') && page_multi_course_ready()) {
            $stmt = db()->prepare("UPDATE page_courses SET sort_order = ? WHERE page_id = ? AND course_id = ?");
            $stmt->execute([$order, $id, $courseId]);
        } else {
            $stmt = db()->prepare("UPDATE pages SET course_sort_order = ? WHERE id = ? AND course_id = ?");
            $stmt->execute([$order, $id, $courseId]);
        }
    } elseif ($type === 'product') {
        if (function_exists('product_multi_course_ready') && product_multi_course_ready()) {
            $stmt = db()->prepare("UPDATE product_courses SET sort_order = ? WHERE product_id = ? AND course_id = ?");
            $stmt->execute([$order, $id, $courseId]);
        } else {
            $stmt = db()->prepare("UPDATE products SET sort_order = ? WHERE id = ? AND course_id = ?");
            $stmt->execute([$order, $id, $courseId]);
        }
    } else {
        continue;
    }
    $order++;
}

echo json_encode(['ok' => true]);
