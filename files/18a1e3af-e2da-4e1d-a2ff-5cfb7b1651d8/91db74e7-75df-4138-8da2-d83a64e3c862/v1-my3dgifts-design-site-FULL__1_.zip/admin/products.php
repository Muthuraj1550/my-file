<?php
/**
 * Shared admin screen for both Shop products and Courses.
 * admin/courses.php sets $adminMode = 'course' and includes this file,
 * so Courses and Products are two separate menu pages (no more mix-up).
 */
$adminMode = ($adminMode ?? 'product') === 'course' ? 'course' : 'product';
$isCourseMode = $adminMode === 'course';
$selfPage  = $isCourseMode ? 'courses.php' : 'products.php';
$adminTitle = $isCourseMode ? 'Courses' : 'Products (Shop)';
require_once __DIR__ . '/_layout_top.php';

if (!shop_tables_ready()) {
?>
  <div class="flash flash-error">
    The Shop isn't set up yet. Go to phpMyAdmin and import <code>migration-products-shop.sql</code>
    (safe on a live site - it only adds new tables, it won't touch your existing data). Then reload this page.
  </div>
<?php
  require_once __DIR__ . '/_layout_bottom.php';
  exit;
}

function admin_upload_image($field, $subdir = '') {
    if (empty($_FILES[$field]['name'])) return null;
    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return null;
    $newName = 'prod_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

/** Optional convenience: admin can also upload the actual deliverable file (STL/zip/etc) and we auto-fill delivery_link with its URL. */
function admin_upload_delivery_file() {
    if (empty($_FILES['delivery_file']['name'])) return null;
    $blocked = media_blocked_extensions();
    $ext = strtolower(pathinfo($_FILES['delivery_file']['name'], PATHINFO_EXTENSION));
    if ($ext === '' || in_array($ext, $blocked, true)) return null;
    $newName = 'file_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES['delivery_file']['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_product'])) {
    csrf_check();
    $title = trim($_POST['title']);
    $img = admin_upload_image('thumbnail_file');
    $deliveryFileUrl = admin_upload_delivery_file();
    $deliveryLink = $deliveryFileUrl ?: trim($_POST['delivery_link']);

    $price = (float) $_POST['price'];
    $salePriceRaw = trim($_POST['sale_price']);
    $salePrice = ($salePriceRaw === '') ? null : (float) $salePriceRaw;

    $type = $isCourseMode ? 'course'
          : (in_array($_POST['type'], ['file','software','bundle']) ? $_POST['type'] : 'file');

    $data = [
        'title'          => $title,
        'slug'           => unique_slug('products', slugify($title), $_POST['edit_id'] ?: null),
        'type'           => $type,
        'category'       => trim($_POST['category']),
        'short_desc'     => trim($_POST['short_desc']),
        'description'    => trim($_POST['description']),
        'price'          => $price,
        'sale_price'     => $salePrice,
        'delivery_link'  => $deliveryLink,
        'delivery_note'  => trim($_POST['delivery_note']),
        'featured'       => isset($_POST['featured']) ? 1 : 0,
        'status'         => $_POST['status'] === 'published' ? 'published' : 'draft',
        'sort_order'     => (int) $_POST['sort_order'],
    ];

    if (course_level_ready() && ($isCourseMode || course_license_ready())) {
        $level = trim($_POST['level'] ?? '');
        $data['level'] = in_array($level, ['beginner','intermediate','advanced'], true) ? $level : null;
    }

    $courseIds = [];
    if (course_license_ready()) {
        $courseIds = array_values(array_filter(array_map('intval', (array)($_POST['course_ids'] ?? []))));
        // Legacy single column - kept in sync with the first ticked course so
        // any older code path that still reads course_id directly still works.
        $data['course_id'] = $courseIds[0] ?? null;

        $selectedSites = array_map('trim', (array)($_POST['license_sites'] ?? []));
        $validKeys     = array_column(tool_sites_all(), 'site_key');
        $selectedSites = array_values(array_intersect($selectedSites, $validKeys));
        $data['license_site'] = implode(',', $selectedSites);
    }

    $cols = array_keys($data);
    $setSql = implode(', ', array_map(fn($c) => "$c=?", $cols));

    if (!empty($_POST['edit_id'])) {
        $productId = (int) $_POST['edit_id'];
        if ($img) {
            db()->prepare("UPDATE products SET $setSql, thumbnail=? WHERE id=?")
                ->execute([...array_values($data), $img, $productId]);
        } else {
            db()->prepare("UPDATE products SET $setSql WHERE id=?")
                ->execute([...array_values($data), $productId]);
        }
    } else {
        $insertCols = implode(', ', $cols) . ', thumbnail';
        $placeholders = implode(',', array_fill(0, count($cols) + 1, '?'));
        db()->prepare("INSERT INTO products ($insertCols) VALUES ($placeholders)")
            ->execute([...array_values($data), $img]);
        $productId = (int) db()->lastInsertId();
    }

    if (!$isCourseMode && course_license_ready() && function_exists('product_multi_course_ready') && product_multi_course_ready()) {
        set_product_courses($productId, $courseIds);
    }

    flash($isCourseMode ? 'Course saved.' : 'Product saved.');
    redirect('/admin/' . $selfPage);
}

if (isset($_GET['del'])) {
    db()->prepare("DELETE FROM products WHERE id=?")->execute([(int)$_GET['del']]);
    flash($isCourseMode ? 'Course deleted.' : 'Product deleted.');
    redirect('/admin/' . $selfPage);
}

$editProduct = null;
if (!empty($_GET['edit'])) {
    $editProduct = get_product((int)$_GET['edit']);
}
$products = $isCourseMode
    ? db()->query("SELECT * FROM products WHERE type='course' ORDER BY created_at DESC")->fetchAll()
    : db()->query("SELECT * FROM products WHERE type<>'course' ORDER BY created_at DESC")->fetchAll();
$recentOrders = db()->query("SELECT po.*, u.name AS user_name, u.email AS user_email, p.title AS product_title
                              FROM product_orders po
                              LEFT JOIN users u ON u.id = po.user_id
                              LEFT JOIN products p ON p.id = po.product_id
                              ORDER BY po.created_at DESC LIMIT 30")->fetchAll();
?>
<div class="card" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
  <?php if ($isCourseMode): ?>
    <a href="courses.php?new=1" class="btn">🎓 Add New Course</a>
    <a href="products.php" class="btn btn-outline">🛍 Go to Products (Shop) ↗</a>
  <?php else: ?>
    <a href="products.php?new=1" class="btn">➕ Add New File / Product</a>
    <a href="courses.php" class="btn btn-outline">🎓 Go to Courses ↗</a>
  <?php endif; ?>
</div>

<div class="card">
  <h3><?php echo ($editProduct ? 'Edit ' : 'Add New ') . ($isCourseMode ? 'Course' : 'Product'); ?></h3>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editProduct ? (int)$editProduct['id'] : ''; ?>">

    <label>Title</label>
    <input type="text" name="title" value="<?php echo h($editProduct['title'] ?? ''); ?>" required>

    <?php if ($isCourseMode): ?>
      <input type="hidden" name="type" value="course">
      <p style="color:var(--muted);font-size:12px;">This page only manages <b>Courses</b>. Files, software &amp; bundles live on the <a href="products.php">Products (Shop)</a> page.</p>

      <?php if (course_level_ready()):
        $curLevel = $editProduct['level'] ?? '';
        $levelOptions = [
          'beginner'     => '🔰 Beginner - zero 3D design knowledge',
          'intermediate' => '🎯 Intermediate - knows the software basics',
          'advanced'     => '🚀 Advanced - software features only, fast-paced',
        ];
      ?>
      <label>Course Level (used for the Beginner / Intermediate / Advanced filter on the Shop page)</label>
      <select name="level" id="courseLevelSelect" onchange="document.getElementById('courseLevelHint').textContent = ({beginner:'<?php echo h(course_level_hint('beginner')); ?>', intermediate:'<?php echo h(course_level_hint('intermediate')); ?>', advanced:'<?php echo h(course_level_hint('advanced')); ?>'})[this.value] || '';">
        <option value="">— Not set (won't show under any level filter) —</option>
        <?php foreach ($levelOptions as $val => $lbl): ?>
          <option value="<?php echo $val; ?>" <?php echo ($curLevel === $val) ? 'selected' : ''; ?>><?php echo $lbl; ?></option>
        <?php endforeach; ?>
      </select>
      <p id="courseLevelHint" style="color:var(--muted);font-size:12px;margin-top:-10px;"><?php echo h(course_level_hint($curLevel)); ?></p>
      <?php else: ?>
      <div class="flash flash-error" style="margin-top:8px;">Course Level filter isn't set up yet — import <code>migration-course-level.sql</code> in phpMyAdmin, then reload this page.</div>
      <?php endif; ?>

    <?php else: ?>
      <label>Type</label>
      <select name="type">
        <?php $defaultType = $editProduct['type'] ?? 'file'; ?>
        <?php foreach (['file'=>'Digital File / STL','software'=>'Software / Tool','bundle'=>'Bundle Pack'] as $val=>$lbl): ?>
          <option value="<?php echo $val; ?>" <?php echo ($defaultType===$val)?'selected':''; ?>><?php echo $lbl; ?></option>
        <?php endforeach; ?>
      </select>
      <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Courses are managed separately on the <a href="courses.php">Courses</a> page. Attach this item to a course below.</p>
    <?php endif; ?>

    <label>Category (used for shop filter tabs, e.g. "3D Design", "Miniature")</label>
    <input type="text" name="category" value="<?php echo h($editProduct['category'] ?? ''); ?>">

    <label>Short Description (shown on shop grid card)</label>
    <input type="text" name="short_desc" value="<?php echo h($editProduct['short_desc'] ?? ''); ?>" maxlength="300">

    <label>Full Description</label>
    <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Build the description from blocks. Use "Heading" blocks for sub-topics - each has a 👁 eye icon to include it in (or 🙈 hide it from) the "Topics Covered" list shown near the top of this product/course page.</p>
    <textarea id="productContentArea" name="description" style="min-height:140px;font-family:monospace;"><?php echo h($editProduct['description'] ?? ''); ?></textarea>
    <?php require __DIR__ . '/_content_builder.php'; ?>
    <script>document.addEventListener('DOMContentLoaded', function(){
      M3DGContentBuilder.attach('productContentArea', []);
    });</script>

    <label>Thumbnail Image</label>
    <input type="file" name="thumbnail_file" accept="image/*">
    <?php if (!empty($editProduct['thumbnail'])): ?>
      <img src="<?php echo h($editProduct['thumbnail']); ?>" style="max-width:160px;border-radius:8px;margin-bottom:16px;display:block;">
    <?php endif; ?>

    <div style="display:flex;gap:16px;flex-wrap:wrap;">
      <div style="flex:1;min-width:160px;">
        <label>Price (₹)</label>
        <input type="number" step="0.01" min="0" name="price" value="<?php echo h($editProduct['price'] ?? '0'); ?>" required>
      </div>
      <div style="flex:1;min-width:160px;">
        <label>Sale Price (₹) - optional, leave blank for no discount</label>
        <input type="number" step="0.01" min="0" name="sale_price" value="<?php echo h($editProduct['sale_price'] ?? ''); ?>">
      </div>
    </div>

    <?php if (course_license_ready()): ?>
    <?php if (!$isCourseMode): ?>
    <?php
      $availableCourses = all_course_products($editProduct['id'] ?? null);
      $multiCourseReady = function_exists('product_multi_course_ready') && product_multi_course_ready();
      $linkedCourseIds = $multiCourseReady && !empty($editProduct['id'])
          ? product_course_ids($editProduct['id'])
          : (!empty($editProduct['course_id']) ? [(int)$editProduct['course_id']] : []);
    ?>
    <label>Include this in a Course (optional)</label>
    <?php if (!$multiCourseReady): ?>
      <div class="flash flash-error" style="margin-top:8px;margin-bottom:8px;">Multi-course selection isn't set up yet — import <code>migration-product-multi-course.sql</code> in phpMyAdmin, then reload this page. Until then, a product can only belong to one course.</div>
      <select name="course_ids[]">
        <option value="">— Not part of a course —</option>
        <?php foreach ($availableCourses as $c): ?>
          <option value="<?php echo (int)$c['id']; ?>" <?php echo in_array((int)$c['id'], $linkedCourseIds, true) ? 'selected' : ''; ?>><?php echo h($c['title']); ?></option>
        <?php endforeach; ?>
      </select>
    <?php elseif (!$availableCourses): ?>
      <p style="color:var(--muted);font-size:12px;">No courses yet — create one on the <a href="courses.php">Courses</a> page first.</p>
    <?php else: ?>
      <div style="display:flex;gap:14px;flex-wrap:wrap;padding:8px 0;">
        <?php foreach ($availableCourses as $c): ?>
          <label style="width:auto;display:inline-flex;align-items:center;gap:6px;font-weight:400;">
            <input type="checkbox" name="course_ids[]" value="<?php echo (int)$c['id']; ?>" style="width:auto;"
              <?php echo in_array((int)$c['id'], $linkedCourseIds, true) ? 'checked' : ''; ?>>
            <?php echo h($c['title']); ?>
          </label>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Tick every course this file should auto-list under (shows as an included item on each course's public page). Leave all unticked for a normal standalone product.</p>

    <?php $curItemLevel = $editProduct['level'] ?? ''; ?>
    <label style="margin-top:12px;">Level (who this lesson is for, inside that course)</label>
    <select name="level">
      <option value="">— All levels (no filter) —</option>
      <option value="beginner" <?php echo $curItemLevel==='beginner'?'selected':''; ?>>🔰 Beginner</option>
      <option value="intermediate" <?php echo $curItemLevel==='intermediate'?'selected':''; ?>>🎯 Intermediate</option>
      <option value="advanced" <?php echo $curItemLevel==='advanced'?'selected':''; ?>>🚀 Advanced</option>
    </select>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">On that course's public page, a visitor can pick their level and this lesson will only show for that level (leave "All levels" if it's needed by everyone).</p>
    <?php endif; ?>

    <label>Site Password / License (auto-generate per buyer)</label>
    <?php if (!tool_sites_ready()): ?>
      <div class="flash flash-error" style="margin-top:8px;">No tool sites registered yet — go to <a href="tool-sites.php">Tool Sites &amp; Access</a> and import <code>migration-tool-sites.sql</code> / add a site first, then reload this page.</div>
    <?php else:
      $selectedSites = license_sites_expand($editProduct['license_site'] ?? '');
    ?>
      <div style="display:flex;gap:14px;flex-wrap:wrap;padding:8px 0;">
        <?php foreach (tool_sites_all() as $ts): ?>
          <label style="width:auto;display:inline-flex;align-items:center;gap:6px;font-weight:400;">
            <input type="checkbox" name="license_sites[]" value="<?php echo h($ts['site_key']); ?>" style="width:auto;"
              <?php echo in_array($ts['site_key'], $selectedSites, true) ? 'checked' : ''; ?>
              <?php echo $ts['status'] !== 'active' ? 'disabled' : ''; ?>>
            <?php echo h($ts['name']); ?> <span style="color:var(--muted);font-size:11px;">(<?php echo h($ts['site_key']); ?><?php echo $ts['status'] !== 'active' ? ', disabled' : ''; ?>)</span>
          </label>
        <?php endforeach; ?>
      </div>
      <p style="color:var(--muted);font-size:12px;margin-top:-4px;">This list comes straight from <a href="tool-sites.php">Tool Sites &amp; Access</a> — add a site there and it shows up here automatically. Check every site this course should unlock; leave all unchecked for a normal product with no login.</p>
    <?php endif; ?>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">If any site is checked, a unique username+password is auto-generated for each buyer the moment they get access (payment or free grant), valid <b>only on the site(s) checked above</b>, and shown to them on My Purchases. Each site's own <code>api/verify-license.php</code> call (using that site's API key) checks the password itself.</p>
    <?php else: ?>
    <div class="flash flash-error" style="margin-top:8px;">Course grouping + Site Password isn't set up yet — import <code>migration-course-license.sql</code> in phpMyAdmin, then reload this page.</div>
    <?php endif; ?>

    <h3 style="margin-top:24px;">Delivery (what the buyer gets after payment)</h3>
    <label>Delivery Link (MediaFire / Google Drive / any URL)</label>
    <input type="text" name="delivery_link" value="<?php echo h($editProduct['delivery_link'] ?? ''); ?>" placeholder="https://www.mediafire.com/file/...">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">— OR —</p>
    <label>Upload the file directly (overrides the link above if a file is chosen)</label>
    <input type="file" name="delivery_file">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Best for smaller files (STL/zip/PDF). For large video courses, use a MediaFire/Drive link above instead.</p>
    <label>Delivery Note (optional, e.g. "ZIP password: 1234")</label>
    <input type="text" name="delivery_note" value="<?php echo h($editProduct['delivery_note'] ?? ''); ?>">

    <div style="display:flex;gap:16px;flex-wrap:wrap;margin-top:16px;">
      <div style="flex:1;min-width:160px;">
        <label>Sort Order</label>
        <input type="number" name="sort_order" value="<?php echo h($editProduct['sort_order'] ?? '0'); ?>">
      </div>
      <div style="flex:1;min-width:160px;">
        <label>Status</label>
        <select name="status">
          <option value="published" <?php echo (($editProduct['status'] ?? 'published')==='published')?'selected':''; ?>>Published</option>
          <option value="draft" <?php echo (($editProduct['status'] ?? '')==='draft')?'selected':''; ?>>Draft</option>
        </select>
      </div>
    </div>
    <label style="margin-top:12px;"><input type="checkbox" name="featured" style="width:auto;display:inline-block;" <?php echo !empty($editProduct['featured']) ? 'checked' : ''; ?>> ⭐ Featured (shows first on Shop page)</label>

    <button type="submit" name="save_product" class="btn" style="margin-top:16px;">Save <?php echo $isCourseMode ? 'Course' : 'Product'; ?></button>
    <?php if ($editProduct): ?><a href="<?php echo h($selfPage); ?>" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<?php if ($editProduct && ($editProduct['type'] ?? '') === 'course' && course_license_ready()):
  $includedItems = course_included_items($editProduct['id']);
  $editPageFor = ['post' => 'posts.php', 'page' => 'pages.php', 'product' => 'products.php'];
?>
<div class="card">
  <h3>📦 Course Content (<?php echo count($includedItems); ?>)</h3>
  <p style="color:var(--muted);font-size:13px;">This list is automatic — it shows every Post, Page, or Product where you ticked <b><?php echo h($editProduct['title']); ?></b> under "Include this in a Course" (a Product can be ticked into more than one course). It's the curriculum shown on this course's public page (as locked topics before purchase, and as clickable links to buyers after purchase). To add more, edit that post/page/product and tick this course there.</p>
  <?php if (!post_course_link_ready() || !page_course_link_ready()): ?>
    <div class="flash flash-error" style="margin-bottom:10px;">Posts/Pages can't be linked to a course yet — import <code>migration-course-content-links.sql</code> in phpMyAdmin, then reload this page. (Products can already be linked.)</div>
  <?php endif; ?>
  <?php if ($includedItems): ?>
    <p style="color:var(--muted);font-size:12px;">Drag the ⠿ handle (or use the ↑ / ↓ buttons) to change the order lessons appear in on the public course page. Saves automatically.</p>
    <table id="courseReorderTable" data-course-id="<?php echo (int)$editProduct['id']; ?>">
      <thead><tr><th style="width:28px;"></th><th>Title</th><th>Type</th><th>Status</th><th>On course page</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($includedItems as $it): ?>
        <tr draggable="true" data-type="<?php echo h($it['type']); ?>" data-id="<?php echo (int)$it['id']; ?>">
          <td class="course-reorder-handle" title="Drag to reorder" style="cursor:grab;color:var(--muted,#94a3b8);text-align:center;">⠿</td>
          <td><?php echo h($it['title']); ?></td>
          <td><?php echo h(ucfirst($it['type'])); ?></td>
          <td><span class="badge <?php echo $it['status']==='published'?'badge-active':'badge-expired'; ?>"><?php echo h($it['status']); ?></span></td>
          <td><?php echo !empty($it['show_in_course']) ? '👁 Shown' : '<span style="color:var(--muted,#94a3b8);">🙈 Hidden</span>'; ?></td>
          <td style="white-space:nowrap;">
            <button type="button" class="btn btn-sm btn-outline course-reorder-btn" data-dir="up" title="Move up">↑</button>
            <button type="button" class="btn btn-sm btn-outline course-reorder-btn" data-dir="down" title="Move down">↓</button>
            <a href="<?php echo h($editPageFor[$it['type']] ?? 'products.php'); ?>?edit=<?php echo (int)$it['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <span id="courseReorderStatus" style="color:var(--muted,#94a3b8);font-size:12px;"></span>
    <script>
    (function(){
      var table = document.getElementById('courseReorderTable');
      if (!table) return;
      var tbody = table.querySelector('tbody');
      var status = document.getElementById('courseReorderStatus');
      var courseId = table.getAttribute('data-course-id');
      var csrf = document.querySelector('input[name=csrf]') ? document.querySelector('input[name=csrf]').value : '';

      function saveOrder(){
        var items = Array.prototype.map.call(tbody.querySelectorAll('tr'), function(row){
          return { type: row.getAttribute('data-type'), id: row.getAttribute('data-id') };
        });
        status.textContent = 'Saving order…';
        var fd = new FormData();
        fd.append('csrf', csrf);
        fd.append('course_id', courseId);
        fd.append('items', JSON.stringify(items));
        fetch('ajax-course-reorder.php', { method: 'POST', body: fd })
          .then(function(r){ return r.json(); })
          .then(function(res){ status.textContent = res.ok ? 'Order saved ✓' : (res.error || 'Could not save order.'); })
          .catch(function(){ status.textContent = 'Could not save order.'; });
      }

      tbody.querySelectorAll('.course-reorder-btn').forEach(function(btn){
        btn.addEventListener('click', function(){
          var row = btn.closest('tr');
          var dir = btn.getAttribute('data-dir');
          if (dir === 'up' && row.previousElementSibling) {
            tbody.insertBefore(row, row.previousElementSibling);
          } else if (dir === 'down' && row.nextElementSibling) {
            tbody.insertBefore(row.nextElementSibling, row);
          } else {
            return;
          }
          saveOrder();
        });
      });

      var dragRow = null;
      tbody.querySelectorAll('tr').forEach(function(row){
        row.addEventListener('dragstart', function(){ dragRow = row; row.style.opacity = '0.4'; });
        row.addEventListener('dragend', function(){ row.style.opacity = '1'; dragRow = null; saveOrder(); });
        row.addEventListener('dragover', function(e){
          e.preventDefault();
          if (!dragRow || dragRow === row) return;
          var rect = row.getBoundingClientRect();
          var before = (e.clientY - rect.top) < (rect.height / 2);
          tbody.insertBefore(dragRow, before ? row : row.nextElementSibling);
        });
      });
    })();
    </script>
  <?php else: ?>
    <p>Nothing included yet — nothing has been pointed at this course.</p>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="card">
  <h3><?php echo $isCourseMode ? '📚 All Courses' : '🛍 All Products'; ?> (<?php echo count($products); ?>)</h3>
  <table>
    <thead><tr><th>Title</th><th>Type</th><th>Price</th><th>Sold</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($products as $p): ?>
      <tr>
        <td>
          <?php echo $p['featured'] ? '⭐ ' : ''; ?><?php echo h($p['title']); ?>
          <?php if ($isCourseMode && course_level_ready() && !empty($p['level'])): ?>
            <br><small style="color:var(--muted)"><?php echo h(course_level_label($p['level'])); ?></small>
          <?php endif; ?>
          <?php if (course_license_ready()): $prodCourses = product_courses_list($p['id']); ?>
          <?php if ($prodCourses): ?>
            <br><small style="color:var(--muted)">📦 in course<?php echo count($prodCourses) > 1 ? 's' : ''; ?>: <?php echo h(implode(', ', array_column($prodCourses, 'title'))); ?><?php if (!$isCourseMode && course_level_ready() && !empty($p['level'])): ?> · <?php echo h(course_level_label($p['level'])); ?><?php endif; ?></small>
          <?php endif; ?>
          <?php endif; ?>
          <?php if (course_license_ready() && !empty($p['license_site']) && $p['license_site'] !== 'none'): ?>
            <br><small style="color:var(--muted)">🔑 <?php echo h(license_site_label($p['license_site'])); ?> password auto-generated on purchase</small>
          <?php endif; ?>
        </td>
        <td><?php echo h(ucfirst($p['type'])); ?></td>
        <td>
          <?php if (!empty($p['sale_price']) && (float)$p['sale_price'] < (float)$p['price']): ?>
            <s>₹<?php echo number_format($p['price'],0); ?></s> ₹<?php echo number_format($p['sale_price'],0); ?>
          <?php else: ?>
            ₹<?php echo number_format($p['price'],0); ?>
          <?php endif; ?>
        </td>
        <td><?php echo product_sales_count($p['id']); ?></td>
        <td><span class="badge <?php echo $p['status']==='published'?'badge-active':'badge-expired'; ?>"><?php echo h($p['status']); ?></span></td>
        <td>
          <a href="<?php echo SITE_URL; ?>/product.php?slug=<?php echo h($p['slug']); ?>" target="_blank" class="btn btn-sm btn-outline">View</a>
          <a href="?edit=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <a href="?del=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product? Buyers keep their existing access, but the product page will disappear.');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$products): ?><tr><td colspan="6">No products yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<div class="card">
  <h3>Recent Orders</h3>
  <table>
    <thead><tr><th>Date</th><th>Buyer</th><th>Product</th><th>Amount</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($recentOrders as $o): ?>
      <tr>
        <td><?php echo date('d M Y H:i', strtotime($o['created_at'])); ?></td>
        <td><?php echo h($o['user_name'] ?? '—'); ?><br><span style="color:var(--muted);font-size:12px;"><?php echo h($o['user_email'] ?? ''); ?></span></td>
        <td><?php echo h($o['product_title'] ?? '—'); ?></td>
        <td>₹<?php echo number_format($o['amount'],0); ?></td>
        <td><span class="badge <?php echo $o['status']==='paid'?'badge-active':'badge-expired'; ?>"><?php echo h($o['status']); ?></span></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$recentOrders): ?><tr><td colspan="5">No orders yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
