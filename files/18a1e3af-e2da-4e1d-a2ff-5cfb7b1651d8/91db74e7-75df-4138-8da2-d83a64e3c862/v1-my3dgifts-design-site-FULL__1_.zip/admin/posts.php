<?php
$adminTitle = 'Posts';
require_once __DIR__ . '/_layout_top.php';

function handle_image_upload($field) {
    if (empty($_FILES[$field]['name'])) return null;
    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return null;
    $newName = 'img_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

$pinReady = posts_pin_column_ready();
$courseLinkReady = function_exists('course_license_ready') && course_license_ready() && function_exists('post_course_link_ready') && post_course_link_ready();
$levelReady = function_exists('post_level_ready') && post_level_ready();
$gatingReady = function_exists('post_course_gating_ready') && post_course_gating_ready();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_post'])) {
    csrf_check();
    $title = trim($_POST['title']);
    $img = handle_image_upload('featured_image_file');
    $data = [
        'title'            => $title,
        'slug'             => unique_slug('posts', slugify($title), $_POST['edit_id'] ?: null),
        'excerpt'          => trim($_POST['excerpt']),
        'content'          => $_POST['content'], // stored as HTML, written by trusted admin only
        'meta_title'       => trim($_POST['meta_title']),
        'meta_description' => trim($_POST['meta_description']),
        'button_text'      => trim($_POST['button_text']),
        'button_url'       => trim($_POST['button_url']),
        'button_new_tab'   => isset($_POST['button_new_tab']) ? 1 : 0,
        'status'           => $_POST['status'] === 'published' ? 'published' : 'draft',
    ];
    if ($pinReady) $data['is_pinned'] = isset($_POST['is_pinned']) ? 1 : 0;
    $courseIds = [];
    if ($courseLinkReady) {
        $courseIds = array_values(array_filter(array_map('intval', (array)($_POST['course_ids'] ?? []))));
        // Legacy single column - kept in sync with the first ticked course.
        $data['course_id'] = $courseIds[0] ?? null;
        $data['course_sort_order'] = (int) ($_POST['course_sort_order'] ?? 0);
        if ($gatingReady) {
            $data['show_in_course'] = isset($_POST['show_in_course']) ? 1 : 0;
        }
        if ($levelReady) {
            $level = trim($_POST['level'] ?? '');
            $data['level'] = in_array($level, ['beginner','intermediate','advanced'], true) ? $level : null;
        }
    }

    $cols = array_keys($data);
    $setSql = implode(', ', array_map(fn($c) => "$c=?", $cols));

    if (!empty($_POST['edit_id'])) {
        $postId = (int) $_POST['edit_id'];
        if ($img) {
            db()->prepare("UPDATE posts SET $setSql, featured_image=? WHERE id=?")
                ->execute([...array_values($data), $img, $postId]);
        } else {
            db()->prepare("UPDATE posts SET $setSql WHERE id=?")
                ->execute([...array_values($data), $postId]);
        }
    } else {
        $insertCols = implode(', ', $cols) . ', featured_image';
        $placeholders = implode(',', array_fill(0, count($cols) + 1, '?'));
        db()->prepare("INSERT INTO posts ($insertCols) VALUES ($placeholders)")
            ->execute([...array_values($data), $img]);
        $postId = (int) db()->lastInsertId();
    }

    if ($courseLinkReady && function_exists('post_multi_course_ready') && post_multi_course_ready()) {
        set_post_courses($postId, $courseIds);
    }

    flash('Post saved.');
    redirect('/admin/posts.php');
}

if (isset($_GET['pin']) && $pinReady) {
    db()->prepare("UPDATE posts SET is_pinned = 1 - is_pinned WHERE id=?")->execute([(int)$_GET['pin']]);
    flash('Pin status updated.');
    redirect('/admin/posts.php');
}

if (isset($_GET['del'])) {
    db()->prepare("DELETE FROM posts WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Post deleted.');
    redirect('/admin/posts.php');
}

$editPost = null;
if (!empty($_GET['edit'])) {
    $stmt = db()->prepare("SELECT * FROM posts WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editPost = $stmt->fetch();
}
$posts = db()->query("SELECT * FROM posts ORDER BY " . ($pinReady ? "is_pinned DESC, " : "") . "created_at DESC")->fetchAll();
$viewsMap = view_counts_map('post');
?>
<div class="card">
  <h3><?php echo $editPost ? 'Edit Post' : 'Add New Post'; ?></h3>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editPost ? (int)$editPost['id'] : ''; ?>">
    <label>Title</label>
    <input type="text" name="title" value="<?php echo h($editPost['title'] ?? ''); ?>" required>
    <label>Excerpt (short summary shown in listings)</label>
    <textarea name="excerpt" style="min-height:60px;"><?php echo h($editPost['excerpt'] ?? ''); ?></textarea>
    <label>Content</label>
    <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Build the post from blocks - add an image, a paragraph, a YouTube video, a text link, or raw HTML, in any order.</p>
    <textarea id="postContentArea" name="content" style="min-height:200px;font-family:monospace;"><?php echo h($editPost['content'] ?? ''); ?></textarea>
    <?php require __DIR__ . '/_content_builder.php'; ?>
    <script>document.addEventListener('DOMContentLoaded', function(){
      M3DGContentBuilder.attach('postContentArea', []);
    });</script>
    <label>Featured Image <span style="font-weight:400;color:var(--muted);">(shown as the thumbnail on the Blog page)</span></label>
    <input type="file" name="featured_image_file" accept="image/*">
    <?php if (!empty($editPost['featured_image'])): ?>
      <img src="<?php echo h($editPost['featured_image']); ?>" style="max-width:160px;border-radius:8px;margin-bottom:16px;display:block;">
    <?php endif; ?>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Need to reuse an image/file you already uploaded, or upload one for use inside the Content HTML below? Use the <a href="filemanager.php" target="_blank">File Manager</a> and copy its link.</p>

    <?php if ($pinReady): ?>
      <label style="margin-top:16px;"><input type="checkbox" name="is_pinned" style="width:auto;display:inline-block;" <?php echo !empty($editPost['is_pinned']) ? 'checked' : ''; ?>> 📌 Pin this post to the top of the Blog page</label>
    <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Pinning isn't set up yet - run <code>migration-post-pin.sql</code> on your database to enable it.</p>
    <?php endif; ?>

    <h3 style="margin-top:24px;">🎓 Course Curriculum (optional)</h3>
    <?php if ($courseLinkReady): ?>
      <?php
        $postMultiCourseReady = function_exists('post_multi_course_ready') && post_multi_course_ready();
        $availablePostCourses = all_course_products();
        $linkedPostCourseIds = $postMultiCourseReady && !empty($editPost['id'])
            ? post_course_ids($editPost['id'])
            : (!empty($editPost['course_id']) ? [(int)$editPost['course_id']] : []);
      ?>
      <label>Include this post in a Course</label>
      <?php if (!$postMultiCourseReady): ?>
        <div class="flash flash-error" style="margin-top:8px;margin-bottom:8px;">Multi-course selection isn't set up yet — import <code>migration-content-multi-course.sql</code> in phpMyAdmin, then reload this page. Until then, a post can only belong to one course.</div>
        <select name="course_ids[]">
          <option value="">— Not part of a course —</option>
          <?php foreach ($availablePostCourses as $c): ?>
            <option value="<?php echo (int)$c['id']; ?>" <?php echo in_array((int)$c['id'], $linkedPostCourseIds, true) ? 'selected' : ''; ?>><?php echo h($c['title']); ?></option>
          <?php endforeach; ?>
        </select>
      <?php else: ?>
        <div style="display:flex;gap:14px;flex-wrap:wrap;padding:8px 0;">
          <?php foreach ($availablePostCourses as $c): ?>
            <label style="width:auto;display:inline-flex;align-items:center;gap:6px;font-weight:400;">
              <input type="checkbox" name="course_ids[]" value="<?php echo (int)$c['id']; ?>" style="width:auto;"
                <?php echo in_array((int)$c['id'], $linkedPostCourseIds, true) ? 'checked' : ''; ?>>
              <?php echo h($c['title']); ?>
            </label>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Tick every course this should be a locked lesson in: only members who are logged in and have bought <b>at least one of the ticked courses</b> can open it (direct link included) - everyone else sees a "buy this course" message. This lesson page also gets a noindex tag so Google won't rank the paid content itself (each course's own product page stays indexable as usual).</p>
      <label>Order within the course (lower shows first, optional)</label>
      <input type="number" name="course_sort_order" value="<?php echo h($editPost['course_sort_order'] ?? '0'); ?>" style="max-width:140px;">

      <?php if ($gatingReady): ?>
      <label style="margin-top:12px;"><input type="checkbox" name="show_in_course" style="width:auto;display:inline-block;" <?php echo ((int)($editPost['show_in_course'] ?? 1) === 1) ? 'checked' : ''; ?>> Show title &amp; link on the course's public "What's Covered" list</label>
      <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Uncheck to keep this lesson linked to the course (still access-controlled as above) but hide its title/link from the public curriculum list - e.g. a bonus lesson you don't want to advertise upfront.</p>
      <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Per-item show/hide on the course page isn't set up yet - run <code>migration-course-content-gating.sql</code> on your database to enable it.</p>
      <?php endif; ?>

      <?php if ($levelReady):
        $curPostLevel = $editPost['level'] ?? '';
      ?>
      <label style="margin-top:12px;">Level (who this lesson is for)</label>
      <select name="level">
        <option value="">— All levels (no filter) —</option>
        <option value="beginner" <?php echo $curPostLevel==='beginner'?'selected':''; ?>>🔰 Beginner</option>
        <option value="intermediate" <?php echo $curPostLevel==='intermediate'?'selected':''; ?>>🎯 Intermediate</option>
        <option value="advanced" <?php echo $curPostLevel==='advanced'?'selected':''; ?>>🚀 Advanced</option>
      </select>
      <p style="color:var(--muted);font-size:12px;margin-top:-10px;">On the course's public page, a visitor can pick their level and this lesson will only show for that level (leave "All levels" if it's needed by everyone, e.g. an intro lesson).</p>
      <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Per-lesson Level tagging isn't set up yet - run <code>migration-content-item-level.sql</code> on your database to enable it.</p>
      <?php endif; ?>
    <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Adding posts to a course's curriculum isn't set up yet - run <code>migration-course-content-links.sql</code> (and <code>migration-course-license.sql</code> if not already done) on your database to enable it.</p>
    <?php endif; ?>

    <h3 style="margin-top:24px;">Call-to-Action Button (optional)</h3>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Shown as a button right after the post content.</p>
    <label>Button Text</label>
    <input type="text" name="button_text" value="<?php echo h($editPost['button_text'] ?? ''); ?>" placeholder="e.g. Order This Design">
    <label>Button URL</label>
    <input type="text" name="button_url" value="<?php echo h($editPost['button_url'] ?? ''); ?>" placeholder="/designer.php or https://...">
    <label><input type="checkbox" name="button_new_tab" style="width:auto;display:inline-block;" <?php echo !empty($editPost['button_new_tab']) ? 'checked' : ''; ?>> Open in new tab</label>

    <h3 style="margin-top:24px;">SEO (optional)</h3>
    <label>SEO Title (leave blank to use the post title)</label>
    <input type="text" name="meta_title" value="<?php echo h($editPost['meta_title'] ?? ''); ?>">
    <label>Meta Description</label>
    <textarea name="meta_description" style="min-height:60px;"><?php echo h($editPost['meta_description'] ?? ''); ?></textarea>

    <label style="margin-top:16px;">Status</label>
    <select name="status">
      <option value="draft" <?php echo (($editPost['status'] ?? '')==='draft')?'selected':''; ?>>Draft</option>
      <option value="published" <?php echo (($editPost['status'] ?? '')==='published')?'selected':''; ?>>Published</option>
    </select>
    <button type="submit" name="save_post" class="btn">Save Post</button>
    <?php if ($editPost): ?><a href="posts.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <h3>All Posts</h3>
  <table>
    <thead><tr><th>Title</th><th>Status</th><th>Views</th><th>Date</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($posts as $p): ?>
      <tr>
        <td>
          <?php if ($pinReady && !empty($p['is_pinned'])): ?><span class="badge badge-gold" style="margin-right:6px;">📌 Pinned</span><?php endif; ?><?php echo h($p['title']); ?>
          <?php if ($courseLinkReady): $postCourses = post_courses_list($p['id']); ?>
          <?php if ($postCourses): ?>
            <br><small style="color:var(--muted)">🎓 in course<?php echo count($postCourses) > 1 ? 's' : ''; ?>: <?php echo h(implode(', ', array_column($postCourses, 'title'))); ?><?php if ($levelReady && !empty($p['level'])): ?> · <?php echo ['beginner'=>'🔰 Beginner','intermediate'=>'🎯 Intermediate','advanced'=>'🚀 Advanced'][$p['level']] ?? ''; ?><?php endif; ?><?php if ($gatingReady && empty($p['show_in_course'])): ?> · <span title="Hidden from the public course list">🙈 hidden on course page</span><?php endif; ?></small>
          <?php endif; ?>
          <?php endif; ?>
        </td>
        <td><span class="badge <?php echo $p['status']==='published'?'badge-active':'badge-expired'; ?>"><?php echo h($p['status']); ?></span></td>
        <td>👁 <?php echo (int)($viewsMap[$p['id']] ?? 0); ?></td>
        <td><?php echo date('d M Y', strtotime($p['created_at'])); ?></td>
        <td>
          <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo h($p['slug']); ?>" target="_blank" class="btn btn-sm btn-outline">View</a>
          <a href="?edit=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <?php if (function_exists('share_links_ready') && share_links_ready()): ?>
            <a href="share-links.php?type=post&amp;id=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline">🔗 Share</a>
          <?php endif; ?>
          <?php if ($pinReady): ?>
            <a href="?pin=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline"><?php echo !empty($p['is_pinned']) ? 'Unpin' : 'Pin'; ?></a>
          <?php endif; ?>
          <a href="?del=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this post?');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$posts): ?><tr><td colspan="5">No posts yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
