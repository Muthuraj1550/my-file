<?php
$adminTitle = 'Tool Site API';
require_once __DIR__ . '/_layout_top.php';
$base = rtrim(SITE_URL, '/');
?>
<div class="card">
  <h3>🔑 API credentials</h3>
  <p style="color:var(--muted);font-size:14px;">
    Course la <b>Site Password / License</b> set panna product oruvar vaangunaal, avaruku
    username + password auto generate aagum. Antha login ah tool site (Main Editor / Litho)
    keezha ulla endpoint mulama verify pannum. <b>api_key server-side la mattum</b> —
    browser JS la vaikka koodathu.
  </p>
  <table class="table">
    <tr><th style="width:210px;">Per-site API keys</th><td><a href="tool-sites.php">Admin → Tool Sites &amp; Access</a> (ange thaan generate pannuveenga)</td></tr>
    <tr><th>Master key (optional)</th><td><code><?php echo h(APP_SECRET); ?></code></td></tr>
    <tr><th>Verify endpoint</th><td><code><?php echo h($base); ?>/api/verify-license.php</code></td></tr>
    <tr><th>User list endpoint</th><td><code><?php echo h($base); ?>/api/license-users.php</code></td></tr>
    <tr><th>site values</th><td><code>litho</code> · <code>main_editor</code> (<code>both</code> license rendukkum work aagum)</td></tr>
  </table>
</div>

<div class="card">
  <h3>Main Editor site kku setup (coding thevai illa)</h3>
  <ol style="color:var(--muted);font-size:13.5px;line-height:1.9;">
    <li>Inga <a href="tool-sites.php">Tool Sites &amp; Access</a> la <code>main_editor</code> API key copy pannunga.</li>
    <li>Main Editor site → <b>Admin → Course Site Access</b> la, indha site oda URL + antha API key paste pannunga.</li>
    <li>Save panniddu "Test Connection" la oru course username/password check pannunga.</li>
    <li>Appuram course user, Main Editor login page la avanga course username + password podalaam.</li>
  </ol>
</div>

<div class="card">
  <h3>Verify endpoint — request / response</h3>
  <p style="color:var(--muted);font-size:13px;">Vera oru tool site kku custom coding venumna, ithu mattum podhum:</p>
<pre style="white-space:pre-wrap;background:var(--bg);padding:16px;border-radius:10px;font-size:12.5px;overflow:auto;">
POST <?php echo h($base); ?>/api/verify-license.php
Content-Type: application/json

{ "api_key": "SITE_API_KEY", "site": "main_editor",
  "username": "USER", "password": "PASS" }

→ { "valid": true, "username": "...", "user_name": "...", "product": "...",
    "site": "main_editor", "source": "product",
    "plan": { "plan_name": "...", "plan_expiry": "...",
              "premium_designer": 1, "ai_daily_limit": 20, "project_slots": 5 } }

→ { "valid": false, "reason": "..." }
</pre>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
