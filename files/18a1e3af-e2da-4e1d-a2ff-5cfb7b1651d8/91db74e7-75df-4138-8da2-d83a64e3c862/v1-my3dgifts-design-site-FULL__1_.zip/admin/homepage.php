<?php
$adminTitle = 'Homepage';
require_once __DIR__ . '/_layout_top.php';

function coin_image_upload($field) {
    if (empty($_FILES[$field]['name'])) return null;
    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return null;
    $newName = 'coin_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

function banner_image_upload($field) {
    if (empty($_FILES[$field]['name'])) return null;
    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return null;
    $newName = 'banner_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_hero'])) {
    csrf_check();
    set_setting('home_hero_title', trim($_POST['home_hero_title']));
    set_setting('home_hero_subtitle', trim($_POST['home_hero_subtitle']));
    set_setting('home_hero_btn1_text', trim($_POST['home_hero_btn1_text']));
    set_setting('home_hero_btn1_url', trim($_POST['home_hero_btn1_url']));
    set_setting('home_hero_btn2_text', trim($_POST['home_hero_btn2_text']));
    set_setting('home_hero_btn2_url', trim($_POST['home_hero_btn2_url']));
    set_setting('home_custom_html', $_POST['home_custom_html']);
    set_setting('seo_home_title', trim($_POST['seo_home_title']));
    set_setting('seo_home_description', trim($_POST['seo_home_description']));
    flash('Homepage updated.');
    redirect('/admin/homepage.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_banner'])) {
    csrf_check();
    set_setting('home_banner_enabled', isset($_POST['home_banner_enabled']) ? '1' : '0');
    set_setting('home_banner_url', trim($_POST['home_banner_url']));
    set_setting('home_banner_new_tab', isset($_POST['home_banner_new_tab']) ? '1' : '0');
    set_setting('home_banner_alt', trim($_POST['home_banner_alt']));
    $bimg = banner_image_upload('home_banner_image_file');
    if ($bimg) set_setting('home_banner_image', $bimg);
    flash('Homepage banner updated.');
    redirect('/admin/homepage.php#banner');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_testimonials'])) {
    csrf_check();
    set_setting('home_testimonials_enabled', isset($_POST['home_testimonials_enabled']) ? '1' : '0');
    for ($i = 1; $i <= 3; $i++) {
        set_setting("testimonial{$i}_name", trim($_POST["testimonial{$i}_name"] ?? ''));
        set_setting("testimonial{$i}_role", trim($_POST["testimonial{$i}_role"] ?? ''));
        set_setting("testimonial{$i}_text", trim($_POST["testimonial{$i}_text"] ?? ''));
        set_setting("testimonial{$i}_rating", max(0, min(5, (int)($_POST["testimonial{$i}_rating"] ?? 5))));
    }
    flash('Testimonials updated.');
    redirect('/admin/homepage.php#testimonials');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_coin'])) {
    csrf_check();
    set_setting('coin_widget_enabled', isset($_POST['coin_widget_enabled']) ? '1' : '0');
    set_setting('coin_face1_text', trim($_POST['coin_face1_text']));
    set_setting('coin_face1_url', trim($_POST['coin_face1_url']));
    set_setting('coin_face1_new_tab', isset($_POST['coin_face1_new_tab']) ? '1' : '0');
    set_setting('coin_face2_text', trim($_POST['coin_face2_text']));
    set_setting('coin_face2_url', trim($_POST['coin_face2_url']));
    set_setting('coin_face2_new_tab', isset($_POST['coin_face2_new_tab']) ? '1' : '0');
    $img1 = coin_image_upload('coin_face1_image_file');
    if ($img1) set_setting('coin_face1_image', $img1);
    $img2 = coin_image_upload('coin_face2_image_file');
    if ($img2) set_setting('coin_face2_image', $img2);
    set_setting('coin_toss_enabled', isset($_POST['coin_toss_enabled']) ? '1' : '0');
    set_setting('coin_toss_start_delay', max(0, (int)$_POST['coin_toss_start_delay']));
    set_setting('coin_toss_repeat_count', max(0, (int)$_POST['coin_toss_repeat_count']));
    set_setting('coin_toss_gap', max(1, (int)$_POST['coin_toss_gap']));
    flash('Coin animation updated.');
    redirect('/admin/homepage.php#coin');
}
?>
<div class="card" style="max-width:680px;">
  <h3>Hero Section</h3>
  <p style="color:var(--muted);font-size:13px;">This is the big banner at the top of your homepage.</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Hero Title</label>
    <input type="text" name="home_hero_title" value="<?php echo h(get_setting('home_hero_title')); ?>">
    <label>Hero Subtitle</label>
    <input type="text" name="home_hero_subtitle" value="<?php echo h(get_setting('home_hero_subtitle')); ?>">

    <label>Button 1 Text</label>
    <input type="text" name="home_hero_btn1_text" value="<?php echo h(get_setting('home_hero_btn1_text')); ?>">
    <label>Button 1 URL (e.g. /designer.php or a full https:// link)</label>
    <input type="text" name="home_hero_btn1_url" value="<?php echo h(get_setting('home_hero_btn1_url')); ?>">

    <label>Button 2 Text</label>
    <input type="text" name="home_hero_btn2_text" value="<?php echo h(get_setting('home_hero_btn2_text')); ?>">
    <label>Button 2 URL</label>
    <input type="text" name="home_hero_btn2_url" value="<?php echo h(get_setting('home_hero_btn2_url')); ?>">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Leave a button's text blank to hide it.</p>

    <h3 style="margin-top:30px;">Custom HTML Block</h3>
    <p style="color:var(--muted);font-size:13px;">Optional. Shown as its own section on the homepage, below the "Why My 3D Gifts?"
    box and above the blog list. Paste any HTML here - banners, embeds, extra buttons, testimonials, etc. Leave blank to hide it.</p>
    <textarea name="home_custom_html" style="min-height:180px;font-family:monospace;"><?php echo h(get_setting('home_custom_html')); ?></textarea>

    <h3 style="margin-top:30px;">Homepage SEO</h3>
    <label>SEO Title (leave blank to use the default site name)</label>
    <input type="text" name="seo_home_title" value="<?php echo h(get_setting('seo_home_title')); ?>">
    <label>Meta Description</label>
    <textarea name="seo_home_description" style="min-height:70px;"><?php echo h(get_setting('seo_home_description')); ?></textarea>

    <button type="submit" name="save_hero" class="btn">Save Homepage</button>
  </form>
</div>

<div class="card" style="max-width:680px;" id="banner">
  <h3>🖼️ Homepage Banner</h3>
  <p style="color:var(--muted);font-size:13px;">Optional full-width image banner shown right below the Hero section (e.g. a course/product promo, sale banner, festival offer). Off by default.</p>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label><input type="checkbox" name="home_banner_enabled" style="width:auto;display:inline-block;" <?php echo get_setting('home_banner_enabled', '0')==='1' ? 'checked' : ''; ?>> Enable banner on homepage</label>
    <label>Banner Image</label>
    <input type="file" name="home_banner_image_file" accept="image/*">
    <?php if (get_setting('home_banner_image')): ?>
      <img src="<?php echo h(get_setting('home_banner_image')); ?>" style="max-width:100%;max-height:120px;border-radius:8px;margin:8px 0;display:block;">
    <?php endif; ?>
    <label>Banner Link URL (optional - e.g. /products.php or a full https:// link)</label>
    <input type="text" name="home_banner_url" value="<?php echo h(get_setting('home_banner_url')); ?>">
    <label><input type="checkbox" name="home_banner_new_tab" style="width:auto;display:inline-block;" <?php echo get_setting('home_banner_new_tab')==='1' ? 'checked' : ''; ?>> Open link in new tab</label>
    <label>Alt Text (for accessibility/SEO)</label>
    <input type="text" name="home_banner_alt" value="<?php echo h(get_setting('home_banner_alt')); ?>">
    <button type="submit" name="save_banner" class="btn">Save Banner</button>
  </form>
</div>

<div class="card" style="max-width:680px;" id="testimonials">
  <h3>💬 Testimonials</h3>
  <p style="color:var(--muted);font-size:13px;">Up to 3 buyer quotes shown on the homepage below "Why My 3D Gifts?". Leave a testimonial's text blank to hide that card.</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label><input type="checkbox" name="home_testimonials_enabled" style="width:auto;display:inline-block;" <?php echo get_setting('home_testimonials_enabled', '1')==='1' ? 'checked' : ''; ?>> Show testimonials on homepage</label>
    <?php for ($i = 1; $i <= 3; $i++): ?>
      <h3 style="margin-top:20px;font-size:16px;">Testimonial <?php echo $i; ?></h3>
      <label>Buyer Name</label>
      <input type="text" name="testimonial<?php echo $i; ?>_name" value="<?php echo h(get_setting("testimonial{$i}_name")); ?>">
      <label>Role / Context (e.g. "Bought the Wave Cut Course")</label>
      <input type="text" name="testimonial<?php echo $i; ?>_role" value="<?php echo h(get_setting("testimonial{$i}_role")); ?>">
      <label>Quote</label>
      <textarea name="testimonial<?php echo $i; ?>_text" style="min-height:70px;"><?php echo h(get_setting("testimonial{$i}_text")); ?></textarea>
      <label>Star Rating (0-5)</label>
      <input type="number" name="testimonial<?php echo $i; ?>_rating" min="0" max="5" value="<?php echo (int)get_setting("testimonial{$i}_rating", 5); ?>">
    <?php endfor; ?>
    <button type="submit" name="save_testimonials" class="btn" style="margin-top:16px;">Save Testimonials</button>
  </form>
</div>

<div class="card" style="max-width:680px;" id="coin">
  <h3>🪙 3D Coin Spin Animation</h3>
  <p style="color:var(--muted);font-size:13px;">Shows a spinning coin on the homepage that flips between two sides on its own, each side with its own image, caption text and link. Upload images below, or use the <a href="filemanager.php" target="_blank">File Manager</a> and paste a link in manually.</p>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label><input type="checkbox" name="coin_widget_enabled" style="width:auto;display:inline-block;" <?php echo get_setting('coin_widget_enabled', '0')==='1' ? 'checked' : ''; ?>> Show coin animation on homepage</label>
    <p style="color:var(--muted);font-size:12px;margin-top:-8px;">Currently off by default for this site (digital file / course shop homepage) - tick this box any time you want to bring it back.</p>


    <h3 style="margin-top:10px;font-size:16px;">Side A</h3>
    <label>Side A Image</label>
    <input type="file" name="coin_face1_image_file" accept="image/*">
    <?php if (get_setting('coin_face1_image')): ?>
      <img src="<?php echo h(get_setting('coin_face1_image')); ?>" style="max-width:100px;border-radius:50%;margin-bottom:16px;display:block;">
    <?php endif; ?>
    <label>Side A Caption</label>
    <input type="text" name="coin_face1_text" value="<?php echo h(get_setting('coin_face1_text', 'Buy 3D Print Gift')); ?>">
    <label>Side A Link URL</label>
    <input type="text" name="coin_face1_url" value="<?php echo h(get_setting('coin_face1_url', '/membership.php')); ?>">
    <label><input type="checkbox" name="coin_face1_new_tab" style="width:auto;display:inline-block;" <?php echo get_setting('coin_face1_new_tab')==='1' ? 'checked' : ''; ?>> Open in new tab</label>

    <h3 style="margin-top:24px;font-size:16px;">Side B</h3>
    <label>Side B Image</label>
    <input type="file" name="coin_face2_image_file" accept="image/*">
    <?php if (get_setting('coin_face2_image')): ?>
      <img src="<?php echo h(get_setting('coin_face2_image')); ?>" style="max-width:100px;border-radius:50%;margin-bottom:16px;display:block;">
    <?php endif; ?>
    <label>Side B Caption</label>
    <input type="text" name="coin_face2_text" value="<?php echo h(get_setting('coin_face2_text', 'Buy 3D Design Template')); ?>">
    <label>Side B Link URL</label>
    <input type="text" name="coin_face2_url" value="<?php echo h(get_setting('coin_face2_url', '/designer.php')); ?>">
    <label><input type="checkbox" name="coin_face2_new_tab" style="width:auto;display:inline-block;" <?php echo get_setting('coin_face2_new_tab')==='1' ? 'checked' : ''; ?>> Open in new tab</label>

    <h3 style="margin-top:24px;font-size:16px;">🚀 Toss Animation</h3>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Every so often, the coin flies up from the bottom-left corner, spins through the air, and lands at the bottom-right corner - like tossing a coin.</p>
    <label><input type="checkbox" name="coin_toss_enabled" style="width:auto;display:inline-block;" <?php echo get_setting('coin_toss_enabled', '1')==='1' ? 'checked' : ''; ?>> Enable toss animation</label>
    <label>Start after page loads (seconds)</label>
    <input type="number" name="coin_toss_start_delay" min="0" value="<?php echo (int)get_setting('coin_toss_start_delay', 3); ?>">
    <label>How many times to repeat (0 = keep repeating forever)</label>
    <input type="number" name="coin_toss_repeat_count" min="0" value="<?php echo (int)get_setting('coin_toss_repeat_count', 3); ?>">
    <label>Gap between each toss (seconds)</label>
    <input type="number" name="coin_toss_gap" min="1" value="<?php echo (int)get_setting('coin_toss_gap', 6); ?>">

    <button type="submit" name="save_coin" class="btn">Save Coin Animation</button>
  </form>
</div>

<div class="card" style="max-width:680px;">
  <a href="<?php echo SITE_URL; ?>/" target="_blank" class="btn btn-outline">Preview Homepage ↗</a>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
