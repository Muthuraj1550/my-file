<?php
$adminTitle = 'Main Editor Members';
require_once __DIR__ . '/_layout_top.php';

$ready = true;
try { db()->query("SELECT 1 FROM main_editor_registrations LIMIT 1"); }
catch (Throwable $e) { $ready = false; }

$search = trim($_GET['q'] ?? '');
$rows = [];
if ($ready) {
    $sql = "SELECT * FROM main_editor_registrations";
    $params = [];
    if ($search !== '') {
        $sql .= " WHERE name LIKE ? OR email LIKE ? OR phone LIKE ?";
        $needle = '%' . $search . '%';
        $params = [$needle, $needle, $needle];
    }
    $sql .= " ORDER BY created_at DESC LIMIT 300";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
}
?>
<?php if (!$ready): ?>
<div class="card" style="border-color:#f59e0b;">
  <h3>⚠️ Setup needed</h3>
  <p style="color:var(--muted);font-size:13px;">Import <code>migration-main-editor-registrations.sql</code> in phpMyAdmin first,
  then turn ON <b>Main Editor → Admin → Course Site Access → "sync_registration_to_course_site"</b> so new
  registrations start flowing here.</p>
</div>
<?php else: ?>

<div class="card">
  <p style="color:var(--muted);font-size:13px;margin:0;">
    Members who registered on <b>my3dgifts.com (Main Editor)</b> — pushed here automatically at registration time.
    This is separate from this site's own Members list. Click <b>View Full Details</b> on a row to reveal phone,
    address and password.
  </p>
</div>

<div class="card">
  <form method="get" style="margin-bottom:16px;max-width:340px;">
    <input type="text" name="q" placeholder="Search by name, email or phone" value="<?php echo h($search); ?>">
  </form>

  <table>
    <thead><tr><th>Registered</th><th>Name</th><th>Phone</th><th>Email</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): $rid = (int) $r['id']; ?>
      <tr>
        <td><?php echo date('d M Y H:i', strtotime($r['created_at'])); ?></td>
        <td><?php echo h($r['name']); ?></td>
        <td><?php echo h($r['phone'] ?: '—'); ?></td>
        <td><?php echo h($r['email']); ?></td>
        <td><button type="button" class="btn btn-sm btn-outline" onclick="toggleMEDetails(<?php echo $rid; ?>)">View Full Details</button></td>
      </tr>
      <tr id="me-details-<?php echo $rid; ?>" style="display:none;">
        <td colspan="5" style="background:rgba(255,255,255,0.03);">
          <div style="display:flex;gap:24px;flex-wrap:wrap;padding:6px 4px;font-size:13px;">
            <div><b>Address:</b> <?php echo h($r['address'] ?: '—'); ?></div>
            <div><b>Password:</b> <code><?php echo h($r['password_plain'] ?: '—'); ?></code></div>
            <div><b>Last updated:</b> <?php echo date('d M Y H:i', strtotime($r['updated_at'])); ?></div>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="5">No Main Editor registrations recorded yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<script>
function toggleMEDetails(id) {
  var row = document.getElementById('me-details-' + id);
  if (row) row.style.display = (row.style.display === 'none' ? '' : 'none');
}
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
