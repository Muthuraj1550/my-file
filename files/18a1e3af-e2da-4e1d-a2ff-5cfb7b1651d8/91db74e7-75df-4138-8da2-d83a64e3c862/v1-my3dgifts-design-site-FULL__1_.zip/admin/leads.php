<?php
$adminTitle = 'Leads (Contact Form)';
require_once __DIR__ . '/_layout_top.php';

if (!leads_table_ready()) {
?>
  <div class="flash flash-error">
    The contact form isn't set up yet. Import <code>migration-products-shop.sql</code> in phpMyAdmin, then reload this page.
  </div>
<?php
  require_once __DIR__ . '/_layout_bottom.php';
  exit;
}

if (isset($_GET['read'])) {
    db()->prepare("UPDATE form_submissions SET is_read=1 WHERE id=?")->execute([(int)$_GET['read']]);
    redirect('/admin/leads.php');
}
if (isset($_GET['del'])) {
    db()->prepare("DELETE FROM form_submissions WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Message deleted.');
    redirect('/admin/leads.php');
}

$leads = db()->query("SELECT l.*, p.title AS product_title FROM form_submissions l
                       LEFT JOIN products p ON p.id = l.product_id
                       ORDER BY l.created_at DESC")->fetchAll();
?>
<div class="card">
  <h3>Contact Form Messages (<?php echo count($leads); ?>)</h3>
  <table>
    <thead><tr><th>Date</th><th>From</th><th>Message</th><th>Product</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($leads as $l): ?>
      <tr style="<?php echo $l['is_read'] ? '' : 'font-weight:600;'; ?>">
        <td><?php echo date('d M Y H:i', strtotime($l['created_at'])); ?></td>
        <td><?php echo h($l['name']); ?><br>
          <span style="font-weight:400;color:var(--muted);font-size:12px;">
            <?php echo h($l['email'] ?? ''); ?><?php echo ($l['email'] && $l['phone']) ? ' · ' : ''; ?><?php echo h($l['phone'] ?? ''); ?>
          </span>
        </td>
        <td style="max-width:320px;font-weight:400;"><?php echo nl2br(h($l['message'])); ?></td>
        <td style="font-weight:400;"><?php echo h($l['product_title'] ?? '—'); ?></td>
        <td>
          <?php if (!$l['is_read']): ?><a href="?read=<?php echo (int)$l['id']; ?>" class="btn btn-sm btn-outline">Mark Read</a><?php endif; ?>
          <a href="?del=<?php echo (int)$l['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this message?');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$leads): ?><tr><td colspan="5">No messages yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
