<style>
.cb-wrap{border:1px solid var(--border,#27324a);border-radius:10px;padding:12px;background:rgba(255,255,255,.02);}
.cb-block{border:1px solid var(--border,#27324a);border-radius:8px;padding:12px;margin-bottom:10px;background:var(--card,#151f38);}
.cb-block.cb-drag-over{border-color:var(--accent,#6366f1);}
.cb-block.cb-dragging{opacity:.4;}
.cb-block-head{display:flex;align-items:center;gap:8px;justify-content:space-between;margin-bottom:8px;}
.cb-block-head-left{display:flex;align-items:center;gap:8px;}
.cb-drag-handle{cursor:grab;color:var(--muted,#94a3b8);font-size:14px;user-select:none;padding:0 2px;}
.cb-drag-handle:active{cursor:grabbing;}
.cb-block-tag{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--gold,#e6c25c);}
.cb-block-actions{display:flex;flex-wrap:wrap;}
.cb-block-actions button{background:none;border:1px solid var(--border,#27324a);color:var(--muted,#94a3b8);border-radius:6px;padding:3px 8px;font-size:12px;cursor:pointer;margin-left:4px;margin-bottom:2px;}
.cb-block-actions button:hover{color:#fff;}
.cb-block textarea, .cb-block input[type=text], .cb-block select{width:100%;}
.cb-block textarea{min-height:90px;font-family:inherit;}
.cb-block.cb-html textarea{font-family:monospace;min-height:140px;}
.cb-toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;}
.cb-toolbar button{background:var(--accent,#6366f1);color:#fff;border:none;border-radius:8px;padding:8px 14px;font-size:13px;cursor:pointer;}
.cb-toolbar button.outline{background:none;border:1px solid var(--border,#27324a);color:var(--muted,#94a3b8);}
.cb-toolbar button:disabled{opacity:.4;cursor:not-allowed;}
.cb-img-preview{max-width:220px;border-radius:8px;display:block;margin:8px 0;}
.cb-empty{color:var(--muted,#94a3b8);font-size:13px;padding:10px 2px;}
.cb-yt-preview{position:relative;width:160px;height:90px;overflow:hidden;border-radius:8px;margin:8px 0;background:#000;}
.cb-yt-preview img{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;}
.cb-yt-preview iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0;}
.cb-yt-play{position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.25);border:0;color:#fff;font-size:22px;cursor:pointer;display:flex;align-items:center;justify-content:center;}
.cb-yt-play:hover{background:rgba(0,0,0,.4);}
.cb-yt-hint{color:var(--muted,#94a3b8);font-size:12px;margin-top:6px;}
.cb-link-preview{margin-top:8px;padding:8px 10px;border:1px dashed var(--border,#27324a);border-radius:6px;font-size:13px;}
.cb-link-row{display:flex;gap:8px;align-items:center;margin-top:8px;}
.cb-link-row label{width:auto;margin:0;font-size:12px;color:var(--muted,#94a3b8);display:flex;align-items:center;gap:4px;}
.cb-link-row input[type=checkbox]{width:auto;}
.cb-heading-row{display:flex;gap:8px;align-items:center;}
.cb-heading-row select{max-width:130px;flex:none;}
.cb-heading-row input{flex:1;font-weight:700;}
.cb-toc-hint{color:var(--muted,#94a3b8);font-size:11px;margin-top:6px;}
.cb-block-actions button[data-act=toctoggle]{font-size:14px;}
</style>
<script>
window.M3DGContentBuilder = (function(){

  // Shared clipboard so a block can be copied/cut in one editor (e.g. Post) and
  // pasted into another (e.g. Page) opened later in the same admin session.
  var clipboard = null;

  function esc(s){ var d=document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }

  /** Pull the YouTube video id out of any of the URL shapes people paste in. */
  function ytExtractId(input){
    input = (input || '').trim();
    if (!input) return '';
    // Already a bare 11-char id
    if (/^[a-zA-Z0-9_-]{11}$/.test(input)) return input;
    var patterns = [
      /(?:youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
      /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
      /(?:youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
      /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/
    ];
    for (var i = 0; i < patterns.length; i++) {
      var m = input.match(patterns[i]);
      if (m) return m[1];
    }
    return '';
  }

  function serializeBlocks(blocks){
    return blocks.map(function(b){
      if (b.type === 'paragraph') {
        var html = '<p>' + esc(b.text).replace(/\n/g,'<br>') + '</p>';
        return '<!--BLOCK:paragraph-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'heading') {
        var lvl = (b.level === 1 || b.level === '1') ? 1 : (b.level === 3 || b.level === '3') ? 3 : 2;
        var vis = b.hideInToc ? 'hide' : 'show';
        var html = '<h' + lvl + '>' + esc(b.text) + '</h' + lvl + '>';
        return '<!--BLOCK:heading:' + lvl + ':' + vis + '-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'image') {
        var html = b.url ? ('<img src="' + b.url + '" alt="' + esc(b.alt) + '" style="max-width:100%;border-radius:10px;">') : '';
        return '<!--BLOCK:image-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'youtube') {
        var id = ytExtractId(b.url);
        var html = id ? (
          '<div class="yt-embed" style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;max-width:100%;border-radius:10px;margin:12px 0;">' +
          '<iframe src="https://www.youtube.com/embed/' + id + '" title="' + esc(b.title || 'YouTube video') + '" ' +
          'style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" ' +
          'allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" ' +
          'referrerpolicy="strict-origin-when-cross-origin" allowfullscreen loading="lazy"></iframe>' +
          '</div>'
        ) : '';
        return '<!--BLOCK:youtube:' + esc(b.url) + '-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'link') {
        var newTab = b.newTab ? ' target="_blank" rel="noopener"' : '';
        var html = (b.url ? '<p style="margin:14px 0;"><a href="' + esc(b.url) + '"' + newTab + '>' + esc(b.text || b.url) + '</a></p>' : '');
        return '<!--BLOCK:link-->' + html + '<!--/BLOCK-->';
      }
      // html
      return '<!--BLOCK:html-->' + (b.html || '') + '<!--/BLOCK-->';
    }).join('\n');
  }

  function parseBlocks(content){
    content = content || '';
    var re = /<!--BLOCK:(paragraph|image|html|youtube(?::[^>]*)?|link|heading(?::[^>]*)?)-->([\s\S]*?)<!--\/BLOCK-->/g;
    var blocks = [];
    var m, found = false;
    while ((m = re.exec(content)) !== null) {
      found = true;
      var rawType = m[1], inner = m[2];
      if (rawType.indexOf('heading') === 0) {
        var lvl = 2, hideInToc = false;
        var hColonIdx = rawType.indexOf(':');
        if (hColonIdx !== -1) {
          var hRest = rawType.substring(hColonIdx + 1); // "2" or "2:hide" or "2:show"
          var hParts = hRest.split(':');
          var lvlStr = hParts[0];
          lvl = (lvlStr === '1') ? 1 : (lvlStr === '3') ? 3 : 2;
          hideInToc = (hParts[1] === 'hide');
        }
        var tmpH = document.createElement('div'); tmpH.innerHTML = inner;
        blocks.push({ type:'heading', level: lvl, text: (tmpH.textContent || ''), hideInToc: hideInToc });
        continue;
      }
      if (rawType.indexOf('youtube') === 0) {
        var urlFromTag = '';
        var colonIdx = rawType.indexOf(':');
        if (colonIdx !== -1) {
          var tmp0 = document.createElement('div');
          tmp0.innerHTML = rawType.substring(colonIdx + 1);
          urlFromTag = tmp0.textContent || '';
        }
        if (!urlFromTag) {
          var tmpFrame = document.createElement('div'); tmpFrame.innerHTML = inner;
          var ifr = tmpFrame.querySelector('iframe');
          if (ifr) {
            var idMatch = (ifr.getAttribute('src') || '').match(/embed\/([a-zA-Z0-9_-]{11})/);
            urlFromTag = idMatch ? idMatch[1] : '';
          }
        }
        blocks.push({ type:'youtube', url: urlFromTag, title:'' });
        continue;
      }
      var type = rawType;
      if (type === 'paragraph') {
        var tmp = document.createElement('div'); tmp.innerHTML = inner;
        blocks.push({ type:'paragraph', text: (tmp.textContent || '').replace(/\n{2,}/g,'\n') });
      } else if (type === 'image') {
        var tmp2 = document.createElement('div'); tmp2.innerHTML = inner;
        var img = tmp2.querySelector('img');
        blocks.push({ type:'image', url: img ? img.getAttribute('src') : '', alt: img ? (img.getAttribute('alt')||'') : '' });
      } else if (type === 'link') {
        var tmp3 = document.createElement('div'); tmp3.innerHTML = inner;
        var a = tmp3.querySelector('a');
        blocks.push({ type:'link', url: a ? a.getAttribute('href') : '', text: a ? (a.textContent||'') : '', newTab: a ? a.getAttribute('target')==='_blank' : false });
      } else {
        blocks.push({ type:'html', html: inner });
      }
    }
    if (!found && content.trim() !== '') {
      // Legacy content saved before the block builder existed - keep it fully editable as one HTML block.
      blocks.push({ type:'html', html: content });
    }
    return blocks;
  }

  function attach(textareaId, forms){
    var ta = document.getElementById(textareaId);
    if (!ta) return;
    forms = forms || [];

    var blocks = parseBlocks(ta.value);
    ta.style.display = 'none';

    var wrap = document.createElement('div');
    wrap.className = 'cb-wrap';
    var list = document.createElement('div');
    wrap.appendChild(list);

    var toolbar = document.createElement('div');
    toolbar.className = 'cb-toolbar';
    toolbar.innerHTML =
      '<button type="button" data-add="paragraph">+ Paragraph</button>' +
      '<button type="button" data-add="heading">+ Heading</button>' +
      '<button type="button" data-add="image">+ Image</button>' +
      '<button type="button" data-add="youtube">+ YouTube Video</button>' +
      '<button type="button" data-add="link">+ Text Link</button>' +
      '<button type="button" data-add="html">+ HTML</button>' +
      (forms.length ? '<button type="button" data-add="form">+ Form</button>' : '') +
      '<button type="button" class="outline" data-paste disabled>📋 Paste Block</button>' +
      '<button type="button" class="outline" data-sync>Preview HTML ↓</button>';
    wrap.appendChild(toolbar);

    ta.parentNode.insertBefore(wrap, ta);

    var pasteBtn = toolbar.querySelector('[data-paste]');
    function updatePasteBtn(){ pasteBtn.disabled = !clipboard; }

    function render(){
      list.innerHTML = '';
      if (!blocks.length) {
        var empty = document.createElement('div');
        empty.className = 'cb-empty';
        empty.textContent = 'No content blocks yet - add an image, a paragraph, a YouTube video, a link, or raw HTML below.';
        list.appendChild(empty);
      }
      blocks.forEach(function(b, i){ list.appendChild(renderBlock(b, i)); });
      sync();
    }

    function renderBlock(b, i){
      var el = document.createElement('div');
      el.className = 'cb-block cb-' + b.type;

      // Drag-and-drop reordering (in addition to the ↑ / ↓ buttons below - handy
      // when a page has many blocks and moving one a long way would take lots of clicks).
      el.addEventListener('dragover', function(e){ e.preventDefault(); el.classList.add('cb-drag-over'); });
      el.addEventListener('dragleave', function(){ el.classList.remove('cb-drag-over'); });
      el.addEventListener('drop', function(e){
        e.preventDefault();
        el.classList.remove('cb-drag-over');
        var from = parseInt(e.dataTransfer.getData('text/plain'), 10);
        if (isNaN(from) || from === i) return;
        var moved = blocks.splice(from, 1)[0];
        var insertAt = from < i ? i - 1 : i;
        blocks.splice(insertAt, 0, moved);
        render();
      });

      var head = document.createElement('div');
      head.className = 'cb-block-head';
      var tagNames = { paragraph:'Paragraph', heading:'Heading', image:'Image', html:'HTML', form:'Form', youtube:'YouTube Video', link:'Text Link' };
      var headLeft = document.createElement('div');
      headLeft.className = 'cb-block-head-left';
      headLeft.innerHTML =
        '<span class="cb-drag-handle" draggable="true" title="Drag to move this block">⠿</span>' +
        '<span class="cb-block-tag">' + tagNames[b.type] + '</span>';
      head.appendChild(headLeft);
      headLeft.querySelector('.cb-drag-handle').addEventListener('dragstart', function(e){
        e.dataTransfer.setData('text/plain', String(i));
        e.dataTransfer.effectAllowed = 'move';
        el.classList.add('cb-dragging');
      });
      headLeft.querySelector('.cb-drag-handle').addEventListener('dragend', function(){ el.classList.remove('cb-dragging'); });

      var actions = document.createElement('div');
      actions.className = 'cb-block-actions';
      var convertBtn = '';
      if (b.type === 'paragraph') convertBtn = '<button type="button" data-act="tohead" title="Turn into Heading">H</button>';
      else if (b.type === 'heading') convertBtn = '<button type="button" data-act="topara" title="Turn into Paragraph">¶</button>';
      var tocBtn = '';
      if (b.type === 'heading') {
        tocBtn = '<button type="button" data-act="toctoggle" title="' +
          (b.hideInToc ? 'Hidden from the Topics list - click to show it there' : 'Shown in the Topics list - click to hide it there') + '">' +
          (b.hideInToc ? '🙈' : '👁') + '</button>';
      }
      actions.innerHTML =
        '<button type="button" data-act="up" title="Move up">↑</button>' +
        '<button type="button" data-act="down" title="Move down">↓</button>' +
        tocBtn +
        '<button type="button" data-act="copy" title="Copy block">⧉</button>' +
        '<button type="button" data-act="cut" title="Cut block">✂</button>' +
        convertBtn +
        '<button type="button" data-act="del" title="Delete block">✕</button>';
      head.appendChild(actions);
      el.appendChild(head);

      var body = document.createElement('div');
      if (b.type === 'paragraph') {
        body.innerHTML = '<textarea placeholder="Write a paragraph...">' + esc(b.text) + '</textarea>';
        body.querySelector('textarea').addEventListener('input', function(e){ b.text = e.target.value; sync(); });
      } else if (b.type === 'heading') {
        body.innerHTML =
          '<div class="cb-heading-row">' +
            '<select data-role="hlevel">' +
              '<option value="1"' + (b.level===1?' selected':'') + '>Heading 1 (largest)</option>' +
              '<option value="2"' + (!b.level||b.level===2?' selected':'') + '>Heading 2</option>' +
              '<option value="3"' + (b.level===3?' selected':'') + '>Heading 3</option>' +
            '</select>' +
            '<input type="text" data-role="htext" value="' + esc(b.text) + '" placeholder="Heading text (shown bold)">' +
          '</div>' +
          '<div class="cb-toc-hint">' + (b.hideInToc ? '🙈 Hidden from the "Topics Covered" list shown on the post/page/product.' : '👁 Shown in the "Topics Covered" list shown on the post/page/product.') + '</div>';
        body.querySelector('[data-role=hlevel]').addEventListener('change', function(e){ b.level = parseInt(e.target.value,10); sync(); });
        body.querySelector('[data-role=htext]').addEventListener('input', function(e){ b.text = e.target.value; sync(); });
      } else if (b.type === 'html') {
        body.innerHTML = '<textarea placeholder="&lt;div&gt;...raw HTML, download buttons, embeds, etc...&lt;/div&gt;">' + esc(b.html) + '</textarea>';
        body.querySelector('textarea').addEventListener('input', function(e){ b.html = e.target.value; sync(); });
      } else if (b.type === 'image') {
        var previewHtml = b.url ? ('<img class="cb-img-preview" src="' + b.url + '">') : '';
        body.innerHTML =
          previewHtml +
          '<input type="file" accept="image/*" data-role="file">' +
          '<div style="margin-top:6px;color:var(--muted);font-size:12px;">or paste an image URL:</div>' +
          '<input type="text" data-role="url" value="' + esc(b.url) + '" placeholder="https://...">' +
          '<div style="margin-top:6px;">Alt text: <input type="text" data-role="alt" value="' + esc(b.alt) + '" placeholder="Describe the image"></div>';
        body.querySelector('[data-role=url]').addEventListener('input', function(e){ b.url = e.target.value; render(); });
        body.querySelector('[data-role=alt]').addEventListener('input', function(e){ b.alt = e.target.value; sync(); });
        body.querySelector('[data-role=file]').addEventListener('change', function(e){
          var file = e.target.files[0];
          if (!file) return;
          var fd = new FormData();
          fd.append('image', file);
          fd.append('csrf', document.querySelector('input[name=csrf]').value);
          el.style.opacity = '0.5';
          fetch('ajax-upload-image.php', { method:'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(res){
              el.style.opacity = '1';
              if (res.ok) { b.url = res.url; render(); }
              else alert(res.error || 'Upload failed.');
            })
            .catch(function(){ el.style.opacity = '1'; alert('Upload failed.'); });
        });
      } else if (b.type === 'youtube') {
        // Admin preview stays a small static thumbnail (not a live embed) so a page
        // with several videos doesn't turn into a long scroll of loaded players.
        // The real, full-size player still shows normally on the public post/page.
        var id = ytExtractId(b.url);
        var ytPreview = id
          ? ('<div class="cb-yt-preview" data-vid="' + id + '"><img src="https://img.youtube.com/vi/' + id + '/mqdefault.jpg" alt="Video thumbnail"><button type="button" class="cb-yt-play" title="Preview this video">▶</button></div>')
          : '';
        body.innerHTML =
          '<input type="text" data-role="yturl" value="' + esc(b.url) + '" placeholder="Paste a YouTube link (e.g. https://www.youtube.com/watch?v=... or https://youtu.be/...)">' +
          '<div class="cb-yt-hint">' + (id ? 'Looks good - small thumbnail below. Click ▶ to preview, it plays full-size on the live page.' : 'Paste any YouTube video/short link, or just the video ID.') + '</div>' +
          ytPreview;
        body.querySelector('[data-role=yturl]').addEventListener('input', function(e){ b.url = e.target.value; render(); });
        var playBtn = body.querySelector('.cb-yt-play');
        if (playBtn) {
          playBtn.addEventListener('click', function(){
            var holder = body.querySelector('.cb-yt-preview');
            holder.innerHTML = '<iframe src="https://www.youtube.com/embed/' + id + '?autoplay=1" allow="autoplay; encrypted-media" allowfullscreen loading="lazy"></iframe>';
          });
        }
      } else if (b.type === 'link') {
        body.innerHTML =
          '<input type="text" data-role="linktext" value="' + esc(b.text) + '" placeholder="Link text (e.g. Download the STL file)">' +
          '<div class="cb-link-row" style="margin-top:8px;"><input type="text" data-role="linkurl" style="flex:1;" value="' + esc(b.url) + '" placeholder="https://... or /page.php"></div>' +
          '<label class="cb-link-row"><input type="checkbox" data-role="linkblank" ' + (b.newTab ? 'checked' : '') + '> Open in new tab</label>' +
          (b.url ? ('<div class="cb-link-preview">Preview: <a href="' + esc(b.url) + '" target="_blank" rel="noopener">' + esc(b.text || b.url) + '</a></div>') : '');
        body.querySelector('[data-role=linktext]').addEventListener('input', function(e){ b.text = e.target.value; sync(); });
        body.querySelector('[data-role=linkurl]').addEventListener('input', function(e){ b.url = e.target.value; render(); });
        body.querySelector('[data-role=linkblank]').addEventListener('change', function(e){ b.newTab = e.target.checked; sync(); });
      } else if (b.type === 'form') {
        var opts = forms.map(function(f){
          return '<option value="' + f.id + '"' + (String(b.formId)===String(f.id)?' selected':'') + '>' + esc(f.name) + '</option>';
        }).join('');
        body.innerHTML = '<select data-role="form-select"><option value="">-- Select a form --</option>' + opts + '</select>' +
          '<div style="margin-top:6px;color:var(--muted);font-size:12px;">Create/manage forms under Admin &gt; Forms.</div>';
        body.querySelector('[data-role=form-select]').addEventListener('change', function(e){ b.formId = e.target.value; sync(); });
      }
      el.appendChild(body);

      actions.querySelector('[data-act=up]').addEventListener('click', function(){ if (i>0){ blocks.splice(i-1,0,blocks.splice(i,1)[0]); render(); } });
      actions.querySelector('[data-act=down]').addEventListener('click', function(){ if (i<blocks.length-1){ blocks.splice(i+1,0,blocks.splice(i,1)[0]); render(); } });
      actions.querySelector('[data-act=copy]').addEventListener('click', function(){
        clipboard = JSON.parse(JSON.stringify(b));
        updatePasteBtn();
        var btn = actions.querySelector('[data-act=copy]');
        var old = btn.textContent; btn.textContent = '✓'; setTimeout(function(){ btn.textContent = old; }, 900);
      });
      actions.querySelector('[data-act=cut]').addEventListener('click', function(){
        clipboard = JSON.parse(JSON.stringify(b));
        blocks.splice(i,1);
        render();
      });
      var toHeadBtn = actions.querySelector('[data-act=tohead]');
      if (toHeadBtn) toHeadBtn.addEventListener('click', function(){ b.type = 'heading'; b.level = b.level || 2; render(); });
      var toParaBtn = actions.querySelector('[data-act=topara]');
      if (toParaBtn) toParaBtn.addEventListener('click', function(){ b.type = 'paragraph'; render(); });
      var tocToggleBtn = actions.querySelector('[data-act=toctoggle]');
      if (tocToggleBtn) tocToggleBtn.addEventListener('click', function(){ b.hideInToc = !b.hideInToc; render(); });
      actions.querySelector('[data-act=del]').addEventListener('click', function(){ if (confirm('Remove this block?')) { blocks.splice(i,1); render(); } });

      return el;
    }

    function sync(){ ta.value = serializeBlocks(blocks); updatePasteBtn(); }

    toolbar.querySelectorAll('[data-add]').forEach(function(btn){
      btn.addEventListener('click', function(){
        var type = btn.getAttribute('data-add');
        var nb = { type:type, text:'', html:'', url:'', alt:'', formId:'', newTab:false, title:'', level: 2, hideInToc: false };
        blocks.push(nb);
        render();
      });
    });
    pasteBtn.addEventListener('click', function(){
      if (!clipboard) return;
      blocks.push(JSON.parse(JSON.stringify(clipboard)));
      render();
    });
    toolbar.querySelector('[data-sync]').addEventListener('click', function(){
      sync();
      alert(ta.value || '(empty)');
    });

    var formEl = ta.closest('form');
    if (formEl) formEl.addEventListener('submit', sync);

    updatePasteBtn();
    render();
  }

  return { attach: attach };
})();
</script>
