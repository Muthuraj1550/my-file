<?php
$adminTitle = 'Settings';
require_once __DIR__ . '/_layout_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    set_setting('cashfree_mode', $_POST['cashfree_mode'] === 'production' ? 'production' : 'sandbox');
    set_setting('cashfree_app_id', trim($_POST['cashfree_app_id']));
    set_setting('cashfree_secret_key', trim($_POST['cashfree_secret_key']));
    set_setting('cashfree_api_version', trim($_POST['cashfree_api_version']) ?: '2023-08-01');
    set_setting('renew_days_before', (int)$_POST['renew_days_before']);
    set_setting('coin_price_inr', max(0.01, (float)($_POST['coin_price_inr'] ?? 1)));
    set_setting('coin_min_purchase', max(1, (int)($_POST['coin_min_purchase'] ?? 10)));
    set_setting('site_tagline', trim($_POST['site_tagline']));
    set_setting('main_editor_url', rtrim(trim($_POST['main_editor_url']), '/'));
    set_setting('whatsapp_number', preg_replace('/[^0-9]/', '', trim($_POST['whatsapp_number'] ?? '')));
    flash('Settings saved.');
    redirect('/admin/settings.php');
}
?>
<div class="card" style="max-width:640px;">
  <h3>Cashfree Payment Gateway</h3>
  <p style="color:var(--muted);font-size:13px;">
    Get your keys from the <a href="https://merchant.cashfree.com/" target="_blank">Cashfree Merchant Dashboard</a>
    → Developers → API Keys. Use the <strong>Test/Sandbox</strong> keys first, then switch mode to
    Production with your live keys when you're ready to accept real payments.
    Webhook URL to configure in Cashfree dashboard: <code><?php echo SITE_URL; ?>/payment-webhook.php</code>
  </p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Mode</label>
    <select name="cashfree_mode">
      <option value="sandbox" <?php echo get_setting('cashfree_mode')==='sandbox'?'selected':''; ?>>Sandbox (Test)</option>
      <option value="production" <?php echo get_setting('cashfree_mode')==='production'?'selected':''; ?>>Production (Live)</option>
    </select>
    <label>App ID (Client ID)</label>
    <input type="text" name="cashfree_app_id" value="<?php echo h(get_setting('cashfree_app_id')); ?>">
    <label>Secret Key (Client Secret)</label>
    <input type="text" name="cashfree_secret_key" value="<?php echo h(get_setting('cashfree_secret_key')); ?>">
    <label>API Version</label>
    <input type="text" name="cashfree_api_version" value="<?php echo h(get_setting('cashfree_api_version', '2023-08-01')); ?>">

    <h3 style="margin-top:30px;">Coin Pricing <span style="color:var(--muted);font-weight:normal;font-size:12px;">(for "Buy Coins" on Membership page — coins are used on Main Editor)</span></h3>
    <label>Price per coin (₹)</label>
    <input type="number" min="0.01" step="0.01" name="coin_price_inr" value="<?php echo h(get_setting('coin_price_inr', '1')); ?>">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Used on the membership page for the "Buy Coins" custom-amount box.</p>
    <label>Minimum coin purchase</label>
    <input type="number" min="1" name="coin_min_purchase" value="<?php echo h(get_setting('coin_min_purchase', '10')); ?>">

    <h3 style="margin-top:30px;">General</h3>
    <label>Site Tagline (shown on homepage)</label>
    <input type="text" name="site_tagline" value="<?php echo h(get_setting('site_tagline')); ?>">
    <label>Show Renew Reminder (days before expiry)</label>
    <input type="number" name="renew_days_before" value="<?php echo h(get_setting('renew_days_before', 5)); ?>">
    <label>Main Editor Base URL</label>
    <input type="text" name="main_editor_url" value="<?php echo h(get_setting('main_editor_url', 'https://my3dgifts.com')); ?>" placeholder="https://my3dgifts.com">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">No trailing slash. Used for the /designer redirect and the Membership Plan button (→ <code>/membership.php</code> there).</p>

    <h3 style="margin-top:30px;">WhatsApp Support</h3>
    <p style="color:var(--muted);font-size:13px;">
      Buyers sometimes assume a design course also covers things it doesn't (like 3D print repair).
      Set your WhatsApp number here so people can quickly ask a question and clear up any doubt themselves —
      a small "Ask on WhatsApp" button will show on every Blog post, and a small WhatsApp icon will show on the Homepage.
    </p>
    <label>WhatsApp Number (with country code, digits only — e.g. 919876543210)</label>
    <input type="text" name="whatsapp_number" value="<?php echo h(get_setting('whatsapp_number', '')); ?>" placeholder="919876543210">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Leave blank to hide the WhatsApp button/icon everywhere on the site.</p>

    <button type="submit" class="btn">Save Settings</button>
  </form>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
