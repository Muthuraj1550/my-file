<?php
/** Admin -> Courses (separate page from Products/Shop). */
$adminMode = 'course';
require __DIR__ . '/products.php';
