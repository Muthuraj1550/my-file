<?php
$adminTitle = 'Members';
require_once __DIR__ . '/_layout_top.php';

$newCreds = null; // ['username'=>..,'password'=>..,'name'=>..] shown once, right after creation

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])) {
    csrf_check();
    $ids = array_values(array_filter(array_map('intval', $_POST['member_ids'] ?? [])));
    if (!$ids) {
        flash('Select at least one member first.', 'error');
        redirect('/admin/members.php');
    }
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    switch ($_POST['bulk_action']) {

        case 'grant_product':
            $pid = (int)($_POST['bulk_product_id'] ?? 0);
            if ($pid && shop_tables_ready()) {
                foreach ($ids as $uid) grant_product_to_user($uid, $pid);
                flash('Access granted to ' . count($ids) . ' member(s).');
            } else {
                flash('Pick a product/course first.', 'error');
            }
            break;

        case 'set_plan':
            $planName = trim($_POST['bulk_plan_name'] ?? '');
            $expiry = trim($_POST['bulk_plan_expiry'] ?? '');
            if ($planName === '') {
                flash('Pick a plan first.', 'error');
            } else {
                $plan = get_plan_by_name($planName);
                $sql = "UPDATE users SET plan_name=?, plan_id=?" . ($expiry !== '' ? ", plan_expiry=?" : "") . " WHERE id IN ($placeholders)";
                $params = [$planName, $plan ? $plan['id'] : null];
                if ($expiry !== '') $params[] = $expiry;
                db()->prepare($sql)->execute(array_merge($params, $ids));
                flash('Plan set to "' . $planName . '" for ' . count($ids) . ' member(s).');
            }
            break;

        case 'set_status':
            $status = ($_POST['bulk_status'] ?? '') === 'blocked' ? 'blocked' : 'active';
            db()->prepare("UPDATE users SET status=? WHERE id IN ($placeholders)")->execute(array_merge([$status], $ids));
            flash('Site access set to "' . $status . '" for ' . count($ids) . ' member(s).');
            break;

        case 'delete':
            foreach ($ids as $uid) {
                // Clean up tables without a foreign-key cascade first (missing tables from
                // un-run migrations are simply skipped); FK-cascaded tables clean up on their own.
                foreach (['orders', 'ai_usage_log', 'content_views', 'user_products', 'product_orders',
                          'site_access', 'product_licenses', 'main_editor_plan_orders', 'form_submissions'] as $t) {
                    try { db()->prepare("DELETE FROM $t WHERE user_id=?")->execute([$uid]); } catch (Exception $e) {}
                }
                db()->prepare("DELETE FROM users WHERE id=? AND role='member'")->execute([$uid]);
            }
            flash(count($ids) . ' member(s) deleted permanently.');
            break;
    }
    redirect('/admin/members.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_member'])) {
    csrf_check();
    $name = trim($_POST['new_name'] ?? '');
    if ($name === '') {
        flash('Name is required to create a member.', 'error');
        redirect('/admin/members.php');
    }
    if (!username_login_ready()) {
        flash('Run migration-username-login.sql in phpMyAdmin first (adds the username column).', 'error');
        redirect('/admin/members.php');
    }

    $username = generate_username_from_name($name);
    $password = generate_random_password(8);
    $placeholderEmail = $username . '@members.' . preg_replace('/^https?:\/\//', '', parse_url(SITE_URL, PHP_URL_HOST) ?: 'my3dgifts.com');

    $free = get_plan_by_name('Free');
    $expiry = date('Y-m-d', strtotime('+100 years'));
    $stmt = db()->prepare("INSERT INTO users (name, email, username, password_hash, role, plan_id, plan_name, plan_expiry)
                            VALUES (?,?,?,?,'member',?,?,?)");
    $stmt->execute([
        $name, $placeholderEmail, $username,
        password_hash($password, PASSWORD_DEFAULT),
        $free ? $free['id'] : null,
        'Free',
        $expiry,
    ]);
    $newMemberId = (int) db()->lastInsertId();

    // Optional: grant access to any products/courses ticked on the create form.
    if (shop_tables_ready() && !empty($_POST['grant_products']) && is_array($_POST['grant_products'])) {
        foreach ($_POST['grant_products'] as $pid) {
            grant_product_to_user($newMemberId, (int)$pid);
        }
    }

    $_SESSION['new_member_creds'] = ['username' => $username, 'password' => $password, 'name' => $name];
    redirect('/admin/members.php');
}

if (!empty($_SESSION['new_member_creds'])) {
    $newCreds = $_SESSION['new_member_creds'];
    unset($_SESSION['new_member_creds']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_member'])) {
    csrf_check();
    $mid = (int)$_POST['mid'];
    $stmt = db()->prepare("UPDATE users SET plan_name=?, plan_expiry=?, ai_limit_override=?, status=?, tripo_coins=?, plan_coins=? WHERE id=?");
    $stmt->execute([
        trim($_POST['plan_name']),
        $_POST['plan_expiry'] ?: null,
        $_POST['ai_limit_override'] !== '' ? (int)$_POST['ai_limit_override'] : null,
        $_POST['status'],
        (int)($_POST['tripo_coins'] ?? 0),
        (int)($_POST['plan_coins'] ?? 0),
        $mid,
    ]);
    flash('Member updated.');
    redirect('/admin/members.php');
}

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = db()->prepare("SELECT * FROM users WHERE role='member' AND (name LIKE ? OR email LIKE ?) ORDER BY created_at DESC LIMIT 200");
    $like = '%' . $search . '%';
    $stmt->execute([$like, $like]);
} else {
    $stmt = db()->query("SELECT * FROM users WHERE role='member' ORDER BY created_at DESC LIMIT 200");
}
$members = $stmt->fetchAll();
$allPlans = all_plans();
$shopReady = shop_tables_ready();
$allProductsForGrant = $shopReady ? all_products(false) : [];
$toolSitesReady = tool_sites_ready();
$totalMembersCount = (int) db()->query("SELECT COUNT(*) c FROM users WHERE role='member'")->fetch()['c'];
?>
<p style="color:var(--muted);font-size:13px;margin:-6px 0 14px;">👥 <?php echo $totalMembersCount; ?> total members</p>

<?php if ($newCreds): ?>
<div class="card" style="border:2px solid #16a34a;background:#f0fdf4;margin-bottom:16px;">
  <h3 style="margin-top:0;">✅ Member Created — <?php echo h($newCreds['name']); ?></h3>
  <p style="margin:6px 0;">Give these login details to the member now — the password is <b>not stored anywhere</b> and won't be shown again.</p>
  <p style="font-size:16px;margin:4px 0;">Username: <code style="background:#dcfce7;padding:2px 8px;border-radius:4px;"><?php echo h($newCreds['username']); ?></code></p>
  <p style="font-size:16px;margin:4px 0;">Password: <code style="background:#dcfce7;padding:2px 8px;border-radius:4px;"><?php echo h($newCreds['password']); ?></code></p>
  <p style="color:var(--muted);font-size:12px;">They can log in at <code><?php echo h(SITE_URL); ?>/login.php</code> with this username (or change their password after logging in, if that option is available).</p>
</div>
<?php endif; ?>

<?php if (!username_login_ready()): ?>
<div class="card" style="border:1px solid #f59e0b;background:#fffbeb;margin-bottom:16px;">
  <b>⚠ Migration Pending:</b> run <code>migration-username-login.sql</code> in phpMyAdmin to enable "Add New Member" (username/password auto-generate).
</div>
<?php else: ?>
<div class="card" style="margin-bottom:16px;max-width:420px;">
  <h3 style="margin-top:0;">➕ Add New Member</h3>
  <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Just type their name — a username and password are generated automatically and shown once, ready to hand over.</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="new_name" placeholder="Member's full name" required>
    <?php if ($shopReady && $allProductsForGrant): ?>
      <p style="font-size:12px;color:var(--muted);margin:12px 0 4px;">🔓 Give access to (optional) — tick any products/courses to unlock for this member right away:</p>
      <div style="max-height:180px;overflow-y:auto;border:1px solid var(--border,#27324a);border-radius:8px;padding:8px 10px;margin-bottom:10px;">
        <?php foreach ($allProductsForGrant as $gp): ?>
          <label style="display:block;font-size:13px;font-weight:400;margin:4px 0;">
            <input type="checkbox" name="grant_products[]" value="<?php echo (int)$gp['id']; ?>" style="width:auto;margin-right:6px;">
            <?php echo $gp['type'] === 'course' ? '🎓' : '🗂️'; ?> <?php echo h($gp['title']); ?>
            <?php if ($gp['status'] !== 'published'): ?><span style="color:var(--muted);">(draft)</span><?php endif; ?>
          </label>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <button type="submit" name="create_member" class="btn">Create Member</button>
  </form>
</div>
<?php endif; ?>

<form method="get" style="margin-bottom:16px;max-width:340px;">
  <input type="text" name="q" placeholder="Search by name or email" value="<?php echo h($search); ?>">
</form>

<form id="bulkForm" method="post" onsubmit="return bulkSubmitGuard(event);">
  <?php echo csrf_field(); ?>
  <div class="card" style="margin-bottom:14px;">
    <h3 style="margin-top:0;">⚡ Bulk Actions <span id="bulkCount" style="color:var(--muted);font-size:13px;font-weight:400;"></span></h3>
    <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Tick members in the table below (☑ header checkbox selects all), then pick one action here.</p>
    <div style="display:flex;flex-wrap:wrap;gap:20px 28px;align-items:flex-end;">

      <?php if ($shopReady && $allProductsForGrant): ?>
      <div>
        <label style="display:block;font-size:12px;color:var(--muted);">🎓 Grant product / course</label>
        <select name="bulk_product_id" style="min-width:190px;margin:2px 0;">
          <option value="">-- select --</option>
          <?php foreach ($allProductsForGrant as $gp): ?>
            <option value="<?php echo (int)$gp['id']; ?>"><?php echo $gp['type']==='course'?'🎓 ':'🗂️ '; ?><?php echo h($gp['title']); ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" name="bulk_action" value="grant_product" class="btn btn-sm">Grant</button>
      </div>
      <?php endif; ?>

      <div>
        <label style="display:block;font-size:12px;color:var(--muted);">📋 Set membership plan</label>
        <select name="bulk_plan_name" style="min-width:140px;margin:2px 0;">
          <option value="">-- select --</option>
          <?php foreach ($allPlans as $p): ?><option value="<?php echo h($p['plan_name']); ?>"><?php echo h($p['plan_name']); ?></option><?php endforeach; ?>
        </select>
        <input type="date" name="bulk_plan_expiry" title="Optional new expiry date - leave blank to keep each member's current expiry" style="margin:2px 0;">
        <button type="submit" name="bulk_action" value="set_plan" class="btn btn-sm">Apply</button>
      </div>

      <div>
        <label style="display:block;font-size:12px;color:var(--muted);">🔒 This site's login (active/blocked)</label>
        <select name="bulk_status" style="min-width:110px;margin:2px 0;">
          <option value="active">Active</option>
          <option value="blocked">Blocked</option>
        </select>
        <button type="submit" name="bulk_action" value="set_status" class="btn btn-sm">Apply</button>
      </div>

      <?php if ($toolSitesReady): ?>
      <div>
        <label style="display:block;font-size:12px;color:var(--muted);">&nbsp;</label>
        <a href="tool-sites.php" class="btn btn-sm btn-outline">🔑 Manage Tool-Site Access (Litho / Main Editor...) →</a>
      </div>
      <?php endif; ?>

      <div>
        <label style="display:block;font-size:12px;color:var(--muted);">&nbsp;</label>
        <button type="submit" name="bulk_action" value="delete" class="btn btn-sm btn-danger" onclick="return confirm('Delete ALL selected members permanently? Their purchases, licenses and access will be removed too. This cannot be undone.');">🗑 Delete Selected</button>
      </div>

    </div>
  </div>
</form>
<script>
function bulkSelectedCount(){ return document.querySelectorAll('input[name="member_ids[]"]:checked').length; }
function bulkUpdateCount(){
  var n = bulkSelectedCount();
  document.getElementById('bulkCount').textContent = n ? '(' + n + ' selected)' : '';
}
function bulkToggleAll(el){
  document.querySelectorAll('input[name="member_ids[]"]').forEach(function(cb){ cb.checked = el.checked; });
  bulkUpdateCount();
}
function bulkSubmitGuard(e){
  if (bulkSelectedCount() === 0) { alert('Select at least one member first.'); e.preventDefault(); return false; }
  return true;
}
</script>

<div class="card">
  <table>
    <thead><tr>
      <th><input type="checkbox" onclick="bulkToggleAll(this)" title="Select all"></th>
      <th>Name</th><th>Email / Username</th><th>Plan</th><th>Expiry</th><th>Status</th><th>Plan Coins</th><th>Purchased Coins</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach ($members as $m): ?>
      <?php $active = $m['plan_expiry'] && strtotime($m['plan_expiry']) >= strtotime(date('Y-m-d')); ?>
      <tr>
        <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="mid" value="<?php echo (int)$m['id']; ?>">
        <td><input type="checkbox" name="member_ids[]" value="<?php echo (int)$m['id']; ?>" form="bulkForm" onchange="bulkUpdateCount()"></td>
        <td><?php echo h($m['name']); ?></td>
        <td><?php echo h($m['email']); ?><?php if (!empty($m['username'] ?? null)): ?><br><small style="color:var(--muted)">👤 <?php echo h($m['username']); ?></small><?php endif; ?><br><small style="color:var(--muted)"><?php echo h($m['phone']); ?></small></td>
        <td>
          <select name="plan_name" style="margin:0;min-width:130px;">
            <?php $hasMatch = false; ?>
            <?php foreach ($allPlans as $p): $sel = ($p['plan_name'] === $m['plan_name']); if ($sel) $hasMatch = true; ?>
              <option value="<?php echo h($p['plan_name']); ?>" <?php echo $sel ? 'selected' : ''; ?>><?php echo h($p['plan_name']); ?></option>
            <?php endforeach; ?>
            <?php if (!$hasMatch && $m['plan_name'] !== ''): ?>
              <option value="<?php echo h($m['plan_name']); ?>" selected><?php echo h($m['plan_name']); ?> (not in current plans)</option>
            <?php endif; ?>
          </select>
        </td>
        <td><input type="date" name="plan_expiry" value="<?php echo h($m['plan_expiry']); ?>" style="margin:0;"></td>
        <td>
          <select name="status" style="margin:0;">
            <option value="active" <?php echo $m['status']==='active'?'selected':''; ?>>Active</option>
            <option value="blocked" <?php echo $m['status']==='blocked'?'selected':''; ?>>Blocked</option>
          </select>
        </td>
        <td>
          <input type="number" min="0" name="plan_coins" value="<?php echo (int)($m['plan_coins'] ?? 0); ?>" style="margin:0;width:80px;" title="Monthly membership coins (reset on renewal, spent first)">
        </td>
        <td>
          <input type="number" min="0" name="tripo_coins" value="<?php echo (int)($m['tripo_coins'] ?? 0); ?>" style="margin:0;width:80px;" title="Purchased coins (lifetime, never expire)">
        </td>
        <td>
          <input type="hidden" name="ai_limit_override" value="<?php echo h($m['ai_limit_override']); ?>">
          <button type="submit" name="update_member" class="btn btn-sm">Save</button>
          <?php if ($shopReady): ?>
            <a href="member-products.php?id=<?php echo (int)$m['id']; ?>" class="btn btn-sm btn-outline" style="margin-left:4px;">🔓 Products</a>
          <?php endif; ?>
        </td>
        </form>
      </tr>
    <?php endforeach; ?>
    <?php if (!$members): ?><tr><td colspan="9">No members found.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
