<?php
/**
 * Admin > Import / Export
 * - Export Posts/Pages/Products/Everything as a JSON file (used to move
 *   content between two installs of this same platform, e.g. the test site
 *   bfdes.my3dgifts.com -> the live my3dgifts.com site).
 * - Import that same JSON file back in (upsert by slug - safe to re-run).
 * - Bulk-import a WordPress "Export" file (Tools > Export in WP, a .xml
 *   WXR file) - pulls in Posts and Pages (title/content/excerpt/status).
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();

/* ---------------- EXPORT (sends a raw file, must run before any HTML) ---------------- */
if (isset($_GET['export'])) {
    $what = $_GET['export'];
    $data = [];
    if ($what === 'posts' || $what === 'all') $data['posts'] = db()->query("SELECT * FROM posts")->fetchAll();
    if ($what === 'pages' || $what === 'all') $data['pages'] = db()->query("SELECT * FROM pages")->fetchAll();
    if (($what === 'products' || $what === 'all') && shop_tables_ready()) $data['products'] = db()->query("SELECT * FROM products")->fetchAll();
    if (!$data) { http_response_code(400); exit('Nothing to export.'); }

    $fname = 'my3dgifts-' . $what . '-' . date('Y-m-d') . '.json';
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $fname . '"');
    echo json_encode(['exported_at' => date('c'), 'source' => SITE_URL, 'data' => $data], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ---------------- IMPORT ---------------- */
$importSummary = null;
$importError = null;

/** Insert or update a post/page row, matched by slug. Returns true if it did something. */
function import_upsert_content($table, array $row) {
    $slug = $row['slug'] ?? '';
    if ($slug === '') return false;
    $existing = db()->prepare("SELECT id FROM $table WHERE slug = ?");
    $existing->execute([$slug]);
    $existingRow = $existing->fetch();

    $cols = array_keys($row);
    if ($existingRow) {
        $set = implode(',', array_map(fn($c) => "$c=:$c", array_diff($cols, ['id'])));
        $stmt = db()->prepare("UPDATE $table SET $set WHERE slug=:slug");
    } else {
        $colList = implode(',', array_diff($cols, ['id']));
        $placeholders = implode(',', array_map(fn($c) => ":$c", array_diff($cols, ['id'])));
        $stmt = db()->prepare("INSERT INTO $table ($colList) VALUES ($placeholders)");
    }
    $params = [];
    foreach ($cols as $c) { if ($c !== 'id') $params[$c] = $row[$c]; }
    $params['slug'] = $slug;
    $stmt->execute($params);
    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_json']) && !empty($_FILES['json_file']['tmp_name'])) {
    csrf_check();
    $raw = file_get_contents($_FILES['json_file']['tmp_name']);
    $parsed = json_decode($raw, true);
    if (!$parsed || empty($parsed['data'])) {
        $importError = 'Could not read that file - is it a JSON export from this same tool?';
    } else {
        $counts = ['posts' => 0, 'pages' => 0, 'products' => 0];
        // Known columns per table - only these are copied across, so extra/old fields in an older export are ignored safely.
        $postCols = ['title','slug','excerpt','content','featured_image','meta_title','meta_description','button_text','button_url','button_new_tab','status','is_pinned','course_id','course_sort_order','show_in_course','level'];
        $pageCols = ['title','slug','content','meta_title','meta_description','button_text','button_url','button_new_tab','status','show_in_menu','course_id','course_sort_order','show_in_course','level'];
        $prodCols = ['title','slug','type','category','short_desc','description','thumbnail','price','sale_price','delivery_link','delivery_note','featured','status','sort_order','course_id','license_site','level'];

        if (!empty($parsed['data']['posts'])) {
            foreach ($parsed['data']['posts'] as $p) {
                $row = array_intersect_key($p, array_flip($postCols));
                if (import_upsert_content('posts', $row)) $counts['posts']++;
            }
        }
        if (!empty($parsed['data']['pages'])) {
            foreach ($parsed['data']['pages'] as $p) {
                $row = array_intersect_key($p, array_flip($pageCols));
                if (import_upsert_content('pages', $row)) $counts['pages']++;
            }
        }
        if (!empty($parsed['data']['products']) && shop_tables_ready()) {
            foreach ($parsed['data']['products'] as $p) {
                $row = array_intersect_key($p, array_flip($prodCols));
                if (import_upsert_content('products', $row)) $counts['products']++;
            }
        }
        $importSummary = "Imported: {$counts['posts']} posts, {$counts['pages']} pages, {$counts['products']} products.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_wp']) && !empty($_FILES['wp_file']['tmp_name'])) {
    csrf_check();
    libxml_use_internal_errors(true);
    $xml = simplexml_load_file($_FILES['wp_file']['tmp_name']);
    if (!$xml) {
        $importError = 'Could not read that WordPress export file - make sure it is the .xml file from WordPress > Tools > Export.';
    } else {
        $ns = $xml->getNamespaces(true);
        $counts = ['posts' => 0, 'pages' => 0, 'skipped' => 0];
        foreach ($xml->channel->item as $item) {
            $wp = $item->children($ns['wp'] ?? 'http://wordpress.org/export/1.2/');
            $content = $item->children($ns['content'] ?? 'http://purl.org/rss/1.0/modules/content/');
            $excerptNs = $item->children($ns['excerpt'] ?? 'http://wordpress.org/export/1.2/excerpt/');

            $postType = (string)($wp->post_type ?? 'post');
            $status = (string)($wp->status ?? 'draft');
            if (!in_array($postType, ['post', 'page'], true)) { $counts['skipped']++; continue; }
            if (!in_array($status, ['publish', 'draft', 'pending', 'private'], true)) { $counts['skipped']++; continue; }

            $title = trim((string)$item->title) ?: 'Untitled';
            $bodyHtml = trim((string)$content->encoded);
            $excerpt = trim((string)$excerptNs->encoded);
            $wpSlug = trim((string)$wp->post_name);
            $pubDate = (string)($wp->post_date ?: $item->pubDate);
            $mappedStatus = ($status === 'publish') ? 'published' : 'draft';

            if ($postType === 'post') {
                $slug = unique_slug('posts', $wpSlug !== '' ? $wpSlug : slugify($title));
                $row = [
                    'title' => $title, 'slug' => $slug, 'excerpt' => mb_substr($excerpt, 0, 500),
                    'content' => $bodyHtml, 'status' => $mappedStatus,
                ];
                $existing = db()->prepare("SELECT id FROM posts WHERE slug = ?"); $existing->execute([$slug]);
                if (!$existing->fetch()) {
                    db()->prepare("INSERT INTO posts (title,slug,excerpt,content,status,created_at) VALUES (?,?,?,?,?,?)")
                        ->execute([$row['title'], $row['slug'], $row['excerpt'], $row['content'], $row['status'], $pubDate ?: date('Y-m-d H:i:s')]);
                    $counts['posts']++;
                }
            } else {
                $slug = unique_slug('pages', $wpSlug !== '' ? $wpSlug : slugify($title));
                $existing = db()->prepare("SELECT id FROM pages WHERE slug = ?"); $existing->execute([$slug]);
                if (!$existing->fetch()) {
                    db()->prepare("INSERT INTO pages (title,slug,content,status,show_in_menu,created_at) VALUES (?,?,?,?,0,?)")
                        ->execute([$title, $slug, $bodyHtml, $mappedStatus, $pubDate ?: date('Y-m-d H:i:s')]);
                    $counts['pages']++;
                }
            }
        }
        $importSummary = "WordPress import done: {$counts['posts']} new posts, {$counts['pages']} new pages added (existing slugs skipped, {$counts['skipped']} non-post/page items ignored). New pages are added with 'Show in menu' OFF - turn it on in Admin > Pages if needed.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_users']) && !empty($_FILES['users_csv']['tmp_name'])) {
    csrf_check();
    $fh = fopen($_FILES['users_csv']['tmp_name'], 'r');
    if (!$fh) {
        $importError = 'Could not read that CSV file.';
    } else {
        // Skip any genuinely blank line(s) some export tools put before the header,
        // then strip a UTF-8 BOM off the first header cell wherever it actually lands.
        $header = null;
        while (($row = fgetcsv($fh)) !== false) {
            $nonEmpty = array_filter($row, fn($v) => trim((string)$v) !== '');
            if ($nonEmpty) { $header = $row; break; }
        }
        if ($header) {
            $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string)$header[0]);
        }
        if (!$header) {
            $importError = 'That CSV looks empty.';
        } else {
            $header = array_map(fn($v) => trim((string)$v), $header);
            $colIndex = array_flip($header);
            $need = ['user_login', 'user_email', 'user_pass'];
            $missing = array_diff($need, array_keys($colIndex));
            if ($missing) {
                $importError = 'This CSV is missing column(s): ' . implode(', ', $missing) . ' - make sure it\'s a WordPress user export.';
            } else {
                $usernameReady = username_login_ready();
                $created = 0; $skipped = 0;
                while (($row = fgetcsv($fh)) !== false) {
                    $nonEmpty = array_filter($row, fn($v) => trim((string)$v) !== '');
                    if (!$nonEmpty) continue; // blank line, skip
                    if (count($row) < count($header)) { $skipped++; continue; } // malformed row
                    $get = fn($col) => isset($colIndex[$col]) ? trim((string)($row[$colIndex[$col]] ?? '')) : '';
                    $login = $get('user_login');
                    $email = strtolower($get('user_email'));
                    $pass  = $get('user_pass');
                    if ($login === '' || $email === '' || $pass === '') { $skipped++; continue; }

                    $exists = db()->prepare("SELECT id FROM users WHERE email = ?" . ($usernameReady ? " OR username = ?" : ""));
                    $exists->execute($usernameReady ? [$email, $login] : [$email]);
                    if ($exists->fetch()) { $skipped++; continue; }

                    $displayName = $get('display_name') ?: trim($get('first_name') . ' ' . $get('last_name')) ?: $login;
                    $free = get_plan_by_name('Free');
                    $expiry = date('Y-m-d', strtotime('+100 years'));

                    if ($usernameReady) {
                        $stmt = db()->prepare("INSERT INTO users (name, email, username, password_hash, role, plan_id, plan_name, plan_expiry) VALUES (?,?,?,?,'member',?,?,?)");
                        $stmt->execute([$displayName, $email, $login, $pass, $free ? $free['id'] : null, 'Free', $expiry]);
                    } else {
                        $stmt = db()->prepare("INSERT INTO users (name, email, password_hash, role, plan_id, plan_name, plan_expiry) VALUES (?,?,?,'member',?,?,?)");
                        $stmt->execute([$displayName, $email, $pass, $free ? $free['id'] : null, 'Free', $expiry]);
                    }
                    $created++;
                }
                $importSummary = "Users imported: {$created} created, {$skipped} skipped (already existed or had missing data). Their old password keeps working as-is - no reset needed.";
            }
        }
        fclose($fh);
    }
}

$adminTitle = 'Import / Export';
require_once __DIR__ . '/_layout_top.php';
?>

<?php if ($importError): ?><div class="flash flash-error"><?php echo h($importError); ?></div><?php endif; ?>
<?php if ($importSummary): ?><div class="flash flash-success"><?php echo h($importSummary); ?></div><?php endif; ?>

<div class="card" style="max-width:640px;margin-bottom:16px;">
  <h3 style="margin-top:0;">⬇️ Export Site Data</h3>
  <p style="color:var(--muted);font-size:13px;margin-top:-6px;">Download a JSON backup of this site's content — use this to move content from your test site (e.g. bfdes.my3dgifts.com) into the live site, or just to keep a backup.</p>
  <div style="display:flex;gap:8px;flex-wrap:wrap;">
    <a href="?export=posts" class="btn btn-outline">Export Posts</a>
    <a href="?export=pages" class="btn btn-outline">Export Pages</a>
    <?php if (shop_tables_ready()): ?><a href="?export=products" class="btn btn-outline">Export Products</a><?php endif; ?>
    <a href="?export=all" class="btn">Export Everything</a>
  </div>
</div>

<div class="card" style="max-width:640px;margin-bottom:16px;">
  <h3 style="margin-top:0;">👤 Import Users — Login Only (CSV)</h3>
  <p style="color:var(--muted);font-size:13px;margin-top:-6px;">
    Upload a WordPress users CSV export (needs at least the <code>user_login</code>,
    <code>user_email</code>, <code>user_pass</code> columns — a plugin like "Export/Import Users" or
    WP-CLI's <code>user list</code> produces this). This creates a <b>login-only</b> member account for
    each row — <b>no product/course access is granted</b>, since you said these are people who already
    bought courses on the old site (grant that separately via Admin &gt; Members &gt; 🔓 Products, or a
    Site Data import above if the products/orders live in this platform too).
  </p>
  <p style="color:var(--muted);font-size:13px;">
    Their old WordPress password is carried over as-is and keeps working when they log in here — no
    password reset needed. Rows with an email or username that already exists in this site are skipped
    (safe to re-run).
  </p>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="users_csv" accept=".csv" required>
    <button type="submit" name="import_users" class="btn" style="margin-top:8px;">Import Users</button>
  </form>
</div>

<div class="card" style="max-width:640px;margin-bottom:16px;">
  <h3 style="margin-top:0;">⬆️ Import Site Data (JSON)</h3>
  <p style="color:var(--muted);font-size:13px;margin-top:-6px;">Upload a JSON file exported from this same tool (from this site or another install of it). Matches by slug — existing posts/pages/products with the same slug get updated, new ones get created. Safe to re-run.</p>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="json_file" accept=".json" required>
    <button type="submit" name="import_json" class="btn" style="margin-top:8px;">Import JSON</button>
  </form>
</div>

<div class="card" style="max-width:640px;">
  <h3 style="margin-top:0;">📥 Bulk Import from WordPress</h3>
  <p style="color:var(--muted);font-size:13px;margin-top:-6px;">
    Old WordPress site-ல் <b>Tools → Export</b> (All content, அல்லது Posts/Pages தேர்ந்தெடுத்து) பண்ணி
    கிடைக்கிற <code>.xml</code> file-ஐ இங்க upload பண்ணுங்க. Title/Content/Excerpt/Status
    கொண்டு Posts &amp; Pages தானா create ஆகும் (slug already இருந்தா அந்த item skip ஆகும் -
    duplicate வராது, திரும்ப திரும்ப run பண்ணலாம்). Images/featured image தானா import ஆகாது —
    content-க்குள் இருக்கிற image URLs அப்படியே old site-ஐ point பண்ணும், தேவைன்னா பிறகு
    Admin &gt; Posts/Pages-ல் edit பண்ணி மாத்திக்கலாம்.
  </p>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="wp_file" accept=".xml" required>
    <button type="submit" name="import_wp" class="btn" style="margin-top:8px;">Import WordPress File</button>
  </form>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
