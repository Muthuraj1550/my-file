<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();
$__admin = current_user();
$__active = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($adminTitle ?? 'Admin'); ?> - <?php echo h(SITE_NAME); ?> Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
</head>
<body>
<div class="admin-shell">
  <aside class="admin-sidebar">
    <div style="padding:0 22px 16px;font-weight:800;color:var(--gold);">⚙️ Admin</div>
    <a href="index.php" class="<?php echo $__active==='index.php'?'active':''; ?>"><span class="txt">Dashboard</span></a>
    <a href="homepage.php" class="<?php echo $__active==='homepage.php'?'active':''; ?>"><span class="txt">Homepage</span></a>
    <a href="courses.php" class="<?php echo $__active==='courses.php'?'active':''; ?>"><span class="txt">Courses</span></a>
    <a href="products.php" class="<?php echo $__active==='products.php'?'active':''; ?>"><span class="txt">Products (Shop)</span></a>
    <a href="plans.php" class="<?php echo $__active==='plans.php'?'active':''; ?>"><span class="txt">Membership Plans</span></a>
    <a href="members.php" class="<?php echo $__active==='members.php'?'active':''; ?>"><span class="txt">Members</span></a>
    <a href="orders.php" class="<?php echo $__active==='orders.php'?'active':''; ?>"><span class="txt">Orders</span></a>
    <a href="main-editor-users.php" class="<?php echo $__active==='main-editor-users.php'?'active':''; ?>"><span class="txt">Main Editor Members</span></a>
    <a href="posts.php" class="<?php echo $__active==='posts.php'?'active':''; ?>"><span class="txt">Posts</span></a>
    <a href="pages.php" class="<?php echo $__active==='pages.php'?'active':''; ?>"><span class="txt">Pages</span></a>
    <a href="share-links.php" class="<?php echo $__active==='share-links.php'?'active':''; ?>"><span class="txt">Share Links</span></a>
    <a href="import-export.php" class="<?php echo $__active==='import-export.php'?'active':''; ?>"><span class="txt">Import / Export</span></a>
    <a href="leads.php" class="<?php echo $__active==='leads.php'?'active':''; ?>"><span class="txt">Leads (Contact Form)<?php echo function_exists('unread_leads_count') && unread_leads_count() > 0 ? ' 🔴' : ''; ?></span></a>
    <a href="filemanager.php" class="<?php echo $__active==='filemanager.php'?'active':''; ?>"><span class="txt">File Manager</span></a>
    <a href="menu.php" class="<?php echo $__active==='menu.php'?'active':''; ?>"><span class="txt">Menu</span></a>
    <a href="announcements.php" class="<?php echo $__active==='announcements.php'?'active':''; ?>"><span class="txt">Announcements</span></a>
    <a href="analytics.php" class="<?php echo $__active==='analytics.php'?'active':''; ?>"><span class="txt">Analytics</span></a>
    <a href="tools.php" class="<?php echo $__active==='tools.php'?'active':''; ?>"><span class="txt">Tools (Tool Lab)</span></a>
    <a href="tool-sites.php" class="<?php echo $__active==='tool-sites.php'?'active':''; ?>"><span class="txt">Tool Sites & Access</span></a>
    <a href="api-docs.php" class="<?php echo $__active==='api-docs.php'?'active':''; ?>"><span class="txt">Tool Site API</span></a>
    <a href="settings.php" class="<?php echo $__active==='settings.php'?'active':''; ?>"><span class="txt">Settings</span></a>
    <a href="account.php" class="<?php echo $__active==='account.php'?'active':''; ?>"><span class="txt">My Account</span></a>
    <a href="<?php echo SITE_URL; ?>/" target="_blank"><span class="txt">View Site ↗</span></a>
    <a href="logout.php"><span class="txt">Logout</span></a>
  </aside>
  <div class="admin-content">
    <div class="admin-topbar">
      <h2 style="margin:0;"><?php echo h($adminTitle ?? 'Dashboard'); ?></h2>
      <div style="color:var(--muted);font-size:13px;">Logged in as <?php echo h($__admin['name']); ?></div>
    </div>
    <?php $__flash = get_flash(); if ($__flash): ?>
      <div class="flash flash-<?php echo h($__flash['type']); ?>"><?php echo h($__flash['msg']); ?></div>
    <?php endif; ?>
