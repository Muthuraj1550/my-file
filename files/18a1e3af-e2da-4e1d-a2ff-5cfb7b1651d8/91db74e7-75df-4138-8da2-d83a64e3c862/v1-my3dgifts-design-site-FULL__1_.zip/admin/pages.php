<?php
$adminTitle = 'Pages';
require_once __DIR__ . '/_layout_top.php';

$courseLinkReady = function_exists('course_license_ready') && course_license_ready() && function_exists('page_course_link_ready') && page_course_link_ready();
$levelReady = function_exists('page_level_ready') && page_level_ready();
$gatingReady = function_exists('page_course_gating_ready') && page_course_gating_ready();
$footerMenuReady = function_exists('page_footer_menu_ready') && page_footer_menu_ready();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_page'])) {
    csrf_check();
    $title = trim($_POST['title']);
    $slug = unique_slug('pages', slugify($title), $_POST['edit_id'] ?: null);
    $status = $_POST['status'] === 'published' ? 'published' : 'draft';
    $showMenu = isset($_POST['show_in_menu']) ? 1 : 0;
    $content = $_POST['content'];
    $metaTitle = trim($_POST['meta_title']);
    $metaDesc  = trim($_POST['meta_description']);
    $btnText   = trim($_POST['button_text']);
    $btnUrl    = trim($_POST['button_url']);
    $btnBlank  = isset($_POST['button_new_tab']) ? 1 : 0;

    $extraCols = '';
    $extraVals = [];
    $courseIds = [];
    if ($courseLinkReady) {
        $courseIds = array_values(array_filter(array_map('intval', (array)($_POST['course_ids'] ?? []))));
        // Legacy single column - kept in sync with the first ticked course.
        $extraCols = ', course_id=?, course_sort_order=?';
        $extraVals = [$courseIds[0] ?? null, (int) ($_POST['course_sort_order'] ?? 0)];
        if ($gatingReady) {
            $extraCols .= ', show_in_course=?';
            $extraVals[] = isset($_POST['show_in_course']) ? 1 : 0;
        }
        if ($levelReady) {
            $level = trim($_POST['level'] ?? '');
            $extraCols .= ', level=?';
            $extraVals[] = in_array($level, ['beginner','intermediate','advanced'], true) ? $level : null;
        }
    }
    if ($footerMenuReady) {
        $extraCols .= ', show_in_footer=?';
        $extraVals[] = isset($_POST['show_in_footer']) ? 1 : 0;
    }

    if (!empty($_POST['edit_id'])) {
        $pageId = (int) $_POST['edit_id'];
        db()->prepare("UPDATE pages SET title=?, slug=?, content=?, meta_title=?, meta_description=?, button_text=?, button_url=?, button_new_tab=?, status=?, show_in_menu=?" . $extraCols . " WHERE id=?")
            ->execute([$title, $slug, $content, $metaTitle, $metaDesc, $btnText, $btnUrl, $btnBlank, $status, $showMenu, ...$extraVals, $pageId]);
    } else {
        $insertCols = "title, slug, content, meta_title, meta_description, button_text, button_url, button_new_tab, status, show_in_menu" . ($courseLinkReady ? ', course_id, course_sort_order' : '') . (($courseLinkReady && $gatingReady) ? ', show_in_course' : '') . (($courseLinkReady && $levelReady) ? ', level' : '') . ($footerMenuReady ? ', show_in_footer' : '');
        $placeholders = implode(',', array_fill(0, 10 + ($courseLinkReady ? 2 : 0) + (($courseLinkReady && $gatingReady) ? 1 : 0) + (($courseLinkReady && $levelReady) ? 1 : 0) + ($footerMenuReady ? 1 : 0), '?'));
        db()->prepare("INSERT INTO pages ($insertCols) VALUES ($placeholders)")
            ->execute([$title, $slug, $content, $metaTitle, $metaDesc, $btnText, $btnUrl, $btnBlank, $status, $showMenu, ...$extraVals]);
        $pageId = (int) db()->lastInsertId();
    }

    if ($courseLinkReady && function_exists('page_multi_course_ready') && page_multi_course_ready()) {
        set_page_courses($pageId, $courseIds);
    }

    flash('Page saved.');
    redirect('/admin/pages.php');
}

if (isset($_GET['del'])) {
    db()->prepare("DELETE FROM pages WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Page deleted.');
    redirect('/admin/pages.php');
}

$editPage = null;
if (!empty($_GET['edit'])) {
    $stmt = db()->prepare("SELECT * FROM pages WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editPage = $stmt->fetch();
}
$pages = db()->query("SELECT * FROM pages ORDER BY created_at DESC")->fetchAll();
$viewsMap = view_counts_map('page');
?>
<div class="card">
  <h3><?php echo $editPage ? 'Edit Page' : 'Add New Page'; ?></h3>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editPage ? (int)$editPage['id'] : ''; ?>">
    <label>Title</label>
    <input type="text" name="title" value="<?php echo h($editPage['title'] ?? ''); ?>" required>
    <label>Content</label>
    <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Build the page from blocks - add an image, a paragraph, a YouTube video, a text link, or raw HTML, in any order.</p>
    <textarea id="pageContentArea" name="content" style="min-height:200px;font-family:monospace;"><?php echo h($editPage['content'] ?? ''); ?></textarea>
    <?php require __DIR__ . '/_content_builder.php'; ?>
    <script>document.addEventListener('DOMContentLoaded', function(){
      M3DGContentBuilder.attach('pageContentArea', []);
    });</script>

    <h3 style="margin-top:24px;">🎓 Course Curriculum (optional)</h3>
    <?php if ($courseLinkReady): ?>
      <?php
        $pageMultiCourseReady = function_exists('page_multi_course_ready') && page_multi_course_ready();
        $availablePageCourses = all_course_products();
        $linkedPageCourseIds = $pageMultiCourseReady && !empty($editPage['id'])
            ? page_course_ids($editPage['id'])
            : (!empty($editPage['course_id']) ? [(int)$editPage['course_id']] : []);
      ?>
      <label>Include this page in a Course</label>
      <?php if (!$pageMultiCourseReady): ?>
        <div class="flash flash-error" style="margin-top:8px;margin-bottom:8px;">Multi-course selection isn't set up yet — import <code>migration-content-multi-course.sql</code> in phpMyAdmin, then reload this page. Until then, a page can only belong to one course.</div>
        <select name="course_ids[]">
          <option value="">— Not part of a course —</option>
          <?php foreach ($availablePageCourses as $c): ?>
            <option value="<?php echo (int)$c['id']; ?>" <?php echo in_array((int)$c['id'], $linkedPageCourseIds, true) ? 'selected' : ''; ?>><?php echo h($c['title']); ?></option>
          <?php endforeach; ?>
        </select>
      <?php else: ?>
        <div style="display:flex;gap:14px;flex-wrap:wrap;padding:8px 0;">
          <?php foreach ($availablePageCourses as $c): ?>
            <label style="width:auto;display:inline-flex;align-items:center;gap:6px;font-weight:400;">
              <input type="checkbox" name="course_ids[]" value="<?php echo (int)$c['id']; ?>" style="width:auto;"
                <?php echo in_array((int)$c['id'], $linkedPageCourseIds, true) ? 'checked' : ''; ?>>
              <?php echo h($c['title']); ?>
            </label>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Tick every course this should be a locked lesson in: only members who are logged in and have bought <b>at least one of the ticked courses</b> can open it (direct link included) - everyone else sees a "buy this course" message. This lesson page also gets a noindex tag so Google won't rank the paid content itself (each course's own product page stays indexable as usual).</p>
      <label>Order within the course (lower shows first, optional)</label>
      <input type="number" name="course_sort_order" value="<?php echo h($editPage['course_sort_order'] ?? '0'); ?>" style="max-width:140px;">

      <?php if ($gatingReady): ?>
      <label style="margin-top:12px;"><input type="checkbox" name="show_in_course" style="width:auto;display:inline-block;" <?php echo ((int)($editPage['show_in_course'] ?? 1) === 1) ? 'checked' : ''; ?>> Show title &amp; link on the course's public "What's Covered" list</label>
      <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Uncheck to keep this lesson linked to the course (still access-controlled as above) but hide its title/link from the public curriculum list - e.g. a bonus lesson you don't want to advertise upfront.</p>
      <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Per-item show/hide on the course page isn't set up yet - run <code>migration-course-content-gating.sql</code> on your database to enable it.</p>
      <?php endif; ?>

      <?php if ($levelReady):
        $curPageLevel = $editPage['level'] ?? '';
      ?>
      <label style="margin-top:12px;">Level (who this lesson is for)</label>
      <select name="level">
        <option value="">— All levels (no filter) —</option>
        <option value="beginner" <?php echo $curPageLevel==='beginner'?'selected':''; ?>>🔰 Beginner</option>
        <option value="intermediate" <?php echo $curPageLevel==='intermediate'?'selected':''; ?>>🎯 Intermediate</option>
        <option value="advanced" <?php echo $curPageLevel==='advanced'?'selected':''; ?>>🚀 Advanced</option>
      </select>
      <p style="color:var(--muted);font-size:12px;margin-top:-10px;">On the course's public page, a visitor can pick their level and this lesson will only show for that level (leave "All levels" if it's needed by everyone).</p>
      <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Per-lesson Level tagging isn't set up yet - run <code>migration-content-item-level.sql</code> on your database to enable it.</p>
      <?php endif; ?>
    <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Adding pages to a course's curriculum isn't set up yet - run <code>migration-course-content-links.sql</code> (and <code>migration-course-license.sql</code> if not already done) on your database to enable it.</p>
    <?php endif; ?>

    <h3 style="margin-top:24px;">Call-to-Action Button (optional)</h3>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Shown as a button right after the page content.</p>
    <label>Button Text</label>
    <input type="text" name="button_text" value="<?php echo h($editPage['button_text'] ?? ''); ?>" placeholder="e.g. Contact Us">
    <label>Button URL</label>
    <input type="text" name="button_url" value="<?php echo h($editPage['button_url'] ?? ''); ?>" placeholder="/designer.php or https://...">
    <label><input type="checkbox" name="button_new_tab" style="width:auto;display:inline-block;" <?php echo !empty($editPage['button_new_tab']) ? 'checked' : ''; ?>> Open in new tab</label>

    <h3 style="margin-top:24px;">SEO (optional)</h3>
    <label>SEO Title (leave blank to use the page title)</label>
    <input type="text" name="meta_title" value="<?php echo h($editPage['meta_title'] ?? ''); ?>">
    <label>Meta Description</label>
    <textarea name="meta_description" style="min-height:60px;"><?php echo h($editPage['meta_description'] ?? ''); ?></textarea>

    <label style="margin-top:16px;">Status</label>
    <select name="status">
      <option value="draft" <?php echo (($editPage['status'] ?? '')==='draft')?'selected':''; ?>>Draft</option>
      <option value="published" <?php echo (($editPage['status'] ?? '')==='published')?'selected':''; ?>>Published</option>
    </select>
    <label><input type="checkbox" name="show_in_menu" style="width:auto;display:inline-block;" <?php echo (!isset($editPage) || !empty($editPage['show_in_menu'])) ? 'checked' : ''; ?>> Show in top menu</label>
    <?php if ($footerMenuReady): ?>
      <label><input type="checkbox" name="show_in_footer" style="width:auto;display:inline-block;" <?php echo !empty($editPage['show_in_footer']) ? 'checked' : ''; ?>> Show in footer</label>
    <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Want a "Show in footer" tick here too? Import <code>migration-page-footer-menu.sql</code> in phpMyAdmin.</p>
    <?php endif; ?>
    <button type="submit" name="save_page" class="btn">Save Page</button>
    <?php if ($editPage): ?><a href="pages.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <h3>All Pages</h3>
  <table>
    <thead><tr><th>Title</th><th>Status</th><th>In Menu</th><th>In Footer</th><th>Views</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($pages as $p): ?>
      <tr>
        <td>
          <?php echo h($p['title']); ?>
          <?php if ($courseLinkReady): $pageCourses = page_courses_list($p['id']); ?>
          <?php if ($pageCourses): ?>
            <br><small style="color:var(--muted)">🎓 in course<?php echo count($pageCourses) > 1 ? 's' : ''; ?>: <?php echo h(implode(', ', array_column($pageCourses, 'title'))); ?><?php if ($levelReady && !empty($p['level'])): ?> · <?php echo ['beginner'=>'🔰 Beginner','intermediate'=>'🎯 Intermediate','advanced'=>'🚀 Advanced'][$p['level']] ?? ''; ?><?php endif; ?><?php if ($gatingReady && empty($p['show_in_course'])): ?> · <span title="Hidden from the public course list">🙈 hidden on course page</span><?php endif; ?></small>
          <?php endif; ?>
          <?php endif; ?>
        </td>
        <td><span class="badge <?php echo $p['status']==='published'?'badge-active':'badge-expired'; ?>"><?php echo h($p['status']); ?></span></td>
        <td><?php echo $p['show_in_menu'] ? 'Yes' : 'No'; ?></td>
        <td><?php echo $footerMenuReady ? (!empty($p['show_in_footer']) ? 'Yes' : 'No') : '—'; ?></td>
        <td>👁 <?php echo (int)($viewsMap[$p['id']] ?? 0); ?></td>
        <td>
          <a href="<?php echo SITE_URL; ?>/page.php?slug=<?php echo h($p['slug']); ?>" target="_blank" class="btn btn-sm btn-outline">View</a>
          <a href="?edit=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <?php if (function_exists('share_links_ready') && share_links_ready()): ?>
            <a href="share-links.php?type=page&amp;id=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline">🔗 Share</a>
          <?php endif; ?>
          <a href="?del=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this page?');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$pages): ?><tr><td colspan="5">No pages yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
