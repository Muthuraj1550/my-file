<?php
$adminTitle = 'Member Product Access';
require_once __DIR__ . '/_layout_top.php';

if (!shop_tables_ready()) {
    flash('Run migration-products-shop.sql first (adds the products/user_products tables).', 'error');
    redirect('/admin/members.php');
}

$memberId = (int)($_GET['id'] ?? $_POST['mid'] ?? 0);
$stmt = db()->prepare("SELECT * FROM users WHERE id = ? AND role='member'");
$stmt->execute([$memberId]);
$member = $stmt->fetch();
if (!$member) {
    flash('Member not found.', 'error');
    redirect('/admin/members.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_access'])) {
    csrf_check();
    $selected = array_map('intval', $_POST['product_ids'] ?? []);
    $owned = array_column(my_purchased_products($member['id']), 'id');

    // Grant newly ticked products.
    foreach ($selected as $pid) {
        if (!in_array($pid, $owned, true)) {
            grant_product_to_user($member['id'], $pid);
        }
    }
    // Revoke unticked ones that were directly granted (course-inherited access,
    // i.e. items included in an owned course, isn't a row here and can't be unticked directly).
    foreach ($owned as $pid) {
        if (!in_array($pid, $selected, true)) {
            revoke_product_from_user($member['id'], $pid);
        }
    }
    flash('Product access updated for ' . $member['name'] . '.');
    redirect('/admin/member-products.php?id=' . $member['id']);
}

$allProducts = all_products(false);
$ownedIds = array_column(my_purchased_products($member['id']), 'id');
?>
<p><a href="members.php">&larr; Back to Members</a></p>
<div class="card" style="max-width:640px;">
  <h3 style="margin-top:0;">🔓 Product / Course Access — <?php echo h($member['name']); ?></h3>
  <p style="color:var(--muted);font-size:13px;">Tick everything this member should have access to (files, software, or a Course). Ticking a <b>Course</b> also unlocks every item that Course covers (lessons + any product marked "Include this in a Course"). Save applies changes immediately — no payment involved.</p>

  <?php if (!$allProducts): ?>
    <p>No products yet — add some in <a href="products.php">Products (Shop)</a> first.</p>
  <?php else: ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="mid" value="<?php echo (int)$member['id']; ?>">
      <div style="max-height:420px;overflow-y:auto;border:1px solid var(--border,#27324a);border-radius:8px;padding:10px 14px;margin:12px 0;">
        <?php foreach ($allProducts as $p): $checked = in_array((int)$p['id'], $ownedIds, true); ?>
          <label style="display:block;font-size:14px;font-weight:400;margin:7px 0;">
            <input type="checkbox" name="product_ids[]" value="<?php echo (int)$p['id']; ?>" style="width:auto;margin-right:8px;" <?php echo $checked ? 'checked' : ''; ?>>
            <?php echo $p['type'] === 'course' ? '🎓' : '🗂️'; ?> <?php echo h($p['title']); ?>
            <?php if ($p['status'] !== 'published'): ?><span style="color:var(--muted);font-size:12px;">(draft)</span><?php endif; ?>
            <?php if ((float)$p['price'] > 0): ?><span style="color:var(--muted);font-size:12px;"> — ₹<?php echo number_format($p['price'],0); ?></span><?php endif; ?>
          </label>
        <?php endforeach; ?>
      </div>
      <button type="submit" name="save_access" class="btn">Save Access</button>
    </form>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
