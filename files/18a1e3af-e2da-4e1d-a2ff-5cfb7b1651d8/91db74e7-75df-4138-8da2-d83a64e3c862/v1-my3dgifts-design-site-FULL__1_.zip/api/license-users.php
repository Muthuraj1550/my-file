<?php
/**
 * User list for an external tool site. Server-to-server only.
 *
 * POST/GET: api_key (that site's key, or APP_SECRET), site = <api id> | all
 * Response: { ok:true, count:N, users:[ { username, user_name, email, products[],
 *             sites:{ "litho":"product", "balloon":"manual" }, status,
 *             created_at, last_verified_at } ], sites:[ {site_key,name} ] }
 */
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$data = json_decode((string)file_get_contents('php://input'), true) ?: ($_POST + $_GET);

$site = trim((string)($data['site'] ?? ''));
$auth = tool_site_auth((string)($data['api_key'] ?? ''), $site !== '' ? $site : null);
if (!$auth) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => 'Invalid api_key (or site mismatch)']);
    exit;
}
if ($site === '') { $site = $auth['site']; }
if (!$auth['master'] && $site !== $auth['site']) { $site = $auth['site']; }

if (!course_license_ready()) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'reason' => 'Run migration-course-license.sql first']);
    exit;
}

$users = site_users_list($site);
$sites = array_map(function ($s) { return ['site_key' => $s['site_key'], 'name' => $s['name']]; }, tool_sites_all(true));

echo json_encode(['ok' => true, 'site' => $site, 'count' => count($users), 'users' => $users, 'sites' => $sites]);
