<?php
/**
 * Login check for ANY registered tool site (Litho Studio, Main Editor,
 * or any site you add in Admin -> Tool Sites & Access).
 *
 * Request (POST JSON, or POST/GET fields):
 *   api_key   = that site's API key (Admin -> Tool Sites & Access)
 *               (APP_SECRET also works as a master key)
 *   site      = that site's API ID (e.g. 'litho'); optional if the api_key
 *               already belongs to one site
 *   username  = what the buyer typed on your tool's login screen
 *   password  = what the buyer typed
 *
 * Response (JSON):
 *   { "valid": true,  "product": "...", "user_name": "...", "site": "litho", "source": "product|manual" }
 *   { "valid": false, "reason": "..." }
 *
 * Call this server-side only — never from browser JS (api_key would leak).
 */
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) { $data = $_POST + $_GET; }

$apiKey   = (string)($data['api_key'] ?? '');
$site     = trim((string)($data['site'] ?? ''));
$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

$auth = tool_site_auth($apiKey, $site !== '' ? $site : null);
if (!$auth) {
    http_response_code(403);
    echo json_encode(['valid' => false, 'reason' => 'Invalid api_key (or site mismatch)']);
    exit;
}
if ($site === '' || $site === 'all') { $site = $auth['site']; }
if ($site === '' || $site === 'all') {
    http_response_code(400);
    echo json_encode(['valid' => false, 'reason' => 'site (API ID) required with the master key']);
    exit;
}

if ($username === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['valid' => false, 'reason' => 'Missing username or password']);
    exit;
}

if (!course_license_ready()) {
    http_response_code(500);
    echo json_encode(['valid' => false, 'reason' => 'Licensing not set up yet (run migration-course-license.sql)']);
    exit;
}

$hit = verify_site_login($username, $password, $site);
if (!$hit) {
    echo json_encode(['valid' => false, 'reason' => 'No matching active access for this site']);
    exit;
}

echo json_encode([
    'valid'     => true,
    'product'   => $hit['product'],
    'user_name' => $hit['name'],
    'username'  => $hit['username'],
    'site'      => $hit['site'],
    'source'    => $hit['source'],
    'plan'      => site_login_plan_info($hit['user_id'] ?? null),
]);
