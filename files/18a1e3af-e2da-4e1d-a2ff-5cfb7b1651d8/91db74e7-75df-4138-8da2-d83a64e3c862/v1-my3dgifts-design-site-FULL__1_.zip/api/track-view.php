<?php
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) { $data = $_POST; }

$viewId  = $data['view_id'] ?? null;
$type    = $data['type'] ?? null;
$seconds = $data['seconds'] ?? 0;

if (!$viewId || !in_array($type, ['post', 'page', 'designer', 'product'], true)) {
    http_response_code(400);
    echo json_encode(['ok' => false]);
    exit;
}

update_view_duration($viewId, $type, $seconds);
echo json_encode(['ok' => true]);
