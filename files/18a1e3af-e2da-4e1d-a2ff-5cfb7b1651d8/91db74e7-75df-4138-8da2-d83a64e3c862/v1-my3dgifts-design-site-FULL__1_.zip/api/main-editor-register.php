<?php
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

// Called SERVER-TO-SERVER by Main Editor right after someone registers
// there (only when Main Editor's "sync_registration_to_course_site" setting
// is ON). Verified with the same api_key both sides already use for the
// course-login / activate-plan handoff (main_editor_shared_secret()).

function main_editor_register_log($line) {
    try {
        $dir = __DIR__ . '/../logs';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        @file_put_contents($dir . '/main-editor-register.log', '[' . date('Y-m-d H:i:s') . '] ' . $line . "\n", FILE_APPEND | LOCK_EX);
    } catch (Throwable $e) { /* never block on logging */ }
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) $data = $_POST;

$name     = trim((string) ($data['name'] ?? ''));
$email    = trim((string) ($data['email'] ?? ''));
$phone    = trim((string) ($data['phone'] ?? ''));
$address  = trim((string) ($data['address'] ?? ''));
$password = (string) ($data['password_plain'] ?? '');
$ts       = (int) ($data['ts'] ?? 0);
$sig      = (string) ($data['sig'] ?? '');

if ($name === '' || $email === '') {
    main_editor_register_log("REJECTED: missing name/email");
    echo json_encode(['ok' => false, 'msg' => 'Missing fields']);
    exit;
}
if (abs(time() - $ts) > 900) {
    main_editor_register_log("REJECTED: expired request for email=$email");
    echo json_encode(['ok' => false, 'msg' => 'Request expired']);
    exit;
}

$sigParams = ['name' => $name, 'email' => $email, 'phone' => $phone, 'address' => $address, 'password_plain' => $password, 'ts' => $ts];
if (!main_editor_verify_sig($sigParams, $sig)) {
    main_editor_register_log("REJECTED: invalid signature for email=$email — check Main Editor's Course Site API key matches this site's Tool Sites & Access key for main_editor");
    http_response_code(403);
    echo json_encode(['ok' => false, 'msg' => 'Invalid signature']);
    exit;
}

try {
    db()->query("SELECT 1 FROM main_editor_registrations LIMIT 1");
} catch (Throwable $e) {
    main_editor_register_log("REJECTED: main_editor_registrations table missing — import migration-main-editor-registrations.sql");
    echo json_encode(['ok' => false, 'msg' => 'Table not set up yet — import migration-main-editor-registrations.sql']);
    exit;
}

$stmt = db()->prepare("SELECT id FROM main_editor_registrations WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$existing = $stmt->fetch();

if ($existing) {
    db()->prepare("UPDATE main_editor_registrations SET name=?, phone=?, address=?, password_plain=? WHERE id=?")
        ->execute([$name, $phone, $address, $password, $existing['id']]);
} else {
    db()->prepare("INSERT INTO main_editor_registrations (name, email, phone, address, password_plain) VALUES (?,?,?,?,?)")
        ->execute([$name, $email, $phone, $address, $password]);
}

main_editor_register_log("OK: recorded registration for email=$email");
echo json_encode(['ok' => true]);
