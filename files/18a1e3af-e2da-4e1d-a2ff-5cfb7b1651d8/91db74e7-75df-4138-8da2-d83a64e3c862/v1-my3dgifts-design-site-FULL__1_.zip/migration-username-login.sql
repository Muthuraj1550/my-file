-- =========================================================
--  MIGRATION: Username Login (Admin > Members > Add New Member)
--  Run this in phpMyAdmin. Safe on an existing site - it only
--  ADDS one nullable column, no existing data is touched.
-- =========================================================

ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(60) DEFAULT NULL AFTER email;
ALTER TABLE users ADD UNIQUE KEY IF NOT EXISTS username (username);

-- ⚠ If "IF NOT EXISTS" gives an error on an older MySQL/MariaDB version,
-- remove that phrase from the relevant line and run it again (skip the
-- UNIQUE KEY line if it says the key already exists).
