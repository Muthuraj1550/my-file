-- =========================================================
--  My3DGifts Standalone Platform - Course Content Gating
--
--  Adds a per-item "Show on course page" toggle for posts/pages
--  linked to a course (migration-course-content-links.sql), so the
--  admin can keep an item inside a course (for access control) while
--  hiding its title/link from the public "What's Covered" list.
--
--  Import this file in phpMyAdmin AFTER migration-course-content-links.sql.
--  Safe on a live site - only ADDS new columns, no existing data is
--  touched. Default is 1 (shown), so every existing curriculum item
--  keeps showing exactly as before until you uncheck it in
--  Admin > Posts / Admin > Pages.
-- =========================================================

SET NAMES utf8mb4;

ALTER TABLE posts ADD COLUMN IF NOT EXISTS show_in_course TINYINT(1) NOT NULL DEFAULT 1 AFTER course_sort_order;
ALTER TABLE pages ADD COLUMN IF NOT EXISTS show_in_course TINYINT(1) NOT NULL DEFAULT 1 AFTER course_sort_order;

-- NOTE: if your MySQL version is older than 8.0 / MariaDB 10.5 and the
-- "ADD COLUMN IF NOT EXISTS" lines above give a syntax error, just remove
-- the words "IF NOT EXISTS" from those two lines and run again (safe to
-- re-run either way, it's non-destructive).
--
-- What this enables:
--  1. Posts/Pages that are part of a course (course_id set) are no longer
--     openly readable just by guessing/visiting their URL - only members
--     who are logged in AND own that course can see the actual content.
--     Everyone else sees a "buy this course to unlock" message instead.
--  2. Those same posts/pages get a noindex/nofollow meta tag automatically,
--     so Google won't index or rank the paid lesson content itself. Course
--     PRODUCT pages (the sales page, product.php) are NOT affected - they
--     stay indexable so visitors can still find and buy the course via
--     search.
--  3. Each curriculum item (post/page) now has a "Show on course page"
--     checkbox in its admin editor - uncheck it to keep the item linked to
--     the course (still access-controlled) but hide its title/link from
--     the public "What's Covered" list on the course page.
-- =========================================================
