-- =========================================================
--  My3DGifts Course Level Filter (Beginner / Intermediate / Advanced)
--  Import this file in phpMyAdmin AFTER migration-products-shop.sql.
--  Safe on a live site - only ADDS a column, no existing data
--  is touched or deleted. Default is NULL (no level set), so
--  every existing course keeps showing exactly as before until
--  you open it in Admin > Courses and pick a level.
-- =========================================================

SET NAMES utf8mb4;

ALTER TABLE products
  ADD COLUMN IF NOT EXISTS level ENUM('beginner','intermediate','advanced') DEFAULT NULL AFTER type;

-- NOTE: if your MySQL version is older than 8.0 / MariaDB 10.5 and the
-- "ADD COLUMN IF NOT EXISTS" line above gives a syntax error, just remove
-- the words "IF NOT EXISTS" and run again (it's fine to run once).
