-- =========================================================
--  My3DGifts Standalone Platform - Digital Products / Shop
--  Import this file in phpMyAdmin AFTER db.sql (safe on an
--  existing site - it only ADDS new tables/columns, no
--  existing data is touched or deleted).
-- =========================================================

SET NAMES utf8mb4;

-- ---------- PRODUCTS (digital files / video courses) ----------
CREATE TABLE IF NOT EXISTS products (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    title           VARCHAR(200) NOT NULL,
    slug            VARCHAR(220) NOT NULL,
    type            ENUM('file','course','software','bundle') NOT NULL DEFAULT 'file',
    category        VARCHAR(100) DEFAULT NULL,
    short_desc      VARCHAR(300) DEFAULT NULL,
    description     TEXT,
    thumbnail       VARCHAR(500) DEFAULT NULL,
    price           DECIMAL(10,2) NOT NULL DEFAULT 0,
    sale_price      DECIMAL(10,2) DEFAULT NULL,     -- NULL = no discount shown
    delivery_link   VARCHAR(500) DEFAULT NULL,      -- MediaFire / Google Drive / own uploaded file URL
    delivery_note   VARCHAR(500) DEFAULT NULL,      -- e.g. "Password: 1234" shown next to the link
    featured        TINYINT(1) NOT NULL DEFAULT 0,
    status          ENUM('draft','published') NOT NULL DEFAULT 'published',
    sort_order      INT NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- PRODUCT ORDERS (Cashfree, one order per purchase) ----------
CREATE TABLE IF NOT EXISTS product_orders (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED NOT NULL,
    product_id      INT UNSIGNED NOT NULL,
    cf_order_id     VARCHAR(100) NOT NULL,
    amount          DECIMAL(10,2) NOT NULL,
    status          ENUM('created','paid','failed') NOT NULL DEFAULT 'created',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY cf_order_id (cf_order_id),
    KEY user_id (user_id),
    KEY product_id (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- USER PRODUCTS (access grants - what a member actually owns) ----------
CREATE TABLE IF NOT EXISTS user_products (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED NOT NULL,
    product_id      INT UNSIGNED NOT NULL,
    order_id        INT UNSIGNED DEFAULT NULL,
    granted_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY user_product (user_id, product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- CONTACT / ENQUIRY FORM SUBMISSIONS ----------
CREATE TABLE IF NOT EXISTS form_submissions (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name            VARCHAR(150) NOT NULL,
    email           VARCHAR(190) DEFAULT NULL,
    phone           VARCHAR(30)  DEFAULT NULL,
    message         TEXT,
    product_id      INT UNSIGNED DEFAULT NULL,
    source          VARCHAR(50) NOT NULL DEFAULT 'contact',
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- MENU VISIBILITY (show/hide a menu link based on membership/purchase) ----------
ALTER TABLE menu_items ADD COLUMN IF NOT EXISTS visibility ENUM('everyone','members_only','buyers_only') NOT NULL DEFAULT 'everyone';
ALTER TABLE menu_items ADD COLUMN IF NOT EXISTS required_product_id INT UNSIGNED DEFAULT NULL;

-- ---------- Seed a "Shop" link in the top menu (safe - only runs if not already there) ----------
INSERT INTO menu_items (label, url, sort_order, is_active, visibility)
SELECT 'Shop', '/products.php', 0, 1, 'everyone'
WHERE NOT EXISTS (SELECT 1 FROM menu_items WHERE url = '/products.php');

-- ---------- Point the homepage hero buttons at the Shop (only if still on the old default text - won't touch anything you've already customized in Admin > Homepage) ----------
UPDATE settings SET setting_value = 'Shop Now'      WHERE setting_key = 'home_hero_btn1_text' AND setting_value = 'Open 3D Designer';
UPDATE settings SET setting_value = '/products.php' WHERE setting_key = 'home_hero_btn1_url'  AND setting_value = '/designer.php';
UPDATE settings SET setting_value = 'Open 3D Designer' WHERE setting_key = 'home_hero_btn2_text' AND setting_value = 'View Plans';
UPDATE settings SET setting_value = '/designer.php'    WHERE setting_key = 'home_hero_btn2_url'  AND setting_value = '/membership.php';

-- NOTE: if your MySQL version is older than 8.0 / MariaDB 10.5 and the
-- "ADD COLUMN IF NOT EXISTS" lines above give a syntax error, just remove
-- the words "IF NOT EXISTS" from those two lines and run again.
