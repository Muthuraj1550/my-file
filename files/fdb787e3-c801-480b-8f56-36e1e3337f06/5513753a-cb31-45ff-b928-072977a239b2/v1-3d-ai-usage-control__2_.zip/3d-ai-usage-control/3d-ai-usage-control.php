<?php
/**
 * Plugin Name: 3D AI Usage Control
 * Plugin URI:  https://my3dgifts.com
 * Description: 3D Design Tool-ல் AI generate limit மற்றும் payment system. Membership plan + Per-user custom limit support.
 * Version:     2.1.0
 * Author:      My 3D Gifts Pro
 * Text Domain: 3d-ai-usage
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'AI_USAGE_VERSION', '2.1.0' );
define( 'AI_USAGE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AI_USAGE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// =====================================================================
// DATABASE TABLE SETUP
// =====================================================================
register_activation_hook( __FILE__, 'ai_usage_create_table' );

function ai_usage_create_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'ai_usage_log';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id     BIGINT(20) UNSIGNED NOT NULL,
        used_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        prompt      TEXT,
        ip_address  VARCHAR(45),
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY used_at (used_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );

    // Default options
    $defaults = [
        'ai_usage_plans'           => [],
        'ai_usage_payment_url'     => '',
        'ai_usage_payment_btn_txt' => 'Upgrade & Get More Designs',
        'ai_usage_limit_msg'       => 'உங்கள் AI Design limit முடிந்தது! மேலும் designs உருவாக்க upgrade செய்யுங்கள்.',
        'ai_usage_reset_period'    => 'monthly',
        'ai_usage_proxy_url'       => '',
        'ai_usage_default_limit'   => 5,
        'ai_usage_guest_limit'     => 0,
    ];
    foreach ( $defaults as $key => $val ) {
        if ( get_option( $key ) === false ) {
            update_option( $key, $val );
        }
    }
}

// =====================================================================
// ADMIN MENU
// =====================================================================
add_action( 'admin_menu', 'ai_usage_admin_menu' );

function ai_usage_admin_menu() {
    add_menu_page(
        'AI Usage Control',
        'AI Usage Control',
        'manage_options',
        'ai-usage-control',
        'ai_usage_admin_page',
        'dashicons-chart-bar',
        56
    );
    add_submenu_page(
        'ai-usage-control',
        'Settings',
        'Settings',
        'manage_options',
        'ai-usage-control',
        'ai_usage_admin_page'
    );
    add_submenu_page(
        'ai-usage-control',
        'Per-User Limits',
        '👤 Per-User Limits',
        'manage_options',
        'ai-usage-user-limits',
        'ai_usage_user_limits_page'
    );
    add_submenu_page(
        'ai-usage-control',
        'Usage Reports',
        'Usage Reports',
        'manage_options',
        'ai-usage-reports',
        'ai_usage_reports_page'
    );
    add_submenu_page(
        'ai-usage-control',
        'Reset User Usage',
        'Reset Usage',
        'manage_options',
        'ai-usage-reset',
        'ai_usage_reset_page'
    );
}

// =====================================================================
// ADMIN SETTINGS SAVE
// =====================================================================
add_action( 'admin_init', 'ai_usage_save_settings' );

function ai_usage_save_settings() {
    if ( ! isset( $_POST['ai_usage_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['ai_usage_nonce'], 'ai_usage_save' ) ) return;
    if ( ! current_user_can( 'manage_options' ) ) return;

    update_option( 'ai_usage_payment_url',     sanitize_url( $_POST['ai_usage_payment_url'] ?? '' ) );
    update_option( 'ai_usage_payment_btn_txt', sanitize_text_field( $_POST['ai_usage_payment_btn_txt'] ?? 'Upgrade Now' ) );
    update_option( 'ai_usage_limit_msg',       sanitize_textarea_field( $_POST['ai_usage_limit_msg'] ?? '' ) );
    update_option( 'ai_usage_reset_period',    sanitize_text_field( $_POST['ai_usage_reset_period'] ?? 'monthly' ) );
    update_option( 'ai_usage_proxy_url',       sanitize_text_field( $_POST['ai_usage_proxy_url'] ?? '' ) );
    update_option( 'ai_usage_default_limit',   absint( $_POST['ai_usage_default_limit'] ?? 5 ) );
    update_option( 'ai_usage_guest_limit',     absint( $_POST['ai_usage_guest_limit'] ?? 0 ) );

    // Role-based plans
    global $wp_roles;
    $plans = [];
    foreach ( $wp_roles->get_names() as $role_id => $role_name ) {
        $key = 'plan_' . $role_id;
        if ( isset( $_POST[ $key ] ) ) {
            $plans[ $role_id ] = absint( $_POST[ $key ] );
        }
    }
    update_option( 'ai_usage_plans', $plans );

    add_action( 'admin_notices', function() {
        echo '<div class="notice notice-success is-dismissible"><p>✅ AI Usage settings saved successfully!</p></div>';
    });
}

// =====================================================================
// ADMIN SETTINGS PAGE
// =====================================================================
function ai_usage_admin_page() {
    global $wp_roles;
    $plans       = get_option( 'ai_usage_plans', [] );
    $pay_url     = get_option( 'ai_usage_payment_url', '' );
    $pay_btn     = get_option( 'ai_usage_payment_btn_txt', 'Upgrade Now' );
    $limit_msg   = get_option( 'ai_usage_limit_msg', '' );
    $reset_p     = get_option( 'ai_usage_reset_period', 'monthly' );
    $proxy_url   = get_option( 'ai_usage_proxy_url', '' );
    $def_limit   = get_option( 'ai_usage_default_limit', 5 );
    $guest_limit = get_option( 'ai_usage_guest_limit', 0 );
    ?>
    <div class="wrap">
      <h1 style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:28px;">🎨</span> AI Usage Control Panel
      </h1>
      <p style="color:#666;">3D Design Tool-ல் AI generate usage-ஐ membership plan அடிப்படையில் control செய்யுங்கள்.</p>

      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:15px;margin:20px 0;">
        <?php
        global $wpdb;
        $table     = $wpdb->prefix . 'ai_usage_log';
        $total     = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $today     = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE DATE(used_at) = CURDATE()");
        $this_month = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE MONTH(used_at) = MONTH(CURDATE()) AND YEAR(used_at) = YEAR(CURDATE())");
        ?>
        <div style="background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:20px;text-align:center;">
          <div style="font-size:32px;font-weight:bold;color:#2271b1;"><?php echo esc_html($total); ?></div>
          <div style="color:#666;margin-top:5px;">Total AI Generates</div>
        </div>
        <div style="background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:20px;text-align:center;">
          <div style="font-size:32px;font-weight:bold;color:#00a32a;"><?php echo esc_html($today); ?></div>
          <div style="color:#666;margin-top:5px;">Today's Generates</div>
        </div>
        <div style="background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:20px;text-align:center;">
          <div style="font-size:32px;font-weight:bold;color:#d63638;"><?php echo esc_html($this_month); ?></div>
          <div style="color:#666;margin-top:5px;">This Month</div>
        </div>
      </div>

      <form method="post">
        <?php wp_nonce_field( 'ai_usage_save', 'ai_usage_nonce' ); ?>

        <!-- SECTION 1: Proxy & API -->
        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;margin-bottom:20px;">
          <h2 style="margin-top:0;border-bottom:2px solid #2271b1;padding-bottom:10px;">⚙️ 1. Gemini API Settings</h2>
          <table class="form-table">
            <tr>
              <th><label>🔑 Gemini API Key</label></th>
              <td>
                <input type="text" name="ai_usage_proxy_url" value="<?php echo esc_attr($proxy_url); ?>" class="regular-text" placeholder="AIzaSy...உங்கள் Gemini API Key இங்கே">
                <p class="description">
                  உங்கள் Gemini API Key இங்கே paste செய்யுங்கள் (<code>AIzaSy...</code> என தொடங்கும்).<br>
                  👉 <a href="https://aistudio.google.com/app/apikey" target="_blank">https://aistudio.google.com/app/apikey</a> இல் free-ஆக எடுக்கலாம்.<br>
                  <strong style="color:#2271b1;">இந்த key HTML tool-ல் GEMINI_API_KEY-ஐ automatically override செய்யும்.</strong>
                </p>
              </td>
            </tr>
          </table>
        </div>

        <!-- SECTION 2: Usage Limits per Role -->
        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;margin-bottom:20px;">
          <h2 style="margin-top:0;border-bottom:2px solid #2271b1;padding-bottom:10px;">📊 2. Membership Plan Limits</h2>
          <p style="color:#666;">ஒவ்வொரு WordPress role-க்கும் எத்தனை AI designs generate செய்யலாம் என்பதை set செய்யுங்கள்.</p>
          <table class="form-table">
            <tr>
              <th><label>Guest (Not Logged In)</label></th>
              <td>
                <input type="number" name="ai_usage_guest_limit" value="<?php echo esc_attr($guest_limit); ?>" min="0" max="9999" style="width:100px;">
                <span style="color:#666;margin-left:10px;">designs (0 = no access)</span>
              </td>
            </tr>
            <?php foreach ( $wp_roles->get_names() as $role_id => $role_name ): 
                $current_limit = isset($plans[$role_id]) ? $plans[$role_id] : $def_limit;
            ?>
            <tr>
              <th><label><?php echo esc_html($role_name); ?> <small style="color:#999;">(<?php echo esc_html($role_id); ?>)</small></label></th>
              <td>
                <input type="number" name="plan_<?php echo esc_attr($role_id); ?>" value="<?php echo esc_attr($current_limit); ?>" min="0" max="99999" style="width:100px;">
                <span style="color:#666;margin-left:10px;">designs per
                  <?php
                  $period = get_option('ai_usage_reset_period','monthly');
                  echo $period === 'daily' ? 'day' : ($period === 'weekly' ? 'week' : 'month');
                  ?>
                </span>
                <?php if ($role_id === 'administrator'): ?>
                  <span style="background:#e7f5ea;color:#00a32a;padding:2px 8px;border-radius:4px;font-size:12px;margin-left:5px;">Recommended: 99999 (unlimited)</span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
            <tr>
              <th><label>Default Limit (unlisted roles)</label></th>
              <td>
                <input type="number" name="ai_usage_default_limit" value="<?php echo esc_attr($def_limit); ?>" min="0" max="99999" style="width:100px;">
                <span style="color:#666;margin-left:10px;">designs</span>
              </td>
            </tr>
          </table>
        </div>

        <!-- SECTION 3: Reset Period -->
        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;margin-bottom:20px;">
          <h2 style="margin-top:0;border-bottom:2px solid #2271b1;padding-bottom:10px;">🔄 3. Usage Reset Period</h2>
          <table class="form-table">
            <tr>
              <th><label>Limit Reset Period</label></th>
              <td>
                <select name="ai_usage_reset_period" style="width:200px;">
                  <option value="daily"   <?php selected($reset_p,'daily'); ?>>Daily (Every day)</option>
                  <option value="weekly"  <?php selected($reset_p,'weekly'); ?>>Weekly (Every 7 days)</option>
                  <option value="monthly" <?php selected($reset_p,'monthly'); ?>>Monthly (Every 30 days)</option>
                  <option value="yearly"  <?php selected($reset_p,'yearly'); ?>>Yearly (Every 365 days)</option>
                  <option value="never"   <?php selected($reset_p,'never'); ?>>Never (Lifetime limit)</option>
                </select>
                <p class="description">இந்த period முடிந்தால் user-ன் usage count reset ஆகும்.</p>
              </td>
            </tr>
          </table>
        </div>

        <!-- SECTION 4: Payment Settings -->
        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;margin-bottom:20px;">
          <h2 style="margin-top:0;border-bottom:2px solid #2271b1;padding-bottom:10px;">💳 4. Payment & Upgrade Settings</h2>
          <p style="color:#666;">Limit முடிந்தவர்களுக்கு காட்டப்படும் payment options.</p>
          <table class="form-table">
            <tr>
              <th><label>Payment / Upgrade URL</label></th>
              <td>
                <input type="url" name="ai_usage_payment_url" value="<?php echo esc_url($pay_url); ?>" class="large-text" placeholder="https://yoursite.com/upgrade">
                <p class="description">User limit தாண்டியதும் இந்த URL-க்கு redirect ஆவார்கள் / button காட்டப்படும்.</p>
              </td>
            </tr>
            <tr>
              <th><label>Payment Button Text</label></th>
              <td>
                <input type="text" name="ai_usage_payment_btn_txt" value="<?php echo esc_attr($pay_btn); ?>" class="regular-text">
              </td>
            </tr>
            <tr>
              <th><label>Limit Reached Message</label></th>
              <td>
                <textarea name="ai_usage_limit_msg" rows="3" class="large-text"><?php echo esc_textarea($limit_msg); ?></textarea>
                <p class="description">User limit மீறியதும் காட்டப்படும் message.</p>
              </td>
            </tr>
          </table>
        </div>

        <?php submit_button( '💾 Save All Settings', 'primary large' ); ?>
      </form>

      <!-- Quick Info Box -->
      <div style="background:#f0f6fc;border:1px solid #c3d9f7;border-radius:8px;padding:20px;margin-top:20px;">
        <h3 style="margin-top:0;">📋 Shortcode Usage</h3>
        <p>3D Design tool-ஐ page-ல் embed செய்ய இந்த shortcode-ஐ பயன்படுத்துங்கள்:</p>
        <code style="background:#fff;padding:8px 12px;border-radius:4px;border:1px solid #ddd;display:inline-block;font-size:14px;">[design_engine_ui]</code>
        <p style="margin-top:15px;">AI Usage status widget மட்டும் show செய்ய:</p>
        <code style="background:#fff;padding:8px 12px;border-radius:4px;border:1px solid #ddd;display:inline-block;font-size:14px;">[ai_usage_status]</code>
      </div>
    </div>
    <?php
}

// =====================================================================
// USAGE REPORTS PAGE
// =====================================================================
function ai_usage_reports_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'ai_usage_log';

    // Top users
    $top_users = $wpdb->get_results(
        "SELECT user_id, COUNT(*) as cnt, MAX(used_at) as last_used 
         FROM $table 
         GROUP BY user_id 
         ORDER BY cnt DESC 
         LIMIT 20"
    );
    ?>
    <div class="wrap">
      <h1>📊 AI Usage Reports</h1>
      <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;">
        <h2>Top Users by AI Usage</h2>
        <table class="wp-list-table widefat fixed striped">
          <thead>
            <tr>
              <th>User</th>
              <th>Role</th>
              <th>Limit</th>
              <th>Used (This Period)</th>
              <th>Remaining</th>
              <th>Last Used</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ( $top_users as $row ):
                $user   = get_user_by( 'id', $row->user_id );
                if ( ! $user ) continue;
                $limit  = ai_usage_get_user_limit( $row->user_id );
                $used   = ai_usage_get_user_count( $row->user_id );
                $remain = max( 0, $limit - $used );
            ?>
            <tr>
              <td><?php echo esc_html($user->display_name); ?> <small style="color:#999;">&lt;<?php echo esc_html($user->user_email); ?>&gt;</small></td>
              <td><?php echo esc_html( implode(', ', $user->roles) ); ?></td>
              <td>
                <?php 
                $info = ai_usage_get_custom_limit_info($row->user_id);
                if ($info['has_custom']): ?>
                  <span style="background:#fef9c3;border:1px solid #fde047;padding:2px 6px;border-radius:4px;font-size:12px;">⚡ Custom: <?php echo esc_html($info['limit']); ?></span>
                <?php else: ?>
                  <?php echo $limit >= 99999 ? '<span style="color:green">Unlimited</span>' : esc_html($limit); ?>
                <?php endif; ?>
              </td>
              <td><?php echo esc_html($used); ?></td>
              <td>
                <?php if ($limit >= 99999): ?>
                  <span style="color:green">∞</span>
                <?php elseif ($remain <= 0): ?>
                  <span style="color:red;font-weight:bold;">0 (Limit Reached)</span>
                <?php else: ?>
                  <span style="color:<?php echo $remain < 3 ? 'orange' : 'green'; ?>;"><?php echo esc_html($remain); ?></span>
                <?php endif; ?>
              </td>
              <td><?php echo esc_html( date('d M Y H:i', strtotime($row->last_used)) ); ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if ( empty($top_users) ): ?>
            <tr><td colspan="6" style="text-align:center;color:#999;padding:20px;">No usage data yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;margin-top:20px;">
        <h2>Recent Activity (Last 50)</h2>
        <table class="wp-list-table widefat fixed striped">
          <thead>
            <tr><th>User</th><th>Time</th><th>Prompt (excerpt)</th><th>IP</th></tr>
          </thead>
          <tbody>
            <?php
            $recent = $wpdb->get_results("SELECT * FROM $table ORDER BY used_at DESC LIMIT 50");
            foreach ( $recent as $r ):
                $user = get_user_by('id', $r->user_id);
            ?>
            <tr>
              <td><?php echo $user ? esc_html($user->display_name) : 'User #' . $r->user_id; ?></td>
              <td><?php echo esc_html( date('d M Y H:i', strtotime($r->used_at)) ); ?></td>
              <td><?php echo esc_html( mb_substr($r->prompt, 0, 80) ); ?>...</td>
              <td><?php echo esc_html($r->ip_address); ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if ( empty($recent) ): ?>
            <tr><td colspan="4" style="text-align:center;color:#999;padding:20px;">No activity yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php
}

// =====================================================================
// RESET USER USAGE PAGE
// =====================================================================
function ai_usage_reset_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'ai_usage_log';
    $msg   = '';

    if ( isset($_POST['reset_nonce']) && wp_verify_nonce($_POST['reset_nonce'], 'ai_reset_usage') ) {
        if ( isset($_POST['reset_all']) ) {
            $wpdb->query("TRUNCATE TABLE $table");
            $msg = '✅ All usage data has been reset!';
        } elseif ( isset($_POST['reset_user_id']) && intval($_POST['reset_user_id']) > 0 ) {
            $uid = intval($_POST['reset_user_id']);
            $wpdb->delete($table, ['user_id' => $uid]);
            $user = get_user_by('id', $uid);
            $msg  = '✅ Usage reset for: ' . ($user ? $user->display_name : "User #$uid");
        }
    }
    ?>
    <div class="wrap">
      <h1>🔄 Reset User Usage</h1>
      <?php if ($msg): ?>
        <div class="notice notice-success"><p><?php echo esc_html($msg); ?></p></div>
      <?php endif; ?>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;">
          <h2>Reset Specific User</h2>
          <form method="post">
            <?php wp_nonce_field('ai_reset_usage','reset_nonce'); ?>
            <table class="form-table">
              <tr>
                <th>User ID or Email</th>
                <td>
                  <input type="text" name="reset_user_email_input" id="reset_user_email_input" class="regular-text" placeholder="Email or User ID">
                  <input type="hidden" name="reset_user_id" id="reset_user_id_hidden">
                  <button type="button" onclick="resolveUser()" class="button">Find User</button>
                  <div id="user_found_info" style="margin-top:8px;color:#2271b1;"></div>
                </td>
              </tr>
            </table>
            <button type="submit" class="button button-primary" onclick="document.getElementById('reset_user_id_hidden').value = document.getElementById('resolved_uid').value || ''">Reset This User</button>
          </form>
        </div>

        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;">
          <h2 style="color:#d63638;">⚠️ Reset All Users</h2>
          <p>இது அனைத்து users-ன் usage data-வையும் delete செய்யும். Undo முடியாது!</p>
          <form method="post" onsubmit="return confirm('Are you sure? This will delete ALL usage records!');">
            <?php wp_nonce_field('ai_reset_usage','reset_nonce'); ?>
            <input type="hidden" name="reset_all" value="1">
            <button type="submit" class="button" style="background:#d63638;color:#fff;border-color:#d63638;">Delete All Usage Data</button>
          </form>
        </div>
      </div>
    </div>

    <script>
    var resolved_uid = 0;
    function resolveUser() {
        var val = document.getElementById('reset_user_email_input').value;
        if (!val) return;
        fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=ai_find_user&q=' + encodeURIComponent(val) + '&_wpnonce=<?php echo wp_create_nonce('ai_find_user'); ?>')
            .then(r => r.json())
            .then(d => {
                if (d.success) {
                    document.getElementById('user_found_info').innerHTML = '✅ Found: <strong>' + d.data.name + '</strong> (ID: ' + d.data.id + ')';
                    document.getElementById('reset_user_id_hidden').value = d.data.id;
                } else {
                    document.getElementById('user_found_info').innerHTML = '<span style="color:red">User not found</span>';
                }
            });
    }
    </script>
    <?php
}

// =====================================================================
// PER-USER LIMITS PAGE
// =====================================================================
function ai_usage_user_limits_page() {
    global $wpdb;
    $msg      = '';
    $msg_type = 'success';

    // ── Handle Save ──
    if ( isset($_POST['user_limit_nonce']) && wp_verify_nonce($_POST['user_limit_nonce'], 'ai_user_limit_save') ) {
        $uid    = intval($_POST['target_user_id'] ?? 0);
        $action = sanitize_text_field($_POST['limit_action'] ?? 'set');

        if ( $uid > 0 ) {
            $user = get_user_by('id', $uid);

            if ( $action === 'remove' ) {
                delete_user_meta($uid, '_ai_usage_custom_limit');
                delete_user_meta($uid, '_ai_usage_custom_expiry');
                delete_user_meta($uid, '_ai_usage_custom_note');
                $msg = '✅ Custom limit removed for: ' . ($user ? esc_html($user->display_name) : "User #$uid") . '. Role-based plan will apply.';

            } elseif ( $action === 'set' ) {
                $new_limit = absint($_POST['custom_limit'] ?? 0);
                $expiry    = sanitize_text_field($_POST['custom_expiry'] ?? '');
                $note      = sanitize_textarea_field($_POST['custom_note'] ?? '');

                update_user_meta($uid, '_ai_usage_custom_limit',  $new_limit);
                update_user_meta($uid, '_ai_usage_custom_expiry', $expiry);
                update_user_meta($uid, '_ai_usage_custom_note',   $note);

                $msg = '✅ Custom limit of <strong>' . $new_limit . ' designs</strong> set for: ' . ($user ? esc_html($user->display_name) : "User #$uid");
                if ($expiry) $msg .= ' (Expires: ' . esc_html($expiry) . ')';

            } elseif ( $action === 'add' ) {
                $add_count = absint($_POST['add_count'] ?? 0);
                // "Add" = reduce used count by inserting fake offset into meta
                $current_bonus = (int) get_user_meta($uid, '_ai_usage_bonus_credits', true);
                update_user_meta($uid, '_ai_usage_bonus_credits', $current_bonus + $add_count);
                $msg = '✅ Added <strong>' . $add_count . ' bonus designs</strong> for: ' . ($user ? esc_html($user->display_name) : "User #$uid");
            }
        } else {
            $msg      = '❌ Please select a valid user first.';
            $msg_type = 'error';
        }
    }

    // ── Handle expiry auto-remove (cron-free, check on page load) ──
    ai_usage_check_expired_limits();

    // ── Load all users with custom limits ──
    $custom_limit_users = get_users([
        'meta_key'     => '_ai_usage_custom_limit',
        'meta_compare' => 'EXISTS',
        'number'       => 100,
    ]);

    // Also get users with bonus credits
    $bonus_users = get_users([
        'meta_key'     => '_ai_usage_bonus_credits',
        'meta_compare' => 'EXISTS',
        'number'       => 100,
    ]);

    // Merge unique
    $special_users = [];
    foreach ( array_merge($custom_limit_users, $bonus_users) as $u ) {
        $special_users[$u->ID] = $u;
    }
    ?>
    <div class="wrap">
      <h1 style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:26px;">👤</span> Per-User Custom Limits
      </h1>
      <p style="color:#666;">Manual payment செய்த users அல்லது special cases-க்கு individual design limit set செய்யுங்கள். இது role-based plan-ஐ override செய்யும்.</p>

      <?php if ($msg): ?>
        <div class="notice notice-<?php echo $msg_type === 'error' ? 'error' : 'success'; ?> is-dismissible">
          <p><?php echo wp_kses($msg, ['strong'=>[]]); ?></p>
        </div>
      <?php endif; ?>

      <div style="display:grid;grid-template-columns:1.2fr 0.8fr;gap:20px;margin-top:10px;">

        <!-- LEFT: Set Custom Limit Form -->
        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;">
          <h2 style="margin-top:0;border-bottom:2px solid #2271b1;padding-bottom:10px;">🎯 Set Custom Limit for a User</h2>

          <form method="post" id="user-limit-form">
            <?php wp_nonce_field('ai_user_limit_save','user_limit_nonce'); ?>
            <input type="hidden" name="target_user_id" id="target_user_id" value="">
            <input type="hidden" name="limit_action"   id="limit_action"   value="set">

            <!-- User Search -->
            <div style="margin-bottom:20px;">
              <label style="font-weight:600;display:block;margin-bottom:6px;">Search User</label>
              <div style="display:flex;gap:8px;align-items:center;">
                <input type="text" id="user_search_input" class="regular-text"
                  placeholder="Name, email or user ID..." style="flex:1;"
                  oninput="searchUsers(this.value)">
                <span id="user_search_spinner" style="display:none;color:#2271b1;">⏳</span>
              </div>
              <!-- Autocomplete dropdown -->
              <div id="user_search_results" style="display:none;background:#fff;border:1px solid #ccd0d4;border-radius:6px;margin-top:4px;max-height:200px;overflow-y:auto;box-shadow:0 4px 12px rgba(0,0,0,0.1);"></div>
            </div>

            <!-- Selected User Card -->
            <div id="selected_user_card" style="display:none;background:#f0f6fc;border:1px solid #c3d9f7;border-radius:8px;padding:14px 18px;margin-bottom:20px;">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                <div>
                  <div style="font-weight:700;font-size:15px;" id="sel_name">-</div>
                  <div style="color:#666;font-size:13px;margin-top:2px;" id="sel_email">-</div>
                  <div style="margin-top:6px;display:flex;gap:10px;flex-wrap:wrap;">
                    <span style="background:#e7f5ea;color:#00a32a;padding:2px 8px;border-radius:4px;font-size:12px;" id="sel_role">-</span>
                    <span style="background:#fff3cd;color:#856404;padding:2px 8px;border-radius:4px;font-size:12px;" id="sel_plan_limit">Plan: -</span>
                    <span style="background:#cff4fc;color:#0c6578;padding:2px 8px;border-radius:4px;font-size:12px;" id="sel_used">Used: -</span>
                  </div>
                </div>
                <div style="text-align:right;">
                  <div style="font-size:11px;color:#999;margin-bottom:4px;">Current Effective Limit</div>
                  <div style="font-size:28px;font-weight:bold;color:#2271b1;" id="sel_effective_limit">-</div>
                </div>
              </div>
              <div id="sel_custom_badge" style="display:none;margin-top:8px;background:#fef9c3;border:1px solid #fde047;border-radius:6px;padding:6px 10px;font-size:12px;color:#713f12;">
                ⚡ Custom limit active: <strong id="sel_custom_val">-</strong>
                <span id="sel_expiry_info"></span>
                <span id="sel_note_info"></span>
              </div>
            </div>

            <!-- Action Tabs -->
            <div style="display:flex;gap:0;border-bottom:2px solid #e0e0e0;margin-bottom:20px;">
              <?php
              $tabs = ['set'=>'Set Fixed Limit','add'=>'Add Bonus Designs','remove'=>'Remove Custom Limit'];
              foreach ($tabs as $tid => $tlabel): ?>
              <button type="button" class="limit-tab <?php echo $tid==='set'?'active':''; ?>"
                data-tab="<?php echo $tid; ?>"
                onclick="switchTab('<?php echo $tid; ?>')"
                style="padding:8px 16px;border:none;background:<?php echo $tid==='set'?'#2271b1':'#f0f0f0'; ?>;color:<?php echo $tid==='set'?'#fff':'#555'; ?>;cursor:pointer;font-size:13px;<?php echo $tid==='set'?'border-radius:6px 6px 0 0;':''; ?>">
                <?php echo $tid==='set'?'🎯':($tid==='add'?'➕':'🗑️'); ?> <?php echo $tlabel; ?>
              </button>
              <?php endforeach; ?>
            </div>

            <!-- Tab: Set Fixed Limit -->
            <div id="tab_set" class="limit-tab-content">
              <table class="form-table" style="margin:0;">
                <tr>
                  <th style="padding:8px 10px 8px 0;width:160px;">Custom Design Limit</th>
                  <td style="padding:8px 0;">
                    <input type="number" name="custom_limit" id="custom_limit_input" min="0" max="99999"
                      value="10" style="width:120px;font-size:16px;padding:6px 10px;">
                    <span style="color:#666;margin-left:8px;">designs</span>
                    <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap;">
                      <?php foreach ([5,10,25,50,100,250,500] as $quick): ?>
                        <button type="button" onclick="document.getElementById('custom_limit_input').value=<?php echo $quick; ?>"
                          style="background:#f0f6fc;border:1px solid #c3d9f7;color:#2271b1;padding:3px 10px;border-radius:4px;cursor:pointer;font-size:12px;">
                          +<?php echo $quick; ?>
                        </button>
                      <?php endforeach; ?>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th style="padding:8px 10px 8px 0;">Expiry Date <small style="color:#999;">(optional)</small></th>
                  <td style="padding:8px 0;">
                    <input type="date" name="custom_expiry" id="custom_expiry_input"
                      style="padding:6px 10px;border:1px solid #ccd0d4;border-radius:4px;">
                    <p style="margin:4px 0 0;color:#999;font-size:12px;">இந்த date-க்கு பிறகு custom limit remove ஆகும், role plan திரும்பும்.</p>
                  </td>
                </tr>
                <tr>
                  <th style="padding:8px 10px 8px 0;">Admin Note <small style="color:#999;">(optional)</small></th>
                  <td style="padding:8px 0;">
                    <input type="text" name="custom_note" style="width:100%;padding:6px 10px;border:1px solid #ccd0d4;border-radius:4px;"
                      placeholder="e.g. Manual payment ₹299 on 24 Mar 2026">
                  </td>
                </tr>
              </table>
              <div style="margin-top:16px;">
                <button type="submit" onclick="setAction('set')" class="button button-primary button-large"
                  id="save_btn" disabled>
                  💾 Save Custom Limit
                </button>
              </div>
            </div>

            <!-- Tab: Add Bonus -->
            <div id="tab_add" class="limit-tab-content" style="display:none;">
              <p style="color:#666;">User-ன் current usage-ஐ மாற்றாமல், எத்தனை extra designs தர வேண்டும் என்று இங்கே enter செய்யுங்கள்.</p>
              <table class="form-table" style="margin:0;">
                <tr>
                  <th style="padding:8px 10px 8px 0;width:160px;">Bonus Designs to Add</th>
                  <td style="padding:8px 0;">
                    <input type="number" name="add_count" id="add_count_input" min="1" max="9999"
                      value="10" style="width:120px;font-size:16px;padding:6px 10px;">
                    <span style="color:#666;margin-left:8px;">extra designs</span>
                    <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap;">
                      <?php foreach ([5,10,25,50,100] as $quick): ?>
                        <button type="button" onclick="document.getElementById('add_count_input').value=<?php echo $quick; ?>"
                          style="background:#f0f6fc;border:1px solid #c3d9f7;color:#2271b1;padding:3px 10px;border-radius:4px;cursor:pointer;font-size:12px;">
                          +<?php echo $quick; ?>
                        </button>
                      <?php endforeach; ?>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th style="padding:8px 10px 8px 0;">Admin Note</th>
                  <td style="padding:8px 0;">
                    <input type="text" name="custom_note" style="width:100%;padding:6px 10px;border:1px solid #ccd0d4;border-radius:4px;"
                      placeholder="e.g. Paid ₹199 for 10 extra designs">
                  </td>
                </tr>
              </table>
              <div style="margin-top:16px;">
                <button type="submit" onclick="setAction('add')" class="button button-primary button-large"
                  id="add_btn" disabled>
                  ➕ Add Bonus Designs
                </button>
              </div>
            </div>

            <!-- Tab: Remove Custom Limit -->
            <div id="tab_remove" class="limit-tab-content" style="display:none;">
              <div style="background:#fff8f8;border:1px solid #f9a8a8;border-radius:8px;padding:16px;margin-bottom:16px;">
                <p style="margin:0;color:#555;">இந்த user-க்கு set செய்யப்பட்ட custom limit remove ஆகும். அதற்கு பதிலாக அவர்களின் <strong>role-based plan limit</strong> apply ஆகும்.</p>
              </div>
              <button type="submit" onclick="setAction('remove')" class="button button-large"
                style="background:#d63638;color:#fff;border-color:#d63638;"
                id="remove_btn" disabled>
                🗑️ Remove Custom Limit
              </button>
            </div>

          </form>
        </div>

        <!-- RIGHT: Users with Custom Limits -->
        <div style="background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:25px;">
          <h2 style="margin-top:0;border-bottom:2px solid #f59e0b;padding-bottom:10px;">⚡ Users with Custom Limits</h2>
          <?php if ( empty($special_users) ): ?>
            <div style="text-align:center;padding:30px;color:#999;">
              <div style="font-size:40px;margin-bottom:10px;">📋</div>
              <p>No custom limits set yet.</p>
            </div>
          <?php else: ?>
            <div style="overflow-y:auto;max-height:500px;">
            <?php foreach ( $special_users as $su ):
                $info      = ai_usage_get_custom_limit_info($su->ID);
                $used      = ai_usage_get_user_count($su->ID);
                $eff_limit = ai_usage_get_user_limit($su->ID);
                $bonus     = (int) get_user_meta($su->ID, '_ai_usage_bonus_credits', true);
                $is_expired = $info['expiry'] && strtotime($info['expiry']) < time();
            ?>
            <div style="border:1px solid #e0e0e0;border-radius:8px;padding:12px 14px;margin-bottom:10px;<?php echo $is_expired ? 'opacity:0.6;border-style:dashed;' : ''; ?>">
              <div style="display:flex;justify-content:space-between;align-items:center;">
                <div>
                  <div style="font-weight:600;font-size:13px;"><?php echo esc_html($su->display_name); ?></div>
                  <div style="color:#999;font-size:11px;"><?php echo esc_html($su->user_email); ?></div>
                  <div style="margin-top:4px;">
                    <span style="background:#e7f5ea;color:#00a32a;padding:1px 6px;border-radius:3px;font-size:11px;"><?php echo esc_html(implode(', ', $su->roles)); ?></span>
                  </div>
                </div>
                <div style="text-align:right;">
                  <?php if ($info['has_custom']): ?>
                    <div style="font-size:11px;color:#999;">Custom</div>
                    <div style="font-size:20px;font-weight:bold;color:<?php echo $is_expired ? '#dc3545' : '#f59e0b'; ?>;">
                      <?php echo esc_html($info['limit']); ?>
                    </div>
                  <?php endif; ?>
                  <?php if ($bonus > 0): ?>
                    <div style="font-size:11px;color:#059669;">+<?php echo $bonus; ?> bonus</div>
                  <?php endif; ?>
                </div>
              </div>
              <?php if ($info['expiry']): ?>
                <div style="margin-top:6px;font-size:11px;color:<?php echo $is_expired ? '#dc3545' : '#6b7280'; ?>;">
                  <?php echo $is_expired ? '⚠️ Expired: ' : '⏰ Expires: '; ?><?php echo esc_html(date('d M Y', strtotime($info['expiry']))); ?>
                </div>
              <?php endif; ?>
              <?php if ($info['note']): ?>
                <div style="margin-top:4px;font-size:11px;color:#6b7280;font-style:italic;">📝 <?php echo esc_html($info['note']); ?></div>
              <?php endif; ?>
              <div style="margin-top:8px;display:flex;gap:6px;justify-content:space-between;align-items:center;">
                <span style="font-size:11px;color:#666;">Used: <strong><?php echo $used; ?></strong> / <?php echo $eff_limit >= 99999 ? '∞' : $eff_limit; ?></span>
                <button type="button"
                  onclick="quickLoadUser(<?php echo $su->ID; ?>, '<?php echo esc_js($su->display_name); ?>', '<?php echo esc_js($su->user_email); ?>')"
                  style="background:#2271b1;color:#fff;border:none;border-radius:4px;padding:3px 10px;cursor:pointer;font-size:11px;">
                  Edit
                </button>
              </div>
            </div>
            <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <style>
    .limit-tab-content { display:none; }
    #tab_set { display:block; }
    </style>
    <script>
    var selectedUserId = 0;
    var searchTimer;

    function switchTab(tab) {
        document.querySelectorAll('.limit-tab-content').forEach(el => el.style.display = 'none');
        document.getElementById('tab_' + tab).style.display = 'block';
        document.querySelectorAll('.limit-tab').forEach(btn => {
            var active = btn.dataset.tab === tab;
            btn.style.background = active ? '#2271b1' : '#f0f0f0';
            btn.style.color = active ? '#fff' : '#555';
        });
        document.getElementById('limit_action').value = tab;
    }

    function setAction(a) {
        document.getElementById('limit_action').value = a;
    }

    function enableButtons(enable) {
        ['save_btn','add_btn','remove_btn'].forEach(id => {
            var el = document.getElementById(id);
            if (el) el.disabled = !enable;
        });
    }

    function searchUsers(q) {
        clearTimeout(searchTimer);
        if (q.length < 2) {
            document.getElementById('user_search_results').style.display = 'none';
            return;
        }
        document.getElementById('user_search_spinner').style.display = 'inline';
        searchTimer = setTimeout(function() {
            fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=ai_search_users&q=' + encodeURIComponent(q) + '&_wpnonce=<?php echo wp_create_nonce('ai_search_users'); ?>')
            .then(r => r.json())
            .then(d => {
                document.getElementById('user_search_spinner').style.display = 'none';
                var res = document.getElementById('user_search_results');
                if (!d.success || !d.data.length) {
                    res.innerHTML = '<div style="padding:10px 14px;color:#999;font-size:13px;">No users found</div>';
                } else {
                    res.innerHTML = d.data.map(u => `
                        <div onclick="selectUser(${u.id}, '${u.name.replace(/'/g,"\\'")}', '${u.email.replace(/'/g,"\\'")}', ${u.limit}, ${u.used}, '${u.role}', ${u.effective})"
                             style="padding:10px 14px;cursor:pointer;border-bottom:1px solid #f0f0f0;font-size:13px;"
                             onmouseover="this.style.background='#f0f6fc'" onmouseout="this.style.background='#fff'">
                            <strong>${u.name}</strong> &lt;${u.email}&gt;
                            <span style="float:right;font-size:11px;color:#999;">${u.role}</span>
                            <div style="font-size:11px;color:#666;margin-top:2px;">
                                Plan limit: ${u.limit === 99999 ? 'Unlimited' : u.limit} | Used: ${u.used}
                                ${u.has_custom ? ' | <span style="color:#f59e0b">⚡ Custom: ' + u.custom_limit + '</span>' : ''}
                            </div>
                        </div>
                    `).join('');
                }
                res.style.display = 'block';
            })
            .catch(() => { document.getElementById('user_search_spinner').style.display = 'none'; });
        }, 350);
    }

    function selectUser(id, name, email, planLimit, used, role, effective) {
        selectedUserId = id;
        document.getElementById('target_user_id').value = id;
        document.getElementById('user_search_input').value = name + ' <' + email + '>';
        document.getElementById('user_search_results').style.display = 'none';

        document.getElementById('sel_name').textContent = name;
        document.getElementById('sel_email').textContent = email;
        document.getElementById('sel_role').textContent = role;
        document.getElementById('sel_plan_limit').textContent = 'Plan: ' + (planLimit >= 99999 ? 'Unlimited' : planLimit);
        document.getElementById('sel_used').textContent = 'Used: ' + used;
        document.getElementById('sel_effective_limit').textContent = effective >= 99999 ? '∞' : effective;
        document.getElementById('selected_user_card').style.display = 'block';

        enableButtons(true);

        // Load custom limit info via AJAX
        fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=ai_get_user_custom&uid=' + id + '&_wpnonce=<?php echo wp_create_nonce('ai_get_user_custom'); ?>')
        .then(r => r.json())
        .then(d => {
            if (d.success && d.data.has_custom) {
                document.getElementById('sel_custom_badge').style.display = 'block';
                document.getElementById('sel_custom_val').textContent = d.data.limit + ' designs';
                document.getElementById('sel_expiry_info').textContent = d.data.expiry ? ' | Expires: ' + d.data.expiry : '';
                document.getElementById('sel_note_info').textContent = d.data.note ? ' | Note: ' + d.data.note : '';
                document.getElementById('custom_limit_input').value = d.data.limit;
                if (d.data.expiry) document.getElementById('custom_expiry_input').value = d.data.expiry;
            } else {
                document.getElementById('sel_custom_badge').style.display = 'none';
            }
        });
    }

    function quickLoadUser(id, name, email) {
        document.getElementById('user_search_input').value = name + ' <' + email + '>';
        selectUser(id, name, email, 0, 0, '', 0);
        // Refetch proper data
        fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=ai_search_users&q=' + encodeURIComponent(email) + '&_wpnonce=<?php echo wp_create_nonce('ai_search_users'); ?>')
        .then(r => r.json()).then(d => {
            if (d.success && d.data.length) {
                var u = d.data[0];
                selectUser(u.id, u.name, u.email, u.limit, u.used, u.role, u.effective);
            }
        });
        window.scrollTo({top: 0, behavior: 'smooth'});
    }
    </script>
    <?php
}

// =====================================================================
// HELPER: Check and auto-remove expired custom limits
// =====================================================================
function ai_usage_check_expired_limits() {
    $users_with_expiry = get_users([
        'meta_key'     => '_ai_usage_custom_expiry',
        'meta_compare' => 'EXISTS',
        'number'       => 200,
    ]);
    foreach ( $users_with_expiry as $u ) {
        $expiry = get_user_meta($u->ID, '_ai_usage_custom_expiry', true);
        if ( $expiry && strtotime($expiry) < time() ) {
            delete_user_meta($u->ID, '_ai_usage_custom_limit');
            delete_user_meta($u->ID, '_ai_usage_custom_expiry');
            delete_user_meta($u->ID, '_ai_usage_custom_note');
        }
    }
}

// AJAX: Search users for autocomplete
add_action('wp_ajax_ai_search_users', function() {
    check_ajax_referer('ai_search_users');
    if (!current_user_can('manage_options')) wp_send_json_error();

    $q     = sanitize_text_field($_GET['q'] ?? '');
    $users = get_users([
        'search'         => '*' . $q . '*',
        'search_columns' => ['user_login','user_email','display_name','ID'],
        'number'         => 10,
    ]);

    $plans = get_option('ai_usage_plans', []);
    $out   = [];
    foreach ($users as $u) {
        $role        = implode(', ', $u->roles);
        $plan_limit  = ai_usage_get_user_limit($u->ID); // effective
        $info        = ai_usage_get_custom_limit_info($u->ID);

        // Role-only limit (without custom override)
        $role_limit = (int) get_option('ai_usage_default_limit', 5);
        foreach ($u->roles as $r) {
            if (isset($plans[$r])) { $role_limit = $plans[$r]; break; }
        }

        $out[] = [
            'id'           => $u->ID,
            'name'         => $u->display_name,
            'email'        => $u->user_email,
            'role'         => $role,
            'limit'        => $role_limit,
            'effective'    => $plan_limit,
            'used'         => ai_usage_get_user_count($u->ID),
            'has_custom'   => $info['has_custom'],
            'custom_limit' => $info['limit'],
        ];
    }
    wp_send_json_success($out);
});

// AJAX: Get single user custom limit info
add_action('wp_ajax_ai_get_user_custom', function() {
    check_ajax_referer('ai_get_user_custom');
    if (!current_user_can('manage_options')) wp_send_json_error();
    $uid  = absint($_GET['uid'] ?? 0);
    $info = ai_usage_get_custom_limit_info($uid);
    wp_send_json_success($info);
});

// AJAX: Find user
add_action('wp_ajax_ai_find_user', function() {
    check_ajax_referer('ai_find_user');
    if (!current_user_can('manage_options')) wp_send_json_error();
    $q = sanitize_text_field($_GET['q'] ?? '');
    $user = is_numeric($q) ? get_user_by('id', $q) : get_user_by('email', $q);
    if (!$user) {
        $users = get_users(['search' => '*' . $q . '*', 'number' => 1]);
        $user = $users[0] ?? null;
    }
    if ($user) {
        wp_send_json_success(['id' => $user->ID, 'name' => $user->display_name . ' <' . $user->user_email . '>']);
    } else {
        wp_send_json_error('not found');
    }
});

// =====================================================================
// HELPER: GET USER'S ALLOWED LIMIT
// Priority: Per-user override > Role plan > Default
// Also adds bonus credits on top of effective limit
// =====================================================================
function ai_usage_get_user_limit( $user_id = null ) {
    if ( ! $user_id ) $user_id = get_current_user_id();
    if ( ! $user_id ) return (int) get_option('ai_usage_guest_limit', 0);

    // 1. Check per-user custom override (highest priority)
    $custom = get_user_meta( $user_id, '_ai_usage_custom_limit', true );
    if ( $custom !== '' && $custom !== false && $custom !== null ) {
        $base = (int) $custom;
    } else {
        // 2. Role-based plan limit
        $plans = get_option('ai_usage_plans', []);
        $user  = get_user_by('id', $user_id);
        if ( ! $user ) return (int) get_option('ai_usage_default_limit', 5);
        $base = (int) get_option('ai_usage_default_limit', 5);
        foreach ( $user->roles as $role ) {
            if ( isset($plans[$role]) ) { $base = (int) $plans[$role]; break; }
        }
    }

    // 3. Add bonus credits (from "Add Bonus" feature)
    $bonus = (int) get_user_meta( $user_id, '_ai_usage_bonus_credits', true );
    return $base + $bonus;
}

// =====================================================================
// HELPER: GET PER-USER CUSTOM LIMIT INFO (for display)
// =====================================================================
function ai_usage_get_custom_limit_info( $user_id ) {
    $custom = get_user_meta( $user_id, '_ai_usage_custom_limit', true );
    $expiry = get_user_meta( $user_id, '_ai_usage_custom_expiry', true );
    $note   = get_user_meta( $user_id, '_ai_usage_custom_note', true );
    return [
        'has_custom' => ( $custom !== '' && $custom !== false && $custom !== null ),
        'limit'      => $custom !== '' ? (int) $custom : null,
        'expiry'     => $expiry ?: '',
        'note'       => $note ?: '',
    ];
}

// =====================================================================
// HELPER: GET USER'S CURRENT USAGE COUNT (within reset period)
// =====================================================================
function ai_usage_get_user_count( $user_id = null ) {
    global $wpdb;
    if ( ! $user_id ) $user_id = get_current_user_id();
    if ( ! $user_id ) return 0;

    $table  = $wpdb->prefix . 'ai_usage_log';
    $period = get_option('ai_usage_reset_period', 'monthly');

    switch ($period) {
        case 'daily':
            $since = date('Y-m-d 00:00:00');
            break;
        case 'weekly':
            $since = date('Y-m-d 00:00:00', strtotime('-7 days'));
            break;
        case 'monthly':
            $since = date('Y-m-01 00:00:00');
            break;
        case 'yearly':
            $since = date('Y-01-01 00:00:00');
            break;
        case 'never':
        default:
            $since = '2000-01-01 00:00:00';
    }

    return (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE user_id = %d AND used_at >= %s",
        $user_id, $since
    ));
}

// =====================================================================
// HELPER: LOG ONE USAGE
// =====================================================================
function ai_usage_log( $user_id, $prompt = '' ) {
    global $wpdb;
    $table = $wpdb->prefix . 'ai_usage_log';
    $ip    = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    $ip    = sanitize_text_field( explode(',', $ip)[0] );

    $wpdb->insert($table, [
        'user_id'    => $user_id,
        'used_at'    => current_time('mysql'),
        'prompt'     => mb_substr($prompt, 0, 500),
        'ip_address' => $ip,
    ]);
}

// =====================================================================
// REST API ENDPOINT: Check + Log Usage
// POST /wp-json/ai-usage/v1/check
// POST /wp-json/ai-usage/v1/log
// =====================================================================
add_action('rest_api_init', function() {
    register_rest_route('ai-usage/v1', '/check', [
        'methods'             => 'GET',
        'callback'            => 'ai_usage_rest_check',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('ai-usage/v1', '/log', [
        'methods'             => 'POST',
        'callback'            => 'ai_usage_rest_log',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('ai-usage/v1', '/config', [
        'methods'             => 'GET',
        'callback'            => 'ai_usage_rest_config',
        'permission_callback' => '__return_true',
    ]);
});

function ai_usage_rest_check( WP_REST_Request $req ) {
    $user_id = get_current_user_id();
    $limit   = ai_usage_get_user_limit($user_id);
    $used    = ai_usage_get_user_count($user_id);
    $remain  = max(0, $limit - $used);

    return rest_ensure_response([
        'allowed'         => $remain > 0 || $limit >= 99999,
        'limit'           => $limit,
        'used'            => $used,
        'remaining'       => $remain,
        'is_unlimited'    => $limit >= 99999,
        'payment_url'     => get_option('ai_usage_payment_url',''),
        'payment_btn_txt' => get_option('ai_usage_payment_btn_txt','Upgrade Now'),
        'limit_msg'       => get_option('ai_usage_limit_msg','Limit reached. Please upgrade.'),
    ]);
}

function ai_usage_rest_log( WP_REST_Request $req ) {
    // Verify nonce from cookie/header
    $nonce = $req->get_header('X-WP-Nonce');
    if ( ! wp_verify_nonce($nonce, 'wp_rest') ) {
        return new WP_Error('invalid_nonce', 'Invalid nonce', ['status' => 403]);
    }

    $user_id = get_current_user_id();
    if ( ! $user_id ) {
        return new WP_Error('not_logged_in', 'Login required', ['status' => 401]);
    }

    $limit  = ai_usage_get_user_limit($user_id);
    $used   = ai_usage_get_user_count($user_id);
    $remain = max(0, $limit - $used);

    if ( $remain <= 0 && $limit < 99999 ) {
        return new WP_Error('limit_exceeded', 'Usage limit exceeded', ['status' => 403, 'data' => [
            'payment_url'     => get_option('ai_usage_payment_url',''),
            'payment_btn_txt' => get_option('ai_usage_payment_btn_txt','Upgrade Now'),
            'limit_msg'       => get_option('ai_usage_limit_msg',''),
        ]]);
    }

    $prompt = sanitize_textarea_field( $req->get_param('prompt') ?? '' );
    ai_usage_log($user_id, $prompt);

    return rest_ensure_response([
        'logged'    => true,
        'remaining' => max(0, $remain - 1),
    ]);
}

function ai_usage_rest_config( WP_REST_Request $req ) {
    return rest_ensure_response([
        'proxy_url'       => get_option('ai_usage_proxy_url',''),
        'payment_url'     => get_option('ai_usage_payment_url',''),
        'payment_btn_txt' => get_option('ai_usage_payment_btn_txt',''),
        'limit_msg'       => get_option('ai_usage_limit_msg',''),
        'nonce'           => wp_create_nonce('wp_rest'),
        'logged_in'       => is_user_logged_in(),
    ]);
}

// =====================================================================
// SHORTCODE: [ai_usage_status] - Show usage bar to user
// =====================================================================
add_shortcode('ai_usage_status', function() {
    $user_id = get_current_user_id();
    $limit   = ai_usage_get_user_limit($user_id);
    $used    = ai_usage_get_user_count($user_id);
    $remain  = max(0, $limit - $used);
    $pct     = $limit > 0 ? min(100, round(($used / $limit) * 100)) : 0;
    $pay_url = get_option('ai_usage_payment_url','');
    $pay_btn = get_option('ai_usage_payment_btn_txt','Upgrade Now');

    if (!is_user_logged_in()) {
        return '<div style="background:#fff3cd;border:1px solid #ffc107;padding:12px 16px;border-radius:8px;">Login செய்து AI Design tool பயன்படுத்துங்கள்.</div>';
    }
    if ($limit >= 99999) {
        return '<div style="background:#d4edda;border:1px solid #28a745;padding:12px 16px;border-radius:8px;color:#155724;">✨ Unlimited AI Designs - Premium Member!</div>';
    }

    $color = $pct >= 90 ? '#dc3545' : ($pct >= 70 ? '#fd7e14' : '#28a745');
    ob_start(); ?>
    <div style="background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:16px 20px;font-family:sans-serif;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <span style="font-weight:600;color:#333;">🎨 AI Design Usage</span>
        <span style="font-size:13px;color:#666;"><?php echo esc_html($used); ?> / <?php echo esc_html($limit); ?> used</span>
      </div>
      <div style="background:#e9ecef;border-radius:20px;height:10px;overflow:hidden;">
        <div style="background:<?php echo esc_attr($color); ?>;height:100%;width:<?php echo esc_attr($pct); ?>%;border-radius:20px;transition:width 0.3s;"></div>
      </div>
      <div style="display:flex;justify-content:space-between;margin-top:8px;">
        <span style="font-size:12px;color:#666;"><?php echo esc_html($remain); ?> designs remaining</span>
        <?php if ($remain <= 0 && $pay_url): ?>
          <a href="<?php echo esc_url($pay_url); ?>" style="font-size:12px;background:#2271b1;color:#fff;padding:3px 10px;border-radius:4px;text-decoration:none;"><?php echo esc_html($pay_btn); ?></a>
        <?php endif; ?>
      </div>
    </div>
    <?php return ob_get_clean();
});

// =====================================================================
// ENQUEUE FRONTEND SCRIPT (inject usage check into AI tool)
// =====================================================================
add_action('wp_enqueue_scripts', function() {
    wp_register_script(
        '3d-ai-usage-js',
        AI_USAGE_PLUGIN_URL . 'assets/ai-usage-check.js',
        [],
        AI_USAGE_VERSION,
        true
    );

    wp_localize_script('3d-ai-usage-js', 'aiUsageConfig', [
        'restUrl'       => rest_url('ai-usage/v1/'),
        'nonce'         => wp_create_nonce('wp_rest'),
        'proxyUrl'      => get_option('ai_usage_proxy_url',''),
        'paymentUrl'    => get_option('ai_usage_payment_url',''),
        'paymentBtnTxt' => get_option('ai_usage_payment_btn_txt','Upgrade Now'),
        'limitMsg'      => get_option('ai_usage_limit_msg','Design limit reached. Please upgrade.'),
        'loggedIn'      => is_user_logged_in() ? 1 : 0,
    ]);

    wp_enqueue_script('3d-ai-usage-js');
});
