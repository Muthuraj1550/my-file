/**
 * 3D AI Usage Control - Frontend Script
 * 
 * இந்த script 3D Design Tool-ல் embed ஆகி:
 * 1. AI generate button-ஐ intercept செய்கிறது
 * 2. WordPress REST API மூலம் usage check செய்கிறது
 * 3. Limit மீறினால் payment popup காட்டுகிறது
 * 4. Proxy URL-ஐ WordPress settings இலிருந்து override செய்கிறது
 */

(function() {
    'use strict';

    // aiUsageConfig is injected by wp_localize_script
    var cfg = window.aiUsageConfig || {};

    // ─── Inject CSS for the limit popup ──────────────────────────────
    var style = document.createElement('style');
    style.textContent = `
        #ai-limit-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(2, 6, 23, 0.95);
            z-index: 9999999;
            justify-content: center;
            align-items: center;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        #ai-limit-overlay.show { display: flex; }
        #ai-limit-box {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 40px 35px;
            text-align: center;
            max-width: 420px;
            width: 90%;
            box-shadow: 0 25px 60px rgba(0,0,0,0.6);
            animation: ai-limit-in 0.3s ease;
        }
        @keyframes ai-limit-in {
            from { opacity: 0; transform: scale(0.9) translateY(-20px); }
            to   { opacity: 1; transform: scale(1) translateY(0); }
        }
        #ai-limit-icon { font-size: 52px; margin-bottom: 15px; }
        #ai-limit-title { color: #f1f5f9; font-size: 22px; font-weight: 700; margin-bottom: 12px; }
        #ai-limit-msg   { color: #94a3b8; font-size: 14px; line-height: 1.6; margin-bottom: 25px; }
        #ai-limit-stats {
            background: #0f172a;
            border: 1px solid #1e293b;
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 22px;
            font-size: 13px;
            color: #64748b;
        }
        #ai-limit-stats span { color: #e2e8f0; font-weight: 600; }
        .ai-limit-pay-btn {
            display: block;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: #fff !important;
            padding: 14px 20px;
            border-radius: 10px;
            text-decoration: none !important;
            font-weight: 700;
            font-size: 15px;
            margin-bottom: 10px;
            transition: opacity 0.2s;
        }
        .ai-limit-pay-btn:hover { opacity: 0.9; }
        .ai-limit-close-btn {
            background: transparent;
            border: 1px solid #334155;
            color: #64748b;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            width: 100%;
            margin-top: 5px;
        }
        .ai-limit-close-btn:hover { border-color: #475569; color: #94a3b8; }

        /* Usage Badge injected next to AI button */
        #ai-usage-badge {
            position: fixed;
            bottom: 80px;
            right: 20px;
            z-index: 99999;
            background: rgba(15, 23, 42, 0.9);
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 6px 10px;
            font-size: 11px;
            color: #94a3b8;
            font-family: sans-serif;
            pointer-events: none;
        }
        #ai-usage-badge .badge-count { color: #e2e8f0; font-weight: bold; }
        #ai-usage-badge .badge-warn  { color: #f97316; }
        #ai-usage-badge .badge-empty { color: #ef4444; }
    `;
    document.head.appendChild(style);

    // ─── Create limit popup HTML ──────────────────────────────────────
    var overlay = document.createElement('div');
    overlay.id  = 'ai-limit-overlay';
    overlay.innerHTML = `
        <div id="ai-limit-box">
            <div id="ai-limit-icon">🔒</div>
            <div id="ai-limit-title">AI Design Limit Reached!</div>
            <div id="ai-limit-msg">${cfg.limitMsg || 'Your AI design limit has been reached. Upgrade to generate more designs.'}</div>
            <div id="ai-limit-stats">
                Used: <span id="al-used">-</span> &nbsp;|&nbsp;
                Limit: <span id="al-limit">-</span> &nbsp;|&nbsp;
                Remaining: <span id="al-remain" style="color:#ef4444">0</span>
            </div>
            ${cfg.paymentUrl ? `<a href="${cfg.paymentUrl}" class="ai-limit-pay-btn" target="_blank">💳 ${cfg.paymentBtnTxt || 'Upgrade Now'}</a>` : ''}
            <button class="ai-limit-close-btn" onclick="document.getElementById('ai-limit-overlay').classList.remove('show')">Close</button>
        </div>
    `;
    document.body.appendChild(overlay);

    // ─── Usage badge ──────────────────────────────────────────────────
    var badge = document.createElement('div');
    badge.id  = 'ai-usage-badge';
    badge.style.display = 'none';
    document.body.appendChild(badge);

    function updateBadge(used, limit, remain) {
        if (!badge) return;
        if (limit >= 99999) {
            badge.style.display = 'none';
            return;
        }
        badge.style.display = 'block';
        var cls = remain <= 0 ? 'badge-empty' : (remain <= 3 ? 'badge-warn' : 'badge-count');
        badge.innerHTML = `🎨 AI: <span class="${cls}">${remain}</span> remaining`;
    }

    // ─── Load current usage on page load ─────────────────────────────
    var _cachedUsage = null;

    function fetchUsage() {
        if (!cfg.restUrl) return Promise.resolve(null);
        return fetch(cfg.restUrl + 'check', {
            credentials: 'include',
            headers: { 'X-WP-Nonce': cfg.nonce }
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            _cachedUsage = d;
            updateBadge(d.used, d.limit, d.remaining);
            // Override Gemini API Key if WordPress plugin has one set
            if (cfg.proxyUrl && cfg.proxyUrl.indexOf('AIza') === 0) {
                window._geminiApiKeyOverride = cfg.proxyUrl;
            }
            return d;
        })
        .catch(function(e) {
            console.warn('[AI Usage] Could not fetch usage:', e);
            return null;
        });
    }

    // ─── Log one usage via REST API ───────────────────────────────────
    function logUsage(prompt) {
        if (!cfg.restUrl || !cfg.loggedIn) return Promise.resolve(null);
        return fetch(cfg.restUrl + 'log', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': cfg.nonce
            },
            body: JSON.stringify({ prompt: prompt || '' })
        })
        .then(function(r) {
            if (!r.ok && r.status === 403) {
                return r.json().then(function(d) { throw { limitExceeded: true, data: d }; });
            }
            return r.json();
        });
    }

    // ─── Show limit popup ─────────────────────────────────────────────
    function showLimitPopup(used, limit) {
        document.getElementById('al-used').textContent   = used   || '?';
        document.getElementById('al-limit').textContent  = limit  || '?';
        document.getElementById('al-remain').textContent = '0';
        overlay.classList.add('show');
    }

    // ─── Intercept runAIGenerate ──────────────────────────────────────
    // We wrap the original function after iframe loads
    function interceptAI() {
        // Try to intercept within the iframe
        var iframe = document.getElementById('v10-iframe');
        if (!iframe) {
            // Might be running inside the iframe itself
            if (typeof window.runAIGenerate === 'function' && !window._aiUsageWrapped) {
                var originalGenerate = window.runAIGenerate;
                window._aiUsageWrapped = true;

                window.runAIGenerate = async function() {
                    // 1. Check limit first
                    var usage = await fetchUsage();
                    if (usage && !usage.allowed && !usage.is_unlimited) {
                        showLimitPopup(usage.used, usage.limit);
                        return; // Block generation
                    }

                    // 2. Get prompt for logging
                    var promptEl = document.getElementById('aiPrompt');
                    var prompt   = promptEl ? promptEl.value.trim() : '';

                    // 3. Log usage BEFORE calling API (pre-decrement)
                    try {
                        await logUsage(prompt);
                    } catch (err) {
                        if (err && err.limitExceeded) {
                            showLimitPopup(err.data && err.data.used, err.data && err.data.limit);
                            return;
                        }
                        // If logging fails for other reasons, still allow (don't block UX)
                        console.warn('[AI Usage] Log failed:', err);
                    }

                    // 4. Override PROXY_URL if set in WP
                    if (cfg.proxyUrl) {
                        window.PROXY_URL = cfg.proxyUrl;
                    }

                    // 5. Call original generate
                    var result = await originalGenerate.apply(this, arguments);

                    // 6. Refresh badge
                    fetchUsage();

                    return result;
                };

                console.log('[AI Usage] ✅ runAIGenerate intercepted successfully');
            }
        } else {
            // Monitor iframe and intercept when it loads
            function tryInterceptIframe() {
                try {
                    var iDoc = iframe.contentDocument || iframe.contentWindow.document;
                    var iWin = iframe.contentWindow;
                    if (!iWin || iWin._aiUsageWrapped) return;

                    if (typeof iWin.runAIGenerate === 'function') {
                        var orig = iWin.runAIGenerate;
                        iWin._aiUsageWrapped = true;

                        // Override Gemini API Key in iframe if set in WP
                        if (cfg.proxyUrl && cfg.proxyUrl.indexOf('AIza') === 0) {
                            iWin._geminiApiKeyOverride = cfg.proxyUrl;
                        }

                        iWin.runAIGenerate = async function() {
                            var usage = await fetchUsage();
                            if (usage && !usage.allowed && !usage.is_unlimited) {
                                showLimitPopup(usage.used, usage.limit);
                                return;
                            }

                            var promptEl = iDoc.getElementById('aiPrompt');
                            var prompt   = promptEl ? promptEl.value.trim() : '';

                            try {
                                await logUsage(prompt);
                            } catch (err) {
                                if (err && err.limitExceeded) {
                                    showLimitPopup(null, null);
                                    return;
                                }
                            }

                            var result = await orig.apply(this, arguments);
                            fetchUsage();
                            return result;
                        };
                        console.log('[AI Usage] ✅ iframe runAIGenerate intercepted');
                    }
                } catch(e) {
                    // Cross-origin - can't intercept iframe directly
                    // Plugin works via postMessage fallback instead
                }
            }

            iframe.addEventListener('load', function() {
                setTimeout(tryInterceptIframe, 1500);
                setTimeout(tryInterceptIframe, 3500);
            });
            setInterval(tryInterceptIframe, 2000);
        }
    }

    // ─── PostMessage fallback (if iframe is cross-origin) ────────────
    // The HTML tool must send a message before generating
    window.addEventListener('message', function(event) {
        if (!event.data || event.data.type !== 'ai_usage_check') return;

        fetchUsage().then(function(usage) {
            var iframe = document.getElementById('v10-iframe');
            var target = iframe ? iframe.contentWindow : null;
            if (!target) return;

            if (usage && !usage.allowed && !usage.is_unlimited) {
                showLimitPopup(usage.used, usage.limit);
                target.postMessage({ type: 'ai_usage_blocked', allowed: false }, '*');
            } else {
                var prompt = event.data.prompt || '';
                logUsage(prompt)
                    .then(function() {
                        target.postMessage({ type: 'ai_usage_ok', allowed: true, proxyUrl: cfg.proxyUrl }, '*');
                        fetchUsage();
                    })
                    .catch(function(err) {
                        if (err && err.limitExceeded) {
                            showLimitPopup(null, null);
                            target.postMessage({ type: 'ai_usage_blocked', allowed: false }, '*');
                        } else {
                            // Allow if log fails
                            target.postMessage({ type: 'ai_usage_ok', allowed: true, proxyUrl: cfg.proxyUrl }, '*');
                        }
                    });
            }
        });
    });

    // ─── Init ─────────────────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', function() {
        fetchUsage();
        interceptAI();
    });

    if (document.readyState !== 'loading') {
        fetchUsage();
        interceptAI();
    }

    // Expose for debugging
    window._aiUsagePlugin = {
        fetchUsage: fetchUsage,
        logUsage:   logUsage,
        showLimitPopup: showLimitPopup,
    };

})();
