<?php
/*
Plugin Name: 3D Engine - V17 Ultimate Titanium
Description: V17 fixes: Free + Premium XML files both shown in dropdown (FREE badge / 👑 PREMIUM badge). Free users see all templates but premium click shows membership popup. Engine postMessage fully synced with plugin overlay. gh_premium_block postMessage handled.
Version: 17.0.0
Author: My 3D Gifts Pro
*/

// ===== FULLSCREEN PAGE — ?v14fs=1 renders pure iframe, no WP header/footer =====
add_action('template_redirect', function() {
    if(empty($_GET['v14fs'])) return;

    $engine_url = get_option('v12_url', home_url('/3d/extrude.html'));
    // Pass any extra query params (project state token) to the iframe src
    $extra = '';
    foreach($_GET as $k => $v){
        if($k === 'v14fs') continue;
        $extra .= '&' . urlencode($k) . '=' . urlencode($v);
    }
    $src = esc_url($engine_url . (strpos($engine_url,'?')!==false ? '' : '?') . $extra);

    // Allowed origins for postMessage
    $site = esc_js(home_url());
    ?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>3D Engine — Fullscreen</title>
<style>
 *,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
 html,body{width:100%;height:100%;overflow:hidden;background:#000}
 #v14fs-frame{width:100%;height:100%;border:none;display:block}
 #v14fs-exit{position:fixed;top:10px;right:14px;z-index:9999;
   background:rgba(15,23,42,0.85);border:1px solid #334155;
   color:#94a3b8;font-size:11px;padding:5px 10px;border-radius:6px;
   cursor:pointer;display:flex;align-items:center;gap:5px;
   backdrop-filter:blur(4px);transition:all .2s;}
 #v14fs-exit:hover{background:#1e293b;color:#e2e8f0;border-color:#38bdf8}
</style>
</head>
<body>
<button id="v14fs-exit" onclick="window.close()" title="Close Fullscreen">✕ Exit</button>
<iframe id="v14fs-frame" src="<?php echo $src; ?>" allowfullscreen></iframe>
<script>
// Relay postMessages between this page and the opener so project state is shared
window.addEventListener('message', function(e){
  if(window.opener) window.opener.postMessage(e.data,'*');
});
if(window.opener){
  window.opener.addEventListener('message', function(e){
    document.getElementById('v14fs-frame').contentWindow.postMessage(e.data,'*');
  });
}
</script>
</body>
</html><?php
    exit;
});


// ===== ADMIN MENU =====
add_action('admin_menu', function() {
    add_menu_page('3D Pro Control', '3D Pro Control', 'manage_options', '3d-pro-v12', 'design_pro_v12_page', 'dashicons-admin-tools');
});

function design_pro_v12_page() {
    global $wp_roles;
    $locked_f     = (array) get_option('v12_locked', array());
    $locked_fonts = (array) get_option('v12_locked_fonts', array());
    ?>
    <div class="wrap" style="background:#fff;padding:25px;border-radius:12px;max-width:960px;">
        <h1 style="color:#0f172a;">🎛️ V12 Ultimate Titanium — Control Panel</h1>
        <form method="post" action="options.php">
            <?php settings_fields('v12-settings'); ?>

            <!-- 1. ENGINE & POPUP -->
            <h3 style="border-bottom:2px solid #38bdf8;padding-bottom:6px;">1. Engine & Popup</h3>
            <table class="form-table">
                <tr><th>Engine URL</th>
                    <td><input type="text" name="v12_url" value="<?php echo esc_url(get_option('v12_url', home_url('/3d/extrude.html'))); ?>" class="regular-text"></td></tr>

                <!-- ═══ GITHUB XML PROJECT LOADER SETTINGS ═══ -->
                <tr><td colspan="2" style="padding:0;"><div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:18px 20px;margin:14px 0;">
                    <h4 style="margin:0 0 14px;color:#1d4ed8;font-size:14px;">🐙 GitHub XML Repository Settings</h4>
                    <table style="width:100%;border-collapse:collapse;">
                        <tr>
                            <td style="width:220px;padding:8px 0;font-weight:600;color:#1e40af;vertical-align:top;padding-top:12px;">
                                🆓 Free / Guest URL
                            </td>
                            <td style="padding:8px 0;">
                                <input type="text" name="v12_gh_repo_url"
                                    value="<?php echo esc_attr(get_option('v12_gh_repo_url', 'https://github.com/Muthuraj1550/Template')); ?>"
                                    class="regular-text" style="width:100%;max-width:500px;"
                                    placeholder="https://github.com/USERNAME/FREE-REPO">
                                <p style="color:#6b7280;font-size:11px;margin:4px 0 0;">
                                    Guest / Free users பயன்படுத்தும் XML files repo. Login செய்யாதவர்களும் இதை access செய்யலாம்.<br>
                                    <strong>Example:</strong> User types <code>=keychain</code> → loads <code>keychain.xml</code>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding:8px 0;font-weight:600;color:#7e22ce;vertical-align:top;padding-top:12px;">
                                👑 Premium / Member URL
                            </td>
                            <td style="padding:8px 0;">
                                <input type="text" name="v12_gh_premium_repo_url"
                                    value="<?php echo esc_attr(get_option('v12_gh_premium_repo_url', '')); ?>"
                                    class="regular-text" style="width:100%;max-width:500px;"
                                    placeholder="https://github.com/USERNAME/PREMIUM-REPO">
                                <p style="color:#6b7280;font-size:11px;margin:4px 0 0;">
                                    Paid membership உள்ளவர்களுக்கான premium XML templates repo. இந்த files dropdown-ல் 👑 badge உடன் காட்டப்படும்.<br>
                                    Free users click செய்தால் membership upgrade warning காட்டும்.
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding:8px 0;font-weight:600;color:#374151;vertical-align:top;padding-top:12px;">
                                📋 Project Dropdown
                            </td>
                            <td style="padding:8px 0;">
                                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                                    <input type="checkbox" name="v12_gh_show_dropdown" value="1"
                                        <?php echo get_option('v12_gh_show_dropdown', '1') === '1' ? 'checked' : ''; ?>>
                                    <span>4+ எழுத்து type செய்தவுடன் dropdown காட்டு</span>
                                </label>
                                <p style="color:#6b7280;font-size:11px;margin:4px 0 0;">
                                    Free templates → normal, Premium templates → 👑 badge உடன் காட்டும்.
                                </p>
                            </td>
                        </tr>
                    </table>
                </div></td></tr>
                <!-- ═══ END GITHUB SETTINGS ═══ -->

                <!-- ═══ HTML CODE PASTE ═══ -->
                <tr><td colspan="2" style="padding:0;"><div style="background:#fefce8;border:1px solid #fde68a;border-radius:10px;padding:18px 20px;margin:8px 0 14px;">
                    <h4 style="margin:0 0 6px;color:#92400e;font-size:14px;">📝 HTML Code Paste
                        <span style="font-weight:normal;font-size:11px;color:#b45309;margin-left:8px;">(File Manager போகாமல் இங்கேயே HTML code paste செய்யலாம்)</span>
                    </h4>
                    <p style="color:#6b7280;font-size:11px;margin:0 0 10px;">
                        ⚠️ <strong>HTML Code Mode</strong> தேர்ந்தெடுத்தால், shortcode page-ல் Engine URL iframe-க்கு பதிலாக இந்த HTML code render ஆகும்.<br>
                        Engine URL iframe வேண்டுமென்றால் <strong>Engine Mode</strong> (default) வைக்கவும்.
                    </p>
                    <div style="display:flex;gap:8px;margin-bottom:10px;">
                        <button type="button" onclick="v12HtmlMode('engine')" id="v12-tab-url"
                            style="padding:6px 16px;border-radius:6px;border:2px solid #22c55e;background:#22c55e;color:#fff;cursor:pointer;font-size:12px;font-weight:600;">
                            ⚙️ Engine Mode (Default)
                        </button>
                        <button type="button" onclick="v12HtmlMode('code')" id="v12-tab-code"
                            style="padding:6px 16px;border-radius:6px;border:2px solid #d1d5db;background:#fff;color:#374151;cursor:pointer;font-size:12px;font-weight:600;">
                            📝 HTML Code Mode
                        </button>
                    </div>
                    <input type="hidden" name="v12_html_mode" id="v12-html-mode-val"
                        value="<?php echo esc_attr(get_option('v12_html_mode', 'engine')); ?>">
                    <textarea name="v12_html_code" id="v12-html-code-area"
                        rows="12"
                        style="width:100%;max-width:700px;font-family:monospace;font-size:12px;border:1px solid #d1d5db;border-radius:6px;padding:10px;background:#1e1e2e;color:#cdd6f4;resize:vertical;<?php echo get_option('v12_html_mode','engine')==='code' ? '' : 'display:none;'; ?>"
                        placeholder="இங்கே உங்கள் HTML code paste செய்யுங்கள்...&#10;&#10;Example:&#10;&lt;!DOCTYPE html&gt;&#10;&lt;html lang=&quot;en&quot;&gt;&#10;&lt;head&gt;&lt;meta charset=&quot;UTF-8&quot;&gt;&lt;/head&gt;&#10;&lt;body&gt;...&lt;/body&gt;&#10;&lt;/html&gt;"><?php echo esc_textarea(get_option('v12_html_code', '')); ?></textarea>
                    <p id="v12-html-code-note" style="color:#b45309;font-size:11px;margin:6px 0 0;<?php echo get_option('v12_html_mode','engine')==='code' ? '' : 'display:none;'; ?>">
                        ✅ HTML Code Mode active — shortcode இந்த code-ஐ நேரடியாக render செய்யும். Engine iframe மறைந்துவிடும்.
                    </p>
                </div></td></tr>
                <!-- ═══ END HTML CODE PASTE ═══ -->
                <script>
                function v12HtmlMode(mode){
                    document.getElementById('v12-html-mode-val').value = mode;
                    var codeArea = document.getElementById('v12-html-code-area');
                    var codeNote = document.getElementById('v12-html-code-note');
                    var tabEngine = document.getElementById('v12-tab-url');
                    var tabCode   = document.getElementById('v12-tab-code');
                    if(mode === 'code'){
                        codeArea.style.display = 'block';
                        codeNote.style.display = 'block';
                        tabCode.style.background='#f59e0b'; tabCode.style.color='#fff'; tabCode.style.borderColor='#f59e0b';
                        tabEngine.style.background='#fff'; tabEngine.style.color='#374151'; tabEngine.style.borderColor='#d1d5db';
                    } else {
                        codeArea.style.display = 'none';
                        codeNote.style.display = 'none';
                        tabEngine.style.background='#22c55e'; tabEngine.style.color='#fff'; tabEngine.style.borderColor='#22c55e';
                        tabCode.style.background='#fff'; tabCode.style.color='#374151'; tabCode.style.borderColor='#d1d5db';
                    }
                }
                (function(){ v12HtmlMode('<?php echo esc_js(get_option('v12_html_mode','engine')); ?>'); })();
                </script>
                <tr><th>Popup Message</th>
                    <td><input type="text" name="v12_msg" value="<?php echo esc_attr(get_option('v12_msg','Premium Feature Locked! 💎')); ?>" class="regular-text"></td></tr>
                <tr><th>Button 1 (Subscription)</th>
                    <td>
                        <input type="text" name="v12_b1_t" value="<?php echo esc_attr(get_option('v12_b1_t','Subscription')); ?>" style="width:160px;">
                        &nbsp;<input type="text" name="v12_b1_l" value="<?php echo esc_url(get_option('v12_b1_l')); ?>" placeholder="URL" style="width:280px;">
                    </td></tr>
                <tr><th>Button 2 (Buy)</th>
                    <td>
                        <input type="text" name="v12_b2_t" value="<?php echo esc_attr(get_option('v12_b2_t','Buy Course')); ?>" style="width:160px;">
                        &nbsp;<input type="text" name="v12_b2_l" value="<?php echo esc_url(get_option('v12_b2_l')); ?>" placeholder="URL" style="width:280px;">
                    </td></tr>
            </table>

            <!-- 2. FEATURE TOGGLES -->
            <h3 style="border-bottom:2px solid #f59e0b;padding-bottom:6px;margin-top:24px;">
                2. Feature Toggles
                <small style="color:#64748b;font-weight:normal;font-size:13px;">(✅ checked = locked for non-members — includes Diamond 💎 button)</small>
            </h3>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;background:#f8fafc;padding:15px;border-radius:8px;">
                <?php
                $feats = [
                    'font_all'      => '🔤 Font Panel (entire)',
                    'import_link'   => '📎 Import STL Link',
                    'import_stl'    => '📁 Import STL Button',
                    'import_obj'    => '📁 Import OBJ Button',
                    'import_fbx'    => '📁 Import FBX Button',
                    'load_xml'      => '📂 Load XML Button',
                    'load_github_xml' => '🐙 GitHub XML Loader (=name)',
                    'extrude'       => '📐 Axis Extrude + 💎',
                    'offset'        => '📏 Offset Extrude + 💎',
                    'bend'          => '🌀 High Quality Bend + 💎',
                    'boolean'       => '🔗 Boolean Refresh',
                    'tracker'       => '📍 Object Tracker',
                    'plugin'        => '🔌 Add Plugin Button',
                    'pass'          => '🔒 Project Lock Password',
                    'save_xml'      => '💾 Save XML',
                    'stl_single'    => '⬇️ Download STL',
                    'stl_multi'     => '📦 Export Individual STLs',
                    'export_stl'    => '⬇️ Export Format: STL (dropdown option)',
                    'export_obj'    => '⬇️ Export Format: OBJ (dropdown option)',
                    'export_fbx'    => '⬇️ Export Format: FBX (dropdown option)',
                    'selection_only'=> '☑️ Selection Only (Export)',
                    'radius'        => '🔵 Corner Round ONLY (cube/cylinder bevel, NOT width/height/depth) + 💎',
                    'array_opt'     => '⚡ Array Option Control + 💎',
                    'ai_btn'        => '🤖 AI Button Control',
                    'fullscreen'    => '⛶ Fullscreen Button',
                ];
                foreach($feats as $id=>$label): ?>
                    <label style="display:flex;align-items:center;gap:6px;padding:7px;background:#fff;border-radius:6px;border:1px solid #e2e8f0;cursor:pointer;font-size:12px;">
                        <input type="checkbox" name="v12_locked[]" value="<?php echo $id; ?>" <?php echo in_array($id,$locked_f)?'checked':''; ?>>
                        <?php echo $label; ?>
                    </label>
                <?php endforeach; ?>
            </div>

            <!-- 3. PER-FONT LOCK -->
            <h3 style="border-bottom:2px solid #a855f7;padding-bottom:6px;margin-top:24px;">
                3. 🔤 Font Membership Control
                <small style="color:#64748b;font-weight:normal;font-size:13px;">(per-font — checked = Members only 💎, shows lock in dropdown)</small>
            </h3>
            <p style="color:#64748b;font-size:12px;margin-top:0;">
                Unchecked = <b style="color:#22c55e;">Free for all</b> &nbsp;|&nbsp;
                Checked = <b style="color:#a855f7;">Members only (💎 badge in dropdown, click → popup)</b>
            </p>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px;background:#faf5ff;padding:15px;border-radius:8px;border:1px solid #d8b4fe;">
                <?php
                $all_fonts = [
                    'helvetiker'        => 'Default Regular',
                    'bold3d'            => 'Default Bold',
                    'gentilis'          => 'Gentilis Regular',
                    'gentilisb'         => 'Gentilis Bold',
                    'optimer'           => 'Optimer Regular',
                    'optimerb'          => 'Optimer Bold',
                    'droidSans'         => 'Droid Sans',
                    'droidSansB'        => 'Droid Sans Bold',
                    'droidSerif'        => 'Droid Serif',
                    'droidSerifB'       => 'Droid Serif Bold',
                    'dancing_canvas'    => '✍ Dancing Script',
                    'pacifico_canvas'   => '✍ Pacifico',
                    'yellowtail_canvas' => '✍ Yellowtail',
                    'satisfy_canvas'    => '✍ Satisfy',
                    'lobster_canvas'    => '✍ Lobster',
                    'great_vibes_canvas'=> '✍ Great Vibes',
                    'cinzel_canvas'     => '✍ Cinzel Decorative',
                    'bebas_canvas'      => '✍ Bebas Neue',
                    'tamil'             => '🇮🇳 Tamil - Noto Sans',
                    'tamil_murasu'      => '🇮🇳 Tamil - Murasu (Bold)',
                ];
                foreach($all_fonts as $fkey=>$flabel): ?>
                    <label style="display:flex;align-items:center;gap:6px;padding:6px;background:#fff;border-radius:6px;border:1px solid #e9d5ff;cursor:pointer;font-size:12px;">
                        <input type="checkbox" name="v12_locked_fonts[]" value="<?php echo esc_attr($fkey); ?>" <?php echo in_array($fkey,$locked_fonts)?'checked':''; ?>>
                        <?php echo $flabel; ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <p style="color:#94a3b8;font-size:11px;">Tip: Keep basic fonts free, lock cursive/Tamil fonts for members.</p>

            <!-- 4. WHITELIST -->
            <h3 style="border-bottom:2px solid #22c55e;padding-bottom:6px;margin-top:24px;">4. Member Whitelist <small style="color:#64748b;font-weight:normal;">(these roles bypass all locks)</small></h3>
            <div style="display:flex;flex-wrap:wrap;gap:10px;background:#f0fdf4;padding:15px;border-radius:8px;">
                <label style="display:flex;align-items:center;gap:5px;">
                    <input type="checkbox" name="v12_white[]" value="guest" <?php echo in_array('guest',(array)get_option('v12_white',[]))?'checked':''; ?>> Guest
                </label>
                <?php foreach ($wp_roles->get_names() as $rid=>$name): ?>
                    <label style="display:flex;align-items:center;gap:5px;">
                        <input type="checkbox" name="v12_white[]" value="<?php echo $rid; ?>" <?php echo in_array($rid,(array)get_option('v12_white',['administrator']))?'checked':''; ?>>
                        <?php echo $name; ?>
                    </label>
                <?php endforeach; ?>
            </div>

            <?php submit_button('💾 Save V12 Settings'); ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', function() {
    register_setting('v12-settings','v12_url');
    register_setting('v12-settings','v12_msg');
    register_setting('v12-settings','v12_b1_t');
    register_setting('v12-settings','v12_b1_l');
    register_setting('v12-settings','v12_b2_t');
    register_setting('v12-settings','v12_b2_l');
    register_setting('v12-settings','v12_locked');
    register_setting('v12-settings','v12_locked_fonts');
    register_setting('v12-settings','v12_white');
    register_setting('v12-settings','v12_gh_repo_url');
    register_setting('v12-settings','v12_gh_premium_repo_url');
    register_setting('v12-settings','v12_gh_show_dropdown');
    register_setting('v12-settings','v12_html_mode');
    register_setting('v12-settings','v12_html_code');
});

// ===== SHORTCODE =====
add_shortcode('design_engine_ui', function() {
    $engine_url   = get_option('v12_url', home_url('/3d/extrude.html'));
    $locked_f     = (array) get_option('v12_locked', array());
    $locked_fonts = (array) get_option('v12_locked_fonts', array());
    $whitelist    = (array) get_option('v12_white', array('administrator'));

    $has_access = false;
    if(is_user_logged_in()){
        $roles = (array)wp_get_current_user()->roles;
        if(array_intersect($roles,$whitelist)) $has_access = true;
    } elseif(in_array('guest',$whitelist)){ $has_access = true; }

    // HTML code mode — inject code into engine iframe via srcdoc (no black screen)
    $html_mode = get_option('v12_html_mode', 'engine');
    $html_code  = get_option('v12_html_code', '');
    $use_html_code = ($html_mode === 'code' && !empty(trim($html_code)));

    // Fullscreen locked for non-members?
    $fs_locked = in_array('fullscreen', $locked_f) && !$has_access;

    // Fullscreen page URL (same page + ?v14fs=1)
    $fs_url = esc_url(add_query_arg('v14fs','1', get_permalink()));

    // GitHub XML repo URLs
    $free_repo_url    = get_option('v12_gh_repo_url', '');
    $premium_repo_url = get_option('v12_gh_premium_repo_url', '');
    $show_dropdown    = get_option('v12_gh_show_dropdown', '1') === '1';

    // ── Fetch GitHub file lists server-side (PHP) ──────────────────────
    // Convert github.com URL → raw API URL for listing files
    function v16_gh_api_url($repo_url){
        // https://github.com/USER/REPO → https://api.github.com/repos/USER/REPO/contents/
        $url = trim($repo_url);
        if(empty($url)) return '';
        $url = preg_replace('#^https?://github\.com/#', '', $url);
        $url = rtrim($url, '/');
        return 'https://api.github.com/repos/' . $url . '/contents/';
    }
    function v16_fetch_xml_list($api_url){
        if(empty($api_url)) return [];
        $resp = wp_remote_get($api_url, [
            'headers' => ['User-Agent' => 'WordPress/V16-Plugin'],
            'timeout' => 8,
        ]);
        if(is_wp_error($resp)) return [];
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if(!is_array($body)) return [];
        $files = [];
        foreach($body as $item){
            if(isset($item['name']) && strtolower(pathinfo($item['name'],PATHINFO_EXTENSION)) === 'xml'){
                $files[] = [
                    'name'         => pathinfo($item['name'], PATHINFO_FILENAME),
                    'download_url' => isset($item['download_url']) ? $item['download_url'] : '',
                ];
            }
        }
        return $files;
    }
    $free_api    = v16_gh_api_url($free_repo_url);
    $premium_api = v16_gh_api_url($premium_repo_url);

    // Cache fetched lists in transients (5 min) to avoid hitting GitHub API on every page load
    $free_files    = get_transient('v16_free_xml_list');
    $premium_files = get_transient('v16_premium_xml_list');
    if($free_files === false){
        $free_files = v16_fetch_xml_list($free_api);
        set_transient('v16_free_xml_list', $free_files, 300);
    }
    if($premium_files === false){
        $premium_files = v16_fetch_xml_list($premium_api);
        set_transient('v16_premium_xml_list', $premium_files, 300);
    }

    ob_start(); ?>
    <div style="position:relative;width:100%;height:90vh;background:#000;" id="v16-wrap">

        <?php if($use_html_code): ?>
        <!-- HTML Code Mode: render pasted HTML inside a full-size iframe via srcdoc -->
        <iframe id="v12-iframe"
            srcdoc="<?php echo esc_attr($html_code); ?>"
            style="width:100%;height:100%;border:none;"
            allowfullscreen></iframe>
        <?php else: ?>
        <!-- Engine Mode: normal engine URL iframe -->
        <iframe id="v12-iframe" src="<?php echo esc_url($engine_url); ?>"
            style="width:100%;height:100%;border:none;" allowfullscreen></iframe>
        <?php endif; ?>

        <!-- ⛶ Fullscreen Button -->
        <div id="v14-fs-wrap" style="position:absolute;top:8px;left:50%;transform:translateX(-50%);z-index:9998;display:flex;flex-direction:column;align-items:center;gap:4px;">
            <button id="v14-fs-btn"
                style="background:rgba(15,23,42,0.78);border:1px solid <?php echo $fs_locked ? '#7e22ce' : '#334155'; ?>;
                       color:<?php echo $fs_locked ? '#a855f7' : '#94a3b8'; ?>;
                       font-size:16px;width:30px;height:30px;border-radius:8px;
                       cursor:pointer;display:flex;align-items:center;justify-content:center;
                       backdrop-filter:blur(6px);transition:all .18s;line-height:1;padding:0;"
            ><?php echo $fs_locked ? '💎' : '⛶'; ?></button>
            <span id="v14-fs-tip" style="display:none;background:rgba(15,23,42,0.92);color:#e2e8f0;
                  font-size:11px;padding:3px 9px;border-radius:5px;white-space:nowrap;
                  border:1px solid #334155;pointer-events:none;">
                <?php echo $fs_locked ? 'Fullscreen 💎' : 'Fullscreen'; ?>
            </span>
        </div>

        <!-- ═══ GitHub XML Project Picker Overlay (Plugin-side) ═══ -->
        <?php if($show_dropdown && (!empty($free_files) || !empty($premium_files))): ?>
        <div id="v16-gh-overlay" style="display:none;position:absolute;inset:0;background:rgba(2,6,23,0.97);z-index:999998;justify-content:center;align-items:flex-start;padding-top:40px;overflow-y:auto;">
            <div style="background:#1e293b;border-radius:16px;padding:28px;width:90%;max-width:500px;color:#fff;position:relative;">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px;">
                    <h3 style="margin:0;color:#38bdf8;">📂 Project Templates</h3>
                    <button onclick="document.getElementById('v16-gh-overlay').style.display='none'"
                        style="background:#ef4444;border:none;color:#fff;font-size:11px;border-radius:5px;padding:2px 6px;cursor:pointer;font-weight:bold;line-height:1.4;flex-shrink:0;flex-grow:0;align-self:center;min-width:0;max-width:28px;">✖</button>
                </div>
                <p style="color:#64748b;font-size:12px;margin:0 0 14px;">Template பெயரை தேடுங்கள் (4+ எழுத்து)</p>
                <input type="text" id="v16-gh-search"
                    placeholder="Example: keychain, birthday, ring..."
                    style="width:100%;padding:10px 14px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:#e2e8f0;font-size:14px;box-sizing:border-box;margin-bottom:12px;"
                    oninput="v16FilterTemplates(this.value)">
                <div id="v16-gh-list" style="max-height:380px;overflow-y:auto;display:flex;flex-direction:column;gap:6px;">
                    <!-- populated by JS below -->
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Premium Popup -->
        <div id="v12-pop" style="display:none;position:absolute;inset:0;background:rgba(2,6,23,0.98);z-index:999999;justify-content:center;align-items:center;">
            <div style="background:#1e293b;padding:35px;border-radius:16px;text-align:center;color:#fff;max-width:360px;width:90%;">
                <div style="font-size:38px;margin-bottom:8px;">👑</div>
                <h2 id="v12-msg-text" style="margin:0 0 6px;"><?php echo esc_html(get_option('v12_msg','Premium Feature Locked!')); ?></h2>
                <p id="v12-sub-text" style="color:#94a3b8;font-size:13px;margin:0 0 18px;min-height:16px;"></p>
                <a href="<?php echo esc_url(get_option('v12_b1_l')); ?>" style="display:block;background:#38bdf8;color:#000;padding:12px;margin:8px 0;border-radius:8px;text-decoration:none;font-weight:bold;"><?php echo esc_html(get_option('v12_b1_t','Subscription')); ?></a>
                <a href="<?php echo esc_url(get_option('v12_b2_l')); ?>" style="display:block;border:1px solid #38bdf8;color:#38bdf8;padding:12px;border-radius:8px;text-decoration:none;"><?php echo esc_html(get_option('v12_b2_t','Buy Course')); ?></a>
                <button onclick="document.getElementById('v12-pop').style.display='none'" style="margin-top:12px;cursor:pointer;background:#ef4444;color:#fff;border:none;padding:10px 28px;border-radius:8px;font-size:15px;font-weight:bold;">✖ Close</button>
            </div>
        </div>
    </div>

<script>
(function(){
 var hasAccess   = <?php echo $has_access ? 'true' : 'false'; ?>;
 var fsLocked    = <?php echo $fs_locked ? 'true' : 'false'; ?>;
 var fsUrl       = <?php echo json_encode($fs_url); ?>;
 var lockList    = <?php echo json_encode($has_access ? [] : $locked_f); ?>;
 var lockedFonts = <?php echo json_encode($has_access ? [] : $locked_fonts); ?>;
 var fsBtn       = document.getElementById('v14-fs-btn');
 var fsTip       = document.getElementById('v14-fs-tip');
 var ifr         = document.getElementById('v12-iframe');
 var isNativeFS  = false;

 // ── GitHub XML template data (fetched server-side by PHP) ──────────
 var freeFiles    = <?php echo json_encode(array_values($free_files)); ?>;
 var premiumFiles = <?php echo json_encode(array_values($premium_files)); ?>;
 var ghOverlay    = document.getElementById('v16-gh-overlay');
 var ghList       = document.getElementById('v16-gh-list');
 var ghSearch     = document.getElementById('v16-gh-search');

 // ── Build template list HTML ───────────────────────────────────────
 window.v16FilterTemplates = function(query){
   if(!ghList) return;
   var q = (query||'').toLowerCase().trim();
   var html = '';
   var allFree = freeFiles;
   var allPrem = premiumFiles;

   // If query < 4 chars, show all; else filter
   var showAll = q.length < 1;
   var filteredFree = showAll ? allFree : allFree.filter(function(f){ return f.name.toLowerCase().indexOf(q) !== -1; });
   var filteredPrem = showAll ? allPrem : allPrem.filter(function(f){ return f.name.toLowerCase().indexOf(q) !== -1; });

   if(filteredFree.length === 0 && filteredPrem.length === 0){
     html = '<p style="color:#64748b;text-align:center;padding:20px;">No templates found for "'+query+'"</p>';
   } else {
     // Free templates
     filteredFree.forEach(function(f){
       html += '<div onclick="v16LoadTemplate(\''+f.download_url.replace(/'/g,"\\'")+'\')"'+
         ' style="padding:10px 14px;background:#0f172a;border-radius:8px;border:1px solid #1e3a5f;cursor:pointer;'+
         'display:flex;align-items:center;gap:10px;transition:background .15s;"'+
         ' onmouseover="this.style.background=\'#1e293b\'" onmouseout="this.style.background=\'#0f172a\'">'+
         '<span style="font-size:18px;">📄</span>'+
         '<span style="color:#e2e8f0;font-size:13px;font-weight:500;">'+f.name+'</span>'+
         '<span style="margin-left:auto;font-size:10px;color:#22c55e;background:#052e16;padding:2px 7px;border-radius:10px;">FREE</span>'+
         '</div>';
     });
     // Premium templates — shown to ALL users, but locked for non-members
     filteredPrem.forEach(function(f){
       if(hasAccess){
         // Member: click loads the template
         html += '<div onclick="v16LoadTemplate(\''+f.download_url.replace(/'/g,"\\'")+'\')"'+
           ' style="padding:10px 14px;background:#1a0a2e;border-radius:8px;border:1px solid #581c87;cursor:pointer;'+
           'display:flex;align-items:center;gap:10px;transition:background .15s;"'+
           ' onmouseover="this.style.background=\'#2e1065\'" onmouseout="this.style.background=\'#1a0a2e\'">'+
           '<span style="font-size:18px;">👑</span>'+
           '<span style="color:#e9d5ff;font-size:13px;font-weight:500;">'+f.name+'</span>'+
           '<span style="margin-left:auto;font-size:10px;color:#a855f7;background:#3b0764;padding:2px 7px;border-radius:10px;">PREMIUM</span>'+
           '</div>';
       } else {
         // Non-member: click shows upgrade popup
         html += '<div onclick="v16PremiumBlock(\''+f.name.replace(/'/g,"\\'")+'\')"'+
           ' style="padding:10px 14px;background:#1a0a2e;border-radius:8px;border:1px solid #581c87;cursor:pointer;'+
           'display:flex;align-items:center;gap:10px;opacity:0.75;transition:background .15s;"'+
           ' onmouseover="this.style.background=\'#2e1065\'" onmouseout="this.style.background=\'#1a0a2e\'">'+
           '<span style="font-size:18px;">👑</span>'+
           '<span style="color:#e9d5ff;font-size:13px;font-weight:500;">'+f.name+'</span>'+
           '<span style="margin-left:auto;font-size:10px;color:#a855f7;background:#3b0764;padding:2px 7px;border-radius:10px;display:flex;align-items:center;gap:3px;">🔒 PREMIUM</span>'+
           '</div>';
       }
     });
   }
   ghList.innerHTML = html;
 };

 // ── Load a free template URL into the engine iframe ────────────────
 window.v16LoadTemplate = function(downloadUrl){
   if(!downloadUrl) return;
   // Send to engine via postMessage
   try {
     ifr.contentWindow.postMessage({ type:'load_xml_url', url: downloadUrl }, '*');
   } catch(e){}
   // Also hide overlay
   if(ghOverlay) ghOverlay.style.display='none';
 };

 // ── Block premium template for non-members ─────────────────────────
 window.v16PremiumBlock = function(name){
   document.getElementById('v12-sub-text').textContent = '"' + name + '" template Membership Plan உள்ளவர்களுக்கு மட்டுமே! 👑';
   document.getElementById('v12-pop').style.display = 'flex';
 };

 // ── Show overlay when engine sends '=xxxx' search signal ──────────
 window.addEventListener('message', function(e){
   if(!e.data) return;
   // Engine tells plugin: user typed =keychain (4+ chars)
   if(e.data.type === 'gh_xml_search' && typeof e.data.query === 'string'){
     var q = e.data.query;
     if(ghOverlay && ghSearch){
       ghSearch.value = q;
       v16FilterTemplates(q);
       ghOverlay.style.display = 'flex';
     }
     return;
   }
   // Engine asks to open overlay manually
   if(e.data.type === 'gh_xml_open_picker'){
     if(ghOverlay){
       if(ghSearch) ghSearch.value='';
       v16FilterTemplates('');
       ghOverlay.style.display='flex';
       if(ghSearch) ghSearch.focus();
     }
     return;
   }
   // Engine: free user clicked premium template — show membership popup
   if(e.data.type === 'gh_premium_block'){
     var tname = e.data.name || 'Premium template';
     document.getElementById('v12-sub-text').textContent = '"' + tname + '" template Membership Plan உள்ளவர்களுக்கு மட்டுமே! 👑';
     document.getElementById('v12-pop').style.display = 'flex';
     return;
   }
 });

 // ── Tooltip on hover ─────────────────────────────────────────────
 fsBtn.addEventListener('mouseenter', function(){
   fsTip.style.display = 'block';
   fsBtn.style.borderColor = '#38bdf8';
   fsBtn.style.color = '#e2e8f0';
   fsBtn.style.background = 'rgba(30,41,59,0.95)';
 });
 fsBtn.addEventListener('mouseleave', function(){
   fsTip.style.display = 'none';
   fsBtn.style.borderColor = fsLocked ? '#7e22ce' : (isNativeFS ? '#38bdf8' : '#334155');
   fsBtn.style.color = fsLocked ? '#a855f7' : (isNativeFS ? '#e2e8f0' : '#94a3b8');
   fsBtn.style.background = 'rgba(15,23,42,0.78)';
 });

 // ── Popup helper ─────────────────────────────────────────────────
 function showPopup(sub){
   document.getElementById('v12-sub-text').textContent = sub || '';
   document.getElementById('v12-pop').style.display = 'flex';
 }

 // ── Button click — enter or EXIT fullscreen ───────────────────────
 fsBtn.addEventListener('click', function(){
   if(fsLocked){
     showPopup('Fullscreen is a Premium Feature 💎');
     return;
   }

   if(isNativeFS){
     // EXIT native fullscreen
     if(document.exitFullscreen)            document.exitFullscreen();
     else if(document.webkitExitFullscreen) document.webkitExitFullscreen();
     return;
   }

   // ENTER — try native browser fullscreen
   var container = ifr.parentElement;
   var req = container.requestFullscreen || container.webkitRequestFullscreen;
   if(req){
     req.call(container).catch(function(){ openFsWindow(); });
   } else {
     openFsWindow();
   }
 });

 // ── Open fallback clean window ────────────────────────────────────
 function openFsWindow(){
   var win = window.open(fsUrl, '_blank',
     'width='+screen.width+',height='+screen.height+
     ',toolbar=0,menubar=0,location=0,status=0,scrollbars=0,resizable=1'
   );
   if(win) win.focus();
 }

 // ── Native fullscreen state change ───────────────────────────────
 function onFsChange(){
   isNativeFS = !!(document.fullscreenElement || document.webkitFullscreenElement);
   if(isNativeFS){
     fsBtn.textContent = '✕';
     fsTip.textContent = 'Exit Fullscreen';
     fsBtn.style.borderColor = '#38bdf8';
     fsBtn.style.color = '#e2e8f0';
   } else {
     fsBtn.textContent = fsLocked ? '💎' : '⛶';
     fsTip.textContent = fsLocked ? 'Fullscreen 💎' : 'Fullscreen';
     fsBtn.style.borderColor = fsLocked ? '#7e22ce' : '#334155';
     fsBtn.style.color = fsLocked ? '#a855f7' : '#94a3b8';
   }
 }
 document.addEventListener('fullscreenchange', onFsChange);
 document.addEventListener('webkitfullscreenchange', onFsChange);


 // ── Popup with subtitle ───────────────────────────────────────────
 function show(sub){ showPopup(sub); }

 // ── Core lock: block all events + dim + readOnly ──────────────────
 function lock(el, sub){
   if(!el || el.dataset.v12lock) return;
   var s = sub || '';
   var blk = function(e){ e.preventDefault(); e.stopPropagation(); show(s); };
   ['click','mousedown','change','input','keydown','touchstart'].forEach(function(ev){
     el.addEventListener(ev, blk, true);
   });
   if(el.tagName==='INPUT'||el.tagName==='TEXTAREA') el.readOnly = true;
   if(el.type==='checkbox'||el.type==='radio') el.disabled = true;
   el.style.filter  = 'grayscale(1) opacity(0.45)';
   el.style.cursor  = 'not-allowed';
   el.dataset.v12lock = '1';
 }

 // ── Lock entire section: inputs + selects + buttons + diamond btns ─
 function lockSection(sec, sub){
   if(!sec) return;
   sec.querySelectorAll('input,select,textarea,button,.diamond-btn').forEach(function(el){
     lock(el, sub);
   });
 }

 // ── Corner Round safety: never lock basic W/H/D inputs ───────────
 var SAFE_LABELS = ['w:','h:','d:','width','height','depth','size x','size y','size z','radius:','r:','outer','inner'];
 function isBasicDimension(el){
   var row = el.closest('.param-row') || el.parentElement;
   if(!row) return false;
   var lbl = row.querySelector('label');
   var txt = ((lbl ? lbl.textContent : '') || '').toLowerCase().trim();
   // "Radius:" alone (sphere radius) might match — only safe if inside corner-round attr
   return SAFE_LABELS.slice(0,8).some(function(k){ return txt === k; });
 }

 var _fontGuardDone = false;

 function scan(){
  try{
   var doc = ifr.contentDocument || ifr.contentWindow.document;
   if(!doc) return;

   // ══════════════════════════════════════════════════════════════════
   // 1. CORNER ROUND ONLY — lock bevel/radius, never W/H/D
   // ══════════════════════════════════════════════════════════════════
   if(lockList.indexOf('radius') !== -1){
     var sub = 'Corner Round is a Premium Feature 💎';

     // Primary: data-corner-round="1" set by the HTML engine
     doc.querySelectorAll('[data-corner-round="1"]').forEach(function(el){
       if(el.tagName==='INPUT'||el.tagName==='SELECT'||el.tagName==='BUTTON'){
         lock(el, sub);
       } else {
         // It's a wrapper — lock its children
         el.querySelectorAll('input,select,button,.diamond-btn').forEach(function(c){ lock(c, sub); });
       }
     });

     // Secondary: id-based section wrappers
     ['[id^="cornerRoundSection_"]','#cornerRoundSection'].forEach(function(sel){
       doc.querySelectorAll(sel).forEach(function(sec){
         sec.querySelectorAll('input,select,button,.diamond-btn').forEach(function(el){
           if(!isBasicDimension(el)) lock(el, sub);
         });
       });
     });

     // Tertiary: param-rows whose label exactly says "Radius:" inside a corner-round parent
     doc.querySelectorAll('.param-row[data-corner-round]').forEach(function(row){
       row.querySelectorAll('input,select,button,.diamond-btn').forEach(function(el){ lock(el, sub); });
     });
   }

   // ══════════════════════════════════════════════════════════════════
   // 2. BEND — lock inputs + ALL diamond buttons in bend section
   // ══════════════════════════════════════════════════════════════════
   if(lockList.indexOf('bend') !== -1){
     var bendSub = 'High Quality Bend is a Premium Feature 💎';
     var bendSec = doc.getElementById('textBendControls');
     if(bendSec) lockSection(bendSec, bendSub);
     doc.querySelectorAll('[data-bend-section="1"]').forEach(function(el){ lock(el, bendSub); });
     doc.querySelectorAll('.bend-section').forEach(function(s){ lockSection(s, bendSub); });
   }

   // ══════════════════════════════════════════════════════════════════
   // 3. EXTRUDE — lock inputs + checkbox + diamond buttons
   // ══════════════════════════════════════════════════════════════════
   if(lockList.indexOf('extrude') !== -1){
     var extSub = 'Axis Extrude is a Premium Feature 💎';
     var extSec = doc.getElementById('axisExtrudeSection');
     if(extSec) lockSection(extSec, extSub);
     doc.querySelectorAll('[data-extrude-section="1"]').forEach(function(el){ lock(el, extSub); });
     var extList = doc.getElementById('extrudeStepsList');
     if(extList) extList.querySelectorAll('.diamond-btn,input,select,button').forEach(function(el){ lock(el, extSub); });
   }

   // ══════════════════════════════════════════════════════════════════
   // 4. OFFSET EXTRUDE — lock inputs + diamond buttons + generate btn
   // ══════════════════════════════════════════════════════════════════
   if(lockList.indexOf('offset') !== -1){
     var offSub = 'Offset Extrude is a Premium Feature 💎';
     var offSec = doc.getElementById('offsetExtrudeSection');
     if(offSec) lockSection(offSec, offSub);
     doc.querySelectorAll('[data-offset-section="1"]').forEach(function(el){ lock(el, offSub); });
   }

   // ══════════════════════════════════════════════════════════════════
   // 5. ARRAY — lock all controls + diamond buttons
   // ══════════════════════════════════════════════════════════════════
   if(lockList.indexOf('array_opt') !== -1){
     var arrSub = 'Array Tool is a Premium Feature 💎';
     var arrSec = doc.getElementById('arraySection');
     if(arrSec) lockSection(arrSec, arrSub);
     // Also lock dynamic elements by data attribute (rendered after section lock)
     doc.querySelectorAll('[data-array-section="1"]').forEach(function(el){ lock(el, arrSub); });
     [
       '#arrayEnabledCheck','#singleLayerArrayCheck','#worldAxisArrayCheck',
       'button[onclick*="addArrayStep"]','button[onclick*="applyArray"]',
       'button[onclick*="generateArray"]','button[onclick*="createArray"]'
     ].forEach(function(s){ try{ doc.querySelectorAll(s).forEach(function(el){ lock(el, arrSub); }); }catch(e){} });
     var arrList = doc.getElementById('arrayStepsList');
     if(arrList) arrList.querySelectorAll('.diamond-btn,input,select,button').forEach(function(el){ lock(el, arrSub); });
   }

   // ══════════════════════════════════════════════════════════════════
   // 6. FONT PANEL (entire) — lock font search + dropdown
   // ══════════════════════════════════════════════════════════════════
   if(lockList.indexOf('font_all') !== -1){
     var fontSub = 'Font Selection is a Premium Feature 💎';
     doc.querySelectorAll('#fontSearchInput,#fontSelectSection,.diamond-btn[onclick*="pinFontParameter"]').forEach(function(el){
       lock(el, fontSub);
     });
   }

   // ══════════════════════════════════════════════════════════════════
   // 7. PER-FONT LOCK — data-font-key in dropdown items
   // ══════════════════════════════════════════════════════════════════
   if(lockedFonts.length > 0){
     lockedFonts.forEach(function(fkey){
       doc.querySelectorAll('[data-font-key="'+fkey+'"]').forEach(function(item){
         if(item.dataset.v12fontlock) return;
         item.dataset.v12fontlock = '1';
         var orig = item.textContent.replace(' 💎','').trim();
         item.textContent = orig + ' 💎';
         item.style.opacity  = '0.6';
         item.style.cursor   = 'not-allowed';
         item.style.color    = '#a855f7';
         ['mousedown','click','touchstart'].forEach(function(ev){
           item.addEventListener(ev, function(e){
             e.preventDefault(); e.stopPropagation();
             show('"' + orig + '" font is available for Members only 💎');
           }, true);
         });
       });
     });

     // Guard fontSearchInput direct typing / Enter
     if(!_fontGuardDone){
       var fi = doc.getElementById('fontSearchInput');
       if(fi){
         _fontGuardDone = true;
         fi.addEventListener('keydown', function(e){
           if(e.key !== 'Enter') return;
           var val = (fi.value || '').toLowerCase().trim();
           var hit = lockedFonts.some(function(fk){
             return val.includes(fk.replace(/_canvas$/,'').replace(/_/g,' '))
                 || fk.replace(/_/g,' ').includes(val);
           });
           if(hit){ e.preventDefault(); e.stopPropagation(); show('This font is for Members only 💎'); fi.value=''; }
         }, true);
       }
     }
   }

   // ══════════════════════════════════════════════════════════════════
   // 8. ORIGINAL SIMPLE LOCKS
   // ══════════════════════════════════════════════════════════════════
   if(lockList.indexOf('tracker')     !== -1) doc.querySelectorAll('#objectTrackerToggle,.tracker-control').forEach(function(el){ lock(el,'Object Tracker is Premium 💎'); });
   if(lockList.indexOf('plugin')      !== -1) doc.querySelectorAll('#addPluginBtn,.btn-plugin').forEach(function(el){ lock(el,'Plugin feature is Premium 💎'); });
   if(lockList.indexOf('import_link') !== -1) doc.querySelectorAll('#stlLinkInput,button[onclick*="importSTLLink"]').forEach(function(el){ lock(el,'STL Link Import is Premium 💎'); });
   if(lockList.indexOf('load_xml')    !== -1) doc.querySelectorAll('#xmlLoadInput,.btn-load-xml').forEach(function(el){ lock(el,'Load XML is Premium 💎'); });
   if(lockList.indexOf('load_github_xml') !== -1){
     doc.querySelectorAll('#githubXmlSection,#githubProjectInput,#githubXmlSection button').forEach(function(el){ lock(el,'GitHub XML Loader is Premium 💎'); });
     // Also disable the JS function inside the iframe
     try {
       var iwin2 = ifr.contentWindow;
       if(iwin2 && iwin2.loadGithubXmlProject){
         iwin2.loadGithubXmlProject = function(){
           document.getElementById('v12-pop').style.display='flex';
           document.getElementById('v12-sub-text').textContent='GitHub XML Loader is a Premium Feature 💎';
         };
       }
     } catch(e){}
   }
   if(lockList.indexOf('boolean')     !== -1) doc.querySelectorAll('button[onclick*="updateLivePreview"]').forEach(function(el){ lock(el,'Boolean Refresh is Premium 💎'); });
   if(lockList.indexOf('stl_multi')   !== -1) doc.querySelectorAll('#separateExportCheck').forEach(function(el){ lock(el,'Multi-STL Export is Premium 💎'); });
   if(lockList.indexOf('stl_single')  !== -1) doc.querySelectorAll('button[onclick*="downloadFinalSTL"]').forEach(function(el){ lock(el,'STL Download is Premium 💎'); });
   if(lockList.indexOf('pass')        !== -1) doc.querySelectorAll('#projectLockPass').forEach(function(el){ lock(el,'Project Password is Premium 💎'); });

   // ── Save XML Fix: lock button even if checkbox appears selected ──
   if(lockList.indexOf('save_xml') !== -1){
     var saveXmlSub = 'Save XML is a Premium Feature 💎';
     doc.querySelectorAll(
       'button[onclick*="saveXML"],button[onclick*="saveProjectXML"],#saveXmlBtn,.btn-save-xml'
     ).forEach(function(el){ lock(el, saveXmlSub); });
     // Also block the window.saveProjectXML function itself
     try{
       var iwin = ifr.contentWindow;
       if(iwin && iwin.saveProjectXML && !iwin._v12saveXmlLocked){
         iwin._v12saveXmlLocked = true;
         iwin.saveProjectXML = function(){ show(saveXmlSub); };
       }
     }catch(e){}
   }

   // ── Import STL button ────────────────────────────────────────────
   if(lockList.indexOf('import_stl') !== -1){
     var stlSub = 'STL Import is a Premium Feature 💎';
     doc.querySelectorAll('button[onclick*="importSTLFile"]').forEach(function(el){ lock(el, stlSub); });
     try{
       var iwin = ifr.contentWindow;
       if(iwin && iwin.importSTLFile && !iwin._v12importSTLLocked){
         iwin._v12importSTLLocked = true;
         iwin.importSTLFile = function(){ show(stlSub); };
       }
     }catch(e){}
   }

   // ── Import OBJ button ────────────────────────────────────────────
   if(lockList.indexOf('import_obj') !== -1){
     var objSub = 'OBJ Import is a Premium Feature 💎';
     doc.querySelectorAll('button[onclick*="importOBJFile"],#objFileInput').forEach(function(el){ lock(el, objSub); });
     try{
       var iwin = ifr.contentWindow;
       if(iwin && iwin.importOBJFile && !iwin._v12importOBJLocked){
         iwin._v12importOBJLocked = true;
         iwin.importOBJFile = function(){ show(objSub); };
       }
     }catch(e){}
   }

   // ── Import FBX button ────────────────────────────────────────────
   if(lockList.indexOf('import_fbx') !== -1){
     var fbxSub = 'FBX Import is a Premium Feature 💎';
     doc.querySelectorAll('button[onclick*="importFBXFile"],#fbxFileInput').forEach(function(el){ lock(el, fbxSub); });
     try{
       var iwin = ifr.contentWindow;
       if(iwin && iwin.importFBXFile && !iwin._v12importFBXLocked){
         iwin._v12importFBXLocked = true;
         iwin.importFBXFile = function(){ show(fbxSub); };
       }
     }catch(e){}
   }

   // ── Export Format: STL option ────────────────────────────────────
   if(lockList.indexOf('export_stl') !== -1){
     var expStlSub = 'STL Export is a Premium Feature 💎';
     var expSel = doc.getElementById('exportFormatSel');
     if(expSel){
       Array.prototype.forEach.call(expSel.options, function(opt){
         if(opt.value === 'stl'){
           if(!opt.dataset.v12lock){
             opt.dataset.v12lock = '1';
             opt.text = opt.text.replace(' 💎','') + ' 💎';
             opt.style.color = '#a855f7';
             opt.disabled = true;
           }
         }
       });
       if(!expSel.dataset.v12stlguard){
         expSel.dataset.v12stlguard = '1';
         expSel.addEventListener('change', function(){
           if(expSel.value === 'stl'){ show(expStlSub); expSel.value = 'obj'; }
         }, true);
       }
     }
   }

   // ── Export Format: OBJ option ────────────────────────────────────
   if(lockList.indexOf('export_obj') !== -1){
     var expObjSub = 'OBJ Export is a Premium Feature 💎';
     var expSel2 = doc.getElementById('exportFormatSel');
     if(expSel2){
       Array.prototype.forEach.call(expSel2.options, function(opt){
         if(opt.value === 'obj'){
           if(!opt.dataset.v12lock){
             opt.dataset.v12lock = '1';
             opt.text = opt.text.replace(' 💎','') + ' 💎';
             opt.style.color = '#a855f7';
             opt.disabled = true;
           }
         }
       });
       if(!expSel2.dataset.v12objguard){
         expSel2.dataset.v12objguard = '1';
         expSel2.addEventListener('change', function(){
           if(expSel2.value === 'obj'){ show(expObjSub); expSel2.value = 'stl'; }
         }, true);
       }
     }
   }

   // ── Export Format: FBX option ────────────────────────────────────
   if(lockList.indexOf('export_fbx') !== -1){
     var expFbxSub = 'FBX Export is a Premium Feature 💎';
     var expSel3 = doc.getElementById('exportFormatSel');
     if(expSel3){
       Array.prototype.forEach.call(expSel3.options, function(opt){
         if(opt.value === 'fbx'){
           if(!opt.dataset.v12lock){
             opt.dataset.v12lock = '1';
             opt.text = opt.text.replace(' 💎','') + ' 💎';
             opt.style.color = '#a855f7';
             opt.disabled = true;
           }
         }
       });
       if(!expSel3.dataset.v12fbxguard){
         expSel3.dataset.v12fbxguard = '1';
         expSel3.addEventListener('change', function(){
           if(expSel3.value === 'fbx'){ show(expFbxSub); expSel3.value = 'stl'; }
         }, true);
       }
     }
   }

   // ── Selection Only checkbox ──────────────────────────────────────
   if(lockList.indexOf('selection_only') !== -1){
     doc.querySelectorAll('#selectionOnlyCheck').forEach(function(el){ lock(el,'Selection Only is a Premium Feature 💎'); });
   }

   // AI Button
   if(lockList.indexOf('ai_btn') !== -1){
     var aiSub = 'AI Features are Premium 💎';
     ['#aiGenerateBtn','#aiBtn','#aiGenerate','#aiTextTo3D','#aiAutoBtn',
      '#aiOptimizeBtn','#aiPromptInput','#aiPromptBtn',
      '.ai-btn','.ai-button','.ai-generate','.btn-ai','.ai-control',
      '[id*="aiGen"]','[class*="ai-gen"]','[class*="aiBtn"]',
      'button[onclick*="aiGenerate"]','button[onclick*="generateAI"]',
      'button[onclick*="runAI"]','button[onclick*="aiCreate"]'
     ].forEach(function(s){ try{ doc.querySelectorAll(s).forEach(function(el){ lock(el, aiSub); }); }catch(e){} });
     doc.querySelectorAll('button,input[type="button"]').forEach(function(btn){
       var t = (btn.innerText||btn.value||'').toLowerCase().trim();
       if(t==='ai'||t.startsWith('ai ')||t.endsWith(' ai')||t.includes('text to 3d')||t.includes('auto design')){ lock(btn, aiSub); }
     });
   }

  }catch(e){ console.warn('V12 scan error:',e); }
 }

 ifr.addEventListener('load', function(){
   setTimeout(scan, 800);
   setTimeout(scan, 2500);
   setTimeout(scan, 5000);
   // ── Inject GitHub XML config into the 3D engine iframe ──
   var ghConfig = {
     type: 'gh_xml_config',
     repoUrl: <?php echo json_encode($free_repo_url); ?>,
     premiumRepoUrl: <?php echo json_encode($premium_repo_url); ?>,
     hasAccess: <?php echo $has_access ? 'true' : 'false'; ?>,
     showDropdown: <?php echo $show_dropdown ? 'true' : 'false'; ?>,
     locked: <?php echo (!$has_access && in_array('load_github_xml', $locked_f)) ? 'true' : 'false'; ?>,
     // Tell engine: when user types =xxxx, send postMessage to plugin to open picker
     usePluginPicker: true,
     freeFiles: <?php echo json_encode(array_values($free_files)); ?>,
     premiumFiles: <?php echo json_encode(array_values($premium_files)); ?>,
     premiumWarning: 'இந்த template Membership Plan உள்ளவர்களுக்கு மட்டுமே! 👑 Premium plan எடுங்கள்.'
   };
   setTimeout(function(){
     try { ifr.contentWindow.postMessage(ghConfig, '*'); } catch(e){}
   }, 1000);
   setTimeout(function(){
     try { ifr.contentWindow.postMessage(ghConfig, '*'); } catch(e){}
   }, 3000);
 });
 setInterval(scan, 2000);

})();
</script>
<?php return ob_get_clean();
});
