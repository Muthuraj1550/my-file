-- =========================================================
--  Migration: Pinned posts
--  Run this once on an EXISTING install to add "Pin to top"
--  support for blog posts. New installs already get this via
--  db.sql and don't need to run it.
-- =========================================================

ALTER TABLE posts
    ADD COLUMN is_pinned TINYINT(1) NOT NULL DEFAULT 0 AFTER status,
    ADD INDEX idx_is_pinned (is_pinned);
