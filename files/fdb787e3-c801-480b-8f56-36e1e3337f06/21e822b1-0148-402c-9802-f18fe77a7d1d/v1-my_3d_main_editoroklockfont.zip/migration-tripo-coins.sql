-- =========================================================
--  MIGRATION: Tripo AI Coins (separate from ai_daily_limit)
--  Run in phpMyAdmin on your LIVE database.
-- =========================================================
-- Tripo AI is coin-based (each generation costs coins). The daily
-- AI limit in `plans.ai_daily_limit` is UNRELATED - that governs
-- the old text-AI feature and must not be touched by Tripo.

-- 1. Add coin balance to each user.
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS tripo_coins INT UNSIGNED NOT NULL DEFAULT 0 AFTER plan_expiry;

-- 2. Cost (in coins) per Tripo generation. Configurable via settings.
INSERT INTO settings (setting_key, setting_value)
    VALUES ('tripo_cost_per_generation', '10')
    ON DUPLICATE KEY UPDATE setting_value = setting_value;

-- 3. Coin packs (one-time purchases; independent from membership plans).
CREATE TABLE IF NOT EXISTS tripo_coin_packs (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    pack_name    VARCHAR(80) NOT NULL,
    coins        INT UNSIGNED NOT NULL,
    price        DECIMAL(10,2) NOT NULL,
    bonus_label  VARCHAR(60) DEFAULT NULL,
    active       TINYINT(1) NOT NULL DEFAULT 1,
    sort_order   INT NOT NULL DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO tripo_coin_packs (pack_name, coins, price, bonus_label, sort_order) VALUES
    ('Starter Pack',   50,   99.00, NULL,          1),
    ('Popular Pack',   200, 349.00, '+20 bonus',   2),
    ('Studio Pack',    500, 799.00, '+75 bonus',   3),
    ('Pro Pack',      1200, 1799.00,'+200 bonus',  4)
ON DUPLICATE KEY UPDATE pack_name = VALUES(pack_name);

-- 4. Purchase log
CREATE TABLE IF NOT EXISTS tripo_coin_orders (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id      INT UNSIGNED NOT NULL,
    pack_id      INT UNSIGNED NOT NULL,
    coins        INT UNSIGNED NOT NULL,
    amount       DECIMAL(10,2) NOT NULL,
    cf_order_id  VARCHAR(80) DEFAULT NULL,
    status       ENUM('created','paid','failed') NOT NULL DEFAULT 'created',
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id),
    CONSTRAINT fk_tripo_orders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
