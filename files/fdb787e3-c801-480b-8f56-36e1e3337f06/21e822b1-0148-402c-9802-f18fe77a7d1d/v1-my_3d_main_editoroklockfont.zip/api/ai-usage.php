<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$user = current_user();
if ($user) check_and_expire_user($user);

$guestId = $user ? null : ensure_guest_id();

$action = $_GET['action'] ?? ($_POST['action'] ?? 'check');

if ($user) {
    $limit = ai_daily_limit_for($user);
    $used  = ai_usage_today($user['id']);
} else {
    $limit = ai_daily_limit_guest();
    $used  = ai_usage_today_guest($guestId);
}

$isUnlimited = $limit >= 99999;
$remaining   = $isUnlimited ? 99999 : max(0, $limit - $used);
$allowed     = $isUnlimited || $used < $limit;

if ($action === 'check') {
    echo json_encode([
        'allowed'      => $allowed,
        'used'         => $used,
        'limit'        => $limit,
        'remaining'    => $remaining,
        'is_unlimited' => $isUnlimited,
        'logged_in'    => (bool) $user,
    ]);
    exit;
}

if ($action === 'log') {
    if (!$allowed) {
        http_response_code(403);
        echo json_encode(['allowed' => false, 'used' => $used, 'limit' => $limit]);
        exit;
    }
    $body   = json_decode(file_get_contents('php://input'), true);
    $prompt = trim($body['prompt'] ?? ($_POST['prompt'] ?? ''));

    log_ai_usage($user ? $user['id'] : null, $guestId, $prompt);

    echo json_encode([
        'allowed'   => true,
        'used'      => $used + 1,
        'limit'     => $limit,
        'remaining' => $isUnlimited ? 99999 : max(0, $limit - $used - 1),
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'unknown_action']);
