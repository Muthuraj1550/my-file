<?php
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) { $data = $_POST + $_GET; }

$toolId = isset($data['tool_id']) ? (int)$data['tool_id'] : 0;
if ($toolId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false]);
    exit;
}

record_tool_click($toolId);
echo json_encode(['ok' => true]);
