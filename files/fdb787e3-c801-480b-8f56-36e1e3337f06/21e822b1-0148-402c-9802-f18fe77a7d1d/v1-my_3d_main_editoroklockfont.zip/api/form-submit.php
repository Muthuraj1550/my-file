<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . SITE_URL . '/');
    exit;
}

// CSRF check (soft-fail: forms can be embedded on cached pages, so don't hard-block real users,
// but do require a token was present at all to cut down on basic bot spam).
if (empty($_POST['csrf']) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    http_response_code(400);
    die('Security check failed. Please go back, refresh the page, and try again.');
}

$formId = (int)($_POST['form_id'] ?? 0);
$redirectTo = $_POST['redirect_to'] ?? '/';
// Only allow redirecting back to a relative path on this site.
if (strpos($redirectTo, '/') !== 0 || strpos($redirectTo, '//') === 0) $redirectTo = '/';

if (!forms_tables_ready() || !$formId) {
    redirect($redirectTo);
}

$form = get_form($formId);
if (!$form) {
    redirect($redirectTo);
}

// Honeypot filled, or submitted too fast / with a forged timestamp —
// silently drop it like a normal submit (no error shown to a bot).
if (!antispam_check()) {
    redirect($redirectTo);
}

$data = [];
$isSpam = false;
foreach ($form['fields'] as $i => $f) {
    $name = 'f_' . $i;
    $label = $f['label'] ?? ('Field ' . ($i + 1));
    $type = $f['type'] ?? 'text';
    $raw = trim((string)($_POST[$name] ?? ''));
    if (!empty($f['required']) && $raw === '') {
        // Missing a required field - bounce back without saving.
        redirect($redirectTo);
    }
    // Textareas (messages) get more room than short fields like name/phone.
    $val = sanitize_plain_text($raw, $type === 'textarea' ? 2000 : 190);
    // Link-injection / ad-copy spam (e.g. "<a href=...>$3,222 deposit</a>")
    // — real form answers don't contain raw link markup or bare URLs.
    if (looks_like_spam_text($val)) $isSpam = true;
    $data[$label] = $val;
}

if ($isSpam) {
    // Don't save it, and don't tip the bot off either — just bounce back
    // like a normal successful submit.
    redirect($redirectTo);
}

$stmt = db()->prepare("INSERT INTO form_submissions (form_id, data_json, ip_address) VALUES (?,?,?)");
$stmt->execute([$formId, json_encode($data, JSON_UNESCAPED_UNICODE), $_SERVER['REMOTE_ADDR'] ?? null]);

// Append a small flag so the page can show the success message, without breaking existing query params.
$sep = (strpos($redirectTo, '?') === false) ? '?' : '&';
redirect($redirectTo . $sep . 'form_ok_' . $formId . '=1');
