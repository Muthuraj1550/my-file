<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/course_link.php';

header('Content-Type: application/json');

// Called SERVER-TO-SERVER by the course site right after a coin
// purchase succeeds there (see membership.php / course_site_coins_pay_url()).
// Additive only — never touches plan_name/plan_expiry (that's
// api/activate-plan.php's job).

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) $data = $_POST;

$email = trim((string) ($data['email'] ?? ''));
$coins = max(0, (int) ($data['coins'] ?? 0));
$ts    = (int) ($data['ts'] ?? 0);
$sig   = (string) ($data['sig'] ?? '');

if ($email === '' || $coins <= 0) {
    echo json_encode(['ok' => false, 'msg' => 'Missing fields']);
    exit;
}
if (abs(time() - $ts) > 900) {
    echo json_encode(['ok' => false, 'msg' => 'Request expired']);
    exit;
}
$sigParams = ['email' => $email, 'coins' => $coins, 'ts' => $ts];
if (course_link_key() === '' || !hash_equals(course_site_sign($sigParams), $sig)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'msg' => 'Invalid signature']);
    exit;
}

$stmt = db()->prepare("SELECT id, tripo_coins FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['ok' => false, 'msg' => 'No Main Editor account with this email yet — user must register first.']);
    exit;
}

db()->prepare("UPDATE users SET tripo_coins = tripo_coins + ? WHERE id = ?")->execute([$coins, $user['id']]);

echo json_encode(['ok' => true, 'msg' => 'Coins credited', 'user_id' => (int) $user['id'], 'new_total' => (int) $user['tripo_coins'] + $coins]);
