<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/course_link.php';

header('Content-Type: application/json');

// Called SERVER-TO-SERVER by the course site right after a Main Editor
// plan payment succeeds there (it has no gateway of its own — see
// membership.php / course_site_plan_pay_url()). Verified with the same
// api_key both sides already exchange for course logins.

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) $data = $_POST;

$email    = trim((string) ($data['email'] ?? ''));
$planName = trim((string) ($data['plan_name'] ?? ''));
$days     = max(1, (int) ($data['days'] ?? 30));
$coins    = max(0, (int) ($data['coins'] ?? 0));
$ts       = (int) ($data['ts'] ?? 0);
$sig      = (string) ($data['sig'] ?? '');

if ($email === '' || $planName === '') {
    echo json_encode(['ok' => false, 'msg' => 'Missing fields']);
    exit;
}
if (abs(time() - $ts) > 900) {
    echo json_encode(['ok' => false, 'msg' => 'Request expired']);
    exit;
}
$sigParams = ['email' => $email, 'plan_name' => $planName, 'days' => $days, 'coins' => $coins, 'ts' => $ts];
if (course_link_key() === '' || !hash_equals(course_site_sign($sigParams), $sig)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'msg' => 'Invalid signature']);
    exit;
}

$stmt = db()->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['ok' => false, 'msg' => 'No Main Editor account with this email yet — user must register first.']);
    exit;
}

$expiry = date('Y-m-d', strtotime('+' . $days . ' days'));
db()->prepare("UPDATE users SET plan_name = ?, plan_expiry = ?, plan_coins = ? WHERE id = ?")
    ->execute([$planName, $expiry, $coins, $user['id']]);

// Point plan_id at a matching local plan row too, if one exists by name (cosmetic/for admin lists).
try {
    $p = db()->prepare("SELECT id FROM plans WHERE plan_name = ? LIMIT 1");
    $p->execute([$planName]);
    if ($row = $p->fetch()) {
        db()->prepare("UPDATE users SET plan_id = ? WHERE id = ?")->execute([$row['id'], $user['id']]);
    }
} catch (Exception $e) { /* non-fatal */ }

echo json_encode(['ok' => true, 'msg' => 'Plan activated', 'user_id' => (int) $user['id']]);
