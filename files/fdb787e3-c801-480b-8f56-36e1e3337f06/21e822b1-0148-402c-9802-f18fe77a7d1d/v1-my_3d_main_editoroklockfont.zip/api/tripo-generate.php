<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$user = current_user();
if ($user) check_and_expire_user($user);
$guestId = $user ? null : ensure_guest_id();

$apiKey = get_setting('tripo_api_key', '');
if (!$apiKey) {
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => 'not_configured', 'message' => 'Tripo AI API key admin/settings.php-ல set பண்ணப்படல.']);
    exit;
}

$BASE = 'https://openapi.tripo3d.ai/v3';

function tripo_http($method, $url, $apiKey, $body = null) {
    $ch = curl_init($url);
    $headers = ['Authorization: Bearer ' . $apiKey, 'Content-Type: application/json'];
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) return [null, $err];
    return [json_decode($resp, true), $code >= 400 ? ($resp ?: 'HTTP ' . $code) : null];
}

// Try to extract the number of Tripo credits consumed by a finished task from
// the various field names Tripo has used across API revisions.
function tripo_extract_spent_credits($d) {
    $candidates = [
        $d['spent_credits'] ?? null,
        $d['credits_cost']  ?? null,
        $d['credits_used']  ?? null,
        $d['credits']       ?? null,
        $d['cost']          ?? null,
        $d['amount']        ?? null,
        isset($d['usage']) && is_array($d['usage']) ? ($d['usage']['credits'] ?? $d['usage']['amount'] ?? null) : null,
    ];
    foreach ($candidates as $c) {
        if (is_numeric($c) && (int)$c > 0) return (int)$c;
    }
    return 0;
}

$action = $_GET['action'] ?? ($_POST['action'] ?? '');

if ($action === 'create_image') {
    // Same daily AI quota as text-to-3D - Tripo generation shares the one limit.
    if ($user) {
        $limit = ai_daily_limit_for($user);
        $used  = ai_usage_today($user['id']);
    } else {
        $limit = ai_daily_limit_guest();
        $used  = ai_usage_today_guest($guestId);
    }
    $isUnlimited = $limit >= 99999;
    if (!$isUnlimited && $used >= $limit) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'quota_exceeded', 'limit' => $limit]);
        exit;
    }

    if (empty($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'missing_image']);
        exit;
    }
    $tmpPath  = $_FILES['image']['tmp_name'];
    $origName = $_FILES['image']['name'];
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) $ext = 'jpg';
    if (filesize($tmpPath) > 20 * 1024 * 1024) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'image_too_large', 'message' => 'Max 20MB.']);
        exit;
    }

    // Step 1: upload the image to Tripo to get a file_token.
    $ch = curl_init($BASE . '/upload');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $apiKey],
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => ['file' => new CURLFile($tmpPath, 'image/' . ($ext === 'jpg' ? 'jpeg' : $ext), 'upload.' . $ext)],
    ]);
    $uploadResp = curl_exec($ch);
    $uploadErr  = curl_error($ch);
    curl_close($ch);
    $uploadData = json_decode((string) $uploadResp, true);
    $fileToken = $uploadData['data']['file_token'] ?? $uploadData['data']['image_token'] ?? null;
    if ($uploadErr || !$fileToken) {
        echo json_encode(['ok' => false, 'error' => 'tripo_upload_failed', 'detail' => $uploadErr ?: $uploadResp]);
        exit;
    }

    // Step 2: create the image-to-model task with that token.
    list($data, $err) = tripo_http('POST', $BASE . '/generation/image-to-model', $apiKey, [
        'file_token' => $fileToken,
        'model'      => 'v3.1-20260211',
    ]);
    if ($err || !$data || !isset($data['data']['task_id'])) {
        echo json_encode(['ok' => false, 'error' => 'tripo_request_failed', 'detail' => $err]);
        exit;
    }
    log_ai_usage($user ? $user['id'] : null, $guestId, '[Tripo AI] image-to-3d: ' . $origName);
    echo json_encode(['ok' => true, 'task_id' => $data['data']['task_id']]);
    exit;
}

if ($action === 'create') {
    // Same daily AI quota as the Gemini flow - Tripo generation shares the one limit.
    if ($user) {
        $limit = ai_daily_limit_for($user);
        $used  = ai_usage_today($user['id']);
    } else {
        $limit = ai_daily_limit_guest();
        $used  = ai_usage_today_guest($guestId);
    }
    $isUnlimited = $limit >= 99999;
    if (!$isUnlimited && $used >= $limit) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'quota_exceeded', 'limit' => $limit]);
        exit;
    }

    $body   = json_decode(file_get_contents('php://input'), true) ?: [];
    $prompt = trim($body['prompt'] ?? '');
    if ($prompt === '' || mb_strlen($prompt) > 1000) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'invalid_prompt']);
        exit;
    }
    list($data, $err) = tripo_http('POST', $BASE . '/generation/text-to-model', $apiKey, [
        'prompt' => $prompt,
        'model'  => 'v3.1-20260211',
    ]);
    if ($err || !$data || !isset($data['data']['task_id'])) {
        echo json_encode(['ok' => false, 'error' => 'tripo_request_failed', 'detail' => $err]);
        exit;
    }
    log_ai_usage($user ? $user['id'] : null, $guestId, '[Tripo AI] ' . $prompt);
    echo json_encode(['ok' => true, 'task_id' => $data['data']['task_id']]);
    exit;
}

if ($action === 'status') {
    $taskId = trim($_GET['task_id'] ?? '');
    if ($taskId === '') { http_response_code(400); echo json_encode(['ok' => false, 'error' => 'missing_task_id']); exit; }
    list($data, $err) = tripo_http('GET', $BASE . '/tasks/' . urlencode($taskId), $apiKey);
    if ($err || !$data || !isset($data['data'])) {
        echo json_encode(['ok' => false, 'error' => 'tripo_status_failed', 'detail' => $err]);
        exit;
    }
    $d = $data['data'];
    $spent = tripo_extract_spent_credits($d);
    echo json_encode([
        'ok'             => true,
        'status'         => $d['status'] ?? 'unknown',
        'progress'       => $d['progress'] ?? 0,
        // NOTE: model_url expires ~5 minutes after success - the browser must
        // download/import it right away.
        'model_url'      => $d['output']['model_url'] ?? ($d['output']['model'] ?? null),
        // Credits Tripo actually charged for THIS task (0 if unavailable/in progress).
        'spent_credits'  => $spent,
    ]);
    exit;
}

if ($action === 'download') {
    $url  = $_GET['url'] ?? '';
    $host = parse_url($url, PHP_URL_HOST);
    // Tripo's signed model URLs live on several CDNs (tripo3d.ai, tripo3d.com,
    // bcebos.com, cloudfront.net, amazonaws.com). Allow the known upstreams
    // Tripo redirects users to; do NOT allow arbitrary hosts.
    $allowedHost = $host && preg_match(
        '/(^|\.)(tripo3d\.ai|tripo3d\.com|bcebos\.com|amazonaws\.com|cloudfront\.net|myqcloud\.com|aliyuncs\.com)$/i',
        $host
    );
    if (!$allowedHost) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'invalid_url', 'host' => $host]);
        exit;
    }
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 120);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    $bytes = curl_exec($ch);
    $err   = curl_error($ch);
    $code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err || !$bytes || $code >= 400) {
        http_response_code(502);
        echo json_encode(['ok' => false, 'error' => 'download_failed', 'detail' => $err ?: ('HTTP ' . $code)]);
        exit;
    }
    header('Content-Type: model/gltf-binary');
    header('Content-Length: ' . strlen($bytes));
    echo $bytes;
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'unknown_action']);
