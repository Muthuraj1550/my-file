-- =========================================================
--  My3DGifts Standalone Platform - Database Schema
--  Import this file via phpMyAdmin (cPanel) into your DB
-- =========================================================

SET NAMES utf8mb4;

-- ---------- USERS ----------
CREATE TABLE IF NOT EXISTS users (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name            VARCHAR(150) NOT NULL,
    email           VARCHAR(190) NOT NULL,
    phone           VARCHAR(30)  DEFAULT NULL,
    address         TEXT DEFAULT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    role            ENUM('member','admin') NOT NULL DEFAULT 'member',
    plan_id         INT UNSIGNED DEFAULT NULL,
    plan_name       VARCHAR(100) DEFAULT NULL,
    plan_expiry     DATE DEFAULT NULL,
    ai_limit_override INT DEFAULT NULL,   -- optional per-user override of daily AI limit
    status          ENUM('active','blocked') NOT NULL DEFAULT 'active',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- MEMBERSHIP PLANS ----------
CREATE TABLE IF NOT EXISTS plans (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    plan_name       VARCHAR(100) NOT NULL,
    slug            VARCHAR(120) NOT NULL,
    price           DECIMAL(10,2) NOT NULL DEFAULT 0,
    validity_days   INT NOT NULL DEFAULT 30,
    ai_daily_limit  INT NOT NULL DEFAULT 5,        -- AI generations allowed per day (99999 = unlimited)
    premium_designer TINYINT(1) NOT NULL DEFAULT 0, -- 1 = unlocks premium XML templates in Designer
    sort_order      INT NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- ORDERS (Cashfree) ----------
CREATE TABLE IF NOT EXISTS orders (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED NOT NULL,
    plan_id         INT UNSIGNED NOT NULL,
    cf_order_id     VARCHAR(100) NOT NULL,
    amount          DECIMAL(10,2) NOT NULL,
    status          ENUM('created','paid','failed') NOT NULL DEFAULT 'created',
    is_renewal      TINYINT(1) NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY cf_order_id (cf_order_id),
    KEY user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- AI USAGE LOG ----------
CREATE TABLE IF NOT EXISTS ai_usage_log (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     INT UNSIGNED NULL,          -- NULL for anonymous/guest usage
    guest_id    VARCHAR(64) NULL,           -- cookie-based id, used when user_id is NULL
    used_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    prompt      TEXT,
    ip_address  VARCHAR(45),
    PRIMARY KEY (id),
    KEY user_id (user_id),
    KEY guest_id (guest_id),
    KEY used_at (used_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- POSTS (Blog) ----------
CREATE TABLE IF NOT EXISTS posts (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    title           VARCHAR(255) NOT NULL,
    slug            VARCHAR(255) NOT NULL,
    excerpt         VARCHAR(500) DEFAULT NULL,
    content         LONGTEXT,
    featured_image  VARCHAR(255) DEFAULT NULL,
    meta_title      VARCHAR(255) DEFAULT NULL,   -- SEO: overrides <title> if set
    meta_description VARCHAR(500) DEFAULT NULL,  -- SEO: <meta name="description">
    button_text     VARCHAR(100) DEFAULT NULL,   -- optional CTA button shown after content
    button_url      VARCHAR(255) DEFAULT NULL,
    button_new_tab  TINYINT(1) NOT NULL DEFAULT 0,
    status          ENUM('draft','published') NOT NULL DEFAULT 'draft',
    is_pinned       TINYINT(1) NOT NULL DEFAULT 0,   -- pinned posts show first on the blog page
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY slug (slug),
    KEY idx_is_pinned (is_pinned)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- PAGES (Static) ----------
CREATE TABLE IF NOT EXISTS pages (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    title           VARCHAR(255) NOT NULL,
    slug            VARCHAR(255) NOT NULL,
    content         LONGTEXT,
    meta_title      VARCHAR(255) DEFAULT NULL,
    meta_description VARCHAR(500) DEFAULT NULL,
    button_text     VARCHAR(100) DEFAULT NULL,
    button_url      VARCHAR(255) DEFAULT NULL,
    button_new_tab  TINYINT(1) NOT NULL DEFAULT 0,
    status          ENUM('draft','published') NOT NULL DEFAULT 'draft',
    show_in_menu    TINYINT(1) NOT NULL DEFAULT 1,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- SETTINGS (key/value) ----------
CREATE TABLE IF NOT EXISTS settings (
    setting_key     VARCHAR(100) NOT NULL,
    setting_value   TEXT,
    PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- CONTENT VIEWS (Analytics: views + time spent for posts/pages/designer) ----------
CREATE TABLE IF NOT EXISTS content_views (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    content_type    VARCHAR(20) NOT NULL,   -- 'post', 'page', or 'designer'
    content_id      INT UNSIGNED NOT NULL DEFAULT 0,  -- 0 for designer (single page, no row id)
    duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
    ip_address      VARCHAR(45),
    referrer_url    VARCHAR(500) DEFAULT NULL,
    referrer_source VARCHAR(100) DEFAULT NULL,  -- classified: 'Google Search', 'YouTube', 'Facebook / Instagram', 'Direct / App', etc.
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY content_lookup (content_type, content_id),
    KEY created_at (created_at),
    KEY referrer_source (referrer_source)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- REMEMBER-ME TOKENS (keeps a device logged in long-term) ----------
CREATE TABLE IF NOT EXISTS remember_tokens (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED NOT NULL,
    selector        VARCHAR(24) NOT NULL,
    token_hash      VARCHAR(64) NOT NULL,   -- sha256 of the validator half of the cookie
    expires_at      DATETIME NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY selector (selector),
    KEY user_id (user_id),
    CONSTRAINT fk_remember_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- MENU ITEMS (Home page top navigation, admin-editable) ----------
CREATE TABLE IF NOT EXISTS menu_items (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    label           VARCHAR(100) NOT NULL,
    url             VARCHAR(255) NOT NULL,
    sort_order      INT NOT NULL DEFAULT 0,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    target_blank    TINYINT(1) NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO menu_items (label, url, sort_order, is_active) VALUES
('3D Designer', '/designer.php', 1, 1),
('Membership', '/membership.php', 2, 1),
('Blog', '/blog.php', 3, 1)
ON DUPLICATE KEY UPDATE label = label;

-- ---------- DEFAULT SETTINGS ----------
INSERT INTO settings (setting_key, setting_value) VALUES
('cashfree_mode', 'sandbox'),
('cashfree_app_id', ''),
('cashfree_secret_key', ''),
('cashfree_api_version', '2023-08-01'),
('renew_days_before', '5'),
('gemini_api_key', ''),
('guest_ai_daily_limit', '2'),
('site_tagline', '3D Printing Gifts, Designed by You'),
('home_hero_title', 'Design. Print. Gift.'),
('home_hero_subtitle', '3D Printing Gifts, Designed by You'),
('home_hero_btn1_text', 'Open 3D Designer'),
('home_hero_btn1_url', '/designer.php'),
('home_hero_btn2_text', 'View Plans'),
('home_hero_btn2_url', '/membership.php'),
('home_custom_html', ''),
('seo_home_title', ''),
('seo_home_description', ''),
('popup_enabled', '0'),
('popup_title', ''),
('popup_message', ''),
('popup_image', ''),
('popup_button_text', ''),
('popup_button_url', ''),
('popup_delay_seconds', '2'),
('popup_frequency_hours', '24'),
('marquee_enabled', '0'),
('marquee_text', ''),
('marquee_link', ''),
('marquee_bg_color', '#6366f1'),
('marquee_text_color', '#ffffff'),
('marquee_speed_seconds', '18')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

-- ---------- DEFAULT PLANS ----------
INSERT INTO plans (plan_name, slug, price, validity_days, ai_daily_limit, premium_designer, sort_order) VALUES
('Free', 'free', 0.00, 36500, 3, 0, 1),
('Silver - Monthly', 'silver-monthly', 199.00, 30, 15, 1, 2),
('Gold - Monthly', 'gold-monthly', 499.00, 30, 50, 1, 3)
ON DUPLICATE KEY UPDATE plan_name = plan_name;

-- ---------- DEFAULT ADMIN ----------
-- Login: admin@my3dgifts.com / Admin@123  (CHANGE THIS PASSWORD IMMEDIATELY AFTER FIRST LOGIN)
INSERT INTO users (name, email, password_hash, role, plan_name, plan_expiry) VALUES
('Site Admin', 'admin@my3dgifts.com', '$2b$10$ALhItw7A2m5qg2xTKd4IlOoOBPjPdgwQ9J34QGrczK6R5HcFUOMdS', 'admin', 'Admin', '2099-12-31')
ON DUPLICATE KEY UPDATE email = email;

-- ---------- TOOL LAB (admin/tools.php manages, tools.php shows to visitors) ----------
CREATE TABLE IF NOT EXISTS tools (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name            VARCHAR(150) NOT NULL,
    icon            VARCHAR(20)  NOT NULL DEFAULT '🛠️',
    link            VARCHAR(500) NOT NULL,
    color           ENUM('teal','coral') NOT NULL DEFAULT 'teal',
    tag_en          VARCHAR(100) NOT NULL DEFAULT 'Tool',
    tag_ta          VARCHAR(100) NOT NULL DEFAULT 'டூல்',
    desc_en         TEXT,
    desc_ta         TEXT,
    featured        TINYINT(1) NOT NULL DEFAULT 0,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    sort_order      INT NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'Lithophane Tool' AS name, '🖼️' AS icon, 'https://litho.my3dgifts.com/' AS link, 'teal' AS color,
    'Generator' AS tag_en, 'ஜெனரேட்டர்' AS tag_ta,
    'Turn your photo into a 3D-printable lithophane model.' AS desc_en,
    'உங்கள் புகைப்படத்தை 3D பிரிண்ட் செய்யக்கூடிய லித்தோஃபேன் மாடலாக மாற்றுங்கள்.' AS desc_ta,
    1 AS featured, 1 AS sort_order
) t WHERE NOT EXISTS (SELECT 1 FROM tools);

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'Cutter — Part Splitter', '✂️', 'https://my3dgifts.com/3d/cutter.html', 'coral',
    'Editor', 'எடிட்டர்',
    'Split a large 3D model into parts, joined with connectors.',
    'பெரிய 3D மாடலை பாகங்களாக பிரித்து, கனெக்டர் உடன் இணைக்க உதவும் டூல்.',
    1, 2
) t WHERE NOT EXISTS (SELECT 1 FROM tools WHERE link = 'https://my3dgifts.com/3d/cutter.html');

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'Timelapse Video Editor', '🎬', 'https://my3dgifts.com/3d-print-timelapse-video-editor/', 'teal',
    'Editor', 'எடிட்டர்',
    'Edit and prepare your 3D print timelapse videos.',
    'உங்கள் 3D பிரிண்ட் டைம்லேப்ஸ் வீடியோக்களை எடிட் செய்து தயார் செய்யுங்கள்.',
    0, 3
) t WHERE NOT EXISTS (SELECT 1 FROM tools WHERE link = 'https://my3dgifts.com/3d-print-timelapse-video-editor/');

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'Support Generator', '🧱', 'https://my3dgifts.com/3d-print-support-generator/', 'coral',
    'Generator', 'ஜெனரேட்டர்',
    'Automatically generates the support structure your model needs.',
    'உங்கள் 3D மாடலுக்கு தேவையான சப்போர்ட் ஸ்ட்ரக்சரை தானாக உருவாக்கும்.',
    0, 4
) t WHERE NOT EXISTS (SELECT 1 FROM tools WHERE link = 'https://my3dgifts.com/3d-print-support-generator/');

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'QR Code Design', '🔳', 'https://my3dgifts.com/qr.html', 'coral',
    'Designer', 'டிசைனர்',
    'Design a scannable QR code that can be 3D printed.',
    '3D பிரிண்ட் செய்யக்கூடிய, ஸ்கேன் ஆகக்கூடிய கியூஆர் கோட் டிசைன் செய்யுங்கள்.',
    0, 5
) t WHERE NOT EXISTS (SELECT 1 FROM tools WHERE link = 'https://my3dgifts.com/qr.html');

INSERT INTO menu_items (label, url, sort_order, is_active)
SELECT * FROM (SELECT 'Tools' AS label, '/tools.php' AS url, 4 AS sort_order, 1 AS is_active) t
WHERE NOT EXISTS (SELECT 1 FROM menu_items WHERE url = '/tools.php');
