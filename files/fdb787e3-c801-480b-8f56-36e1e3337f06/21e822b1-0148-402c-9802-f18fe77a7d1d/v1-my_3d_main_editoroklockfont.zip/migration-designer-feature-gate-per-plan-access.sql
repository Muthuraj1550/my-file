-- =========================================================
--  Per-plan feature access levels (locked / preview / allowed)
--  + a separate "Image to 3D" feature (was sharing ai_panel's gate).
--
--  Run AFTER migration-designer-feature-gate.sql (and its -fix /
--  -rename-stylish follow-ups if you already ran those).
-- =========================================================

ALTER TABLE designer_feature_plans
  ADD COLUMN access ENUM('locked','preview','allowed') NOT NULL DEFAULT 'allowed' AFTER plan_id;

INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order) VALUES
('image_to_3d', 'Image to 3D (Tripo AI)', 'fully_locked', 75);
