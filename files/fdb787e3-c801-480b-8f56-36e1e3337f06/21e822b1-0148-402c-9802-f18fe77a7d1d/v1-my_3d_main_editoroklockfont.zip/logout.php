<?php
require_once __DIR__ . '/includes/auth.php';
log_user_out();
header('Location: ' . SITE_URL . '/');
exit;
