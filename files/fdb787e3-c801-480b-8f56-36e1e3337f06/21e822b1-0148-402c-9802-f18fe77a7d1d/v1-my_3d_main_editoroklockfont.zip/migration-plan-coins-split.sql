-- Split coin balances into two buckets:
--   plan_coins       = monthly membership coins (reset on every plan activation/renewal, spent FIRST)
--   tripo_coins      = purchased/lifetime coins (accumulate, spent AFTER plan_coins are exhausted)
--
-- tripo_coins column already exists from migration-tripo-coins.sql; here we
-- only add plan_coins and the admin setting for the rupee-per-coin rate.

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS plan_coins INT UNSIGNED NOT NULL DEFAULT 0 AFTER tripo_coins;

INSERT INTO settings (setting_key, setting_value)
VALUES ('coin_price_inr', '1')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

-- Minimum coins per custom purchase (guardrail so users don't buy 1 coin).
INSERT INTO settings (setting_key, setting_value)
VALUES ('coin_min_purchase', '10')
ON DUPLICATE KEY UPDATE setting_key = setting_key;
