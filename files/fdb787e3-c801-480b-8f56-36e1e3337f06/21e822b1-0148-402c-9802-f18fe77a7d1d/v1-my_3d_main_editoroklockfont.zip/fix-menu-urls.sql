-- Run in phpMyAdmin > your database > SQL tab.
-- Points every menu link at a page that really exists.
UPDATE menu_items SET url = '/designer.php'   WHERE url IN ('/designer','designer','/designer/');
UPDATE menu_items SET url = '/membership.php' WHERE url IN ('/plan','/plans','/pricing','plan','plans','/plan.php','/plans.php','/pricing.php');
UPDATE menu_items SET url = '/tools.php'      WHERE url IN ('/tools','tools');
UPDATE menu_items SET url = '/blog.php'       WHERE url IN ('/blog','blog');
UPDATE menu_items SET url = '/dashboard.php'  WHERE url IN ('/dashboard','dashboard');
UPDATE menu_items SET url = '/login.php'      WHERE url IN ('/login','login');
UPDATE menu_items SET url = '/register.php'   WHERE url IN ('/register','register');
SELECT id, label, url, is_active FROM menu_items ORDER BY sort_order;
