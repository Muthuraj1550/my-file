<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cashfree.php';

require_login();

$orderId = $_GET['order_id'] ?? '';
$result = $orderId ? cashfree_verify_and_activate($orderId) : ['ok' => false, 'msg' => 'Missing order id'];

$pageTitle = 'Payment Status';
include __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:520px;margin:30px auto;text-align:center;">
  <?php if ($result['ok']): ?>
    <h1 style="color:#22c55e;">✅ Payment Successful</h1>
    <p>Your plan has been activated. Enjoy your upgraded membership!</p>
  <?php else: ?>
    <h1 style="color:#f59e0b;">⏳ Payment Processing</h1>
    <p>We couldn't confirm your payment yet (<?php echo h($result['msg']); ?>). If money was
    deducted, please wait a minute and refresh your dashboard - it updates automatically once
    Cashfree confirms the payment. Contact support if this persists.</p>
  <?php endif; ?>
  <a href="<?php echo SITE_URL; ?>/dashboard.php" class="btn">Go to Dashboard</a>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
