-- =========================================================
--  MIGRATION: Tool Lab (admin/tools.php + public tools.php)
--  Run this ONLY if your site is already live and you already
--  imported db.sql (or a previous migration) before.
--  Brand-new installs: just import db.sql, then this file.
-- =========================================================

CREATE TABLE IF NOT EXISTS tools (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name            VARCHAR(150) NOT NULL,
    icon            VARCHAR(20)  NOT NULL DEFAULT '🛠️',
    link            VARCHAR(500) NOT NULL,
    color           ENUM('teal','coral') NOT NULL DEFAULT 'teal',
    tag_en          VARCHAR(100) NOT NULL DEFAULT 'Tool',
    tag_ta          VARCHAR(100) NOT NULL DEFAULT 'டூல்',
    desc_en         TEXT,
    desc_ta         TEXT,
    featured        TINYINT(1) NOT NULL DEFAULT 0,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    sort_order      INT NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed with the same starter tools from the old standalone Tool Lab builder
-- (safe to edit/delete/reorder afterwards in Admin > Tools). Only runs if
-- the table is currently empty, so it won't duplicate on re-import.
INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'Lithophane Tool' AS name, '🖼️' AS icon, 'https://litho.my3dgifts.com/' AS link, 'teal' AS color,
    'Generator' AS tag_en, 'ஜெனரேட்டர்' AS tag_ta,
    'Turn your photo into a 3D-printable lithophane model.' AS desc_en,
    'உங்கள் புகைப்படத்தை 3D பிரிண்ட் செய்யக்கூடிய லித்தோஃபேன் மாடலாக மாற்றுங்கள்.' AS desc_ta,
    1 AS featured, 1 AS sort_order
) t WHERE NOT EXISTS (SELECT 1 FROM tools);

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'Cutter — Part Splitter', '✂️', 'https://my3dgifts.com/3d/cutter.html', 'coral',
    'Editor', 'எடிட்டர்',
    'Split a large 3D model into parts, joined with connectors.',
    'பெரிய 3D மாடலை பாகங்களாக பிரித்து, கனெக்டர் உடன் இணைக்க உதவும் டூல்.',
    1, 2
) t WHERE NOT EXISTS (SELECT 1 FROM tools WHERE link = 'https://my3dgifts.com/3d/cutter.html');

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'Timelapse Video Editor', '🎬', 'https://my3dgifts.com/3d-print-timelapse-video-editor/', 'teal',
    'Editor', 'எடிட்டர்',
    'Edit and prepare your 3D print timelapse videos.',
    'உங்கள் 3D பிரிண்ட் டைம்லேப்ஸ் வீடியோக்களை எடிட் செய்து தயார் செய்யுங்கள்.',
    0, 3
) t WHERE NOT EXISTS (SELECT 1 FROM tools WHERE link = 'https://my3dgifts.com/3d-print-timelapse-video-editor/');

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'Support Generator', '🧱', 'https://my3dgifts.com/3d-print-support-generator/', 'coral',
    'Generator', 'ஜெனரேட்டர்',
    'Automatically generates the support structure your model needs.',
    'உங்கள் 3D மாடலுக்கு தேவையான சப்போர்ட் ஸ்ட்ரக்சரை தானாக உருவாக்கும்.',
    0, 4
) t WHERE NOT EXISTS (SELECT 1 FROM tools WHERE link = 'https://my3dgifts.com/3d-print-support-generator/');

INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, sort_order)
SELECT * FROM (SELECT
    'QR Code Design', '🔳', 'https://my3dgifts.com/qr.html', 'coral',
    'Designer', 'டிசைனர்',
    'Design a scannable QR code that can be 3D printed.',
    '3D பிரிண்ட் செய்யக்கூடிய, ஸ்கேன் ஆகக்கூடிய கியூஆர் கோட் டிசைன் செய்யுங்கள்.',
    0, 5
) t WHERE NOT EXISTS (SELECT 1 FROM tools WHERE link = 'https://my3dgifts.com/qr.html');

-- Add a "Tools" link to the site's main navigation menu (Admin > Menu also
-- lets you move/rename/hide it afterwards).
INSERT INTO menu_items (label, url, sort_order, is_active)
SELECT * FROM (SELECT 'Tools' AS label, '/tools.php' AS url, 4 AS sort_order, 1 AS is_active) t
WHERE NOT EXISTS (SELECT 1 FROM menu_items WHERE url = '/tools.php');
