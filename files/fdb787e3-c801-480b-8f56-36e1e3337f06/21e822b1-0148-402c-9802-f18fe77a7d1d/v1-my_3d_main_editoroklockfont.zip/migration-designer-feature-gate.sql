-- =========================================================
--  Main Editor - Per-feature plan gating
--
--  Lets admin control, per designer-page feature:
--   - lock_mode: 'free' (no restriction), 'export_locked' (usable/
--     previewable for everyone, but exporting needs a plan that
--     unlocks it), or 'fully_locked' (can't even use it without a
--     plan that unlocks it)
--   - which plan(s) unlock it (many-to-many via designer_feature_plans)
--
--  Manageable from BOTH sides:
--   - admin/designer-features.php  (pick plans per feature)
--   - admin/plans.php              (pick features per plan)
--
--  Safe to import on a live site - only adds 2 new tables + seeds
--  the known designer features (all default to 'fully_locked', no
--  plans attached yet — admin decides who unlocks what).
-- =========================================================

CREATE TABLE IF NOT EXISTS designer_features (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  feature_key  VARCHAR(60) NOT NULL,
  feature_name VARCHAR(120) NOT NULL,
  lock_mode    ENUM('free','export_locked','fully_locked') NOT NULL DEFAULT 'fully_locked',
  sort_order   INT NOT NULL DEFAULT 0,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_feature_key (feature_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS designer_feature_plans (
  feature_id INT NOT NULL,
  plan_id    INT NOT NULL,
  PRIMARY KEY (feature_id, plan_id),
  KEY idx_dfp_plan (plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order) VALUES
('import_svg',        'Import SVG',                         'fully_locked', 10),
('stylish_font',       'Stylish Font (Yellowtail)',           'fully_locked', 20),
('hq_bend',            'High Quality Bend',                  'export_locked', 30),
('multi_axis_extrude', 'Multi-Axis Extrude',                 'export_locked', 40),
('offset_extrude',     'Offset Extrude (Shell)',              'export_locked', 50),
('add_plugin',         'Add Plugin / Add Effect',             'fully_locked', 60),
('ai_panel',           'AI Panel (Tripo AI Studio)',          'fully_locked', 70),
('export_separate',    'Export - Separate Layers',            'fully_locked', 80),
('export_selection',   'Export - Selection Only',             'fully_locked', 90),
('export_obj',         'Export - OBJ Format',                 'fully_locked', 100),
('export_fbx',         'Export - FBX Format',                 'fully_locked', 110);
