<?php
/**
 * =========================================================
 *  My3DGifts Standalone Platform - Main Configuration
 * =========================================================
 *  Edit the values below after uploading to your hosting.
 *  Do NOT share this file publicly.
 */

// ---------- 1. DATABASE ----------
define('DB_HOST', 'localhost');          // usually 'localhost' on cPanel hosting
define('DB_NAME', 'mydgifts_editor');    // create this DB in cPanel -> MySQL Databases
define('DB_USER', 'mydgifts_editor');    // DB user you create
define('DB_PASS', 'My3dgifts@55');       // DB user password

// ---------- 2. SITE ----------
define('SITE_URL', 'https://my3dgifts.com');   // no trailing slash
define('SITE_NAME', 'My 3D Gifts Pro');

// ---------- 3. SECURITY ----------
// Random secret (auto-generated for you) - used for session/cookie hashing
define('APP_SECRET', '67afdbf2e7ddf144b533e83d669e9c5279b898c491f30e3e6c9aba145dfd9ed2');

// Session cookie lifetime (seconds) - 30 days
define('SESSION_LIFETIME', 60 * 60 * 24 * 30);

// ---------- 4. ERROR DISPLAY ----------
// Set to false once the live site is confirmed working
define('APP_DEBUG', true);

if (APP_DEBUG) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

date_default_timezone_set('Asia/Kolkata');
