-- =========================================================
--  MIGRATION: Cloud Project Save + Recovery (login-based)
--  Run this in phpMyAdmin on your LIVE database.
--  Brand-new installs: import this too, after db.sql.
-- =========================================================

-- 1. How many NAMED "Save As" project slots each plan gets.
--    (Everyone who is logged in - Free plan included - always gets ONE
--    auto-saved "last project" slot for recovery, regardless of this number.
--    This column controls EXTRA named saves on top of that, for paid plans.)
ALTER TABLE plans ADD COLUMN IF NOT EXISTS project_slots INT UNSIGNED NOT NULL DEFAULT 0 AFTER premium_designer;

UPDATE plans SET project_slots = 0  WHERE slug = 'free';
UPDATE plans SET project_slots = 5  WHERE slug = 'silver-monthly';
UPDATE plans SET project_slots = 20 WHERE slug = 'gold-monthly';

-- 2. Cloud-saved projects (per logged-in user). Total size per user is
--    capped in application code (api/project-store.php) at 10 MB.
CREATE TABLE IF NOT EXISTS saved_projects (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     INT UNSIGNED NOT NULL,
    slot_name   VARCHAR(100) NOT NULL DEFAULT '__auto__', -- '__auto__' = last-used project (everyone); anything else = a named "Save As" (paid plans only)
    xml_data    LONGTEXT NOT NULL,
    size_bytes  INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY user_slot (user_id, slot_name),
    KEY user_id (user_id),
    CONSTRAINT fk_saved_projects_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ⚠ Same note as the other migration files: if "ADD COLUMN IF NOT EXISTS" gives
-- an error on an older MySQL/MariaDB version, just remove "IF NOT EXISTS" from
-- that one line and run it again.
