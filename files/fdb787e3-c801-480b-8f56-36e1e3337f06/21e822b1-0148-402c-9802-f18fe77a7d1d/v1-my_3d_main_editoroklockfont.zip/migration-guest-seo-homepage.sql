-- =========================================================
--  MIGRATION: Guest Designer access, SEO tags + CTA buttons
--  for Posts/Pages, and Home Page Customizer settings.
--  Run this ONLY if your site is already live.
--  Brand-new installs: just import db.sql, skip this file.
-- =========================================================

-- 1. Allow anonymous (not-logged-in) AI usage tracking
ALTER TABLE ai_usage_log MODIFY user_id INT UNSIGNED NULL;
ALTER TABLE ai_usage_log ADD COLUMN IF NOT EXISTS guest_id VARCHAR(64) NULL AFTER user_id;
ALTER TABLE ai_usage_log ADD INDEX IF NOT EXISTS guest_id (guest_id);

-- 2. SEO + CTA button fields on Posts
ALTER TABLE posts ADD COLUMN IF NOT EXISTS meta_title VARCHAR(255) DEFAULT NULL AFTER featured_image;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS meta_description VARCHAR(500) DEFAULT NULL AFTER meta_title;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS button_text VARCHAR(100) DEFAULT NULL AFTER meta_description;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS button_url VARCHAR(255) DEFAULT NULL AFTER button_text;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS button_new_tab TINYINT(1) NOT NULL DEFAULT 0 AFTER button_url;

-- 3. SEO + CTA button fields on Pages
ALTER TABLE pages ADD COLUMN IF NOT EXISTS meta_title VARCHAR(255) DEFAULT NULL AFTER content;
ALTER TABLE pages ADD COLUMN IF NOT EXISTS meta_description VARCHAR(500) DEFAULT NULL AFTER meta_title;
ALTER TABLE pages ADD COLUMN IF NOT EXISTS button_text VARCHAR(100) DEFAULT NULL AFTER meta_description;
ALTER TABLE pages ADD COLUMN IF NOT EXISTS button_url VARCHAR(255) DEFAULT NULL AFTER button_text;
ALTER TABLE pages ADD COLUMN IF NOT EXISTS button_new_tab TINYINT(1) NOT NULL DEFAULT 0 AFTER button_url;

-- 4. New settings (guest AI limit + homepage customizer + homepage SEO)
INSERT INTO settings (setting_key, setting_value) VALUES
('guest_ai_daily_limit', '2'),
('home_hero_title', 'Design. Print. Gift.'),
('home_hero_subtitle', '3D Printing Gifts, Designed by You'),
('home_hero_btn1_text', 'Open 3D Designer'),
('home_hero_btn1_url', '/designer.php'),
('home_hero_btn2_text', 'View Plans'),
('home_hero_btn2_url', '/membership.php'),
('home_custom_html', ''),
('seo_home_title', ''),
('seo_home_description', '')
ON DUPLICATE KEY UPDATE setting_key = setting_key;
