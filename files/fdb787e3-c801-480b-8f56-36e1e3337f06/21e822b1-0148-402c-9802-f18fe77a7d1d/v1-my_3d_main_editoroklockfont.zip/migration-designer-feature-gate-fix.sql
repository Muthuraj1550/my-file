-- =========================================================
--  FIX for migration-designer-feature-gate.sql failing with:
--    #1005 - Can't create table 'designer_feature_plans'
--    (errno: 150 "Foreign key constraint is incorrectly formed")
--
--  Cause: plans.id's exact column type/attributes didn't match what
--  the FK constraint assumed. Fix: drop the strict FK constraints,
--  use plain indexes instead (same practical effect for this app —
--  all deletes already go through PHP, not raw SQL cascades).
--
--  Run this AFTER migration-designer-feature-gate.sql (which already
--  created designer_features successfully, per your screenshot).
--  Safe to run even if designer_feature_plans doesn't exist yet.
-- =========================================================

DROP TABLE IF EXISTS designer_feature_plans;

CREATE TABLE designer_feature_plans (
  feature_id INT NOT NULL,
  plan_id    INT NOT NULL,
  PRIMARY KEY (feature_id, plan_id),
  KEY idx_dfp_plan (plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
