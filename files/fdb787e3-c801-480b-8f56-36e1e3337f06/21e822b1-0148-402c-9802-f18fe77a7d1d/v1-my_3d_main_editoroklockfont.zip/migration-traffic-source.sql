-- =========================================================
--  MIGRATION: Traffic Source tracking + Tool Lab click tracking
--  Run this ONLY if your site is already live (already imported
--  db.sql before). Brand-new installs: db.sql already has this.
--
--  Adds referrer_url / referrer_source columns to content_views so
--  Admin > Analytics can show WHERE visitors came from (Google
--  search, YouTube, Facebook/Instagram, other sites, or direct/app).
--  Tool Lab clicks are tracked in the same table using
--  content_type='tool_click' and content_id = tools.id — no new
--  table needed.
-- =========================================================

ALTER TABLE content_views
    ADD COLUMN IF NOT EXISTS referrer_url    VARCHAR(500) DEFAULT NULL AFTER ip_address,
    ADD COLUMN IF NOT EXISTS referrer_source VARCHAR(100) DEFAULT NULL AFTER referrer_url;

ALTER TABLE content_views
    ADD KEY IF NOT EXISTS referrer_source (referrer_source);

-- If your MySQL version doesn't support "ADD COLUMN IF NOT EXISTS" (older
-- MariaDB), comment the two ALTER TABLE blocks above and run these instead:
--
-- ALTER TABLE content_views ADD COLUMN referrer_url VARCHAR(500) DEFAULT NULL AFTER ip_address;
-- ALTER TABLE content_views ADD COLUMN referrer_source VARCHAR(100) DEFAULT NULL AFTER referrer_url;
-- ALTER TABLE content_views ADD KEY referrer_source (referrer_source);
