-- Adds a "show in footer" toggle to pages, so pages like About / Contact Us / Privacy Policy
-- can be picked to appear as links in the site footer (managed from Admin > Pages).
ALTER TABLE pages
    ADD COLUMN show_in_footer TINYINT(1) NOT NULL DEFAULT 0 AFTER show_in_menu;
