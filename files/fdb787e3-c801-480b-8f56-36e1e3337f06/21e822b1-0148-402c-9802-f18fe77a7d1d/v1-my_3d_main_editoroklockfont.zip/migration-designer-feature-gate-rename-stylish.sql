-- Run this if you already imported migration-designer-feature-gate.sql
-- before this correction. "Stylish Lock" turned out to mean the
-- "Yellowtail (Stylish)" font, not a project-password feature.
-- Safe to run even if you haven't touched the old row yet.

UPDATE designer_features
   SET feature_key = 'stylish_font', feature_name = 'Stylish Font (Yellowtail)'
 WHERE feature_key = 'project_lock_pass';

-- In case you're importing fresh and the row doesn't exist at all yet:
INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order)
VALUES ('stylish_font', 'Stylish Font (Yellowtail)', 'fully_locked', 20);
