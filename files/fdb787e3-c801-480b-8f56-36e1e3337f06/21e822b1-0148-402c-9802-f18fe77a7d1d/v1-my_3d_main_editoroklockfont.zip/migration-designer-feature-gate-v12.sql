-- =========================================================
--  v12 — Designer feature gating: Boolean operations
--
--  Adds per-plan control for the 3 boolean group/layer operations
--  (Union / Subtract / Intersect) — controllable from the same
--  Designer Access grid as everything else.
--
--  Default lock_mode is 'free' (no restriction) so nothing breaks for
--  existing users/templates — set it to whatever you want per plan on
--  admin/designer-access.php whenever you're ready to restrict it.
--
--  Run AFTER migration-designer-feature-gate-v11.sql.
--  Safe to re-run (INSERT IGNORE).
-- =========================================================

INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order) VALUES
('bool_union',     'Boolean — Union',     'free', 20),
('bool_subtract',  'Boolean — Subtract',  'free', 22),
('bool_intersect', 'Boolean — Intersect', 'free', 24);
