<?php
/**
 * Admin -> Course Site Access
 * Course site la generate panna API key-a INGA enter pannunga.
 * Ithu API key generate panradhu illa.
 */
$adminTitle = 'Course Site Access';
require_once __DIR__ . '/_layout_top.php';
require_once __DIR__ . '/../includes/course_link.php';

$testResult = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $do = $_POST['do'] ?? 'save';

    if ($do === 'save') {
        set_setting('course_api_url',  rtrim(trim($_POST['course_api_url'] ?? ''), '/'));
        set_setting('course_api_key',  trim($_POST['course_api_key'] ?? ''));
        set_setting('course_api_site', trim($_POST['course_api_site'] ?? 'main_editor') ?: 'main_editor');
        set_setting('course_login_enabled', isset($_POST['course_login_enabled']) ? '1' : '0');
        set_setting('course_plan_id',  (int)($_POST['course_plan_id'] ?? 0));
        set_setting('course_plan_days', max(1, (int)($_POST['course_plan_days'] ?? 30)));
        flash('Course site settings saved.');
        redirect('/admin/course-access.php');
    }

    if ($do === 'test') {
        $res = course_link_verify(trim($_POST['t_user'] ?? ''), (string)($_POST['t_pass'] ?? ''));
        $testResult = $res;
    }
}

$plans = all_plans();
?>
<div class="card">
  <h3>🔗 How it works</h3>
  <ol style="color:var(--muted);font-size:13.5px;line-height:1.9;">
    <li>Course site → <b>Admin → Tool Sites &amp; Access</b> la <code>main_editor</code> site oda <b>API key</b> copy pannunga.</li>
    <li>Antha key-ya keezha paste pannunga. (Inga key generate aagadhu — course site thaan key kudukkum.)</li>
    <li>Course vaanguna user, ippo indha site oda <b>Login</b> page la avanga <b>course username + password</b> podalaam.</li>
    <li>Login aana odane, keezha select panna plan apply aagum → <b>paid templates + feature limits</b> ellam unlock.</li>
  </ol>
</div>

<div class="card" style="max-width:680px;">
  <h3>Course Site API</h3>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="do" value="save">

    <label style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
      <input type="checkbox" name="course_login_enabled" value="1" style="width:auto;"
             <?php echo get_setting('course_login_enabled', '1') === '1' ? 'checked' : ''; ?>>
      <span>Course username/password login <b>ON</b></span>
    </label>

    <label>Course Site URL</label>
    <input type="text" name="course_api_url" placeholder="https://mycourse.com"
           value="<?php echo h(get_setting('course_api_url', '')); ?>">

    <label>API Key (course site la irundhu copy pannunga)</label>
    <input type="text" name="course_api_key" value="<?php echo h(get_setting('course_api_key', '')); ?>">

    <label>Site API ID</label>
    <input type="text" name="course_api_site" value="<?php echo h(get_setting('course_api_site', 'main_editor')); ?>">

    <label>Course user kku kudukka vendiya Plan</label>
    <select name="course_plan_id">
      <option value="0">— Auto (first premium plan) —</option>
      <?php foreach ($plans as $p): ?>
        <option value="<?php echo (int)$p['id']; ?>" <?php echo course_link_plan_id() === (int)$p['id'] ? 'selected' : ''; ?>>
          <?php echo h($p['plan_name']); ?><?php echo (int)$p['premium_designer'] === 1 ? ' (premium templates)' : ''; ?>
        </option>
      <?php endforeach; ?>
    </select>

    <label>Ovvoru login kkum plan validity (days)</label>
    <input type="number" min="1" name="course_plan_days" value="<?php echo (int) course_link_days(); ?>">

    <button type="submit" class="btn">Save</button>
  </form>
</div>

<div class="card" style="max-width:680px;">
  <h3>✅ Test a course login</h3>
  <?php if ($testResult !== null): ?>
    <?php if (!empty($testResult['valid'])): ?>
      <div class="flash flash-success">Works! User: <b><?php echo h($testResult['user_name'] ?? ''); ?></b>
        <?php if (!empty($testResult['product'])): ?> · <?php echo h($testResult['product']); ?><?php endif; ?></div>
    <?php else: ?>
      <div class="flash flash-error"><?php echo h($testResult['reason'] ?? 'Failed'); ?></div>
    <?php endif; ?>
  <?php endif; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="do" value="test">
    <label>Course username</label>
    <input type="text" name="t_user">
    <label>Course password</label>
    <input type="text" name="t_pass">
    <button type="submit" class="btn">Test Connection</button>
  </form>
</div>

<?php if (!course_link_ready()): ?>
<div class="card" style="border-color:#f59e0b;">
  <h3>⚠️ Optional migration</h3>
  <p style="color:var(--muted);font-size:13px;">Course username-a members list la kaatanumna,
  <code>migration-course-login.sql</code> ah phpMyAdmin la oru thadava import pannunga. (Illama kooda login work aagum.)</p>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
