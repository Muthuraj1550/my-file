<?php
$adminTitle = 'Dashboard';
require_once __DIR__ . '/_layout_top.php';

$totalMembers = db()->query("SELECT COUNT(*) c FROM users WHERE role='member'")->fetch()['c'];
$activeMembers = db()->query("SELECT COUNT(*) c FROM users WHERE role='member' AND plan_expiry >= CURDATE()")->fetch()['c'];
$totalRevenue = db()->query("SELECT COALESCE(SUM(amount),0) s FROM orders WHERE status='paid'")->fetch()['s'];
$aiToday = 0; // AI Designs / Day tracking removed — Tripo coins are the only spend gate now.
$totalPosts = db()->query("SELECT COUNT(*) c FROM posts")->fetch()['c'];
$topPostQuick = top_content('post', 1);
$topPageQuick = top_content('page', 1);
$designerToday = designer_analytics()['views_today'];
$recentOrders = db()->query("SELECT o.*, u.name, u.email, p.plan_name FROM orders o
                              JOIN users u ON u.id=o.user_id
                              JOIN plans p ON p.id=o.plan_id
                              ORDER BY o.created_at DESC LIMIT 10")->fetchAll();
?>
<div class="stat-row">
  <div class="stat-box"><div class="num"><?php echo $totalMembers; ?></div><div class="lbl">Total Members</div></div>
  <div class="stat-box"><div class="num"><?php echo $activeMembers; ?></div><div class="lbl">Active Plans</div></div>
  <div class="stat-box"><div class="num">₹<?php echo number_format($totalRevenue,0); ?></div><div class="lbl">Total Revenue (Paid)</div></div>
  <div class="stat-box"><div class="num"><?php echo $totalPosts; ?></div><div class="lbl">Blog Posts</div></div>
  <div class="stat-box"><div class="num"><?php echo $designerToday; ?></div><div class="lbl">Designer Sessions Today</div></div>
</div>

<div class="card">
  <h3>🏆 Top Content <a href="analytics.php" class="btn btn-sm btn-outline" style="float:right;">Full Analytics →</a></h3>
  <div class="stat-row">
    <div class="stat-box">
      <div class="num" style="font-size:16px;"><?php echo $topPostQuick ? h($topPostQuick[0]['title']) : '—'; ?></div>
      <div class="lbl">Top Post (<?php echo $topPostQuick ? (int)$topPostQuick[0]['views'] : 0; ?> views)</div>
    </div>
    <div class="stat-box">
      <div class="num" style="font-size:16px;"><?php echo $topPageQuick ? h($topPageQuick[0]['title']) : '—'; ?></div>
      <div class="lbl">Top Page (<?php echo $topPageQuick ? (int)$topPageQuick[0]['views'] : 0; ?> views)</div>
    </div>
  </div>
</div>

<div class="card">
  <h3>Recent Orders</h3>
  <table>
    <thead><tr><th>Date</th><th>Member</th><th>Plan</th><th>Amount</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($recentOrders as $o): ?>
      <tr>
        <td><?php echo date('d M Y H:i', strtotime($o['created_at'])); ?></td>
        <td><?php echo h($o['name']); ?><br><small style="color:var(--muted)"><?php echo h($o['email']); ?></small></td>
        <td><?php echo h($o['plan_name']); ?></td>
        <td>₹<?php echo number_format($o['amount'],2); ?></td>
        <td><span class="badge <?php echo $o['status']==='paid'?'badge-active':'badge-expired'; ?>"><?php echo h($o['status']); ?></span></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$recentOrders): ?><tr><td colspan="5">No orders yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
