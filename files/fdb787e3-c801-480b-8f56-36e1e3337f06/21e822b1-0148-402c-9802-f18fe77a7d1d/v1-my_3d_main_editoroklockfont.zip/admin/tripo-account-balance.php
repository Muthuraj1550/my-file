<?php
// admin/tripo-account-balance.php
// Admin-only AJAX endpoint: checks the REMAINING BALANCE on the Tripo AI
// account itself (i.e. how many Tripo credits are left on the API key
// configured in Settings). This is completely separate from the site's
// own user coin balances (see api/tripo-balance.php for that).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();

header('Content-Type: application/json');

$apiKey = get_setting('tripo_api_key', '');
if (!$apiKey) {
    echo json_encode(['ok' => false, 'error' => 'not_configured', 'message' => 'Tripo AI API key இன்னும் Settings-ல் set பண்ணப்படல.']);
    exit;
}

function _tripo_balance_http($url, $apiKey) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $apiKey, 'Content-Type: application/json']);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$resp, $err, $code];
}

// Tripo's balance/wallet endpoint has lived at /user/balance across both the
// v2 and v3 hosts. Try the v3 host first (same host tripo-generate.php uses),
// then fall back to the v2 host in case the key/account is only valid there.
$candidates = [
    'https://openapi.tripo3d.ai/v3/user/balance',
    'https://api.tripo3d.ai/v2/openapi/user/balance',
];

$lastErr = null;
foreach ($candidates as $url) {
    list($resp, $err, $code) = _tripo_balance_http($url, $apiKey);
    if ($err) { $lastErr = $err; continue; }
    $json = json_decode($resp, true);
    if (!$json) { $lastErr = 'invalid_json_from_' . $url; continue; }
    // Successful shape looks like: {"code":0,"data":{"balance":123.4,"frozen":0}}
    $data = $json['data'] ?? $json;
    if (is_array($data) && (isset($data['balance']) || isset($data['frozen']))) {
        echo json_encode([
            'ok'      => true,
            'source'  => $url,
            'balance' => $data['balance'] ?? null,
            'frozen'  => $data['frozen'] ?? null,
            'raw'     => $data,
        ]);
        exit;
    }
    // If the server responded but not in the expected shape (e.g. an error
    // message from Tripo), keep it around to show the admin and try the
    // next candidate host.
    $lastErr = $json['message'] ?? $json['error'] ?? ('unexpected_response_from_' . $url);
}

echo json_encode([
    'ok'    => false,
    'error' => 'tripo_balance_check_failed',
    'detail'=> $lastErr,
]);
