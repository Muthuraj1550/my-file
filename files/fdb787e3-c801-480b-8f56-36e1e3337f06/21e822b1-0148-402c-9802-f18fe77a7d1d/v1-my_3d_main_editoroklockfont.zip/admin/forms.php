<?php
$adminTitle = 'Forms';
require_once __DIR__ . '/_layout_top.php';

$ready = forms_tables_ready();

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_form'])) {
    csrf_check();
    $name = trim($_POST['name']);
    $submitText = trim($_POST['submit_text']) ?: 'Submit';
    $successMsg = trim($_POST['success_message']) ?: 'Thank you! We received your submission.';

    $fields = [];
    $labels = $_POST['field_label'] ?? [];
    $types = $_POST['field_type'] ?? [];
    $placeholders = $_POST['field_placeholder'] ?? [];
    $requireds = $_POST['field_required'] ?? [];
    $optionsRaw = $_POST['field_options'] ?? [];
    foreach ($labels as $i => $label) {
        $label = trim($label);
        if ($label === '') continue;
        $type = in_array($types[$i] ?? 'text', ['text','email','phone','textarea','dropdown']) ? $types[$i] : 'text';
        $field = [
            'label'       => $label,
            'type'        => $type,
            'placeholder' => trim($placeholders[$i] ?? ''),
            'required'    => isset($requireds[$i]) ? true : false,
        ];
        if ($type === 'dropdown') {
            $opts = array_filter(array_map('trim', explode("\n", $optionsRaw[$i] ?? '')));
            $field['options'] = array_values($opts);
        }
        $fields[] = $field;
    }

    if ($name === '' || !$fields) {
        flash('Please give the form a name and at least one field.', 'error');
        redirect('/admin/forms.php' . (!empty($_POST['edit_id']) ? '?edit=' . (int)$_POST['edit_id'] : ''));
    }

    $fieldsJson = json_encode($fields, JSON_UNESCAPED_UNICODE);

    if (!empty($_POST['edit_id'])) {
        db()->prepare("UPDATE forms SET name=?, fields_json=?, submit_text=?, success_message=? WHERE id=?")
            ->execute([$name, $fieldsJson, $submitText, $successMsg, (int)$_POST['edit_id']]);
        flash('Form updated.');
    } else {
        db()->prepare("INSERT INTO forms (name, fields_json, submit_text, success_message) VALUES (?,?,?,?)")
            ->execute([$name, $fieldsJson, $submitText, $successMsg]);
        flash('Form created.');
    }
    redirect('/admin/forms.php');
}

if ($ready && isset($_GET['del'])) {
    db()->prepare("DELETE FROM forms WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Form deleted.');
    redirect('/admin/forms.php');
}

if ($ready && isset($_GET['del_sub'])) {
    db()->prepare("DELETE FROM form_submissions WHERE id=?")->execute([(int)$_GET['del_sub']]);
    flash('Submission deleted.');
    redirect('/admin/forms.php?view=' . (int)($_GET['view'] ?? 0));
}

$editForm = null;
if ($ready && !empty($_GET['edit'])) {
    $editForm = get_form((int)$_GET['edit']);
}

$viewForm = null;
$submissions = [];
if ($ready && !empty($_GET['view'])) {
    $viewForm = get_form((int)$_GET['view']);
    if ($viewForm) {
        $stmt = db()->prepare("SELECT * FROM form_submissions WHERE form_id=? ORDER BY created_at DESC");
        $stmt->execute([$viewForm['id']]);
        $submissions = $stmt->fetchAll();
        foreach ($submissions as &$s) { $s['data'] = json_decode($s['data_json'], true) ?: []; }
        unset($s);
    }
}

$forms = $ready ? all_forms() : [];
?>

<?php if (!$ready): ?>
<div class="card">
  <h3>⚠️ Set up required</h3>
  <p>The Form Builder isn't set up yet. Run <code>migration-custom-forms.sql</code> on your database, then reload this page.</p>
</div>
<?php else: ?>

<?php if ($viewForm): ?>
<div class="card">
  <h3>📥 Submissions - <?php echo h($viewForm['name']); ?></h3>
  <p style="color:var(--muted);font-size:13px;">
    Embed this form anywhere in a Page or Post by pasting this shortcode into the content:
    <code>[form id=<?php echo (int)$viewForm['id']; ?>]</code> - or use the "Form" block in the content builder.
  </p>
  <table>
    <thead>
      <tr>
        <?php foreach ($viewForm['fields'] as $f): ?><th><?php echo h($f['label']); ?></th><?php endforeach; ?>
        <th>Submitted</th><th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($submissions as $s): ?>
      <tr>
        <?php foreach ($viewForm['fields'] as $f): ?>
          <td><?php echo h($s['data'][$f['label']] ?? ''); ?></td>
        <?php endforeach; ?>
        <td><?php echo date('d M Y, h:i A', strtotime($s['created_at'])); ?></td>
        <td><a href="?view=<?php echo (int)$viewForm['id']; ?>&del_sub=<?php echo (int)$s['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this submission?');">Delete</a></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$submissions): ?><tr><td colspan="<?php echo count($viewForm['fields']) + 2; ?>">No submissions yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
  <a href="forms.php" class="btn btn-outline" style="margin-top:12px;">← Back to Forms</a>
</div>
<?php else: ?>

<div class="card">
  <h3><?php echo $editForm ? 'Edit Form' : 'Create New Form'; ?></h3>
  <form method="post" id="formBuilderForm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editForm ? (int)$editForm['id'] : ''; ?>">
    <label>Form Name (internal, e.g. "Contact Form")</label>
    <input type="text" name="name" value="<?php echo h($editForm['name'] ?? ''); ?>" required>

    <h3 style="margin-top:20px;">Fields</h3>
    <div id="fieldsWrap"></div>
    <button type="button" class="btn btn-outline btn-sm" id="addFieldBtn" style="margin-top:8px;">+ Add Field</button>

    <label style="margin-top:20px;">Submit Button Text</label>
    <input type="text" name="submit_text" value="<?php echo h($editForm['submit_text'] ?? 'Submit'); ?>">
    <label>Success Message (shown after someone submits)</label>
    <textarea name="success_message" style="min-height:60px;"><?php echo h($editForm['success_message'] ?? 'Thank you! We received your submission.'); ?></textarea>

    <button type="submit" name="save_form" class="btn" style="margin-top:16px;">Save Form</button>
    <?php if ($editForm): ?><a href="forms.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <h3>All Forms</h3>
  <table>
    <thead><tr><th>Name</th><th>Fields</th><th>Submissions</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ($forms as $f):
        $count = db()->prepare("SELECT COUNT(*) c FROM form_submissions WHERE form_id=?");
        $count->execute([$f['id']]);
        $count = $count->fetch()['c'];
        $fieldCount = count(json_decode($f['fields_json'], true) ?: []);
      ?>
      <tr>
        <td><?php echo h($f['name']); ?><br><code style="font-size:11px;color:var(--muted);">[form id=<?php echo (int)$f['id']; ?>]</code></td>
        <td><?php echo (int)$fieldCount; ?></td>
        <td><?php echo (int)$count; ?></td>
        <td>
          <a href="?view=<?php echo (int)$f['id']; ?>" class="btn btn-sm btn-outline">View Submissions</a>
          <a href="?edit=<?php echo (int)$f['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <a href="?del=<?php echo (int)$f['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this form and all its submissions?');">Delete</a>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$forms): ?><tr><td colspan="4">No forms yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<style>
.field-row{border:1px solid var(--border,#27324a);border-radius:10px;padding:14px;margin-bottom:10px;background:rgba(255,255,255,.02);}
.field-row-top{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;}
.field-row-top > div{flex:1;min-width:140px;}
.field-row label{font-size:12px;}
.field-remove{background:none;border:none;color:#f87171;cursor:pointer;font-size:13px;padding:6px 0;}
</style>
<script>
(function(){
  var wrap = document.getElementById('fieldsWrap');
  var addBtn = document.getElementById('addFieldBtn');
  var existing = <?php echo json_encode($editForm['fields'] ?? [], JSON_UNESCAPED_UNICODE); ?>;

  function addField(data){
    data = data || {label:'',type:'text',placeholder:'',required:false,options:[]};
    var row = document.createElement('div');
    row.className = 'field-row';
    row.innerHTML =
      '<div class="field-row-top">' +
        '<div><label>Label</label><input type="text" name="field_label[]" value="' + escAttr(data.label) + '" placeholder="e.g. Email Address"></div>' +
        '<div><label>Type</label><select name="field_type[]" class="field-type-select">' +
          ['text','email','phone','textarea','dropdown'].map(function(t){
            return '<option value="'+t+'"'+(data.type===t?' selected':'')+'>'+t.charAt(0).toUpperCase()+t.slice(1)+'</option>';
          }).join('') +
        '</select></div>' +
        '<div class="ph-field"><label>Placeholder</label><input type="text" name="field_placeholder[]" value="' + escAttr(data.placeholder) + '"></div>' +
        '<div style="flex:0 0 auto;"><label><input type="checkbox" name="field_required[]" style="width:auto;display:inline-block;" ' + (data.required?'checked':'') + '> Required</label></div>' +
        '<div style="flex:0 0 auto;"><button type="button" class="field-remove">✕ Remove</button></div>' +
      '</div>' +
      '<div class="options-field" style="margin-top:10px;display:' + (data.type==='dropdown'?'block':'none') + ';">' +
        '<label>Dropdown Options (one per line)</label>' +
        '<textarea name="field_options[]" style="min-height:70px;">' + esc((data.options||[]).join("\n")) + '</textarea>' +
      '</div>';
    wrap.appendChild(row);

    row.querySelector('.field-remove').addEventListener('click', function(){ row.remove(); });
    var typeSel = row.querySelector('.field-type-select');
    var optionsField = row.querySelector('.options-field');
    var phField = row.querySelector('.ph-field');
    typeSel.addEventListener('change', function(){
      var isDropdown = typeSel.value === 'dropdown';
      optionsField.style.display = isDropdown ? 'block' : 'none';
      phField.style.display = (typeSel.value === 'textarea' || isDropdown) ? 'none' : 'block';
    });
    typeSel.dispatchEvent(new Event('change'));
  }

  function esc(s){ var d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
  function escAttr(s){ return esc(s).replace(/"/g,'&quot;'); }

  addBtn.addEventListener('click', function(){ addField(); });

  if (existing.length) {
    existing.forEach(function(f){ addField(f); });
  } else {
    addField({label:'Name', type:'text', required:true});
    addField({label:'Email', type:'email', required:true});
  }
})();
</script>

<?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
