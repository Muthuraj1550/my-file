<?php
$adminTitle = 'Homepage';
require_once __DIR__ . '/_layout_top.php';

function coin_image_upload($field) {
    if (empty($_FILES[$field]['name'])) return null;
    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return null;
    $newName = 'coin_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_hero'])) {
    csrf_check();
    set_setting('home_hero_title', trim($_POST['home_hero_title']));
    set_setting('home_hero_subtitle', trim($_POST['home_hero_subtitle']));
    set_setting('home_hero_btn1_text', trim($_POST['home_hero_btn1_text']));
    set_setting('home_hero_btn1_url', trim($_POST['home_hero_btn1_url']));
    set_setting('home_hero_btn2_text', trim($_POST['home_hero_btn2_text']));
    set_setting('home_hero_btn2_url', trim($_POST['home_hero_btn2_url']));
    set_setting('home_custom_html', $_POST['home_custom_html']);
    set_setting('seo_home_title', trim($_POST['seo_home_title']));
    set_setting('seo_home_description', trim($_POST['seo_home_description']));
    flash('Homepage updated.');
    redirect('/admin/homepage.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_coin'])) {
    csrf_check();
    set_setting('coin_face1_text', trim($_POST['coin_face1_text']));
    set_setting('coin_face1_url', trim($_POST['coin_face1_url']));
    set_setting('coin_face1_new_tab', isset($_POST['coin_face1_new_tab']) ? '1' : '0');
    set_setting('coin_face2_text', trim($_POST['coin_face2_text']));
    set_setting('coin_face2_url', trim($_POST['coin_face2_url']));
    set_setting('coin_face2_new_tab', isset($_POST['coin_face2_new_tab']) ? '1' : '0');
    $img1 = coin_image_upload('coin_face1_image_file');
    if ($img1) set_setting('coin_face1_image', $img1);
    $img2 = coin_image_upload('coin_face2_image_file');
    if ($img2) set_setting('coin_face2_image', $img2);
    set_setting('coin_toss_enabled', isset($_POST['coin_toss_enabled']) ? '1' : '0');
    set_setting('coin_toss_start_delay', max(0, (int)$_POST['coin_toss_start_delay']));
    set_setting('coin_toss_repeat_count', max(0, (int)$_POST['coin_toss_repeat_count']));
    set_setting('coin_toss_gap', max(1, (int)$_POST['coin_toss_gap']));
    flash('Coin animation updated.');
    redirect('/admin/homepage.php#coin');
}
?>
<div class="card" style="max-width:680px;">
  <h3>Hero Section</h3>
  <p style="color:var(--muted);font-size:13px;">This is the big banner at the top of your homepage.</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Hero Title</label>
    <input type="text" name="home_hero_title" value="<?php echo h(get_setting('home_hero_title')); ?>">
    <label>Hero Subtitle</label>
    <input type="text" name="home_hero_subtitle" value="<?php echo h(get_setting('home_hero_subtitle')); ?>">

    <label>Button 1 Text</label>
    <input type="text" name="home_hero_btn1_text" value="<?php echo h(get_setting('home_hero_btn1_text')); ?>">
    <label>Button 1 URL (e.g. /designer or a full https:// link)</label>
    <input type="text" name="home_hero_btn1_url" value="<?php echo h(get_setting('home_hero_btn1_url')); ?>">

    <label>Button 2 Text</label>
    <input type="text" name="home_hero_btn2_text" value="<?php echo h(get_setting('home_hero_btn2_text')); ?>">
    <label>Button 2 URL</label>
    <input type="text" name="home_hero_btn2_url" value="<?php echo h(get_setting('home_hero_btn2_url')); ?>">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Leave a button's text blank to hide it.</p>

    <h3 style="margin-top:30px;">Custom HTML Block</h3>
    <p style="color:var(--muted);font-size:13px;">Optional. Shown as its own section on the homepage, below the "Why My 3D Gifts?"
    box and above the blog list. Paste any HTML here - banners, embeds, extra buttons, testimonials, etc. Leave blank to hide it.</p>
    <textarea name="home_custom_html" style="min-height:180px;font-family:monospace;"><?php echo h(get_setting('home_custom_html')); ?></textarea>

    <h3 style="margin-top:30px;">Homepage SEO</h3>
    <label>SEO Title (leave blank to use the default site name)</label>
    <input type="text" name="seo_home_title" value="<?php echo h(get_setting('seo_home_title')); ?>">
    <label>Meta Description</label>
    <textarea name="seo_home_description" style="min-height:70px;"><?php echo h(get_setting('seo_home_description')); ?></textarea>

    <button type="submit" name="save_hero" class="btn">Save Homepage</button>
  </form>
</div>

<div class="card" style="max-width:680px;" id="coin">
  <h3>🪙 3D Coin Spin Animation</h3>
  <p style="color:var(--muted);font-size:13px;">Shows a spinning coin on the homepage that flips between two sides on its own, each side with its own image, caption text and link. Upload images below, or use the <a href="filemanager.php" target="_blank">File Manager</a> and paste a link in manually.</p>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <h3 style="margin-top:10px;font-size:16px;">Side A</h3>
    <label>Side A Image</label>
    <input type="file" name="coin_face1_image_file" accept="image/*">
    <?php if (get_setting('coin_face1_image')): ?>
      <img src="<?php echo h(get_setting('coin_face1_image')); ?>" style="max-width:100px;border-radius:50%;margin-bottom:16px;display:block;">
    <?php endif; ?>
    <label>Side A Caption</label>
    <input type="text" name="coin_face1_text" value="<?php echo h(get_setting('coin_face1_text', 'Buy 3D Print Gift')); ?>">
    <label>Side A Link URL</label>
    <input type="text" name="coin_face1_url" value="<?php echo h(get_setting('coin_face1_url', '/membership.php')); ?>">
    <label><input type="checkbox" name="coin_face1_new_tab" style="width:auto;display:inline-block;" <?php echo get_setting('coin_face1_new_tab')==='1' ? 'checked' : ''; ?>> Open in new tab</label>

    <h3 style="margin-top:24px;font-size:16px;">Side B</h3>
    <label>Side B Image</label>
    <input type="file" name="coin_face2_image_file" accept="image/*">
    <?php if (get_setting('coin_face2_image')): ?>
      <img src="<?php echo h(get_setting('coin_face2_image')); ?>" style="max-width:100px;border-radius:50%;margin-bottom:16px;display:block;">
    <?php endif; ?>
    <label>Side B Caption</label>
    <input type="text" name="coin_face2_text" value="<?php echo h(get_setting('coin_face2_text', 'Buy 3D Design Template')); ?>">
    <label>Side B Link URL</label>
    <input type="text" name="coin_face2_url" value="<?php echo h(get_setting('coin_face2_url', '/designer')); ?>">
    <label><input type="checkbox" name="coin_face2_new_tab" style="width:auto;display:inline-block;" <?php echo get_setting('coin_face2_new_tab')==='1' ? 'checked' : ''; ?>> Open in new tab</label>

    <h3 style="margin-top:24px;font-size:16px;">🚀 Toss Animation</h3>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">The coin starts at the bottom-left corner. After the timing below, it flies up and spins over to the bottom-right corner and stays there. Next time, it flies back from right to left, and so on - alternating each time.</p>
    <label><input type="checkbox" name="coin_toss_enabled" style="width:auto;display:inline-block;" <?php echo get_setting('coin_toss_enabled', '1')==='1' ? 'checked' : ''; ?>> Enable toss animation</label>
    <label>Start after page loads (seconds)</label>
    <input type="number" name="coin_toss_start_delay" min="0" value="<?php echo (int)get_setting('coin_toss_start_delay', 3); ?>">
    <label>How many times to toss (0 = keep going forever). Default 2 = once left→right, once right→left.</label>
    <input type="number" name="coin_toss_repeat_count" min="0" value="<?php echo (int)get_setting('coin_toss_repeat_count', 2); ?>">
    <label>Gap between each toss (seconds)</label>
    <input type="number" name="coin_toss_gap" min="1" value="<?php echo (int)get_setting('coin_toss_gap', 6); ?>">

    <button type="submit" name="save_coin" class="btn">Save Coin Animation</button>
  </form>
</div>

<div class="card" style="max-width:680px;">
  <a href="<?php echo SITE_URL; ?>/" target="_blank" class="btn btn-outline">Preview Homepage ↗</a>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
