<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['csrf']) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Security check failed.']);
    exit;
}

if (empty($_FILES['image']['name'])) {
    echo json_encode(['ok' => false, 'error' => 'No file received.']);
    exit;
}

$allowed = ['jpg','jpeg','png','webp','gif'];
$ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allowed)) {
    echo json_encode(['ok' => false, 'error' => 'Only jpg, png, webp, and gif images are allowed.']);
    exit;
}

$newName = 'img_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
$dest = __DIR__ . '/../uploads/' . $newName;

if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
    echo json_encode(['ok' => true, 'url' => SITE_URL . '/uploads/' . $newName]);
} else {
    echo json_encode(['ok' => false, 'error' => 'Upload failed.']);
}
