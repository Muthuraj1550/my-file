<?php
$adminTitle = 'My Account';
require_once __DIR__ . '/_layout_top.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    csrf_check();
    $name  = trim($_POST['name']);
    $email = trim(strtolower($_POST['email']));

    if ($name === '') $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';

    if (!$errors) {
        $stmt = db()->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $__admin['id']]);
        if ($stmt->fetch()) $errors[] = 'That email is already used by another account.';
    }

    if (!$errors) {
        db()->prepare("UPDATE users SET name=?, email=? WHERE id=?")->execute([$name, $email, $__admin['id']]);
        flash('Profile updated.');
        redirect('/admin/account.php');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_password'])) {
    csrf_check();
    $current = $_POST['current_pwd'] ?? '';
    $new1    = $_POST['new_pwd'] ?? '';
    $new2    = $_POST['conf_pwd'] ?? '';

    if (!password_verify($current, $__admin['password_hash'])) {
        $errors[] = 'Current password is incorrect.';
    } elseif (strlen($new1) < 6) {
        $errors[] = 'New password must be at least 6 characters.';
    } elseif ($new1 !== $new2) {
        $errors[] = 'New passwords do not match.';
    } else {
        db()->prepare("UPDATE users SET password_hash=? WHERE id=?")
            ->execute([password_hash($new1, PASSWORD_DEFAULT), $__admin['id']]);
        flash('Password changed successfully.');
        redirect('/admin/account.php');
    }
}
?>
<?php foreach ($errors as $e): ?><div class="flash flash-error"><?php echo h($e); ?></div><?php endforeach; ?>

<div class="card" style="max-width:460px;">
  <h3>Profile</h3>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Name</label>
    <input type="text" name="name" value="<?php echo h($__admin['name']); ?>" required>
    <label>Email (used to login)</label>
    <input type="email" name="email" value="<?php echo h($__admin['email']); ?>" required>
    <button type="submit" name="update_profile" class="btn">Save Profile</button>
  </form>
</div>

<div class="card" style="max-width:460px;">
  <h3>Change Password</h3>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Current Password</label>
    <input type="password" name="current_pwd" required>
    <label>New Password</label>
    <input type="password" name="new_pwd" required>
    <label>Confirm New Password</label>
    <input type="password" name="conf_pwd" required>
    <button type="submit" name="update_password" class="btn">Change Password</button>
  </form>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
