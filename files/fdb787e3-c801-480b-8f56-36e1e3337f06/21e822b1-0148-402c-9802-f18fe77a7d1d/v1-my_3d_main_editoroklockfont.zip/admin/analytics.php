<?php
$adminTitle = 'Analytics';
require_once __DIR__ . '/_layout_top.php';

/* ============ Visitor stats + date range ============ */
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));

$preset = $_GET['preset'] ?? '';
if ($preset === 'today')       { $from = $today;                              $to = $today; }
elseif ($preset === 'yesterday'){ $from = $yesterday;                          $to = $yesterday; }
elseif ($preset === '7d')      { $from = date('Y-m-d', strtotime('-6 days')); $to = $today; }
elseif ($preset === '30d')     { $from = date('Y-m-d', strtotime('-29 days'));$to = $today; }
else {
    $from = $_GET['from'] ?? date('Y-m-d', strtotime('-6 days'));
    $to   = $_GET['to']   ?? $today;
}
// sanitise
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = date('Y-m-d', strtotime('-6 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   $to   = $today;
if ($from > $to) { $tmp=$from; $from=$to; $to=$tmp; }

function _visitor_stats($fromDate, $toDate) {
    $stmt = db()->prepare("SELECT COUNT(*) views, COUNT(DISTINCT ip_address) visitors,
                            COALESCE(SUM(duration_seconds),0) total_seconds,
                            AVG(NULLIF(duration_seconds,0)) avg_seconds
                            FROM content_views
                            WHERE created_at >= ? AND created_at < DATE_ADD(?, INTERVAL 1 DAY)");
    $stmt->execute([$fromDate, $toDate]);
    return $stmt->fetch();
}
function _visitor_stats_day($day) { return _visitor_stats($day, $day); }

$rangeStats     = _visitor_stats($from, $to);
$todayStats     = _visitor_stats_day($today);
$yesterdayStats = _visitor_stats_day($yesterday);
$allVisitors    = db()->query("SELECT COUNT(DISTINCT ip_address) v FROM content_views")->fetch()['v'];

// daily breakdown for the selected range
$dailyStmt = db()->prepare("SELECT DATE(created_at) d, COUNT(*) views, COUNT(DISTINCT ip_address) visitors,
                             COALESCE(SUM(duration_seconds),0) total_seconds,
                             AVG(NULLIF(duration_seconds,0)) avg_seconds
                             FROM content_views
                             WHERE created_at >= ? AND created_at < DATE_ADD(?, INTERVAL 1 DAY)
                             GROUP BY DATE(created_at) ORDER BY d DESC");
$dailyStmt->execute([$from, $to]);
$dailyRows = $dailyStmt->fetchAll();

/* ============ Existing analytics ============ */
$topPosts = top_content('post', 15);
$topPages = top_content('page', 15);
$designer = designer_analytics();

$totalViews7d = db()->query("SELECT COUNT(*) c FROM content_views WHERE created_at >= NOW() - INTERVAL 7 DAY")->fetch()['c'];
$totalViewsAll = db()->query("SELECT COUNT(*) c FROM content_views")->fetch()['c'];
$avgMinutesAll = db()->query("SELECT AVG(NULLIF(duration_seconds,0)) a FROM content_views")->fetch()['a'];

$trafficAll = traffic_source_breakdown(0);
$traffic30d = traffic_source_breakdown(30);
$trafficTotal = array_sum(array_column($trafficAll, 'c')) ?: 1;

function _tools_page_table_exists_analytics() {
    try { db()->query("SELECT 1 FROM tools LIMIT 1"); return true; }
    catch (Exception $e) { return false; }
}
$toolClicksTop = [];
if (_tools_page_table_exists_analytics()) {
    $toolClicksTop = db()->query("SELECT t.name, t.icon, COUNT(v.id) clicks
                                   FROM tools t
                                   LEFT JOIN content_views v ON v.content_type='tool_click' AND v.content_id=t.id
                                   GROUP BY t.id ORDER BY clicks DESC, t.sort_order ASC LIMIT 15")->fetchAll();
}

function fmt_minutes($seconds) {
    if (!$seconds) return '0m';
    $m = $seconds / 60;
    return $m < 1 ? round($seconds) . 's' : round($m, 1) . 'm';
}
?>

<div class="card">
  <h3>👥 Visitor Analytics — எத்தனை பேர் வந்தார்கள்?</h3>
  <p style="color:var(--muted);font-size:12px;margin-top:-6px;">
    "Visitors" = unique IP addresses (same person refreshing counts once).
    "Views" = total page opens. Pick a date range or use a quick preset.
  </p>

  <div class="stat-row">
    <div class="stat-box"><div class="num"><?php echo (int)$todayStats['visitors']; ?></div><div class="lbl">Visitors Today (<?php echo (int)$todayStats['views']; ?> views)</div></div>
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($todayStats['total_seconds']); ?></div><div class="lbl">Time Spent Today (avg <?php echo fmt_minutes($todayStats['avg_seconds']); ?>/view)</div></div>
    <div class="stat-box"><div class="num"><?php echo (int)$yesterdayStats['visitors']; ?></div><div class="lbl">Visitors Yesterday (<?php echo (int)$yesterdayStats['views']; ?> views)</div></div>
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($yesterdayStats['total_seconds']); ?></div><div class="lbl">Time Spent Yesterday (avg <?php echo fmt_minutes($yesterdayStats['avg_seconds']); ?>/view)</div></div>
    <div class="stat-box"><div class="num"><?php echo (int)$allVisitors; ?></div><div class="lbl">Total Unique Visitors (All Time)</div></div>
  </div>

  <form method="get" style="display:flex;flex-wrap:wrap;gap:10px;align-items:end;margin:14px 0;">
    <div>
      <label style="display:block;font-size:12px;color:var(--muted);">From</label>
      <input type="date" name="from" value="<?php echo h($from); ?>" max="<?php echo h($today); ?>">
    </div>
    <div>
      <label style="display:block;font-size:12px;color:var(--muted);">To</label>
      <input type="date" name="to" value="<?php echo h($to); ?>" max="<?php echo h($today); ?>">
    </div>
    <button type="submit" class="btn">Apply</button>
    <a class="btn btn-outline" href="?preset=today">Today</a>
    <a class="btn btn-outline" href="?preset=yesterday">Yesterday</a>
    <a class="btn btn-outline" href="?preset=7d">Last 7 days</a>
    <a class="btn btn-outline" href="?preset=30d">Last 30 days</a>
  </form>

  <div class="stat-row">
    <div class="stat-box"><div class="num"><?php echo (int)$rangeStats['visitors']; ?></div><div class="lbl">Unique Visitors (<?php echo h($from); ?> → <?php echo h($to); ?>)</div></div>
    <div class="stat-box"><div class="num"><?php echo (int)$rangeStats['views']; ?></div><div class="lbl">Total Views in Range</div></div>
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($rangeStats['total_seconds']); ?></div><div class="lbl">Time Spent in Range (avg <?php echo fmt_minutes($rangeStats['avg_seconds']); ?>/view)</div></div>
  </div>

  <table>
    <thead><tr><th>Date</th><th>Unique Visitors</th><th>Views</th><th>Time Spent</th><th>Avg. Time / View</th></tr></thead>
    <tbody>
      <?php foreach ($dailyRows as $r): ?>
        <tr>
          <td><?php echo h($r['d']); ?></td>
          <td><?php echo (int)$r['visitors']; ?></td>
          <td><?php echo (int)$r['views']; ?></td>
          <td><?php echo fmt_minutes($r['total_seconds']); ?></td>
          <td><?php echo fmt_minutes($r['avg_seconds']); ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$dailyRows): ?><tr><td colspan="5">No visits recorded in this range.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<div class="stat-row">
  <div class="stat-box"><div class="num"><?php echo (int)$totalViewsAll; ?></div><div class="lbl">Total Views (All Time)</div></div>
  <div class="stat-box"><div class="num"><?php echo (int)$totalViews7d; ?></div><div class="lbl">Views (Last 7 Days)</div></div>
  <div class="stat-box"><div class="num"><?php echo $avgMinutesAll ? round($avgMinutesAll/60, 1) : 0; ?>m</div><div class="lbl">Avg. Time on Page</div></div>
</div>

<div class="card">
  <h3>🌐 Traffic Sources — எப்படி வருகிறார்கள்?</h3>
  <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Visitors classified by where they clicked in from — Google search, YouTube, Facebook/Instagram, another site, or came directly (typed the URL / opened a saved app link). Based on the browser's Referer header, so some visitors (private browsing, some apps) may not report one and are counted as "Direct / App".</p>
  <div class="stat-row">
    <?php foreach (array_slice($trafficAll, 0, 5) as $row): $pct = round(($row['c'] / $trafficTotal) * 100, 1); ?>
    <div class="stat-box"><div class="num"><?php echo (int)$row['c']; ?></div><div class="lbl"><?php echo h($row['source']); ?> (<?php echo $pct; ?>%)</div></div>
    <?php endforeach; ?>
    <?php if (!$trafficAll): ?><div class="stat-box"><div class="num">—</div><div class="lbl">No traffic data yet</div></div><?php endif; ?>
  </div>
  <table>
    <thead><tr><th>Source</th><th>Views (All Time)</th><th>%</th><th>Views (Last 30 Days)</th></tr></thead>
    <tbody>
    <?php
      $traffic30dMap = [];
      foreach ($traffic30d as $r) $traffic30dMap[$r['source']] = (int)$r['c'];
    ?>
    <?php foreach ($trafficAll as $row): $pct = round(($row['c'] / $trafficTotal) * 100, 1); ?>
      <tr>
        <td><?php echo h($row['source']); ?></td>
        <td><?php echo (int)$row['c']; ?></td>
        <td><?php echo $pct; ?>%</td>
        <td><?php echo (int)($traffic30dMap[$row['source']] ?? 0); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$trafficAll): ?><tr><td colspan="4">No views tracked yet — traffic sources will appear here as visitors browse the site. If this stays empty on a site that already had visitors, run <code>migration-traffic-source.sql</code> in phpMyAdmin.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<div class="card">
  <h3>🛠 Tool Lab — Clicks per Tool</h3>
  <table>
    <thead><tr><th>#</th><th>Tool</th><th>Clicks</th></tr></thead>
    <tbody>
    <?php foreach ($toolClicksTop as $i => $t): ?>
      <tr>
        <td><?php echo $i + 1; ?></td>
        <td><?php echo h($t['icon']); ?> <?php echo h($t['name']); ?></td>
        <td><?php echo (int)$t['clicks']; ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$toolClicksTop): ?><tr><td colspan="3">No tools published yet, or <code>migration-tool-lab.sql</code> not imported.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<div class="card">
  <h3>🛠 3D Designer Usage</h3>
  <div class="stat-row">
    <div class="stat-box"><div class="num"><?php echo $designer['total_views']; ?></div><div class="lbl">Total Sessions (All Time)</div></div>
    <div class="stat-box"><div class="num"><?php echo $designer['views_7d']; ?></div><div class="lbl">Sessions (Last 7 Days)</div></div>
    <div class="stat-box"><div class="num"><?php echo $designer['views_today']; ?></div><div class="lbl">Sessions Today</div></div>
    <div class="stat-box"><div class="num"><?php echo $designer['views_yesterday']; ?></div><div class="lbl">Sessions Yesterday</div></div>
  </div>
  <div class="stat-row" style="margin-top:10px;">
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($designer['total_seconds_today']); ?></div><div class="lbl">Designer Time Spent Today</div></div>
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($designer['avg_seconds_today']); ?></div><div class="lbl">Avg. Time / Session Today</div></div>
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($designer['total_seconds_yesterday']); ?></div><div class="lbl">Designer Time Spent Yesterday</div></div>
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($designer['avg_seconds_yesterday']); ?></div><div class="lbl">Avg. Time / Session Yesterday</div></div>
  </div>
  <div class="stat-row" style="margin-top:10px;">
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($designer['total_seconds']); ?></div><div class="lbl">Total Time Spent (All Users, All Time)</div></div>
    <div class="stat-box"><div class="num"><?php echo fmt_minutes($designer['avg_seconds']); ?></div><div class="lbl">Avg. Time / Session (All Time)</div></div>
  </div>
  <p style="color:var(--muted);font-size:12px;">A "session" is counted each time a logged-in member opens the Designer page. "Designer Time Spent" is separate from the general website time-spent numbers above — it only counts time inside the Designer tool.</p>
</div>

<div class="card">
  <h3>🏆 Top Posts (by views)</h3>
  <table>
    <thead><tr><th>#</th><th>Title</th><th>Views</th><th>Total Time</th><th>Avg. Time / View</th></tr></thead>
    <tbody>
    <?php foreach ($topPosts as $i => $p): ?>
      <tr>
        <td><?php echo $i + 1; ?></td>
        <td><a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo h($p['slug']); ?>" target="_blank"><?php echo h($p['title']); ?></a></td>
        <td><?php echo (int)$p['views']; ?></td>
        <td><?php echo fmt_minutes($p['total_seconds']); ?></td>
        <td><?php echo fmt_minutes($p['avg_seconds']); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$topPosts): ?><tr><td colspan="5">No posts yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<div class="card">
  <h3>🏆 Top Pages (by views)</h3>
  <table>
    <thead><tr><th>#</th><th>Title</th><th>Views</th><th>Total Time</th><th>Avg. Time / View</th></tr></thead>
    <tbody>
    <?php foreach ($topPages as $i => $p): ?>
      <tr>
        <td><?php echo $i + 1; ?></td>
        <td><a href="<?php echo SITE_URL; ?>/page.php?slug=<?php echo h($p['slug']); ?>" target="_blank"><?php echo h($p['title']); ?></a></td>
        <td><?php echo (int)$p['views']; ?></td>
        <td><?php echo fmt_minutes($p['total_seconds']); ?></td>
        <td><?php echo fmt_minutes($p['avg_seconds']); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$topPages): ?><tr><td colspan="5">No pages yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
  <p style="color:var(--muted);font-size:12px;">"Avg. Time / View" only counts visits where we successfully measured
  time spent (some visitors leave before the browser can report it, so this is a good estimate, not exact).</p>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
