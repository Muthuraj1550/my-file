<?php
$adminTitle = 'Members';
require_once __DIR__ . '/_layout_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_member'])) {
    csrf_check();
    $mid = (int)$_POST['mid'];
    $stmt = db()->prepare("UPDATE users SET plan_name=?, plan_expiry=?, ai_limit_override=?, status=?, tripo_coins=?, plan_coins=? WHERE id=?");
    $stmt->execute([
        trim($_POST['plan_name']),
        $_POST['plan_expiry'] ?: null,
        $_POST['ai_limit_override'] !== '' ? (int)$_POST['ai_limit_override'] : null,
        $_POST['status'],
        (int)($_POST['tripo_coins'] ?? 0),
        (int)($_POST['plan_coins'] ?? 0),
        $mid,
    ]);
    flash('Member updated.');
    redirect('/admin/members.php');
}

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = db()->prepare("SELECT * FROM users WHERE role='member' AND (name LIKE ? OR email LIKE ?) ORDER BY created_at DESC LIMIT 200");
    $like = '%' . $search . '%';
    $stmt->execute([$like, $like]);
} else {
    $stmt = db()->query("SELECT * FROM users WHERE role='member' ORDER BY created_at DESC LIMIT 200");
}
$members = $stmt->fetchAll();
$allPlans = all_plans();
$totalMembersCount = (int) db()->query("SELECT COUNT(*) c FROM users WHERE role='member'")->fetch()['c'];
?>
<p style="color:var(--muted);font-size:13px;margin:-6px 0 14px;">👥 <?php echo $totalMembersCount; ?> total members</p>
<form method="get" style="margin-bottom:16px;max-width:340px;">
  <input type="text" name="q" placeholder="Search by name or email" value="<?php echo h($search); ?>">
</form>

<div class="card">
  <div style="overflow-x:auto;">
  <table class="members-table" style="table-layout:fixed;">
    <colgroup>
      <col style="width:15%;"><col style="width:18%;"><col style="width:13%;"><col style="width:12%;">
      <col style="width:8%;"><col style="width:9%;"><col style="width:9%;"><col style="width:8%;">
    </colgroup>
    <thead><tr><th>Name</th><th>Email</th><th>Plan</th><th>Expiry</th><th>Status</th><th>Plan Coins</th><th>Purchased Coins</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach ($members as $m): ?>
      <?php
        $active = $m['plan_expiry'] && strtotime($m['plan_expiry']) >= strtotime(date('Y-m-d'));
        $rowFormId = 'mf-' . (int)$m['id'];
      ?>
      <!-- Row edits post via this standalone form (referenced below with form="<?php echo $rowFormId; ?>")
           instead of wrapping <tr> — a <form> cannot legally contain <tr>/<td> as a direct table-row child,
           and browsers silently re-parent it, which was breaking this page's layout. -->
      <form id="<?php echo $rowFormId; ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="mid" value="<?php echo (int)$m['id']; ?>">
        <input type="hidden" name="ai_limit_override" value="<?php echo h($m['ai_limit_override']); ?>">
      </form>
      <tr>
        <td class="mem-cell-clip" title="<?php echo h($m['name']); ?>"><?php echo h($m['name']); ?></td>
        <td class="mem-cell-clip" title="<?php echo h($m['email']); ?>"><?php echo h($m['email']); ?><br><small style="color:var(--muted)"><?php echo h($m['phone']); ?></small></td>
        <td>
          <select form="<?php echo $rowFormId; ?>" name="plan_name" style="margin:0;min-width:120px;max-width:100%;">
            <?php $hasMatch = false; ?>
            <?php foreach ($allPlans as $p): $sel = ($p['plan_name'] === $m['plan_name']); if ($sel) $hasMatch = true; ?>
              <option value="<?php echo h($p['plan_name']); ?>" <?php echo $sel ? 'selected' : ''; ?>><?php echo h($p['plan_name']); ?></option>
            <?php endforeach; ?>
            <?php if (!$hasMatch && $m['plan_name'] !== ''): ?>
              <option value="<?php echo h($m['plan_name']); ?>" selected><?php echo h($m['plan_name']); ?> (not in current plans)</option>
            <?php endif; ?>
          </select>
        </td>
        <td><input form="<?php echo $rowFormId; ?>" type="date" name="plan_expiry" value="<?php echo h($m['plan_expiry']); ?>" style="margin:0;width:100%;"></td>
        <td>
          <select form="<?php echo $rowFormId; ?>" name="status" style="margin:0;">
            <option value="active" <?php echo $m['status']==='active'?'selected':''; ?>>Active</option>
            <option value="blocked" <?php echo $m['status']==='blocked'?'selected':''; ?>>Blocked</option>
          </select>
        </td>
        <td>
          <input form="<?php echo $rowFormId; ?>" type="number" min="0" name="plan_coins" value="<?php echo (int)($m['plan_coins'] ?? 0); ?>" style="margin:0;width:100%;" title="Monthly membership coins (reset on renewal, spent first)">
        </td>
        <td>
          <input form="<?php echo $rowFormId; ?>" type="number" min="0" name="tripo_coins" value="<?php echo (int)($m['tripo_coins'] ?? 0); ?>" style="margin:0;width:100%;" title="Purchased coins (lifetime, never expire)">
        </td>
        <td>
          <button form="<?php echo $rowFormId; ?>" type="submit" name="update_member" class="btn btn-sm">Save</button>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$members): ?><tr><td colspan="8">No members found.</td></tr><?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<style>
  /* Long spam-injected values (fake names/links) get clipped with an ellipsis
     instead of blowing up the row height / column width — full value is
     still visible on hover via the title attribute. */
  .mem-cell-clip { max-width:1px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .members-table td, .members-table th { overflow:hidden; }
</style>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
