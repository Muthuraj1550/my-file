<?php
$adminTitle = 'File Manager';
require_once __DIR__ . '/_layout_top.php';

define('FM_DIR', __DIR__ . '/../uploads/');
define('FM_URL', SITE_URL . '/uploads/');

/** Files never shown/served from the manager even if they somehow land in uploads/. */
function fm_is_hidden($name) {
    return $name === '.' || $name === '..' || $name === '.htaccess' || $name[0] === '.';
}

function fm_ext($name) {
    return strtolower(pathinfo($name, PATHINFO_EXTENSION));
}

/** Turn an arbitrary uploaded filename into a safe one: letters/numbers/-/_ only, extension preserved. */
function fm_safe_filename($original) {
    $ext  = fm_ext($original);
    $base = pathinfo($original, PATHINFO_FILENAME);
    $base = preg_replace('/[^A-Za-z0-9\-_]+/', '-', $base);
    $base = trim(preg_replace('/-+/', '-', $base), '-');
    if ($base === '') $base = 'file';
    return [$base, $ext];
}

// ---------- Upload ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_files'])) {
    csrf_check();
    $blocked = media_blocked_extensions();
    $okCount = 0; $skipped = [];
    if (!empty($_FILES['files']['name'][0])) {
        foreach ($_FILES['files']['name'] as $i => $origName) {
            if ($_FILES['files']['error'][$i] !== UPLOAD_ERR_OK) continue;
            [$base, $ext] = fm_safe_filename($origName);
            if ($ext === '' || in_array($ext, $blocked, true)) {
                $skipped[] = $origName;
                continue;
            }
            $newName = $base . '.' . $ext;
            $dest = FM_DIR . $newName;
            $n = 1;
            while (file_exists($dest)) {
                $newName = $base . '-' . (++$n) . '.' . $ext;
                $dest = FM_DIR . $newName;
            }
            if (move_uploaded_file($_FILES['files']['tmp_name'][$i], $dest)) {
                @chmod($dest, 0644);
                $okCount++;
            } else {
                $skipped[] = $origName;
            }
        }
    }
    if ($okCount > 0) {
        flash($okCount . ' file(s) uploaded.' . ($skipped ? ' Skipped: ' . implode(', ', $skipped) : ''));
    } else {
        flash('No files uploaded.' . ($skipped ? ' Blocked/invalid: ' . implode(', ', $skipped) : ''), 'error');
    }
    redirect('/admin/filemanager.php');
}

// ---------- Delete ----------
if (isset($_GET['del'])) {
    $name = basename($_GET['del']); // basename() blocks path traversal
    $path = FM_DIR . $name;
    if (!fm_is_hidden($name) && is_file($path)) {
        unlink($path);
        flash('File deleted.');
    } else {
        flash('File not found.', 'error');
    }
    redirect('/admin/filemanager.php');
}

// ---------- List ----------
$search = trim($_GET['q'] ?? '');
$files = [];
foreach (scandir(FM_DIR) as $name) {
    if (fm_is_hidden($name)) continue;
    $path = FM_DIR . $name;
    if (!is_file($path)) continue;
    if ($search !== '' && stripos($name, $search) === false) continue;
    $files[] = [
        'name'  => $name,
        'size'  => filesize($path),
        'mtime' => filemtime($path),
        'ext'   => fm_ext($name),
    ];
}
usort($files, fn($a, $b) => $b['mtime'] <=> $a['mtime']);

$imageExts = ['jpg','jpeg','png','gif','webp','svg'];
?>
<div class="card">
  <h3>Upload Media</h3>
  <p style="color:var(--muted);font-size:13px;margin-top:-8px;">Upload images or other files here, then copy the link to use inside a post/page's Content HTML, or as a Featured Image.</p>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="files[]" multiple required>
    <button type="submit" name="upload_files" class="btn">Upload</button>
  </form>
</div>

<div class="card">
  <h3>All Files (<?php echo count($files); ?>)</h3>
  <form method="get" style="margin-bottom:4px;">
    <input type="text" name="q" value="<?php echo h($search); ?>" placeholder="Search by filename...">
  </form>
  <div class="filemanager-grid">
    <?php foreach ($files as $f): $url = FM_URL . rawurlencode($f['name']); ?>
      <div class="fm-item">
        <div class="fm-preview">
          <?php if (in_array($f['ext'], $imageExts, true)): ?>
            <img src="<?php echo h($url); ?>" alt="<?php echo h($f['name']); ?>" loading="lazy">
          <?php else: ?>
            <span>📄</span>
          <?php endif; ?>
        </div>
        <div class="fm-name" title="<?php echo h($f['name']); ?>"><?php echo h($f['name']); ?></div>
        <div class="fm-meta"><?php echo format_file_size($f['size']); ?> · <?php echo date('d M Y', $f['mtime']); ?></div>
        <input type="text" readonly value="<?php echo h($url); ?>" onclick="this.select();" style="font-size:11px;padding:6px 8px;margin-bottom:8px;">
        <div class="fm-actions">
          <button type="button" class="btn btn-sm btn-outline" onclick="fmCopyLink(this, '<?php echo h($url); ?>')">Copy Link</button>
          <a href="?del=<?php echo urlencode($f['name']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this file?');">Delete</a>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (!$files): ?><p style="color:var(--muted);">No files yet.</p><?php endif; ?>
  </div>
</div>

<script>
function fmCopyLink(btn, url) {
  navigator.clipboard.writeText(url).then(function () {
    var old = btn.textContent;
    btn.textContent = 'Copied!';
    setTimeout(function () { btn.textContent = old; }, 1500);
  });
}
</script>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
