<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (is_logged_in() && is_admin()) redirect('/admin/index.php');

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = trim(strtolower($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';
    $stmt = db()->prepare("SELECT * FROM users WHERE email = ? AND role='admin' LIMIT 1");
    $stmt->execute([$email]);
    $u = $stmt->fetch();
    if (!$u || !password_verify($pass, $u['password_hash'])) {
        $errors[] = 'Incorrect email or password.';
    } else {
        log_user_in($u['id']);
        redirect('/admin/index.php');
    }
}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login - <?php echo h(SITE_NAME); ?></title>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css"></head>
<body>
<div class="wrap" style="max-width:400px;padding-top:80px;">
  <div class="card">
    <h1 style="text-align:center;">Admin Login</h1>
    <?php foreach ($errors as $e): ?><div class="flash flash-error"><?php echo h($e); ?></div><?php endforeach; ?>
    <form method="post">
      <?php echo csrf_field(); ?>
      <label>Email</label>
      <input type="email" name="email" required>
      <label>Password</label>
      <input type="password" name="password" required>
      <button type="submit" class="btn btn-block">Login</button>
    </form>
  </div>
</div>
</body></html>
