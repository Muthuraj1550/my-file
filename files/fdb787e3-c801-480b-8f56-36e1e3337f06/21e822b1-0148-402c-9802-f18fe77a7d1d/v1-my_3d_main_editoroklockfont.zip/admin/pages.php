<?php
$adminTitle = 'Pages';
require_once __DIR__ . '/_layout_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_page'])) {
    csrf_check();
    $title = trim($_POST['title']);
    $slug = unique_slug('pages', slugify($title), $_POST['edit_id'] ?: null);
    $status = $_POST['status'] === 'published' ? 'published' : 'draft';
    $showMenu = isset($_POST['show_in_menu']) ? 1 : 0;
    $showFooter = isset($_POST['show_in_footer']) ? 1 : 0;
    $footerReady = pages_footer_column_ready();
    $content = $_POST['content'];
    $metaTitle = trim($_POST['meta_title']);
    $metaDesc  = trim($_POST['meta_description']);
    $btnText   = trim($_POST['button_text']);
    $btnUrl    = trim($_POST['button_url']);
    $btnBlank  = isset($_POST['button_new_tab']) ? 1 : 0;

    if (!empty($_POST['edit_id'])) {
        if ($footerReady) {
            db()->prepare("UPDATE pages SET title=?, slug=?, content=?, meta_title=?, meta_description=?, button_text=?, button_url=?, button_new_tab=?, status=?, show_in_menu=?, show_in_footer=? WHERE id=?")
                ->execute([$title, $slug, $content, $metaTitle, $metaDesc, $btnText, $btnUrl, $btnBlank, $status, $showMenu, $showFooter, (int)$_POST['edit_id']]);
        } else {
            db()->prepare("UPDATE pages SET title=?, slug=?, content=?, meta_title=?, meta_description=?, button_text=?, button_url=?, button_new_tab=?, status=?, show_in_menu=? WHERE id=?")
                ->execute([$title, $slug, $content, $metaTitle, $metaDesc, $btnText, $btnUrl, $btnBlank, $status, $showMenu, (int)$_POST['edit_id']]);
        }
    } else {
        if ($footerReady) {
            db()->prepare("INSERT INTO pages (title, slug, content, meta_title, meta_description, button_text, button_url, button_new_tab, status, show_in_menu, show_in_footer) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
                ->execute([$title, $slug, $content, $metaTitle, $metaDesc, $btnText, $btnUrl, $btnBlank, $status, $showMenu, $showFooter]);
        } else {
            db()->prepare("INSERT INTO pages (title, slug, content, meta_title, meta_description, button_text, button_url, button_new_tab, status, show_in_menu) VALUES (?,?,?,?,?,?,?,?,?,?)")
                ->execute([$title, $slug, $content, $metaTitle, $metaDesc, $btnText, $btnUrl, $btnBlank, $status, $showMenu]);
        }
    }
    flash('Page saved.');
    redirect('/admin/pages.php');
}

if (isset($_GET['del'])) {
    db()->prepare("DELETE FROM pages WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Page deleted.');
    redirect('/admin/pages.php');
}

$editPage = null;
if (!empty($_GET['edit'])) {
    $stmt = db()->prepare("SELECT * FROM pages WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editPage = $stmt->fetch();
}
$pages = db()->query("SELECT * FROM pages ORDER BY created_at DESC")->fetchAll();
$viewsMap = view_counts_map('page');
?>
<div class="card">
  <h3><?php echo $editPage ? 'Edit Page' : 'Add New Page'; ?></h3>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editPage ? (int)$editPage['id'] : ''; ?>">
    <label>Title</label>
    <input type="text" name="title" value="<?php echo h($editPage['title'] ?? ''); ?>" required>
    <label>Content</label>
    <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Build the page from blocks - add an image, then a paragraph, then raw HTML (buttons, embeds, etc.), in any order.</p>
    <textarea id="pageContentArea" name="content" style="min-height:200px;font-family:monospace;"><?php echo h($editPage['content'] ?? ''); ?></textarea>
    <?php require __DIR__ . '/_content_builder.php'; ?>
    <script>document.addEventListener('DOMContentLoaded', function(){
      M3DGContentBuilder.attach('pageContentArea', <?php echo json_encode(array_map(fn($f)=>['id'=>$f['id'],'name'=>$f['name']], all_forms())); ?>);
    });</script>

    <?php if (pages_footer_column_ready()): ?>
      <label style="margin-top:16px;"><input type="checkbox" name="show_in_footer" style="width:auto;display:inline-block;" <?php echo !empty($editPage['show_in_footer']) ? 'checked' : ''; ?>> Show in site footer (About / Contact Us / Privacy Policy etc.)</label>
    <?php else: ?>
      <p style="color:var(--muted);font-size:12px;">Footer links aren't set up yet - run <code>migration-footer-pages.sql</code> on your database to enable this.</p>
    <?php endif; ?>

    <h3 style="margin-top:24px;">Call-to-Action Button (optional)</h3>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Shown as a button right after the page content.</p>
    <label>Button Text</label>
    <input type="text" name="button_text" value="<?php echo h($editPage['button_text'] ?? ''); ?>" placeholder="e.g. Contact Us">
    <label>Button URL</label>
    <input type="text" name="button_url" value="<?php echo h($editPage['button_url'] ?? ''); ?>" placeholder="/designer or https://...">
    <label><input type="checkbox" name="button_new_tab" style="width:auto;display:inline-block;" <?php echo !empty($editPage['button_new_tab']) ? 'checked' : ''; ?>> Open in new tab</label>

    <h3 style="margin-top:24px;">SEO (optional)</h3>
    <label>SEO Title (leave blank to use the page title)</label>
    <input type="text" name="meta_title" value="<?php echo h($editPage['meta_title'] ?? ''); ?>">
    <label>Meta Description</label>
    <textarea name="meta_description" style="min-height:60px;"><?php echo h($editPage['meta_description'] ?? ''); ?></textarea>

    <label style="margin-top:16px;">Status</label>
    <select name="status">
      <option value="draft" <?php echo (($editPage['status'] ?? '')==='draft')?'selected':''; ?>>Draft</option>
      <option value="published" <?php echo (($editPage['status'] ?? '')==='published')?'selected':''; ?>>Published</option>
    </select>
    <label><input type="checkbox" name="show_in_menu" style="width:auto;display:inline-block;" <?php echo (!isset($editPage) || !empty($editPage['show_in_menu'])) ? 'checked' : ''; ?>> Show in top menu</label>
    <button type="submit" name="save_page" class="btn">Save Page</button>
    <?php if ($editPage): ?><a href="pages.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <h3>All Pages</h3>
  <table>
    <thead><tr><th>Title</th><th>Status</th><th>In Menu</th><th>In Footer</th><th>Views</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($pages as $p): ?>
      <tr>
        <td><?php echo h($p['title']); ?></td>
        <td><span class="badge <?php echo $p['status']==='published'?'badge-active':'badge-expired'; ?>"><?php echo h($p['status']); ?></span></td>
        <td><?php echo $p['show_in_menu'] ? 'Yes' : 'No'; ?></td>
        <td><?php echo !empty($p['show_in_footer']) ? 'Yes' : '—'; ?></td>
        <td>👁 <?php echo (int)($viewsMap[$p['id']] ?? 0); ?></td>
        <td>
          <a href="<?php echo SITE_URL; ?>/page.php?slug=<?php echo h($p['slug']); ?>" target="_blank" class="btn btn-sm btn-outline">View</a>
          <a href="?edit=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <a href="?del=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this page?');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$pages): ?><tr><td colspan="6">No pages yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
