<?php
$adminTitle = 'Announcements';
require_once __DIR__ . '/_layout_top.php';

function handle_popup_image_upload() {
    if (empty($_FILES['popup_image_file']['name'])) return null;
    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($_FILES['popup_image_file']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return null;
    $newName = 'popup_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $newName;
    if (move_uploaded_file($_FILES['popup_image_file']['tmp_name'], $dest)) {
        return SITE_URL . '/uploads/' . $newName;
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_popup'])) {
    csrf_check();
    set_setting('popup_enabled', isset($_POST['popup_enabled']) ? '1' : '0');
    set_setting('popup_title', trim($_POST['popup_title']));
    set_setting('popup_message', $_POST['popup_message']);
    set_setting('popup_button_text', trim($_POST['popup_button_text']));
    set_setting('popup_button_url', trim($_POST['popup_button_url']));
    set_setting('popup_delay_seconds', max(0, (int)$_POST['popup_delay_seconds']));
    set_setting('popup_frequency_hours', max(1, (int)$_POST['popup_frequency_hours']));
    $img = handle_popup_image_upload();
    if ($img) set_setting('popup_image', $img);
    if (isset($_POST['popup_remove_image'])) set_setting('popup_image', '');
    flash('Popup notification saved.');
    redirect('/admin/announcements.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_marquee'])) {
    csrf_check();
    set_setting('marquee_enabled', isset($_POST['marquee_enabled']) ? '1' : '0');
    set_setting('marquee_text', trim($_POST['marquee_text']));
    set_setting('marquee_link', trim($_POST['marquee_link']));
    set_setting('marquee_bg_color', trim($_POST['marquee_bg_color']) ?: '#6366f1');
    set_setting('marquee_text_color', trim($_POST['marquee_text_color']) ?: '#ffffff');
    set_setting('marquee_speed_seconds', max(5, (int)$_POST['marquee_speed_seconds']));
    flash('Top scrolling text saved.');
    redirect('/admin/announcements.php');
}
?>
<div class="card" style="max-width:640px;">
  <h3>🔔 Popup Notification (Offer / Announcement)</h3>
  <p style="color:var(--muted);font-size:13px;">Shows once as a centered popup to visitors on the public site
  (not inside the full-screen Designer). Won't show again to the same visitor until the "don't repeat for" hours pass.</p>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label><input type="checkbox" name="popup_enabled" style="width:auto;display:inline-block;" <?php echo get_setting('popup_enabled')==='1'?'checked':''; ?>> Enable popup</label>
    <label>Title</label>
    <input type="text" name="popup_title" value="<?php echo h(get_setting('popup_title')); ?>" placeholder="e.g. 🎉 New Year Offer!">
    <label>Message</label>
    <textarea name="popup_message" style="min-height:90px;"><?php echo h(get_setting('popup_message')); ?></textarea>
    <label>Image (optional)</label>
    <input type="file" name="popup_image_file" accept="image/*">
    <?php if (get_setting('popup_image')): ?>
      <div style="margin-bottom:16px;">
        <img src="<?php echo h(get_setting('popup_image')); ?>" style="max-width:160px;border-radius:8px;display:block;margin-bottom:6px;">
        <label style="display:inline;"><input type="checkbox" name="popup_remove_image" style="width:auto;display:inline-block;"> Remove image</label>
      </div>
    <?php endif; ?>
    <label>Button Text (optional)</label>
    <input type="text" name="popup_button_text" value="<?php echo h(get_setting('popup_button_text')); ?>" placeholder="e.g. View Offer">
    <label>Button URL</label>
    <input type="text" name="popup_button_url" value="<?php echo h(get_setting('popup_button_url')); ?>" placeholder="/membership.php or https://...">
    <label>Show after (seconds)</label>
    <input type="number" name="popup_delay_seconds" value="<?php echo h(get_setting('popup_delay_seconds', 2)); ?>">
    <label>Don't repeat for (hours)</label>
    <input type="number" name="popup_frequency_hours" value="<?php echo h(get_setting('popup_frequency_hours', 24)); ?>">
    <button type="submit" name="save_popup" class="btn">Save Popup</button>
  </form>
</div>

<div class="card" style="max-width:640px;">
  <h3>📢 Top Scrolling Text (Marquee)</h3>
  <p style="color:var(--muted);font-size:13px;">A thin scrolling announcement bar at the very top of every public page.</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label><input type="checkbox" name="marquee_enabled" style="width:auto;display:inline-block;" <?php echo get_setting('marquee_enabled')==='1'?'checked':''; ?>> Enable top scrolling text</label>
    <label>Text</label>
    <input type="text" name="marquee_text" value="<?php echo h(get_setting('marquee_text')); ?>" placeholder="e.g. 🚚 Free shipping on orders above ₹999! Limited time offer.">
    <label>Link (optional - whole bar becomes clickable)</label>
    <input type="text" name="marquee_link" value="<?php echo h(get_setting('marquee_link')); ?>" placeholder="/membership.php or https://...">
    <label>Background Color</label>
    <input type="text" name="marquee_bg_color" value="<?php echo h(get_setting('marquee_bg_color', '#6366f1')); ?>">
    <label>Text Color</label>
    <input type="text" name="marquee_text_color" value="<?php echo h(get_setting('marquee_text_color', '#ffffff')); ?>">
    <label>Scroll Speed (seconds per loop - lower = faster)</label>
    <input type="number" name="marquee_speed_seconds" value="<?php echo h(get_setting('marquee_speed_seconds', 18)); ?>">
    <button type="submit" name="save_marquee" class="btn">Save Scrolling Text</button>
  </form>
</div>

<div class="card">
  <a href="<?php echo SITE_URL; ?>/" target="_blank" class="btn btn-outline">Preview Homepage ↗</a>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
