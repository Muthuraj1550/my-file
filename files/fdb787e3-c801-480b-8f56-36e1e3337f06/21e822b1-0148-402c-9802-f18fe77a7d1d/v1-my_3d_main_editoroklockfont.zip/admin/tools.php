<?php
$adminTitle = 'Tools (Tool Lab)';
require_once __DIR__ . '/_layout_top.php';

function _tools_table_exists() {
    static $ok = null;
    if ($ok === null) {
        try { db()->query("SELECT 1 FROM tools LIMIT 1"); $ok = true; }
        catch (Exception $e) { $ok = false; }
    }
    return $ok;
}
$migrationNeeded = !_tools_table_exists();

if (!$migrationNeeded && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_tool'])) {
    csrf_check();
    $name = trim($_POST['name']);
    $link = trim($_POST['link']);
    if ($name === '' || $link === '') {
        flash('Tool name and link are required.', 'error');
        redirect('/admin/tools.php');
    }
    $featured = isset($_POST['featured']) ? 1 : 0;
    if ($featured) {
        // Max 3 featured tools, same rule as the old standalone builder.
        $excludeId = !empty($_POST['edit_id']) ? (int)$_POST['edit_id'] : 0;
        $stmt = db()->prepare("SELECT COUNT(*) c FROM tools WHERE featured=1 AND id<>?");
        $stmt->execute([$excludeId]);
        $cnt = (int)$stmt->fetch()['c'];
        if ($cnt >= 3) {
            flash('Maximum 3 tools can be highlighted/featured. Un-highlight another one first.', 'error');
            redirect('/admin/tools.php');
        }
    }
    $data = [
        'name'       => $name,
        'icon'       => trim($_POST['icon']) ?: '🛠️',
        'link'       => $link,
        'color'      => $_POST['color'] === 'coral' ? 'coral' : 'teal',
        'tag_en'     => trim($_POST['tag_en']) ?: 'Tool',
        'tag_ta'     => trim($_POST['tag_ta']) ?: 'டூல்',
        'desc_en'    => trim($_POST['desc_en']),
        'desc_ta'    => trim($_POST['desc_ta']) ?: trim($_POST['desc_en']),
        'featured'   => $featured,
        'is_active'  => isset($_POST['is_active']) ? 1 : 0,
        'sort_order' => (int)($_POST['sort_order'] ?? 0),
    ];
    if (!empty($_POST['edit_id'])) {
        db()->prepare("UPDATE tools SET name=?, icon=?, link=?, color=?, tag_en=?, tag_ta=?, desc_en=?, desc_ta=?, featured=?, is_active=?, sort_order=? WHERE id=?")
            ->execute([...array_values($data), (int)$_POST['edit_id']]);
        flash('Tool updated.');
    } else {
        db()->prepare("INSERT INTO tools (name, icon, link, color, tag_en, tag_ta, desc_en, desc_ta, featured, is_active, sort_order) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
            ->execute(array_values($data));
        flash('Tool added.');
    }
    redirect('/admin/tools.php');
}

if (!$migrationNeeded && isset($_GET['del'])) {
    db()->prepare("DELETE FROM tools WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Tool deleted.');
    redirect('/admin/tools.php');
}

if (!$migrationNeeded && isset($_GET['toggle_featured'])) {
    $id = (int)$_GET['toggle_featured'];
    $stmt = db()->prepare("SELECT featured FROM tools WHERE id=?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if ($row) {
        if (!$row['featured']) {
            $cnt = (int)db()->query("SELECT COUNT(*) c FROM tools WHERE featured=1")->fetch()['c'];
            if ($cnt >= 3) {
                flash('Maximum 3 tools can be highlighted/featured.', 'error');
                redirect('/admin/tools.php');
            }
        }
        db()->prepare("UPDATE tools SET featured = 1 - featured WHERE id=?")->execute([$id]);
    }
    redirect('/admin/tools.php');
}

if (!$migrationNeeded && isset($_GET['toggle_active'])) {
    db()->prepare("UPDATE tools SET is_active = 1 - is_active WHERE id=?")->execute([(int)$_GET['toggle_active']]);
    redirect('/admin/tools.php');
}

$editTool = null;
$tools = [];
$clickCounts = [];
if (!$migrationNeeded) {
    if (!empty($_GET['edit'])) {
        $stmt = db()->prepare("SELECT * FROM tools WHERE id=?");
        $stmt->execute([(int)$_GET['edit']]);
        $editTool = $stmt->fetch();
    }
    $tools = db()->query("SELECT * FROM tools ORDER BY sort_order ASC, id ASC")->fetchAll();
    $clickCounts = tool_click_counts();
}
?>
<?php if ($migrationNeeded): ?>
<div class="card" style="border-color:var(--warn);">
  <h3 style="color:var(--warn);">⚠ Migration Pending</h3>
  <p style="color:var(--muted);font-size:14px;">
    <code>tools</code> table இன்னும் இல்ல. phpMyAdmin-ல் <code>migration-tool-lab.sql</code>
    file-ஐ import பண்ணுங்க — அப்புறம் இந்த பக்கத்தை refresh பண்ணுங்க.
  </p>
</div>
<?php else: ?>

<div class="card">
  <h3><?php echo $editTool ? 'Edit Tool' : 'Add New Tool'; ?></h3>
  <p style="color:var(--muted);font-size:13px;margin-top:-6px;">
    இங்க சேர்க்கும் tools, site-ல் <a href="<?php echo SITE_URL; ?>/tools.php" target="_blank">/tools.php</a> (Tool Lab) பக்கத்தில் உடனே தெரியும் — export/copy-paste தேவையில்ல.
  </p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editTool ? (int)$editTool['id'] : ''; ?>">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;">
      <div>
        <label>Tool Name</label>
        <input type="text" name="name" value="<?php echo h($editTool['name'] ?? ''); ?>" required placeholder="e.g. STL Repair Tool">
      </div>
      <div>
        <label>Icon (emoji)</label>
        <input type="text" name="icon" value="<?php echo h($editTool['icon'] ?? ''); ?>" maxlength="4" placeholder="🛠️">
      </div>
      <div>
        <label>Link URL</label>
        <input type="text" name="link" value="<?php echo h($editTool['link'] ?? ''); ?>" required placeholder="https://my3dgifts.com/...">
      </div>
      <div>
        <label>Color theme</label>
        <select name="color">
          <option value="teal" <?php echo (($editTool['color'] ?? 'teal')==='teal')?'selected':''; ?>>Teal</option>
          <option value="coral" <?php echo (($editTool['color'] ?? '')==='coral')?'selected':''; ?>>Coral</option>
        </select>
      </div>
      <div>
        <label>Category (English)</label>
        <input type="text" name="tag_en" value="<?php echo h($editTool['tag_en'] ?? ''); ?>" placeholder="e.g. Generator / Editor / Calculator">
      </div>
      <div>
        <label>Category (Tamil)</label>
        <input type="text" name="tag_ta" value="<?php echo h($editTool['tag_ta'] ?? ''); ?>" placeholder="e.g. ஜெனரேட்டர்">
      </div>
      <div>
        <label>Sort order (lower = shows first)</label>
        <input type="number" name="sort_order" value="<?php echo h($editTool['sort_order'] ?? (count($tools)+1)); ?>">
      </div>
      <div style="grid-column:1/-1;">
        <label>Description (English)</label>
        <textarea name="desc_en" style="min-height:44px;"><?php echo h($editTool['desc_en'] ?? ''); ?></textarea>
      </div>
      <div style="grid-column:1/-1;">
        <label>Description (Tamil)</label>
        <textarea name="desc_ta" style="min-height:44px;"><?php echo h($editTool['desc_ta'] ?? ''); ?></textarea>
      </div>
    </div>
    <label style="margin-top:14px;"><input type="checkbox" name="featured" style="width:auto;display:inline-block;" <?php echo !empty($editTool['featured']) ? 'checked' : ''; ?>> ⭐ Highlight this tool (max 3)</label><br>
    <label style="margin-top:6px;"><input type="checkbox" name="is_active" style="width:auto;display:inline-block;" <?php echo (!$editTool || !empty($editTool['is_active'])) ? 'checked' : ''; ?>> Active (visible on /tools.php)</label>

    <div style="margin-top:16px;">
      <button type="submit" name="save_tool" class="btn"><?php echo $editTool ? 'Save changes' : 'Add Tool'; ?></button>
      <?php if ($editTool): ?><a href="tools.php" class="btn btn-outline">Cancel edit</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="card">
  <h3>All Tools <span style="float:right;color:var(--muted);font-size:13px;font-weight:normal;">👁 <?php echo (int)total_tool_clicks(); ?> total clicks</span></h3>
  <table>
    <thead><tr><th>Order</th><th>Tool</th><th>Category</th><th>Clicks</th><th>Featured</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($tools as $t): ?>
      <tr>
        <td><?php echo (int)$t['sort_order']; ?></td>
        <td><?php echo h($t['icon']); ?> <?php echo h($t['name']); ?><br><span style="color:var(--muted);font-size:12px;"><?php echo h($t['link']); ?></span></td>
        <td><?php echo h($t['tag_en']); ?></td>
        <td><span class="badge badge-active">👁 <?php echo (int)($clickCounts[(int)$t['id']] ?? 0); ?></span></td>
        <td><a href="?toggle_featured=<?php echo (int)$t['id']; ?>" class="btn btn-sm <?php echo $t['featured']?'btn-outline':''; ?>"><?php echo $t['featured'] ? '⭐ Featured' : 'Highlight'; ?></a></td>
        <td><a href="?toggle_active=<?php echo (int)$t['id']; ?>"><span class="badge <?php echo $t['is_active']?'badge-active':'badge-expired'; ?>"><?php echo $t['is_active']?'Active':'Hidden'; ?></span></a></td>
        <td>
          <a href="<?php echo h($t['link']); ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline">View</a>
          <a href="?edit=<?php echo (int)$t['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <a href="?del=<?php echo (int)$t['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this tool?');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$tools): ?><tr><td colspan="7">No tools yet — add one above.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php endif; ?>
<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
