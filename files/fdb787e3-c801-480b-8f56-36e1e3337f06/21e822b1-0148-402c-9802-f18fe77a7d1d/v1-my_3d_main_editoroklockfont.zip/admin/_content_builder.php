<style>
.cb-wrap{border:1px solid var(--border,#27324a);border-radius:10px;padding:12px;background:rgba(255,255,255,.02);}
.cb-block{border:1px solid var(--border,#27324a);border-radius:8px;padding:12px;margin-bottom:10px;background:var(--card,#151f38);}
.cb-block-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;}
.cb-block-tag{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--gold,#e6c25c);}
.cb-block-actions button{background:none;border:1px solid var(--border,#27324a);color:var(--muted,#94a3b8);border-radius:6px;padding:3px 8px;font-size:12px;cursor:pointer;margin-left:4px;}
.cb-block-actions button:hover{color:#fff;}
.cb-block textarea, .cb-block input[type=text], .cb-block select{width:100%;}
.cb-block textarea{min-height:90px;font-family:inherit;}
.cb-block.cb-html textarea{font-family:monospace;min-height:140px;}
.cb-toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;}
.cb-toolbar button{background:var(--accent,#6366f1);color:#fff;border:none;border-radius:8px;padding:8px 14px;font-size:13px;cursor:pointer;}
.cb-toolbar button.outline{background:none;border:1px solid var(--border,#27324a);color:var(--muted,#94a3b8);}
.cb-img-preview{max-width:220px;border-radius:8px;display:block;margin:8px 0;}
.cb-empty{color:var(--muted,#94a3b8);font-size:13px;padding:10px 2px;}
</style>
<script>
window.M3DGContentBuilder = (function(){

  function esc(s){ var d=document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }

  function serializeBlocks(blocks){
    return blocks.map(function(b){
      if (b.type === 'paragraph') {
        var html = '<p>' + esc(b.text).replace(/\n/g,'<br>') + '</p>';
        return '<!--BLOCK:paragraph-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'image') {
        var html = b.url ? ('<img src="' + b.url + '" alt="' + esc(b.alt) + '" style="max-width:100%;border-radius:10px;">') : '';
        return '<!--BLOCK:image-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'form') {
        return '<!--BLOCK:form-->' + (b.formId ? ('[form id=' + b.formId + ']') : '') + '<!--/BLOCK-->';
      }
      // html
      return '<!--BLOCK:html-->' + (b.html || '') + '<!--/BLOCK-->';
    }).join('\n');
  }

  function parseBlocks(content){
    content = content || '';
    var re = /<!--BLOCK:(paragraph|image|html|form)-->([\s\S]*?)<!--\/BLOCK-->/g;
    var blocks = [];
    var m, found = false;
    while ((m = re.exec(content)) !== null) {
      found = true;
      var type = m[1], inner = m[2];
      if (type === 'paragraph') {
        var tmp = document.createElement('div'); tmp.innerHTML = inner;
        blocks.push({ type:'paragraph', text: (tmp.textContent || '').replace(/\n{2,}/g,'\n') });
      } else if (type === 'image') {
        var tmp2 = document.createElement('div'); tmp2.innerHTML = inner;
        var img = tmp2.querySelector('img');
        blocks.push({ type:'image', url: img ? img.getAttribute('src') : '', alt: img ? (img.getAttribute('alt')||'') : '' });
      } else if (type === 'form') {
        var fm = inner.match(/\[form\s+id=(\d+)\]/i);
        blocks.push({ type:'form', formId: fm ? fm[1] : '' });
      } else {
        blocks.push({ type:'html', html: inner });
      }
    }
    if (!found && content.trim() !== '') {
      // Legacy content saved before the block builder existed - keep it fully editable as one HTML block.
      blocks.push({ type:'html', html: content });
    }
    return blocks;
  }

  function attach(textareaId, forms){
    var ta = document.getElementById(textareaId);
    if (!ta) return;
    forms = forms || [];

    var blocks = parseBlocks(ta.value);
    ta.style.display = 'none';

    var wrap = document.createElement('div');
    wrap.className = 'cb-wrap';
    var list = document.createElement('div');
    wrap.appendChild(list);

    var toolbar = document.createElement('div');
    toolbar.className = 'cb-toolbar';
    toolbar.innerHTML =
      '<button type="button" data-add="paragraph">+ Paragraph</button>' +
      '<button type="button" data-add="image">+ Image</button>' +
      '<button type="button" data-add="html">+ HTML</button>' +
      (forms.length ? '<button type="button" data-add="form">+ Form</button>' : '') +
      '<button type="button" class="outline" data-sync>Preview HTML ↓</button>';
    wrap.appendChild(toolbar);

    ta.parentNode.insertBefore(wrap, ta);

    function render(){
      list.innerHTML = '';
      if (!blocks.length) {
        var empty = document.createElement('div');
        empty.className = 'cb-empty';
        empty.textContent = 'No content blocks yet - add an image, a paragraph, or raw HTML below.';
        list.appendChild(empty);
      }
      blocks.forEach(function(b, i){ list.appendChild(renderBlock(b, i)); });
      sync();
    }

    function renderBlock(b, i){
      var el = document.createElement('div');
      el.className = 'cb-block cb-' + b.type;
      var head = document.createElement('div');
      head.className = 'cb-block-head';
      var tagNames = { paragraph:'Paragraph', image:'Image', html:'HTML', form:'Form' };
      head.innerHTML = '<span class="cb-block-tag">' + tagNames[b.type] + '</span>';
      var actions = document.createElement('div');
      actions.className = 'cb-block-actions';
      actions.innerHTML =
        '<button type="button" data-act="up">↑</button>' +
        '<button type="button" data-act="down">↓</button>' +
        '<button type="button" data-act="del">✕</button>';
      head.appendChild(actions);
      el.appendChild(head);

      var body = document.createElement('div');
      if (b.type === 'paragraph') {
        body.innerHTML = '<textarea placeholder="Write a paragraph...">' + esc(b.text) + '</textarea>';
        body.querySelector('textarea').addEventListener('input', function(e){ b.text = e.target.value; sync(); });
      } else if (b.type === 'html') {
        body.innerHTML = '<textarea placeholder="&lt;div&gt;...raw HTML, download buttons, embeds, etc...&lt;/div&gt;">' + esc(b.html) + '</textarea>';
        body.querySelector('textarea').addEventListener('input', function(e){ b.html = e.target.value; sync(); });
      } else if (b.type === 'image') {
        var previewHtml = b.url ? ('<img class="cb-img-preview" src="' + b.url + '">') : '';
        body.innerHTML =
          previewHtml +
          '<input type="file" accept="image/*" data-role="file">' +
          '<div style="margin-top:6px;color:var(--muted);font-size:12px;">or paste an image URL:</div>' +
          '<input type="text" data-role="url" value="' + esc(b.url) + '" placeholder="https://...">' +
          '<div style="margin-top:6px;">Alt text: <input type="text" data-role="alt" value="' + esc(b.alt) + '" placeholder="Describe the image"></div>';
        body.querySelector('[data-role=url]').addEventListener('input', function(e){ b.url = e.target.value; render(); });
        body.querySelector('[data-role=alt]').addEventListener('input', function(e){ b.alt = e.target.value; sync(); });
        body.querySelector('[data-role=file]').addEventListener('change', function(e){
          var file = e.target.files[0];
          if (!file) return;
          var fd = new FormData();
          fd.append('image', file);
          fd.append('csrf', document.querySelector('input[name=csrf]').value);
          el.style.opacity = '0.5';
          fetch('ajax-upload-image.php', { method:'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(res){
              el.style.opacity = '1';
              if (res.ok) { b.url = res.url; render(); }
              else alert(res.error || 'Upload failed.');
            })
            .catch(function(){ el.style.opacity = '1'; alert('Upload failed.'); });
        });
      } else if (b.type === 'form') {
        var opts = forms.map(function(f){
          return '<option value="' + f.id + '"' + (String(b.formId)===String(f.id)?' selected':'') + '>' + esc(f.name) + '</option>';
        }).join('');
        body.innerHTML = '<select data-role="form-select"><option value="">-- Select a form --</option>' + opts + '</select>' +
          '<div style="margin-top:6px;color:var(--muted);font-size:12px;">Create/manage forms under Admin &gt; Forms.</div>';
        body.querySelector('[data-role=form-select]').addEventListener('change', function(e){ b.formId = e.target.value; sync(); });
      }
      el.appendChild(body);

      actions.querySelector('[data-act=up]').addEventListener('click', function(){ if (i>0){ blocks.splice(i-1,0,blocks.splice(i,1)[0]); render(); } });
      actions.querySelector('[data-act=down]').addEventListener('click', function(){ if (i<blocks.length-1){ blocks.splice(i+1,0,blocks.splice(i,1)[0]); render(); } });
      actions.querySelector('[data-act=del]').addEventListener('click', function(){ if (confirm('Remove this block?')) { blocks.splice(i,1); render(); } });

      return el;
    }

    function sync(){ ta.value = serializeBlocks(blocks); }

    toolbar.querySelectorAll('[data-add]').forEach(function(btn){
      btn.addEventListener('click', function(){
        var type = btn.getAttribute('data-add');
        var nb = { type:type, text:'', html:'', url:'', alt:'', formId:'' };
        blocks.push(nb);
        render();
      });
    });
    toolbar.querySelector('[data-sync]').addEventListener('click', function(){
      sync();
      alert(ta.value || '(empty)');
    });

    var formEl = ta.closest('form');
    if (formEl) formEl.addEventListener('submit', sync);

    render();
  }

  return { attach: attach };
})();
</script>
