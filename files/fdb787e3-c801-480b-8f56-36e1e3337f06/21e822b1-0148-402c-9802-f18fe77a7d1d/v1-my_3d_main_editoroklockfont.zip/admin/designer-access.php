<?php
/**
 * Designer Access — ONE screen to control every designer feature for every plan.
 *
 * Rows    = designer features (grouped: Shapes & Tools / Custom Parameters /
 *           Fonts / AI / Export)
 * Columns = "Guest / No plan" (the feature's default lock mode) + one column
 *           per membership plan.
 *
 * Each cell: Locked / Preview / Allowed (plan columns also have "Use default").
 * Everything saves in ONE submit.
 */
$adminTitle = 'Designer Access';
require_once __DIR__ . '/_layout_top.php';

if (!designer_features_ready()) {
    echo '<div class="card"><h3>Designer Access</h3><div class="flash flash-error">Import <code>migration-designer-feature-gate.sql</code>, then <code>-fix</code>, <code>-rename-stylish</code>, <code>-per-plan-access</code> and finally <code>migration-designer-feature-gate-v11.sql</code>. Then reload this page.</div></div>';
    require_once __DIR__ . '/_layout_bottom.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $lockModes = (array) ($_POST['lock_mode'] ?? []);
    $access    = (array) ($_POST['access'] ?? []);
    $stmt = db()->prepare("UPDATE designer_features SET lock_mode = ? WHERE id = ?");
    foreach (all_designer_features() as $f) {
        $fid  = (int) $f['id'];
        $mode = $lockModes[$fid] ?? $f['lock_mode'];
        if (!in_array($mode, ['free', 'export_locked', 'fully_locked'], true)) $mode = 'fully_locked';
        $stmt->execute([$mode, $fid]);

        $planAccess = [];
        foreach ((array) ($access[$fid] ?? []) as $planId => $val) {
            if (in_array($val, ['locked', 'preview', 'allowed'], true)) $planAccess[(int) $planId] = $val;
        }
        set_designer_feature_plans($fid, $planAccess);
    }
    flash('Designer access saved for all features and plans.');
    redirect('/admin/designer-access.php');
}

$grouped = all_designer_features_grouped();
$plans   = all_plans();
?>
<style>
  .da-wrap { overflow-x:auto; }
  .da-table { border-collapse:collapse; width:100%; font-size:12px; }
  .da-table th, .da-table td { border:1px solid #334155; padding:6px 8px; white-space:nowrap; }
  .da-table th { background:#111827; color:#e2e8f0; position:sticky; top:0; z-index:2; }
  .da-table td.feat { text-align:left; background:#0f172a; color:#e2e8f0; position:sticky; left:0; z-index:1; min-width:250px; white-space:normal; }
  .da-table th.feat { text-align:left; left:0; z-index:3; min-width:250px; }
  .da-group td { background:#1e293b; color:var(--gold,#facc15); font-weight:700; letter-spacing:.4px; }
  .da-table select { font-size:11px; padding:3px 4px; width:100%; }
  .da-key { color:#64748b; font-size:10px; display:block; font-weight:400; }
  .mini { width:auto!important; padding:2px 7px; font-size:10px; border:none; border-radius:4px; cursor:pointer; color:#fff; }
  .m-a { background:#16a34a; } .m-p { background:#d97706; } .m-l { background:#dc2626; } .m-d { background:#475569; }
  select.v-allowed { background:#052e16; color:#4ade80; }
  select.v-preview { background:#3b2609; color:#fbbf24; }
  select.v-locked  { background:#3f0d0d; color:#f87171; }
  select.v-default { background:#0f172a; color:#94a3b8; }
</style>

<div class="card">
  <h3 style="margin-top:0;">Designer Access — all features × all plans</h3>
  <p style="color:var(--muted);font-size:13px;margin:0 0 6px;">
    <strong>Locked</strong> = can't use it at all (upgrade popup) ·
    <strong>Preview</strong> = can use it, but export is blocked ·
    <strong>Allowed</strong> = full use + export.
  </p>
  <p style="color:var(--muted);font-size:13px;margin:0 0 6px;">
    The first column is <strong>Guest / No plan</strong> — it is also the fallback for any plan cell left on “Use default”.
  </p>
  <p style="color:var(--muted);font-size:12px;margin:0;">
    ⚠ <strong>Diamond Pin → Custom Parameter Panel</strong> is a real gate now. Pinning a locked tool's value to the right panel
    no longer bypasses its lock — the pinned row obeys the same lock as the left panel. Lock the pin row itself
    if you want to remove the shortcut entirely for a plan.
  </p>
</div>

<form method="post" class="card">
  <?php echo csrf_field(); ?>
  <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px;">
    <strong style="font-size:12px;color:#cbd5e1;">Set EVERYTHING:</strong>
    <button type="button" class="mini m-a" data-all="allowed">All Allowed</button>
    <button type="button" class="mini m-p" data-all="preview">All Preview</button>
    <button type="button" class="mini m-l" data-all="locked">All Locked</button>
    <button type="button" class="mini m-d" data-all="default">Plans → Use default</button>
  </div>

  <div class="da-wrap">
    <table class="da-table">
      <thead>
        <tr>
          <th class="feat">Feature</th>
          <th>Guest / No plan<br>
            <span style="font-weight:400;">
              <button type="button" class="mini m-a" data-col="0" data-val="allowed">A</button>
              <button type="button" class="mini m-p" data-col="0" data-val="preview">P</button>
              <button type="button" class="mini m-l" data-col="0" data-val="locked">L</button>
            </span>
          </th>
          <?php foreach ($plans as $p): ?>
            <th><?php echo h($p['plan_name']); ?><br>
              <span style="font-weight:400;">
                <button type="button" class="mini m-a" data-col="<?php echo (int) $p['id']; ?>" data-val="allowed">A</button>
                <button type="button" class="mini m-p" data-col="<?php echo (int) $p['id']; ?>" data-val="preview">P</button>
                <button type="button" class="mini m-l" data-col="<?php echo (int) $p['id']; ?>" data-val="locked">L</button>
                <button type="button" class="mini m-d" data-col="<?php echo (int) $p['id']; ?>" data-val="default">D</button>
              </span>
            </th>
          <?php endforeach; ?>
          <th>Row</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($grouped as $groupName => $features): ?>
        <tr class="da-group"><td class="feat" colspan="<?php echo count($plans) + 3; ?>"><?php echo h($groupName); ?></td></tr>
        <?php foreach ($features as $f):
          $fid = (int) $f['id'];
          $guestVal = $f['lock_mode'] === 'free' ? 'allowed' : ($f['lock_mode'] === 'export_locked' ? 'preview' : 'locked');
        ?>
        <tr data-row="<?php echo $fid; ?>">
          <td class="feat"><?php echo h($f['feature_name']); ?><span class="da-key"><?php echo h($f['feature_key']); ?></span></td>
          <td>
            <select class="da-sel" data-col="0" name="lock_mode[<?php echo $fid; ?>]">
              <option value="free"          <?php echo $guestVal === 'allowed' ? 'selected' : ''; ?>>Allowed</option>
              <option value="export_locked" <?php echo $guestVal === 'preview' ? 'selected' : ''; ?>>Preview</option>
              <option value="fully_locked"  <?php echo $guestVal === 'locked'  ? 'selected' : ''; ?>>Locked</option>
            </select>
          </td>
          <?php foreach ($plans as $p):
            $cur = $f['plan_access'][(int) $p['id']] ?? 'default';
          ?>
            <td>
              <select class="da-sel" data-col="<?php echo (int) $p['id']; ?>" name="access[<?php echo $fid; ?>][<?php echo (int) $p['id']; ?>]">
                <option value="default" <?php echo $cur === 'default' ? 'selected' : ''; ?>>Use default</option>
                <option value="allowed" <?php echo $cur === 'allowed' ? 'selected' : ''; ?>>Allowed</option>
                <option value="preview" <?php echo $cur === 'preview' ? 'selected' : ''; ?>>Preview</option>
                <option value="locked"  <?php echo $cur === 'locked'  ? 'selected' : ''; ?>>Locked</option>
              </select>
            </td>
          <?php endforeach; ?>
          <td>
            <button type="button" class="mini m-a" data-row-set="<?php echo $fid; ?>" data-val="allowed">A</button>
            <button type="button" class="mini m-p" data-row-set="<?php echo $fid; ?>" data-val="preview">P</button>
            <button type="button" class="mini m-l" data-row-set="<?php echo $fid; ?>" data-val="locked">L</button>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if (!$plans): ?>
    <p style="color:var(--muted);font-size:13px;">No plans yet — add one on the <a href="plans.php">Plans</a> page.</p>
  <?php endif; ?>

  <button type="submit" class="btn" style="margin-top:14px;width:auto;">💾 Save all access</button>
</form>

<script>
(function(){
  // Guest column uses lock_mode values; plan columns use access values.
  var GUEST = { allowed:'free', preview:'export_locked', locked:'fully_locked' };
  function setSel(sel, val){
    var v = (sel.dataset.col === '0') ? (GUEST[val] || null) : val;
    if (v === null) return;               // guest column has no "default"
    if (!Array.prototype.some.call(sel.options, function(o){ return o.value === v; })) return;
    sel.value = v; paint(sel);
  }
  function paint(sel){
    var v = sel.value;
    var cls = (v === 'free' || v === 'allowed') ? 'v-allowed'
            : (v === 'export_locked' || v === 'preview') ? 'v-preview'
            : (v === 'fully_locked' || v === 'locked') ? 'v-locked' : 'v-default';
    sel.className = 'da-sel ' + cls;
  }
  var sels = Array.prototype.slice.call(document.querySelectorAll('.da-sel'));
  sels.forEach(function(s){ paint(s); s.addEventListener('change', function(){ paint(s); }); });

  document.addEventListener('click', function(e){
    var b = e.target.closest('button[data-all],button[data-col][data-val],button[data-row-set]');
    if (!b) return;
    e.preventDefault();
    if (b.hasAttribute('data-all')) {
      sels.forEach(function(s){ setSel(s, b.dataset.all); });
    } else if (b.hasAttribute('data-row-set')) {
      var row = document.querySelector('tr[data-row="' + b.dataset.rowSet + '"]');
      if (row) Array.prototype.slice.call(row.querySelectorAll('.da-sel')).forEach(function(s){ setSel(s, b.dataset.val); });
    } else {
      sels.filter(function(s){ return s.dataset.col === b.dataset.col; })
          .forEach(function(s){ setSel(s, b.dataset.val); });
    }
  });
})();
</script>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
