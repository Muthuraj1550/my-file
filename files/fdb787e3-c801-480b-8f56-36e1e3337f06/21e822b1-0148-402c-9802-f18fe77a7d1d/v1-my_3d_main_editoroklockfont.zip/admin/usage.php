<?php
$adminTitle = 'AI Usage Logs';
require_once __DIR__ . '/_layout_top.php';

// Whether the 'guest_id' column exists yet (added by migration-guest-seo-homepage.sql).
// Older installs that haven't run that migration should NOT fatal-error here.
function _usage_has_guest_id_column() {
    static $has = null;
    if ($has === null) {
        try {
            $col = db()->query("SHOW COLUMNS FROM ai_usage_log LIKE 'guest_id'")->fetch();
            $has = (bool) $col;
        } catch (Exception $e) {
            $has = false;
        }
    }
    return $has;
}
$migrationNeeded = !_usage_has_guest_id_column();

$logs = db()->query("SELECT l.*, u.name, u.email FROM ai_usage_log l
                      LEFT JOIN users u ON u.id = l.user_id
                      ORDER BY l.used_at DESC LIMIT 200")->fetchAll();

$topUsers = db()->query("SELECT u.name, u.email, COUNT(*) c FROM ai_usage_log l
                          JOIN users u ON u.id=l.user_id
                          WHERE DATE(l.used_at) = CURDATE()
                          GROUP BY l.user_id ORDER BY c DESC LIMIT 10")->fetchAll();

if ($migrationNeeded) {
    // guest_id column not present yet - just count guest rows, skip unique-visitor count.
    $guestToday = db()->query("SELECT COUNT(*) c FROM ai_usage_log
                                WHERE user_id IS NULL AND DATE(used_at) = CURDATE()")->fetch();
    $guestToday['g'] = 0;
} else {
    $guestToday = db()->query("SELECT COUNT(*) c, COUNT(DISTINCT guest_id) g FROM ai_usage_log
                                WHERE user_id IS NULL AND DATE(used_at) = CURDATE()")->fetch();
}
?>
<?php if ($migrationNeeded): ?>
<div class="card" style="border-color:var(--warn);">
  <h3 style="color:var(--warn);">⚠ Migration Pending</h3>
  <p style="color:var(--muted);font-size:14px;">
    <code>ai_usage_log.guest_id</code> column இன்னும் இல்ல. phpMyAdmin-ல் <code>migration-guest-seo-homepage.sql</code>
    file-ஐ import பண்ணுங்க — guest (login இல்லாத) users-க்கான unique-visitor count சரியா காட்டும்.
    இது import ஆகும் வரை guest total மட்டும் காட்டும் (unique visitors 0-ஆ காட்டும்).
  </p>
</div>
<?php endif; ?>
<div class="card">
  <h3>Top AI Users Today</h3>
  <table>
    <thead><tr><th>Member</th><th>Generations Today</th></tr></thead>
    <tbody>
    <?php foreach ($topUsers as $t): ?>
      <tr><td><?php echo h($t['name']); ?> (<?php echo h($t['email']); ?>)</td><td><?php echo (int)$t['c']; ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$topUsers): ?><tr><td colspan="2">No AI usage yet today.</td></tr><?php endif; ?>
    </tbody>
  </table>
  <p style="color:var(--muted);font-size:13px;margin-top:10px;">
    Guest (not logged in) usage today: <strong><?php echo (int)$guestToday['c']; ?></strong> generations
    from <strong><?php echo (int)$guestToday['g']; ?></strong> unique visitors.
  </p>
</div>

<div class="card">
  <h3>Recent AI Generations (last 200)</h3>
  <table>
    <thead><tr><th>Date</th><th>User</th><th>Prompt</th><th>IP</th></tr></thead>
    <tbody>
    <?php foreach ($logs as $l): ?>
      <tr>
        <td><?php echo date('d M Y H:i', strtotime($l['used_at'])); ?></td>
        <td><?php echo $l['user_id'] ? h($l['name']) : '<span class="badge badge-expired">Guest</span>'; ?></td>
        <td><?php echo h(mb_substr($l['prompt'], 0, 80)); ?></td>
        <td><?php echo h($l['ip_address']); ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$logs): ?><tr><td colspan="4">No usage logged yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
