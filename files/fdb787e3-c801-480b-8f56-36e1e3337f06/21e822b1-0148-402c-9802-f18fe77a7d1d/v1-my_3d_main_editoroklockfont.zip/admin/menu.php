<?php
$adminTitle = 'Menu';
require_once __DIR__ . '/_layout_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_item'])) {
    csrf_check();
    $label  = trim($_POST['label']);
    $url    = trim($_POST['url']);
    $sort   = (int) $_POST['sort_order'];
    $active = isset($_POST['is_active']) ? 1 : 0;
    $blank  = isset($_POST['target_blank']) ? 1 : 0;

    if ($label === '' || $url === '') {
        flash('Label and URL are required.', 'error');
        redirect('/admin/menu.php');
    }

    if (!empty($_POST['edit_id'])) {
        db()->prepare("UPDATE menu_items SET label=?, url=?, sort_order=?, is_active=?, target_blank=? WHERE id=?")
            ->execute([$label, $url, $sort, $active, $blank, (int)$_POST['edit_id']]);
    } else {
        db()->prepare("INSERT INTO menu_items (label, url, sort_order, is_active, target_blank) VALUES (?,?,?,?,?)")
            ->execute([$label, $url, $sort, $active, $blank]);
    }
    flash('Menu item saved.');
    redirect('/admin/menu.php');
}

if (isset($_GET['del'])) {
    db()->prepare("DELETE FROM menu_items WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Menu item deleted.');
    redirect('/admin/menu.php');
}

if (isset($_GET['toggle'])) {
    db()->prepare("UPDATE menu_items SET is_active = 1 - is_active WHERE id=?")->execute([(int)$_GET['toggle']]);
    redirect('/admin/menu.php');
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $editItem = get_menu_item((int)$_GET['edit']);
}
$items = all_menu_items();
$pages = db()->query("SELECT title, slug FROM pages WHERE status='published' ORDER BY title ASC")->fetchAll();
?>
<div class="card" style="max-width:560px;">
  <h3><?php echo $editItem ? 'Edit Menu Item' : 'Add Menu Item'; ?></h3>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editItem ? (int)$editItem['id'] : ''; ?>">
    <label>Label (text shown in menu)</label>
    <input type="text" name="label" value="<?php echo h($editItem['label'] ?? ''); ?>" required placeholder="e.g. 3D Designer">
    <label>URL</label>
    <input type="text" name="url" value="<?php echo h($editItem['url'] ?? ''); ?>" required
           placeholder="/designer  or  /page.php?slug=about  or  https://external-site.com">
    <?php if ($pages): ?>
      <p style="color:var(--muted);font-size:12px;margin:-10px 0 16px;">
        Your published pages: <?php foreach ($pages as $pg): ?>
          <code style="cursor:pointer;" onclick="document.querySelector('[name=url]').value='/page.php?slug=<?php echo h($pg['slug']); ?>'"><?php echo h($pg['title']); ?></code>&nbsp;
        <?php endforeach; ?>
        (click a title to auto-fill its URL)
      </p>
    <?php endif; ?>
    <label>Sort Order (lower number shows first)</label>
    <input type="number" name="sort_order" value="<?php echo h($editItem['sort_order'] ?? '10'); ?>">
    <label><input type="checkbox" name="is_active" style="width:auto;display:inline-block;" <?php echo (!isset($editItem) || !empty($editItem['is_active'])) ? 'checked' : ''; ?>> Show in menu (active)</label>
    <label><input type="checkbox" name="target_blank" style="width:auto;display:inline-block;" <?php echo !empty($editItem['target_blank']) ? 'checked' : ''; ?>> Open in new tab</label>
    <button type="submit" name="save_item" class="btn">Save Menu Item</button>
    <?php if ($editItem): ?><a href="menu.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <h3>Home Page Menu (top navigation)</h3>
  <p style="color:var(--muted);font-size:13px;">This is the menu that appears at the top of every page on your site.
  Published pages with "Show in menu" checked (from Admin &gt; Pages) are appended automatically after these items.</p>
  <table>
    <thead><tr><th>Order</th><th>Label</th><th>URL</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($items as $m): ?>
      <tr>
        <td><?php echo (int)$m['sort_order']; ?></td>
        <td><?php echo h($m['label']); ?></td>
        <td><code><?php echo h($m['url']); ?></code><?php echo $m['target_blank'] ? ' ↗' : ''; ?></td>
        <td><span class="badge <?php echo $m['is_active']?'badge-active':'badge-expired'; ?>"><?php echo $m['is_active'] ? 'Active' : 'Hidden'; ?></span></td>
        <td>
          <a href="?edit=<?php echo (int)$m['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <a href="?toggle=<?php echo (int)$m['id']; ?>" class="btn btn-sm btn-outline"><?php echo $m['is_active'] ? 'Hide' : 'Show'; ?></a>
          <a href="?del=<?php echo (int)$m['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this menu item?');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$items): ?><tr><td colspan="5">No menu items yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
