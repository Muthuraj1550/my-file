<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
$pageTitle = 'Blog';
include __DIR__ . '/includes/header.php';

$perPage = 10;
$page = max(1, (int)($_GET['p'] ?? 1));
$offset = ($page - 1) * $perPage;

$pinReady = posts_pin_column_ready();
$total = db()->query("SELECT COUNT(*) c FROM posts WHERE status='published'")->fetch()['c'];
$orderBy = ($pinReady ? "is_pinned DESC, " : "") . "created_at DESC";
$cols = "title, slug, excerpt, featured_image, created_at" . ($pinReady ? ", is_pinned" : "");
$stmt = db()->prepare("SELECT $cols FROM posts WHERE status='published' ORDER BY $orderBy LIMIT $perPage OFFSET $offset");
$stmt->execute();
$posts = $stmt->fetchAll();
$totalPages = max(1, ceil($total / $perPage));
?>
<h1>Blog</h1>
<div class="post-list">
<?php if (!$posts): ?>
  <p>No posts yet. Check back soon!</p>
<?php endif; ?>
<?php foreach ($posts as $p): ?>
  <div class="post-card<?php echo !empty($p['featured_image']) ? ' post-card-has-thumb' : ''; ?>">
    <?php if (!empty($p['featured_image'])): ?>
      <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo h($p['slug']); ?>" class="post-thumb">
        <img src="<?php echo h($p['featured_image']); ?>" alt="<?php echo h($p['title']); ?>" loading="lazy">
      </a>
    <?php endif; ?>
    <div class="post-card-body">
      <h2>
        <?php if (!empty($p['is_pinned'])): ?><span class="badge badge-gold" style="vertical-align:middle;margin-right:8px;">📌 Pinned</span><?php endif; ?>
        <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo h($p['slug']); ?>"><?php echo h($p['title']); ?></a>
      </h2>
      <div class="post-meta"><?php echo date('d M Y', strtotime($p['created_at'])); ?></div>
      <p><?php echo h($p['excerpt']); ?></p>
      <a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo h($p['slug']); ?>">Read more →</a>
    </div>
  </div>
<?php endforeach; ?>
</div>

<?php if ($totalPages > 1): ?>
<div style="margin:20px 0;">
  <?php for ($i = 1; $i <= $totalPages; $i++): ?>
    <a href="?p=<?php echo $i; ?>" class="btn btn-sm <?php echo $i === $page ? '' : 'btn-outline'; ?>"><?php echo $i; ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
