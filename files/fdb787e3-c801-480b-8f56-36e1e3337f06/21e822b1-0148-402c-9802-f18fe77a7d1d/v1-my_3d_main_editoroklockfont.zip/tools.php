<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
$pageTitle = 'Tool Lab';
$metaDescription = 'Free online 3D printing tools — lithophane generator, part cutter, QR designer, support generator and more.';
include __DIR__ . '/includes/header.php';

function _toolsPage_table_exists() {
    try { db()->query("SELECT 1 FROM tools LIMIT 1"); return true; }
    catch (Exception $e) { return false; }
}
$tools = [];
if (_toolsPage_table_exists()) {
    $tools = db()->query("SELECT * FROM tools WHERE is_active=1 ORDER BY featured DESC, sort_order ASC, id ASC")->fetchAll();
}
record_view('tool_page', 0); // page-level view, for Admin > Analytics traffic sources
?>
<style>
  /* Tool Lab now uses the SAME dark/gold theme as the rest of the site
     (see assets/css/style.css :root vars) instead of its own light theme. */
  .m3g-tools-wrap{
    --m3g-teal:var(--accent2); --m3g-teal-bg:rgba(139,92,246,.14);
    --m3g-coral:#e0723c; --m3g-coral-bg:rgba(224,114,60,.14);
    --m3g-gold:var(--gold); --m3g-gold-bg:rgba(230,194,92,.14);
    --m3g-ink:var(--text); --m3g-muted:var(--muted);
    --m3g-line:var(--border); --m3g-card:var(--card); --m3g-page:var(--bg2);
    font-family:'Poppins',-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
    background:var(--m3g-page);
    background-image:radial-gradient(circle,rgba(201,162,75,.10) 1px,transparent 1px);
    background-size:22px 22px;
    padding:40px 20px 56px; border-radius:14px; color:var(--m3g-ink); position:relative;
    border:1px solid var(--m3g-line);
  }
  .m3g-tools-wrap *{box-sizing:border-box;}
  .m3g-toolbar{max-width:1040px;margin:0 auto 26px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;}
  .m3g-search{position:relative;flex:1;min-width:220px;max-width:420px;}
  .m3g-search input{width:100%;padding:11px 14px 11px 38px;border-radius:22px;border:1px solid var(--m3g-line);background:var(--bg);font-size:14px;font-family:inherit;color:var(--m3g-ink);}
  .m3g-search .ic{position:absolute;left:13px;top:50%;transform:translateY(-50%);font-size:14px;color:var(--m3g-muted);}
  .m3g-langtoggle{display:flex;border:1px solid var(--m3g-line);border-radius:20px;overflow:hidden;background:var(--m3g-card);}
  .m3g-langtoggle button{font-family:'Poppins',monospace,sans-serif;font-size:12px;font-weight:600;letter-spacing:.04em;border:none;background:transparent;color:var(--m3g-muted);padding:8px 14px;cursor:pointer;transition:background .15s ease,color .15s ease;}
  .m3g-langtoggle button.active{background:linear-gradient(135deg,var(--accent),var(--gold));color:#1a0f2e;}
  .m3g-count{font-size:12.5px;color:var(--m3g-muted);font-family:'Poppins',monospace,sans-serif;}
  .m3g-head{max-width:760px;margin:0 auto 30px;text-align:center;}
  .m3g-eyebrow{font-family:'Poppins',monospace,sans-serif;font-size:12.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--m3g-gold);font-weight:600;margin:0 0 10px;}
  .m3g-title{font-family:'Cinzel',serif;font-weight:600;font-size:clamp(24px,4vw,34px);line-height:1.2;margin:0 0 10px;color:var(--gold);}
  .m3g-sub{color:var(--m3g-muted);font-size:15px;line-height:1.6;margin:0;}
  .m3g-grid{max-width:1040px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:20px;}
  .m3g-card{background:var(--m3g-card);border:1px solid var(--m3g-line);border-radius:14px;padding:22px 20px 20px;position:relative;overflow:hidden;transition:transform .18s ease, box-shadow .18s ease;display:flex;flex-direction:column;}
  .m3g-card:hover{transform:translateY(-3px);box-shadow:0 10px 24px rgba(0,0,0,.35);}
  .m3g-card.featured{border-color:var(--m3g-gold);box-shadow:0 0 0 1px var(--m3g-gold),0 10px 24px rgba(230,194,92,.15);}
  .m3g-star-badge{position:absolute;top:14px;right:16px;font-size:12px;font-family:'Poppins',monospace,sans-serif;font-weight:600;color:var(--m3g-gold);background:var(--m3g-gold-bg);padding:3px 9px 3px 7px;border-radius:12px;letter-spacing:.03em;}
  .m3g-layerline{position:absolute;top:0;left:0;right:0;height:6px;background-repeat:repeat-x;background-size:10px 100%;}
  .m3g-layerline.teal{background-image:linear-gradient(90deg,var(--m3g-teal) 0 60%,transparent 60% 100%);}
  .m3g-layerline.coral{background-image:linear-gradient(90deg,var(--m3g-coral) 0 60%,transparent 60% 100%);}
  .m3g-layerline.gold{background-image:linear-gradient(90deg,var(--m3g-gold) 0 60%,transparent 60% 100%);}
  .m3g-icon{width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;margin:6px 0 14px;}
  .m3g-icon.teal{background:var(--m3g-teal-bg);} .m3g-icon.coral{background:var(--m3g-coral-bg);}
  .m3g-tag{font-family:'Poppins',monospace,sans-serif;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;margin:0 0 6px;}
  .m3g-tag.teal{color:var(--m3g-teal);} .m3g-tag.coral{color:var(--m3g-coral);}
  .m3g-name{font-size:17px;font-weight:600;margin:0 0 6px;color:var(--m3g-ink);}
  .m3g-desc{font-size:14px;color:var(--m3g-muted);line-height:1.55;margin:0 0 12px;flex-grow:1;}
  .m3g-clicks{font-size:11.5px;color:var(--m3g-muted);margin:0 0 10px;font-family:'Poppins',monospace,sans-serif;}
  .m3g-link{align-self:flex-start;font-size:13.5px;font-weight:700;text-decoration:none;padding:9px 16px;border-radius:8px;border:1px solid var(--m3g-line);color:var(--m3g-ink);transition:background .15s ease;}
  .m3g-link.teal:hover{background:var(--m3g-teal-bg);border-color:var(--m3g-teal);color:var(--m3g-teal);}
  .m3g-link.coral:hover{background:var(--m3g-coral-bg);border-color:var(--m3g-coral);color:var(--m3g-coral);}
  .m3g-empty{max-width:1040px;margin:30px auto 0;text-align:center;color:var(--m3g-muted);font-size:14px;}
  @media (max-width:480px){ .m3g-tools-wrap{padding:28px 14px 40px;} }
</style>

<div class="m3g-tools-wrap" id="m3gWrap">

  <div class="m3g-head">
    <p class="m3g-eyebrow" data-en="<?php echo h(SITE_NAME); ?> / Tool Lab" data-ta="<?php echo h(SITE_NAME); ?> / டூல் லேப்"><?php echo h(SITE_NAME); ?> / Tool Lab</p>
    <h2 class="m3g-title" data-en="Tools for your 3D printing work" data-ta="உங்கள் 3D பிரிண்ட் பணிக்கான டூல்ஸ்">Tools for your 3D printing work</h2>
    <p class="m3g-sub" data-en="From lithophanes to QR designs — free online tools we built for makers." data-ta="லித்தோஃபேன் முதல் கியூஆர் டிசைன் வரை — நாங்கள் உருவாக்கிய இலவச ஆன்லைன் டூல்ஸ் இங்கே.">From lithophanes to QR designs — free online tools we built for makers.</p>
  </div>

  <div class="m3g-toolbar">
    <div class="m3g-search">
      <span class="ic">🔍</span>
      <input type="text" id="m3gSearchBox" placeholder="Search tools...">
    </div>
    <div style="display:flex;align-items:center;gap:14px;">
      <span class="m3g-count" id="m3gCount"></span>
      <div class="m3g-langtoggle">
        <button type="button" class="active" data-lang="en">EN</button>
        <button type="button" data-lang="ta">தமிழ்</button>
      </div>
    </div>
  </div>

  <div class="m3g-grid" id="m3gGrid">
    <?php $clickCounts = tool_click_counts(); ?>
    <?php foreach ($tools as $t): $lineClass = $t['featured'] ? 'gold' : $t['color']; $clicks = $clickCounts[(int)$t['id']] ?? 0; ?>
    <div class="m3g-card<?php echo $t['featured'] ? ' featured' : ''; ?>" data-tool-id="<?php echo (int)$t['id']; ?>">
      <div class="m3g-layerline <?php echo h($lineClass); ?>"></div>
      <?php if ($t['featured']): ?><span class="m3g-star-badge" data-en="⭐ Featured" data-ta="⭐ சிறப்பு">⭐ Featured</span><?php endif; ?>
      <div class="m3g-icon <?php echo h($t['color']); ?>"><?php echo h($t['icon']); ?></div>
      <p class="m3g-tag <?php echo h($t['color']); ?>" data-en="<?php echo h($t['tag_en']); ?>" data-ta="<?php echo h($t['tag_ta']); ?>"><?php echo h($t['tag_en']); ?></p>
      <h3 class="m3g-name"><?php echo h($t['name']); ?></h3>
      <p class="m3g-desc" data-en="<?php echo h($t['desc_en']); ?>" data-ta="<?php echo h($t['desc_ta']); ?>"><?php echo h($t['desc_en']); ?></p>
      <p class="m3g-clicks" data-en="👁 <?php echo (int)$clicks; ?> clicks" data-ta="👁 <?php echo (int)$clicks; ?> கிளிக்ஸ்">👁 <?php echo (int)$clicks; ?> clicks</p>
      <a class="m3g-link <?php echo h($t['color']); ?> m3g-tool-link" data-tool-id="<?php echo (int)$t['id']; ?>" href="<?php echo h($t['link']); ?>" target="_blank" rel="noopener">
        <span data-en="Open tool" data-ta="Tool-ஐ திற">Open tool</span> →
      </a>
    </div>
    <?php endforeach; ?>
  </div>
  <p class="m3g-empty" id="m3gEmpty" style="display:none;">No tools match your search.</p>
  <?php if (!$tools): ?><p class="m3g-empty">No tools published yet. Check back soon!</p><?php endif; ?>
</div>

<script>
(function(){
  var wrap = document.getElementById('m3gWrap');
  if (!wrap) return;
  var lang = 'en';
  var btns = wrap.querySelectorAll('.m3g-langtoggle button');
  var nodes = wrap.querySelectorAll('[data-en]');
  var cards = Array.prototype.slice.call(wrap.querySelectorAll('.m3g-grid > .m3g-card'));
  var searchBox = document.getElementById('m3gSearchBox');
  var emptyMsg = document.getElementById('m3gEmpty');
  var countEl = document.getElementById('m3gCount');

  function setLang(l){
    lang = l;
    nodes.forEach(function(el){ var t = el.getAttribute('data-'+l); if (t !== null) el.textContent = t; });
    btns.forEach(function(b){ b.classList.toggle('active', b.getAttribute('data-lang') === l); });
    updateCount();
  }
  btns.forEach(function(b){ b.addEventListener('click', function(){ setLang(b.getAttribute('data-lang')); }); });

  function updateCount(){
    var visible = cards.filter(function(c){ return c.style.display !== 'none'; }).length;
    countEl.textContent = visible + (lang === 'ta' ? ' டூல்ஸ்' : ' tool(s)');
  }

  function filter(){
    var q = (searchBox.value || '').trim().toLowerCase();
    var visible = 0;
    cards.forEach(function(c){
      var hay = c.textContent.toLowerCase();
      var show = !q || hay.indexOf(q) !== -1;
      c.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    emptyMsg.style.display = (visible || !cards.length) ? 'none' : 'block';
    updateCount();
  }
  searchBox.addEventListener('input', filter);
  filter();

  // ── Click tracking: fire-and-forget, page stays open (links open in a
  // new tab), so a plain fetch is enough — no need for sendBeacon here. ──
  var links = wrap.querySelectorAll('.m3g-tool-link');
  links.forEach(function(a){
    a.addEventListener('click', function(){
      var toolId = a.getAttribute('data-tool-id');
      if (!toolId) return;
      try {
        fetch('<?php echo SITE_URL; ?>/api/tool-click.php', {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ tool_id: toolId })
        }).catch(function(){});
      } catch(e) {}
    });
  });
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
