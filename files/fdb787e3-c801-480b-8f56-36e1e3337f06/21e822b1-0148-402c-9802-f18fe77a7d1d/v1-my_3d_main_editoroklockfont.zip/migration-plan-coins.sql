-- =========================================================
--  MIGRATION: Plan bonus coins + Named project slot on session
--  Run in phpMyAdmin AFTER migration-tripo-coins.sql
-- =========================================================

-- Each membership plan can grant a limited number of Tripo coins on activation.
ALTER TABLE plans
    ADD COLUMN IF NOT EXISTS plan_bonus_coins INT UNSIGNED NOT NULL DEFAULT 0 AFTER premium_designer;

-- Seed sensible defaults (adjust in Admin > Plans as needed)
UPDATE plans SET plan_bonus_coins = 10  WHERE plan_name = 'Free';
UPDATE plans SET plan_bonus_coins = 100 WHERE plan_name LIKE '%Silver%';
UPDATE plans SET plan_bonus_coins = 500 WHERE plan_name LIKE '%Gold%';
