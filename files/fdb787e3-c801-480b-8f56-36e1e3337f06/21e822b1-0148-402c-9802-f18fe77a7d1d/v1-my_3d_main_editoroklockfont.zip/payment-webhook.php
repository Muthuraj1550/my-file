<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/cashfree.php';

// Cashfree calls this URL directly (no browser session), so we don't
// touch $_SESSION here at all.

$rawBody   = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '';
$timestamp = $_SERVER['HTTP_X_WEBHOOK_TIMESTAMP'] ?? '';
$secret    = get_setting('cashfree_secret_key');

// ---- Verify signature (skip only if no secret configured yet, e.g. first test) ----
if ($secret && $signature && $timestamp) {
    $expected = base64_encode(hash_hmac('sha256', $timestamp . $rawBody, $secret, true));
    if (!hash_equals($expected, $signature)) {
        http_response_code(400);
        error_log('[Cashfree Webhook] Invalid signature');
        die('Invalid signature');
    }
}

$payload = json_decode($rawBody, true);
$orderId = $payload['data']['order']['order_id']
    ?? $payload['order']['order_id']
    ?? $payload['order_id']
    ?? null;

if (!$orderId) {
    http_response_code(200); // acknowledge so Cashfree doesn't keep retrying a malformed test ping
    echo 'no order id in payload';
    exit;
}

$result = cashfree_verify_and_activate($orderId);
error_log('[Cashfree Webhook] order=' . $orderId . ' result=' . json_encode($result));

http_response_code(200);
echo 'ok';
