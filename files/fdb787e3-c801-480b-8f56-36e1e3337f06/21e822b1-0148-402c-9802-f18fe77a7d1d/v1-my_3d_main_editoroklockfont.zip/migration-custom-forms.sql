-- Custom Form Builder: build forms in Admin > Forms, embed them in any Page/Post with
-- the shortcode [form id=X], and view submitted entries on the same admin page.

CREATE TABLE IF NOT EXISTS forms (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name            VARCHAR(255) NOT NULL,
    fields_json     LONGTEXT NOT NULL,          -- JSON array of field definitions
    submit_text     VARCHAR(100) NOT NULL DEFAULT 'Submit',
    success_message VARCHAR(500) NOT NULL DEFAULT 'Thank you! We received your submission.',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS form_submissions (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    form_id         INT UNSIGNED NOT NULL,
    data_json       LONGTEXT NOT NULL,          -- JSON object: { field_label: value, ... }
    ip_address      VARCHAR(45) DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_form_id (form_id),
    CONSTRAINT fk_form_submissions_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
