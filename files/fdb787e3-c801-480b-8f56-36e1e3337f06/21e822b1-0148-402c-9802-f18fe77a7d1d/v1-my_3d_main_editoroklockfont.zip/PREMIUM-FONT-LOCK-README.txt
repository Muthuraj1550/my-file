Custom Parameter — Premium Font Lock (ON/OFF)
=============================================
File changed: protected/engine.html

Rules now enforced on every pinned FONT parameter:

1. Free fonts        -> always usable by everyone.
2. Premium font + plan that covers it -> usable (unchanged).
3. Premium font, no plan:
   - Lock button OFF (locked, grey padlock — default state):
     Free fonts + the ONE premium font this pin/template was actually
     built with are usable ("INCLUDED" badge). Any OTHER premium font
     stays blocked with the upgrade prompt. This is so a template
     works correctly for whoever bought it, without extra restriction
     on the very font it was designed with.
   - Lock button ON (unlocked, green padlock):
     The ENTIRE premium font library becomes usable ("UNLOCKED" badge
     on every premium font). Use this when the admin/premium creator
     wants to bundle full font-library access with a template sale.

The unlocked font key travels with the template XML:
  <pin ... paidOverride="1" paidFontKey="pacifico_canvas" />
Old templates without paidFontKey fall back to the font the pinned object uses.
paidFontKey is also recorded at pin-creation time (not just on unlock), so
the LOCKED-state "own font included" rule works even if the pin is never
toggled.

Also enforced for =formula font values, not just dropdown picks.

WHO CAN TOGGLE THE LOCK:
Only an account whose plan covers premium fonts may click the 🔒/🔓
button at all (window.togglePinPaidFontSwitch checks planCoversFont()
before allowing the toggle in either direction). A free/guest user
viewing a shared template can use whatever the current lock state
allows, but cannot flip the switch themselves — so they can never
self-unlock the rest of the premium font library.
