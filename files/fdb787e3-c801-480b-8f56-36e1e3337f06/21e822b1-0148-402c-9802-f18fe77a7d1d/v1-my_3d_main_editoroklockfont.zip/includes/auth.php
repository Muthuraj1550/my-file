<?php
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    // IMPORTANT: the session COOKIE was already set to last 30 days
    // (SESSION_LIFETIME), but most shared hosting runs PHP's session
    // garbage collector with a much shorter session.gc_maxlifetime
    // (often the 24-minute default) — so the cookie survives but the
    // session DATA on the server gets deleted, forcing a re-login even
    // though the cookie says "valid". Force both to match so a logged-in
    // device really does stay logged in for SESSION_LIFETIME.
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    ini_set('session.cookie_lifetime', SESSION_LIFETIME);
    session_set_cookie_params(SESSION_LIFETIME);
    session_start();
}

/** Whether the remember_tokens table (migration-remember-tokens.sql) is set up yet. */
function remember_tokens_table_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT 1 FROM remember_tokens LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/**
 * Issue a long-lived "remember me" cookie (selector + validator pattern)
 * so this device stays logged in for SESSION_LIFETIME even if the PHP
 * session itself expires or gets cleared. Called automatically on every
 * login - no checkbox needed, matches "stay logged in" being the default.
 */
function issue_remember_cookie($user_id) {
    if (!remember_tokens_table_ready()) return;
    $selector  = bin2hex(random_bytes(9));
    $validator = bin2hex(random_bytes(33));
    $hash      = hash('sha256', $validator);
    $expires   = date('Y-m-d H:i:s', time() + SESSION_LIFETIME);

    $stmt = db()->prepare("INSERT INTO remember_tokens (user_id, selector, token_hash, expires_at) VALUES (?,?,?,?)");
    $stmt->execute([$user_id, $selector, $hash, $expires]);

    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    setcookie('m3dg_remember', $selector . ':' . $validator, [
        'expires'  => time() + SESSION_LIFETIME,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function clear_remember_cookie($alsoDeleteFromDb = true) {
    if ($alsoDeleteFromDb && !empty($_COOKIE['m3dg_remember']) && remember_tokens_table_ready()) {
        $parts = explode(':', $_COOKIE['m3dg_remember'], 2);
        if (count($parts) === 2) {
            db()->prepare("DELETE FROM remember_tokens WHERE selector = ?")->execute([$parts[0]]);
        }
    }
    if (isset($_COOKIE['m3dg_remember'])) {
        setcookie('m3dg_remember', '', ['expires' => time() - 3600, 'path' => '/']);
        unset($_COOKIE['m3dg_remember']);
    }
}

/**
 * If there's no active session but a valid remember-me cookie exists,
 * silently re-establish the login (and rotate the token for safety).
 * This is what actually keeps a device "logged in for a long time"
 * instead of asking for the password again every session expiry.
 */
function attempt_remember_login() {
    if (!empty($_SESSION['uid'])) return;
    if (empty($_COOKIE['m3dg_remember']) || !remember_tokens_table_ready()) return;

    $parts = explode(':', $_COOKIE['m3dg_remember'], 2);
    if (count($parts) !== 2) { clear_remember_cookie(false); return; }
    [$selector, $validator] = $parts;

    $stmt = db()->prepare("SELECT * FROM remember_tokens WHERE selector = ? AND expires_at >= NOW() LIMIT 1");
    $stmt->execute([$selector]);
    $row = $stmt->fetch();
    if (!$row || !hash_equals($row['token_hash'], hash('sha256', $validator))) {
        clear_remember_cookie(false);
        return;
    }

    // Valid — rotate the token (delete old, issue new) and log the user in.
    db()->prepare("DELETE FROM remember_tokens WHERE id = ?")->execute([$row['id']]);
    session_regenerate_id(true);
    $_SESSION['uid'] = $row['user_id'];
    issue_remember_cookie($row['user_id']);
}
attempt_remember_login();

/** Return the logged-in user's full row from DB, or null */
function current_user() {
    static $cache = null;
    if ($cache !== null) return $cache === false ? null : $cache;
    if (empty($_SESSION['uid'])) { $cache = false; return null; }
    $stmt = db()->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$_SESSION['uid']]);
    $u = $stmt->fetch();
    $cache = $u ?: false;
    return $u ?: null;
}

function is_logged_in() {
    return !empty($_SESSION['uid']);
}

function is_admin() {
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

function require_login($redirect = '/login.php') {
    if (!is_logged_in()) {
        header('Location: ' . SITE_URL . $redirect . '?next=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}

function require_admin() {
    if (!is_logged_in() || !is_admin()) {
        header('Location: ' . SITE_URL . '/admin/login.php');
        exit;
    }
}

/** Log a user in by ID (sets session) */
function log_user_in($user_id) {
    session_regenerate_id(true);
    $_SESSION['uid'] = $user_id;
    issue_remember_cookie($user_id); // device stays logged in even if the PHP session gets cleared
}

function log_user_out() {
    clear_remember_cookie(true);
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** CSRF token helpers */
function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . htmlspecialchars(csrf_token()) . '">';
}

function csrf_check() {
    if (empty($_POST['csrf']) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
        http_response_code(403);
        die('Security check failed. Please refresh the page and try again. (CSRF)');
    }
}

/**
 * Does the user currently have an active (non-expired) paid/free plan?
 * Returns true if plan_expiry is null (unlimited) or in the future.
 */
function has_active_plan($user) {
    if (!$user) return false;
    if (empty($user['plan_expiry'])) return false;
    return strtotime($user['plan_expiry']) >= strtotime(date('Y-m-d'));
}

/** Days left in current plan (negative if expired) */
function plan_days_left($user) {
    if (!$user || empty($user['plan_expiry'])) return -1;
    return (int) floor((strtotime($user['plan_expiry']) - strtotime(date('Y-m-d'))) / 86400);
}

/**
 * Persistent anonymous visitor id (cookie, 1 year) - lets us apply a small
 * free daily AI-usage quota to guests who use the Designer without logging in.
 */
function ensure_guest_id() {
    if (!empty($_COOKIE['m3dg_gid'])) {
        return $_COOKIE['m3dg_gid'];
    }
    $gid = bin2hex(random_bytes(16));
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    setcookie('m3dg_gid', $gid, [
        'expires'  => time() + 60 * 60 * 24 * 365,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    $_COOKIE['m3dg_gid'] = $gid;
    return $gid;
}
