-- =========================================================
--  v11 — Designer feature gating: full per-plan control
--
--  Adds every newly gated designer feature (bevel/corner radius,
--  array + multi-array, multi extrude, per-font locks, AI text-to-3D,
--  GLB export) and the IMPORTANT "diamond pin" gate — so a locked
--  tool can no longer be used through the right-hand Custom Parameter
--  panel as a shortcut.
--
--  Run AFTER the earlier designer-feature-gate migrations.
--  Safe to re-run (INSERT IGNORE / conditional updates).
-- =========================================================

-- Old single "stylish font" gate becomes the per-font Yellowtail gate.
UPDATE designer_features
   SET feature_key = 'font_yellowtail', feature_name = 'Font — Yellowtail (Stylish)', sort_order = 230
 WHERE feature_key = 'stylish_font';

INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order) VALUES
-- ── Shapes / Tools ──
('shape_bevel',        'Shape Corner Radius (Bevel)',        'fully_locked', 5),
('import_svg',         'Import SVG',                          'fully_locked', 10),
('multi_axis_extrude', 'Multi-Axis Extrude',                  'export_locked', 40),
('multi_extrude',      'Multi Extrude (2nd+ axis)',           'fully_locked', 42),
('array_tool',         'Array Tool',                          'fully_locked', 44),
('multi_array',        'Multi-Array Tool (2nd+ axis)',        'fully_locked', 46),
('offset_extrude',     'Offset Extrude (Shell)',              'export_locked', 50),
('hq_bend',            'High Quality Bend (Text)',            'export_locked', 30),
('add_plugin',         'Add Plugin / Add Effect',             'fully_locked', 60),
-- ── Custom parameter shortcut ──
('pin_param',          'Diamond Pin → Custom Parameter Panel', 'free',        65),
-- ── Fonts (Dancing Script … Great Vibes) ──
('font_dancing',       'Font — Dancing Script (Joint)',       'fully_locked', 210),
('font_pacifico',      'Font — Pacifico (Cursive)',           'fully_locked', 220),
('font_yellowtail',    'Font — Yellowtail (Stylish)',         'fully_locked', 230),
('font_satisfy',       'Font — Satisfy (Elegant)',            'fully_locked', 240),
('font_lobster',       'Font — Lobster (Bold Cursive)',       'fully_locked', 250),
('font_great_vibes',   'Font — Great Vibes (Script)',         'fully_locked', 260),
-- ── AI ──
('ai_panel',           'AI Panel (Tripo AI Studio)',          'fully_locked', 70),
('text_to_3d',         'AI Text to 3D',                       'fully_locked', 72),
('image_to_3d',        'AI Image to 3D',                      'fully_locked', 75),
-- ── Export ──
('export_separate',    'Export — Separate Layers',            'fully_locked', 300),
('export_selection',   'Export — Selection Only',             'fully_locked', 310),
('export_obj',         'Export — OBJ Format',                 'fully_locked', 320),
('export_glb',         'Export — GLB Format',                 'fully_locked', 325),
('export_fbx',         'Export — FBX Format',                 'fully_locked', 330);

-- Keep display order tidy for rows that already existed.
UPDATE designer_features SET sort_order = 5   WHERE feature_key = 'shape_bevel';
UPDATE designer_features SET sort_order = 65, feature_name = 'Diamond Pin → Custom Parameter Panel' WHERE feature_key = 'pin_param';
UPDATE designer_features SET feature_name = 'AI Image to 3D' WHERE feature_key = 'image_to_3d';
UPDATE designer_features SET feature_name = 'High Quality Bend (Text)' WHERE feature_key = 'hq_bend';
