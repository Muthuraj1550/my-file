-- =========================================================
--  MIGRATION: Designer analytics + editable home page menu
--  Run this ONLY if your site is already live and you already
--  imported db.sql (or a previous migration) before.
--  Brand-new installs: just import db.sql, skip this file.
-- =========================================================

-- 1. Widen content_views.content_type so 'designer' can be tracked too
--    (safe no-op if you already ran this)
ALTER TABLE content_views MODIFY content_type VARCHAR(20) NOT NULL;
ALTER TABLE content_views MODIFY content_id INT UNSIGNED NOT NULL DEFAULT 0;

-- 2. Menu items table (home page top navigation, admin-editable)
CREATE TABLE IF NOT EXISTS menu_items (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    label           VARCHAR(100) NOT NULL,
    url             VARCHAR(255) NOT NULL,
    sort_order      INT NOT NULL DEFAULT 0,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    target_blank    TINYINT(1) NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed the same menu you already had (safe to edit/reorder afterwards in Admin > Menu)
INSERT INTO menu_items (label, url, sort_order, is_active)
SELECT * FROM (SELECT '3D Designer' AS label, '/designer.php' AS url, 1 AS sort_order, 1 AS is_active) t
WHERE NOT EXISTS (SELECT 1 FROM menu_items WHERE url = '/designer.php');

INSERT INTO menu_items (label, url, sort_order, is_active)
SELECT * FROM (SELECT 'Membership' AS label, '/membership.php' AS url, 2 AS sort_order, 1 AS is_active) t
WHERE NOT EXISTS (SELECT 1 FROM menu_items WHERE url = '/membership.php');

INSERT INTO menu_items (label, url, sort_order, is_active)
SELECT * FROM (SELECT 'Blog' AS label, '/blog.php' AS url, 3 AS sort_order, 1 AS is_active) t
WHERE NOT EXISTS (SELECT 1 FROM menu_items WHERE url = '/blog.php');
