<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$slug = $_GET['slug'] ?? '';
$stmt = db()->prepare("SELECT * FROM pages WHERE slug = ? AND status='published' LIMIT 1");
$stmt->execute([$slug]);
$page = $stmt->fetch();

if (!$page) {
    http_response_code(404);
    $pageTitle = 'Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="card"><h1>Page not found</h1></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = $page['title'];
$metaTitle = $page['meta_title'] ?: null;
$metaDescription = $page['meta_description'] ?: null;
$viewId = record_view('page', $page['id']);
include __DIR__ . '/includes/header.php';
?>
<article class="card">
  <h1><?php echo h($page['title']); ?></h1>
  <div class="post-content"><?php echo render_shortcodes($page['content']); /* trusted admin HTML content */ ?></div>
  <?php if (!empty($page['button_text']) && !empty($page['button_url'])): ?>
    <p style="margin-top:20px;">
      <a href="<?php echo (strpos($page['button_url'],'http')===0) ? h($page['button_url']) : SITE_URL . h($page['button_url']); ?>"
         class="btn" <?php echo $page['button_new_tab'] ? 'target="_blank" rel="noopener"' : ''; ?>><?php echo h($page['button_text']); ?></a>
    </p>
  <?php endif; ?>
</article>
<script>
(function(){
  var viewId = <?php echo (int)$viewId; ?>;
  var start = Date.now();
  function sendDuration(){
    var seconds = Math.round((Date.now() - start) / 1000);
    var payload = JSON.stringify({ view_id: viewId, type: 'page', seconds: seconds });
    if (navigator.sendBeacon) {
      navigator.sendBeacon('<?php echo SITE_URL; ?>/api/track-view.php', new Blob([payload], {type:'application/json'}));
    }
  }
  window.addEventListener('pagehide', sendDuration);
  document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') sendDuration(); });
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
