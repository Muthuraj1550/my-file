# My 3D Gifts - Standalone Platform (WordPress இல்லாமல்)

இது உங்க my3dgifts.com-க்கு WordPress இல்லாமல் இயங்கும் full PHP + MySQL website.
Login/Register, Membership Plans (Cashfree payment), Admin Panel (Posts/Pages/Plans/Members),
AI Usage Control, மற்றும் உங்க 3D Designer tool எல்லாம் இதுல ஒன்றாக integrate ஆகி இருக்கு.

---

## 1. Hosting Requirements (cPanel/shared hosting-ல் இருக்கணும்)

- PHP 7.4 அல்லது அதுக்கு மேல (8.x recommended)
- MySQL / MariaDB database
- PHP extensions: `pdo_mysql`, `curl`, `mbstring` (எல்லா cPanel hosting-லயும் default-ஆ இருக்கும்)
- SSL (https) - Cashfree-க்கு https அவசியம்

## 2. Database Setup

1. cPanel → **MySQL Databases** → புது database create பண்ணுங்க (e.g. `my3dgifts_db`)
2. புது DB user create பண்ணி, அந்த DB-க்கு "All Privileges" கொடுங்க
3. cPanel → **phpMyAdmin** → அந்த database-ஐ select பண்ணி → **Import** → `db.sql` file-ஐ upload பண்ணுங்க

இது தானாகவே create பண்ணும்:
- Default Free/Silver/Gold membership plans
- Default admin login: **admin@my3dgifts.com / Admin@123** ⚠️ **உடனே இதை மாத்துங்க**
Admin Panel → **My Account** page-ல் இருந்தே name/email/password மாத்திடலாம் (SQL edit தேவை இல்ல).

> **ஏற்கனவே இந்த site-ஐ ஒரு தடவை live பண்ணி db.sql import பண்ணி இருந்தீங்கன்னா** (இப்போ Analytics
> feature புதுசா சேர்த்திருக்கேன்), முழுசா `db.sql`-ஐ மறுபடியும் import பண்ண வேண்டாம் — அதனால old data
> போயிடும். அதுக்கு பதிலா `migration-content-views.sql` file-ஐ மட்டும் phpMyAdmin-ல் import பண்ணுங்க,
> அது `content_views` table-ஐ மட்டும் புதுசா add பண்ணும்.
>
> **Designer usage tracking + admin-editable menu புதுசா சேர்த்திருக்கேன்னா** (இந்த round-ல),
> `migration-designer-menu.sql`-ஐயும் இதே மாதிரி import பண்ணுங்க — இது `content_views.content_type`
> column-ஐ 'designer' track பண்ண widen பண்ணும், மற்றும் `menu_items` table-ஐ (existing menu-ஐ
> அப்படியே seed பண்ணி) புதுசா add பண்ணும்.
>
> **Guest Designer access + Homepage Customizer + SEO/Button fields புதுசா சேர்த்திருக்கேன்னா**
> (இந்த round-ல), `migration-guest-seo-homepage.sql`-ஐ import பண்ணுங்க — இது:
> - `ai_usage_log.user_id`-ஐ nullable ஆக்கி `guest_id` column சேர்க்கும் (login இல்லாம designer use பண்ணுறவங்களுக்கு)
> - `posts` / `pages` table-ல SEO (meta title/description) + CTA button fields சேர்க்கும்
> - Homepage customizer settings (hero title/buttons/custom HTML/SEO) seed பண்ணும்
>
> ⚠️ இந்த migration file-ல `ADD COLUMN IF NOT EXISTS` syntax பயன்படுத்தி இருக்கேன் — பழைய MySQL
> (5.7-க்கு கீழ) version-ல இது வேலை செய்யாம போகலாம். Error வந்தா, அந்த ஒரு line-ல இருந்து
> "IF NOT EXISTS" வார்த்தையை மட்டும் நீக்கிட்டு மறுபடியும் run பண்ணுங்க.
>
> **Popup Notification + Top Scrolling Text புதுசா சேர்த்திருக்கேன்னா** (இந்த round-ல),
> `migration-announcements.sql`-ஐ import பண்ணுங்க — இது settings-ல் புது keys மட்டும் seed பண்ணும்
> (existing data-ஐ தொடாது, safe).
>
> **Content Block Builder (Image/Paragraph/HTML blocks) + Custom Form Builder + Footer Page Links
> புதுசா சேர்த்திருக்கேன்னா** (இந்த round-ல), இரண்டு migration files import பண்ணுங்க:
> - `migration-footer-pages.sql` — `pages` table-ல `show_in_footer` column சேர்க்கும். இது run
>   ஆனா பிறகு, Admin → Pages-ல் "About" / "Contact Us" போன்ற pages-ஐ edit பண்ணி "Show in site
>   footer" checkbox-ஐ tick பண்ணுங்க — அப்போ footer-ல automatic-ஆ button link வந்துடும்.
> - `migration-custom-forms.sql` — `forms` மற்றும் `form_submissions` புது tables சேர்க்கும்.
>   இது run ஆனா பிறகு Admin sidebar-ல் புது **Forms** menu வரும் — அங்க field builder-ல் Name,
>   Email, Phone, Text, Dropdown, Textarea fields வச்சு form create பண்ணி, அந்த form-ஐ
>   `[form id=X]` shortcode-ஆ (அல்லது content builder-ல "+ Form" block-ஆ) எந்த Page/Post-ல்ல
>   வேணும்னாலும் paste பண்ணிடலாம். Submit ஆன entries அதே Forms பக்கத்திலேயே "View Submissions"-ல் காணும்.
>
> Admin → Pages/Posts-ல் இப்போ Content field ஒரு **block builder**-ஆ maறிடுச்சு — "+ Image",
> "+ Paragraph", "+ HTML" (எ.கா. download button, custom title) buttons வச்சு வரிசையா blocks
> சேர்க்கலாம், up/down arrows வச்சு reorder பண்ணலாம். ஏற்கனவே இருக்குற content (எ.கா. Contact Us
> பக்கத்துல இருக்குற ஒரே பெரிய paragraph) தானாகவே ஒரு editable HTML block-ஆ காட்டும் — அத
> சுத்தி Image/Paragraph blocks சேர்த்துக்கலாம். இதுக்கு எந்த migration தேவை இல்ல, ஆனா image
> block-ல upload பண்ண Admin login தேவை.

## 3. File Upload

1. இந்த zip-ல உள்ள எல்லா files/folders-ஐயும் உங்க domain-ன public_html (அல்லது subdomain folder) க்குள் FTP/File Manager மூலம் upload பண்ணுங்க.
2. `/uploads/` folder-க்கு **write permission (755 அல்லது 775)** கொடுங்க — post/page featured images இங்க save ஆகும்.

## 4. config.php Edit பண்ணுங்க

`config.php` file-ல் நீங்க கொடுத்த DB credentials (`mydgifts_editor` DB name/user, password) ஏற்கனவே
நான் போட்டு வச்சிருக்கேன், மேலும் ஒரு புது random `APP_SECRET` generate பண்ணி வச்சிருக்கேன் — கூடுதலா
நீங்க எதுவும் மாத்த வேண்டியதில்ல. மட்டும் இதை சரிபாருங்க:

```php
define('DB_HOST', 'localhost');   // உங்க hosting-ல வேற மாதிரி இருந்தா மாத்துங்க
define('SITE_URL', 'https://my3dgifts.com');   // trailing slash வேண்டாம்

define('APP_DEBUG', false);   // site live ஆனதும் (testing முடிஞ்சதும்) false ஆ மாத்துங்க
```

## 5. Cashfree Payment Setup (Sandbox முதலில்)

1. https://merchant.cashfree.com/ - இல் account create பண்ணுங்க (already இருந்தா login)
2. **Developers → API Keys → Test/Sandbox keys** எடுங்க (App ID + Secret Key)
3. Site-ல் `/admin/settings.php` க்கு போய் அந்த keys-ஐ paste பண்ணுங்க, Mode: **Sandbox**
4. Cashfree Dashboard-ல் **Webhooks** section-ல் இந்த URL-ஐ add பண்ணுங்க:
   `https://my3dgifts.com/payment-webhook.php`
5. Sandbox mode-ல ஒரு test plan வாங்கி பாருங்க (Cashfree test cards: https://docs.cashfree.com/docs/test-credit-card-details)
6. எல்லாம் சரியா வேலை செஞ்சா, Cashfree-ல் **Live/Production keys** வாங்கி, Mode: **Production**-ஆ மாத்துங்க

## 6. Gemini AI Key (உங்க Designer tool-க்கு)

`/admin/settings.php` → "Gemini API Key" field-ல் உங்க Google Gemini API key-ஐ (AIza... எண்ணுல ஆரம்பிக்கும்) போடுங்க.
இது Designer tool-க்கு பின்னணியில automatic-ஆ pass ஆகும் (உங்க HTML file-ல key hardcode பண்ண வேண்டாம்).

## 7. இது என்ன பண்ணுது (Features Overview)

| Feature | File(s) | Notes |
|---|---|---|
| Homepage (customizable) | `index.php`, `admin/homepage.php` | Hero text/buttons, optional custom HTML block, and SEO tags - all editable in Admin > Homepage; recent blog posts show below |
| Register/Login | `register.php`, `login.php` | Session-based auth, bcrypt password |
| Membership Plans + Payment | `membership.php`, `payment-return.php`, `payment-webhook.php` | Cashfree Orders API v3 |
| Member Dashboard | `dashboard.php` | Plan status, renew reminder, password change |
| 3D Designer (open to everyone, full-screen) | `designer.php`, `engine-stream.php`, `protected/engine.html` | **No login required** - opens full-screen (no site header/footer) for guests and members alike; premium templates + higher AI limits unlock with a paid plan; has its own 🏠 Home button to return to the site |
| AI Usage Limits | `api/ai-usage.php` | Guests get a small free daily quota (cookie-tracked); logged-in members get their plan's limit; resets at midnight |
| Blog | `blog.php`, `post.php` | Public posts, with optional SEO tags + a CTA button per post |
| Static Pages | `page.php` | About/Contact etc, auto-shown in top menu, with optional SEO tags + a CTA button per page |
| Admin Panel | `/admin/*` | Homepage, Plans, Members, Posts, Pages, Menu, Analytics, AI Logs, Settings, My Account |
| Analytics (views + time on page) | `admin/analytics.php`, `api/track-view.php` | Top posts/pages by views, total & avg minutes spent, plus 3D Designer usage (sessions + time spent, guests included) |
| Home Page Menu (admin-editable) | `admin/menu.php` | Add/edit/reorder/hide top navigation links, no code editing needed |
| Admin Account Settings | `admin/account.php` | Change admin name/email/password from the panel itself |
| Clean URLs for uploaded .html files | root `.htaccess` | Upload any `page.html` via FTP, link to it as `/page` (no extension) anywhere - `/page.html` auto-redirects to `/page` |
| Popup Notification (offer/announcement) | `admin/announcements.php` | Centered popup with title/message/image/button, configurable delay + repeat frequency |
| Top Scrolling Text (marquee) | `admin/announcements.php` | Thin scrolling announcement bar at the top of every public page, with optional link + custom colors |

## 8. Designer Tool Security Note

உங்க upload பண்ண `.html` designer file-ஐ `/protected/engine.html` -ல் வச்சிருக்கேன்.
அந்த folder-ல `.htaccess` (Apache) மூலம் **direct URL access block** பண்ணி இருக்கேன் —
`engine-stream.php` மூலமா மட்டும் தான் அந்த file serve ஆகும்.

**Designer இப்போ login இல்லாமலேயே எல்லாருக்கும் திறந்திருக்கு** (guest access):
- Login இல்லாதவங்க: Free templates + சின்ன daily AI quota (default 2/day, Admin > Settings-ல் மாத்தலாம் - cookie மூலம் track ஆகும்)
- Login பண்ணி premium plan வாங்கினவங்க: Premium templates + அவங்க plan-ஓட AI limit
இதனால designer page-ஐ யாரும் use பண்ணலாம், ஆனா premium features + அதிக AI generations-க்கு
login/upgrade பண்ணணும்-ன்னு prompt வரும்.

**⚠️ இது Apache/cPanel hosting (.htaccess support) இருந்தா தான் வேலை செய்யும்.** உங்க hosting
Nginx-ஆ இருந்தா, `.htaccess` இல் உள்ள rules-ஐ Nginx config-ல் manually add பண்ணணும்
(உங்க hosting provider support-ஐ கேளுங்க).

## 8.5. Homepage Customizer + SEO/Button fields (புதுசு)

- **Admin → Homepage**: Hero title/subtitle, இரண்டு hero buttons (text+URL தனித்தனியா மாத்தலாம்),
  ஒரு optional custom HTML block (banner/embed/எதுவும் paste பண்ணலாம்), மற்றும் homepage-க்கான
  SEO title/description — எல்லாம் code touch பண்ணாம admin panel-ல் இருந்தே மாத்தலாம்.
- **Admin → Posts / Pages**: ஒவ்வொரு post/page-க்கும் தனியா SEO Title + Meta Description,
  மற்றும் ஒரு Call-to-Action button (text + URL + new tab option) சேர்க்கலாம் — அது content-க்கு
  கீழ ஒரு button-ஆ காட்டும்.
- Homepage-ல் "AI" prominent-ஆ highlight பண்ணாம மாத்தி இருக்கேன் (AI option இன்னும் fully polish
  ஆகாததால) — hero section-ல் இப்போ neutral wording தான் இருக்கு, Admin > Homepage-ல் எப்போ வேணும்னாலும் மாத்தலாம்.

## 8.6. Menu/Button-ல் .html file link கொடுக்கும் போது (clean URL)

Menu item-ஆ இருந்தாலும், Post/Page CTA button-ஆ இருந்தாலும், ஒரு plain `.html` file-ஐ (உங்க own
static promo page, template preview, etc.) நேரடியா FTP/File Manager மூலம் site-ன் root
folder-க்கு (அல்லது எந்த folder-க்கும்) upload பண்ணிட்டு:

1. அந்த file-ஐ `offer.html` -ன்னு பெயர் வச்சு upload பண்ணுங்க
2. Menu/Button URL field-ல் `.html` **இல்லாம** `/offer`-ன்னு மட்டும் போடுங்க

இப்போ யாராவது `/offer` visit பண்ணா `offer.html`-ஐ காட்டும், `.html` extension address bar-ல
தெரியாது. யாராவது தப்பா `/offer.html`-ன்னு direct URL type பண்ணினாலும், அதை தானாகவே `/offer`-க்கு
redirect பண்ணிடும் (root `.htaccess`-ல் இந்த rule சேர்த்திருக்கேன்).

**⚠️ இதுவும் Apache/cPanel hosting (.htaccess + mod_rewrite) இருந்தா தான் வேலை செய்யும்.**

## 8.7. Popup Notification + Top Scrolling Text (Admin → Announcements)

- **Popup Notification**: Title, message, optional image, optional button (text+URL), எவ்வளவு
  நேரம் கழிச்சு காட்டணும் (delay), மற்றும் ஒரு visitor-க்கு எத்தனை மணி நேரத்துக்கு repeat ஆகக்கூடாது
  (frequency) - எல்லாம் admin panel-ல் set பண்ணலாம். Full-screen Designer page-ல் இது காட்டாது.
- **Top Scrolling Text**: ஒரு thin marquee bar site-ன் top-ல், text/link/background color/text
  color/scroll speed எல்லாம் admin panel-ல் மாத்தலாம்.
- இரண்டுமே **default-ஆ OFF** — Admin → Announcements-ல் "Enable" checkbox tick பண்ணி Save
  பண்ணினா தான் site-ல் தெரியும்.

## 9. உங்க Original WordPress Plugins vs இது — என்ன simplify பண்ணி இருக்கேன்

- **Renew/Upgrade logic**: ஒரே plan-ஐ renew பண்ணா, remaining days-ல இருந்து extend ஆகும்.
  வேற plan-க்கு upgrade/downgrade பண்ணா, இன்னிக்கு இருந்து புது validity start ஆகும்
  (partial-day proration இல்ல — உங்க business rule வேற மாதிரி வேணும்னா சொல்லுங்க, மாத்தி தரேன்).
- **GitHub XML Premium Templates**: உங்க designer HTML file-லயே already built-in ஆ
  GitHub free/paid repos-ல இருந்து fetch பண்ணும் logic இருக்கு (`GH_CONFIG.repoUrl` /
  `premiumRepoUrl`). நான் வெறும் `hasAccess: true/false` flag-ஐ மட்டும் அனுப்புறேன் plan-ஐ பொறுத்து —
  repo URLs-ஐ மாத்தணும்னா `designer.php`-ல `hasAccess` flag அனுப்புற இடத்துல
  `repoUrl`/`premiumRepoUrl` fields-ஐயும் சேர்த்து அனுப்பலாம்.
- **Cron-based daily expiry sweep**: தற்போது ஒவ்வொரு login/dashboard/membership visit-லயும்
  அந்த ஒரு user-க்கு expiry check நடக்குது (lightweight, cron தேவை இல்ல). Site-wide daily
  sweep வேணும்னா, cPanel → Cron Jobs-ல ஒரு simple `cron/expire-all.php` file எழுதி
  தினமும் ஓட வைக்கலாம் (கேட்டா அதையும் சேர்த்து தரேன்).


## 10. Next Steps பரிந்துரை

1. Sandbox-ல எல்லாம் test பண்ணுங்க (register → buy plan → dashboard-ல plan update ஆகுதான்னு பாருங்க)
2. Default admin password மாத்துங்க
3. Blog posts/pages உங்க content போட்டு publish பண்ணுங்க
4. Live-ஆனதும் Cashfree production keys + APP_DEBUG=false மாத்துங்க

## 11. இந்த Round-ல Fix + புது Features (Bug fixes, Cloud Save, Theme, Mobile, Tripo AI)

**⚠️ இதுக்கு 2 migration files run பண்ணணும் (phpMyAdmin-ல, ஏற்கனவே இருக்கும் data பாதிக்காது):**
1. `migration-guest-seo-homepage.sql` — ஏற்கனவே சேர்த்திருந்தது, ஆனா run ஆகாததால `admin/usage.php` fatal error கொடுத்துச்சு. இப்போ run பண்ணலனாலும் crash ஆகாது (auto-fallback பண்ணும்), ஆனா guest unique-visitor count சரியா வர இதை run பண்ணுங்க.
2. `migration-cloud-projects.sql` — புதுசு, Cloud Project Save/Recovery-க்காக.

- **AI Usage Logs fatal error** – Fixed. Migration run ஆகாதவரை "Migration Pending" notice மட்டும் காட்டும், crash ஆகாது.
- **Gold + Purple Theme** – `assets/css/style.css` முழுசா recolor (site + admin panel), Cinzel/Poppins fonts.
- **Mobile Designer fix** – Toggle/lock buttons screen-ன் middle-ல இருந்து top corners-க்கு மாத்தி, 3D view rotate பண்ணும்போது கை படாம பாத்துக்கிட்டேன். Long-press native "shortcut" popup mobile-ல disable பண்ணிருக்கேன்.
- **Cloud Project Save/Recovery** (login-based, 10MB/account cap):
  - Login பண்ணினா last project auto-ஆ cloud-ல save ஆகும் (`saved_projects` table), வேற device/browser-ல login பண்ணும்போதும் recover ஆகும்.
  - Free plan: auto-recovery மட்டும். Silver: 5 named "Save As" slots. Gold: 20 named slots (Admin > Membership Plans-ல plan edit பண்ணும்போது `project_slots` column மாத்தலாம்).
  - Guests (login இல்லாதவங்க): ஏற்கனவே இருந்த local-browser-only recovery அப்படியே தொடரும்.
- **🤖 Tripo AI (Text → 3D)** – Import Tools section-ல் **கடைசி item**-ஆ சேர்த்திருக்கேன். வேலை செய்ய `/admin/settings.php` → "Tripo AI API Key" field-ல் உங்க key போடணும் (இல்லனா "key not set up" error காட்டும்). Key [developers.tripo3d.ai/en/keys](https://developers.tripo3d.ai/en/keys)-ல வாங்கலாம். இது ஏற்கனவே இருக்கிற daily AI quota-வையே (Gemini-ஓட) share பண்ணும்.


---

## Course Site Login (API key ENTER pannurathu — generate illa)

1. Course site → **Admin → Tool Sites & Access** → `main_editor` site oda **API key** copy pannunga.
2. Indha site → **Admin → Course Site Access** → Course Site URL + API key paste → Save.
   - "Course user kku kudukka vendiya Plan" select pannunga (premium templates + limits adhula irundhu varum).
   - "Test Connection" la oru course username/password check pannalaam.
3. Course vaanguna user, **Login** page la avanga **course username + password** podanum
   (email illama). Login aana odane antha plan apply aagum.
4. Optional: `migration-course-login.sql` import pannina, course username member row la store aagum.

## Membership Plans Redirect (ON / OFF)

**Admin → Settings → Membership Plans Redirect (Course Site)**

- **ON** + course site purchase URL → user "Upgrade / Plans" click panna course site kku pogum.
- **OFF** → normal `membership.php` plan page kaatum.

## v11 — Designer feature control per plan (Aug 2026)

1. Import `migration-designer-feature-gate-v11.sql` in phpMyAdmin
   (after the earlier `migration-designer-feature-gate*.sql` files).
2. Admin → **Designer Access ★** = one grid, all features × all plans,
   one Save. Columns: Guest/No plan + every membership plan.
   Cell values: Locked / Preview (use but no export) / Allowed.

Newly gated features:
- Shape Corner Radius (Bevel), Import SVG, High Quality Bend (text)
- Multi-Axis Extrude, Multi Extrude (2nd+ axis)
- Array Tool, Multi-Array (2nd+ axis), Offset Extrude (Shell), Add Plugin
- Fonts individually: Dancing Script, Pacifico, Yellowtail, Satisfy,
  Lobster, Great Vibes
- AI Panel, AI Text to 3D, AI Image to 3D (separate buttons/gates)
- Export: Separate, Selection Only, OBJ, GLB, FBX
- **Diamond Pin → Custom Parameter Panel** — pinning a locked tool's value
  to the right panel no longer bypasses the lock; pinned rows re-check the
  same gate on every edit. Lock this row to remove the shortcut entirely.
