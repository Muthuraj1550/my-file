-- =========================================================
--  MIGRATION: Popup Notification + Top Scrolling Marquee
--  Run this ONLY if your site is already live.
--  Brand-new installs: just import db.sql, skip this file.
-- =========================================================

INSERT INTO settings (setting_key, setting_value) VALUES
('popup_enabled', '0'),
('popup_title', ''),
('popup_message', ''),
('popup_image', ''),
('popup_button_text', ''),
('popup_button_url', ''),
('popup_delay_seconds', '2'),
('popup_frequency_hours', '24'),
('marquee_enabled', '0'),
('marquee_text', ''),
('marquee_link', ''),
('marquee_bg_color', '#6366f1'),
('marquee_text_color', '#ffffff'),
('marquee_speed_seconds', '18')
ON DUPLICATE KEY UPDATE setting_key = setting_key;
