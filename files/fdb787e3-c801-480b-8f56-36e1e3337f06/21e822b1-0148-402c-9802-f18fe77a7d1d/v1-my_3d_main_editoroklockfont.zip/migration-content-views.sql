-- =========================================================
--  MIGRATION: Run this ONLY if you already imported the
--  original db.sql before (i.e. your site is already live).
--  If this is a brand-new install, just import db.sql - you
--  do NOT need this file, the table is already included there.
-- =========================================================

CREATE TABLE IF NOT EXISTS content_views (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    content_type    ENUM('post','page') NOT NULL,
    content_id      INT UNSIGNED NOT NULL,
    duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
    ip_address      VARCHAR(45),
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY content_lookup (content_type, content_id),
    KEY created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
