-- =========================================================
--  Main Editor - Course Site Login (optional)
--  Course site username-a member row la store panna mattum.
--  Import once in phpMyAdmin. Only ADDS a column.
-- =========================================================

SET NAMES utf8mb4;

ALTER TABLE users ADD COLUMN IF NOT EXISTS course_username VARCHAR(60) DEFAULT NULL AFTER email;

-- Older MySQL/MariaDB la "IF NOT EXISTS" error kudutha, antha vaarthai-ya
-- remove panniddu marubadiyum run pannunga.
