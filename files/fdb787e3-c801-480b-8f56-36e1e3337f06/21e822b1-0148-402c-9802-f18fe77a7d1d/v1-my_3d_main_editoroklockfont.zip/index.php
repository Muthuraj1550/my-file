<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'Home';
$metaTitle = get_setting('seo_home_title', '') ?: null;
$metaDescription = get_setting('seo_home_description', '') ?: get_setting('site_tagline', '');
include __DIR__ . '/includes/header.php';

$recentPosts = db()->query("SELECT title, slug, excerpt, created_at FROM posts WHERE status='published' ORDER BY created_at DESC LIMIT 3")->fetchAll();

$heroTitle    = get_setting('home_hero_title', 'Design. Print. Gift.');
$heroSubtitle = get_setting('home_hero_subtitle', get_setting('site_tagline', ''));
$btn1Text = get_setting('home_hero_btn1_text', 'Open 3D Designer');
$btn1Url  = get_setting('home_hero_btn1_url', '/designer');
$btn2Text = get_setting('home_hero_btn2_text', 'View Plans');
$btn2Url  = get_setting('home_hero_btn2_url', '/membership.php');
$customHtml = get_setting('home_custom_html', '');

$coin = [
    ['img' => get_setting('coin_face1_image', ''), 'emoji' => '🎁', 'text' => get_setting('coin_face1_text', 'Buy 3D Print Gift'),      'url' => get_setting('coin_face1_url', '/membership.php'), 'newTab' => get_setting('coin_face1_new_tab') === '1'],
    ['img' => get_setting('coin_face2_image', ''), 'emoji' => '🧩', 'text' => get_setting('coin_face2_text', 'Buy 3D Design Template'), 'url' => get_setting('coin_face2_url', '/designer'),   'newTab' => get_setting('coin_face2_new_tab') === '1'],
];

function nav_url($url) {
    return (strpos($url, 'http') === 0) ? $url : SITE_URL . $url;
}
foreach ($coin as &$c) { $c['url'] = nav_url($c['url']); }
unset($c);

$tossEnabled    = get_setting('coin_toss_enabled', '1') === '1';
$tossStartDelay = max(0, (int)get_setting('coin_toss_start_delay', 3));
$tossRepeatCount = max(0, (int)get_setting('coin_toss_repeat_count', 2));
$tossGap        = max(1, (int)get_setting('coin_toss_gap', 6));
$coinInitialPos = $tossEnabled ? 'coin-pos-left' : 'coin-pos-center';
?>
<section class="hero">
  <h1><?php echo h($heroTitle); ?></h1>
  <p><?php echo h($heroSubtitle); ?></p>
  <?php if ($btn1Text && $btn1Url): ?>
    <a href="<?php echo h(nav_url($btn1Url)); ?>" class="btn"><?php echo h($btn1Text); ?></a>
  <?php endif; ?>
  &nbsp;
  <?php if ($btn2Text && $btn2Url): ?>
    <a href="<?php echo h(nav_url($btn2Url)); ?>" class="btn btn-outline"><?php echo h($btn2Text); ?></a>
  <?php endif; ?>
</section>

<div class="coin-flip-wrap" id="coinFlipWrap">
  <div class="coin-toss-carrier <?php echo $coinInitialPos; ?>" id="coinTossCarrier">
    <a id="coinFlip" class="coin-flip" href="<?php echo h($coin[0]['url']); ?>" <?php echo $coin[0]['newTab'] ? 'target="_blank" rel="noopener"' : ''; ?>>
      <span class="coin-flip-circle" id="coinFlipCircle">
        <?php if ($coin[0]['img']): ?>
          <img id="coinFlipImg" src="<?php echo h($coin[0]['img']); ?>" alt="">
        <?php else: ?>
          <span id="coinFlipEmoji" class="coin-flip-emoji"><?php echo $coin[0]['emoji']; ?></span>
        <?php endif; ?>
      </span>
      <span class="coin-caption" id="coinFlipCaption"><?php echo h($coin[0]['text']); ?></span>
    </a>
  </div>
</div>
<script>
(function(){
  var faces = <?php echo json_encode($coin, JSON_UNESCAPED_SLASHES); ?>;
  var idx = 0;
  var el = document.getElementById('coinFlip');
  var circle = document.getElementById('coinFlipCircle');
  var caption = document.getElementById('coinFlipCaption');
  if (!el || faces.length < 2) return;
  var isTossing = false;

  // --- Face-swap flip (runs continuously, pauses mid-air during a toss) ---
  setInterval(function(){
    if (isTossing) return;
    el.classList.add('flipping');
    setTimeout(function(){
      idx = 1 - idx;
      var f = faces[idx];
      circle.innerHTML = f.img
        ? '<img id="coinFlipImg" src="' + f.img + '" alt="">'
        : '<span class="coin-flip-emoji">' + f.emoji + '</span>';
      caption.textContent = f.text;
      el.setAttribute('href', f.url);
      if (f.newTab) { el.setAttribute('target', '_blank'); el.setAttribute('rel', 'noopener'); }
      else { el.removeAttribute('target'); el.removeAttribute('rel'); }
      el.classList.remove('flipping');
    }, 300);
  }, 3500);

  // --- Toss-across-the-screen animation (admin-controlled timing/repeat) ---
  var tossEnabled     = <?php echo $tossEnabled ? 'true' : 'false'; ?>;
  var tossStartDelay  = <?php echo $tossStartDelay * 1000; ?>;
  var tossRepeatCount = <?php echo $tossRepeatCount; ?>; // 0 = forever
  var tossGap         = <?php echo $tossGap * 1000; ?>;
  var wrap = document.getElementById('coinFlipWrap');
  var carrier = document.getElementById('coinTossCarrier');
  var tossesDone = 0;
  var currentSide = 'left'; // matches the initial coin-pos-left class rendered server-side

  function runToss(){
    if (tossRepeatCount > 0 && tossesDone >= tossRepeatCount) return;
    tossesDone++;
    isTossing = true;
    var goingRight = (currentSide === 'left');
    var animClass = goingRight ? 'coin-tossing-ltr' : 'coin-tossing-rtl';
    carrier.classList.remove('coin-pos-left', 'coin-pos-right', 'coin-pos-center');
    wrap.classList.add(animClass);
    carrier.addEventListener('animationend', function handler(){
      carrier.removeEventListener('animationend', handler);
      wrap.classList.remove(animClass);
      currentSide = goingRight ? 'right' : 'left';
      var isLastToss = tossRepeatCount > 0 && tossesDone >= tossRepeatCount;
      // Once the coin is done tossing back and forth, let it glide to rest in the center
      // instead of staying stuck in a bottom corner.
      carrier.classList.add(isLastToss ? 'coin-pos-center' : (currentSide === 'right' ? 'coin-pos-right' : 'coin-pos-left'));
      isTossing = false;
      if (!isLastToss) {
        setTimeout(runToss, tossGap);
      }
    });
  }

  if (tossEnabled && wrap && carrier) {
    setTimeout(runToss, tossStartDelay);
  }
})();
</script>

<div class="card">
  <h2>Why My 3D Gifts?</h2>
  <div class="stat-row">
    <div class="stat-box"><div class="num">🎨</div><div class="lbl">Design your own 3D models in the browser</div></div>
    <div class="stat-box"><div class="num">✂️</div><div class="lbl">Model cutting &amp; export tools</div></div>
    <div class="stat-box"><div class="num">🖼️</div><div class="lbl">Lithophane &amp; photo lamp generator</div></div>
    <div class="stat-box"><div class="num">👑</div><div class="lbl">Premium templates for members</div></div>
  </div>
</div>

<?php if (trim($customHtml) !== ''): ?>
<div class="card">
  <?php echo render_shortcodes($customHtml); /* trusted admin HTML, set in Admin > Homepage */ ?>
</div>
<?php endif; ?>

<?php if ($recentPosts): ?>
<h2>Latest from the Blog</h2>
<div class="post-list">
  <?php foreach ($recentPosts as $p): ?>
    <div class="post-card">
      <h2><a href="<?php echo SITE_URL; ?>/post.php?slug=<?php echo h($p['slug']); ?>"><?php echo h($p['title']); ?></a></h2>
      <div class="post-meta"><?php echo date('d M Y', strtotime($p['created_at'])); ?></div>
      <p><?php echo h($p['excerpt']); ?></p>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
