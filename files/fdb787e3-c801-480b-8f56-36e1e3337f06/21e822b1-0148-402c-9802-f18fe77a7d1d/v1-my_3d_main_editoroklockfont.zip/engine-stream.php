<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

// Designer is open to everyone (guests get a small free AI quota + free
// templates only; login/plan just unlocks more AI generations + premium
// templates). This file is only reachable via this script anyway, since
// /protected/ itself is blocked at the webserver level (.htaccess).

$engineFile = __DIR__ . '/protected/engine.html';
if (!file_exists($engineFile)) {
    http_response_code(500);
    echo 'Designer engine file missing. Please contact the site admin.';
    exit;
}

header('Content-Type: text/html; charset=UTF-8');
// Prevent this page from being cached with stale access permissions
header('Cache-Control: no-store, no-cache, must-revalidate');
readfile($engineFile);
