-- =========================================================
--  MIGRATION: Remember-Me Tokens (keeps a device logged in
--  for 30 days instead of asking to log in again frequently)
--  Run this ONLY if your site is already live. Brand-new
--  installs: db.sql already has this table.
-- =========================================================

CREATE TABLE IF NOT EXISTS remember_tokens (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED NOT NULL,
    selector        VARCHAR(24) NOT NULL,
    token_hash      VARCHAR(64) NOT NULL,
    expires_at      DATETIME NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY selector (selector),
    KEY user_id (user_id),
    CONSTRAINT fk_remember_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
