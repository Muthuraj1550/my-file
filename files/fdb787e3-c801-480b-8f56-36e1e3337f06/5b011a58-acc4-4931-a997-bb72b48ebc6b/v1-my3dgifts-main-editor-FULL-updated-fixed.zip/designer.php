<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/course_link.php';

$user = current_user();
if ($user) check_and_expire_user($user);
$guestId = $user ? null : ensure_guest_id();

// Designer opens full-screen for EVERYONE (guests included). Logged-in
// members with a premium plan additionally unlock premium templates and
// a higher daily AI limit. The engine itself has a 🏠 Home button that
// returns to the main site.
$hasAccess = is_premium_designer_user($user);
$isAdmin   = is_admin();
$geminiKey = get_setting('gemini_api_key', '');
$viewId    = record_view('designer', 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
<title>3D Designer - <?php echo h(SITE_NAME); ?></title>
<style>
  html,body{margin:0;padding:0;height:100%;overflow:hidden;background:#0b1120;}
  #designerFrame{position:fixed;top:0;left:0;width:100vw;height:100vh;border:0;background:#0b1120;}
  #upgradeChoiceOverlay{display:none;position:fixed;inset:0;background:rgba(2,6,23,.75);z-index:99999;align-items:center;justify-content:center;font-family:Arial,Helvetica,sans-serif;}
  #upgradeChoiceBox{background:#0f172a;border:1px solid #334155;border-radius:12px;padding:24px;max-width:380px;width:90%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.5);}
  #upgradeChoiceMsg{color:#e2e8f0;font-size:14px;margin-bottom:18px;line-height:1.5;}
  .upgradeChoiceBtn{display:block;width:100%;border:none;border-radius:8px;padding:12px;font-size:14px;font-weight:bold;cursor:pointer;margin-bottom:10px;box-sizing:border-box;}
  #upgradeChoiceMembershipBtn{background:linear-gradient(135deg,#7c3aed,#a855f7);color:#fff;}
  #upgradeChoiceCourseBtn{background:linear-gradient(135deg,#0369a1,#0ea5e9);color:#fff;}
  #upgradeChoiceCancelBtn{background:transparent;color:#94a3b8;border:1px solid #334155;margin-bottom:0;}
</style>
</head>
<body>
<?php
  $loadXml = isset($_GET['load_xml']) ? (string)$_GET['load_xml'] : '';
  $engineSrc = SITE_URL . '/engine-stream.php' . ($loadXml !== '' ? ('?load_xml=' . rawurlencode($loadXml)) : '');
?>
<iframe id="designerFrame" src="<?php echo h($engineSrc); ?>" allow="clipboard-write"></iframe>

<!-- Premium-upgrade choice popup: shown instead of a single-link redirect
     so the person can pick Membership OR the full course purchase. -->
<div id="upgradeChoiceOverlay">
  <div id="upgradeChoiceBox">
    <div id="upgradeChoiceMsg"></div>
    <button id="upgradeChoiceMembershipBtn" class="upgradeChoiceBtn">🌟 Membership Plans</button>
    <button id="upgradeChoiceCourseBtn" class="upgradeChoiceBtn">📚 Full Course Purchase</button>
    <button id="upgradeChoiceCancelBtn" class="upgradeChoiceBtn">Cancel</button>
  </div>
</div>

<script>
(function(){
  var HAS_ACCESS  = <?php echo $hasAccess ? 'true' : 'false'; ?>;
  var IS_LOGGED_IN = <?php echo $user ? 'true' : 'false'; ?>;
  // Only true for role='admin' accounts — gates the "Save Current Project to
  // GitHub" button shown at the top of the template popup (protected/engine.html).
  var IS_ADMIN     = <?php echo $isAdmin ? 'true' : 'false'; ?>;
  var GEMINI_KEY  = <?php echo json_encode($geminiKey); ?>;
  // These start from the PHP-rendered (pre-login) session and are refreshed
  // live the moment the in-editor login popup succeeds (see m3dg_login_request
  // below) — so a paid-plan user gets premium-template access instantly,
  // with no page refresh needed.
  var NAMED_SLOT_LIMIT      = <?php echo (int) get_user_named_slot_limit($user); ?>;
  var TRIPO_LOGGED_IN       = <?php echo $user ? 'true' : 'false'; ?>;
  var TRIPO_COINS           = <?php echo (int)(($user['plan_coins'] ?? 0) + ($user['tripo_coins'] ?? 0)); ?>;
  var TRIPO_PLAN_COINS      = <?php echo (int)($user['plan_coins'] ?? 0); ?>;
  var TRIPO_PURCHASED_COINS = <?php echo (int)($user['tripo_coins'] ?? 0); ?>;
  var FEATURE_ACCESS = <?php echo json_encode(designer_user_feature_access($user)); ?>;
  var frame = document.getElementById('designerFrame');

  // Two upgrade destinations, shown together in the popup below.
  // MEMBERSHIP_URL is always this site's own plans page. COURSE_URL is the
  // "Full Course Purchase" link Admin -> Settings -> plans_redirect_url —
  // its button is hidden if that setting is left empty.
  var MEMBERSHIP_URL = <?php echo json_encode(SITE_URL . '/membership.php'); ?>;
  var COURSE_URL      = <?php echo json_encode(plans_redirect_on() ? plans_redirect_target_url() : ''); ?>;

  function showUpgradeChoice(name) {
    var overlay = document.getElementById('upgradeChoiceOverlay');
    var msg = document.getElementById('upgradeChoiceMsg');
    var courseBtn = document.getElementById('upgradeChoiceCourseBtn');
    var what = name ? ('"' + name + '"') : 'This feature';
    var text = IS_LOGGED_IN
      ? (what + ' needs a plan upgrade. Choose an option below:')
      : (what + ' needs login/registration and a plan upgrade. Choose an option below:');
    msg.textContent = text;
    courseBtn.style.display = COURSE_URL ? 'block' : 'none';
    overlay.style.display = 'flex';
  }
  document.getElementById('upgradeChoiceMembershipBtn').addEventListener('click', function(){
    window.top.location.href = MEMBERSHIP_URL;
  });
  document.getElementById('upgradeChoiceCourseBtn').addEventListener('click', function(){
    if (COURSE_URL) window.top.location.href = COURSE_URL;
  });
  document.getElementById('upgradeChoiceCancelBtn').addEventListener('click', function(){
    document.getElementById('upgradeChoiceOverlay').style.display = 'none';
  });

  // ── Time-on-page tracking (Analytics: Designer usage) ──
  var VIEW_ID = <?php echo (int)$viewId; ?>;
  var __start = Date.now();
  function sendDesignerDuration(){
    var seconds = Math.round((Date.now() - __start) / 1000);
    var payload = JSON.stringify({ view_id: VIEW_ID, type: 'designer', seconds: seconds });
    if (navigator.sendBeacon) {
      navigator.sendBeacon('<?php echo SITE_URL; ?>/api/track-view.php', new Blob([payload], {type:'application/json'}));
    }
  }
  window.addEventListener('pagehide', sendDesignerDuration);
  document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') sendDesignerDuration(); });

  function sendConfig() {
    try {
      frame.contentWindow.postMessage({
        type: 'gh_xml_config',
        hasAccess: HAS_ACCESS,
        showDropdown: true,
        usePluginPicker: false,
        isLoggedIn: IS_LOGGED_IN,
        isAdmin: IS_ADMIN,
        namedSlotLimit: NAMED_SLOT_LIMIT,
        tripoLoggedIn: TRIPO_LOGGED_IN,
        tripoCoins: TRIPO_COINS,
        tripoPlanCoins: TRIPO_PLAN_COINS,
        tripoPurchasedCoins: TRIPO_PURCHASED_COINS,
        tripoCostPerGeneration: <?php echo (int) get_setting('tripo_cost_per_generation', 10); ?>,
        featureAccess: FEATURE_ACCESS
      }, '*');
    } catch(e) {}
  }
  frame.addEventListener('load', function(){
    setTimeout(sendConfig, 800);
    setTimeout(sendConfig, 2000);
  });

  window.addEventListener('message', function(ev){
    if (!ev.data) return;

    // ── AI usage check (the engine asks before every generate) ──
    if (ev.data.type === 'ai_usage_check') {
      fetch('<?php echo SITE_URL; ?>/api/ai-usage.php?action=check', { credentials: 'include' })
        .then(function(r){ return r.json(); })
        .then(function(usage){
          if (!usage.allowed) {
            var msg = IS_LOGGED_IN
              ? 'Your daily AI design limit (' + usage.limit + ') is used up. Upgrade your plan for more.'
              : 'You\'ve used your ' + usage.limit + ' free daily AI design(s). Register for a free account to get more, or login if you already have one.';
            alert(msg);
            frame.contentWindow.postMessage({ type: 'ai_usage_blocked' }, '*');
            return;
          }
          return fetch('<?php echo SITE_URL; ?>/api/ai-usage.php?action=log', {
            method: 'POST', credentials: 'include',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ prompt: ev.data.prompt || '' })
          }).then(function(r){ return r.json(); }).then(function(logRes){
            if (!logRes.allowed) {
              alert('Daily AI limit reached.');
              frame.contentWindow.postMessage({ type: 'ai_usage_blocked' }, '*');
            } else {
              frame.contentWindow.postMessage({ type: 'ai_usage_ok', proxyUrl: GEMINI_KEY }, '*');
            }
          });
        })
        .catch(function(){
          // fail-open on network errors so a glitch doesn't block the user
          frame.contentWindow.postMessage({ type: 'ai_usage_ok', proxyUrl: GEMINI_KEY }, '*');
        });
    }

    // ── Premium template/feature blocked for free/guest users ──
    // Shows BOTH upgrade destinations (Membership plans + Full Course
    // Purchase) so the person picks instead of being sent to just one.
    if (ev.data.type === 'gh_premium_block') {
      showUpgradeChoice(ev.data.name);
    }

    // ── In-editor login popup (stay on the designer page, no reload) ──
    // The engine (sandboxed iframe) can't reliably send a cookie-authenticated
    // request on its own, so designer.php does the fetch (same-origin,
    // credentials included) just like the cloud-project relay below, then
    // refreshes the engine's config (isLoggedIn / coins / limits) in place.
    if (ev.data.type === 'm3dg_login_request') {
      var loginReqId = ev.data.reqId;
      fetch('<?php echo SITE_URL; ?>/api/login.php', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: ev.data.email || '', password: ev.data.password || '' })
      }).then(function(r){ return r.json(); }).then(function(res){
        if (res && res.ok) {
          IS_LOGGED_IN = true;
          // Apply the freshly-logged-in user's access/coins/slot data right away —
          // this is what makes premium (paid) templates unlock immediately after
          // login, with no page refresh needed.
          if (typeof res.hasAccess === 'boolean') HAS_ACCESS = res.hasAccess;
          if (typeof res.isAdmin === 'boolean') IS_ADMIN = res.isAdmin;
          if (typeof res.namedSlotLimit === 'number') NAMED_SLOT_LIMIT = res.namedSlotLimit;
          if (typeof res.tripoLoggedIn === 'boolean') TRIPO_LOGGED_IN = res.tripoLoggedIn;
          if (typeof res.tripoCoins === 'number') TRIPO_COINS = res.tripoCoins;
          if (typeof res.tripoPlanCoins === 'number') TRIPO_PLAN_COINS = res.tripoPlanCoins;
          if (typeof res.tripoPurchasedCoins === 'number') TRIPO_PURCHASED_COINS = res.tripoPurchasedCoins;
          if (res.featureAccess && typeof res.featureAccess === 'object') FEATURE_ACCESS = res.featureAccess;
          sendConfig(); // pushes fresh isLoggedIn / hasAccess / tripoCoins / namedSlotLimit into the engine
        }
        frame.contentWindow.postMessage({
          type: 'm3dg_login_response', reqId: loginReqId,
          ok: !!(res && res.ok), name: res && res.name, error: res && res.error
        }, '*');
      }).catch(function(){
        frame.contentWindow.postMessage({ type: 'm3dg_login_response', reqId: loginReqId, ok: false, error: 'Network error. Please try again.' }, '*');
      });
    }

    // ── Cloud project save/recovery (login-only, up to 10MB/user) ──
    // The engine (sandboxed iframe) can't send cookies-authenticated requests
    // reliably from postMessage alone, so designer.php does the actual fetch
    // (same-origin, credentials included) and posts the result back.
    if (ev.data.type === 'cloud_project_request') {
      var reqId  = ev.data.reqId;
      var action = ev.data.action; // list | load | save | delete | share | import
      var base   = '<?php echo SITE_URL; ?>/api/project-store.php';

      function reply(data) {
        frame.contentWindow.postMessage({ type: 'cloud_project_response', reqId: reqId, data: data }, '*');
      }

      if (!IS_LOGGED_IN) { reply({ ok: false, error: 'login_required' }); return; }

      if (action === 'list' || action === 'load') {
        var url = base + '?action=' + encodeURIComponent(action);
        if (action === 'load' && ev.data.slot) url += '&slot=' + encodeURIComponent(ev.data.slot);
        fetch(url, { credentials: 'include' })
          .then(function(r){ return r.json(); })
          .then(reply)
          .catch(function(){ reply({ ok: false, error: 'network_error' }); });
      } else if (action === 'save' || action === 'delete' || action === 'share' || action === 'import') {
        fetch(base + '?action=' + action, {
          method: 'POST', credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ slot: ev.data.slot, xml: ev.data.xml, share_code: ev.data.share_code })
        }).then(function(r){ return r.json(); }).then(reply)
          .catch(function(){ reply({ ok: false, error: 'network_error' }); });
      } else {
        reply({ ok: false, error: 'unknown_action' });
      }
    }

    // ── Admin: save current project to GitHub as a new template ──
    // (button only rendered client-side when isAdmin is true, but this
    // relay re-checks admin status server-side via api/github-template-save.php
    // regardless — never trust the iframe's own gate.)
    if (ev.data.type === 'gh_template_save_request') {
      var gReqId = ev.data.reqId;
      function gReply(data) {
        frame.contentWindow.postMessage({ type: 'gh_template_save_response', reqId: gReqId, data: data }, '*');
      }
      if (!IS_LOGGED_IN) { gReply({ ok: false, error: 'login_required' }); return; }
      fetch('<?php echo SITE_URL; ?>/api/github-template-save.php', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          repo: ev.data.repo, name: ev.data.name, xml: ev.data.xml, thumbnail: ev.data.thumbnail
        })
      }).then(function(r){ return r.json(); }).then(gReply)
        .catch(function(){ gReply({ ok: false, error: 'network_error' }); });
    }

    // ── Admin: delete a template from GitHub ──
    if (ev.data.type === 'gh_template_delete_request') {
      var dReqId = ev.data.reqId;
      function dReply(data) {
        frame.contentWindow.postMessage({ type: 'gh_template_delete_response', reqId: dReqId, data: data }, '*');
      }
      if (!IS_LOGGED_IN) { dReply({ ok: false, error: 'login_required' }); return; }
      fetch('<?php echo SITE_URL; ?>/api/github-template-delete.php', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ repo: ev.data.repo, name: ev.data.name })
      }).then(function(r){ return r.json(); }).then(dReply)
        .catch(function(){ dReply({ ok: false, error: 'network_error' }); });
    }
  });
})();
</script>
</body>
</html>
