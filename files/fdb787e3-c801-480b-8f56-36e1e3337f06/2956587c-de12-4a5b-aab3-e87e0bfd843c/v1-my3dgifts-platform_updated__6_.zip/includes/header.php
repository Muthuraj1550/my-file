<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$__user = current_user();
if ($__user) check_and_expire_user($__user);

$__pages_menu = db()->query("SELECT title, slug FROM pages WHERE status='published' AND show_in_menu=1 ORDER BY title ASC")->fetchAll();
$__menu_items = active_menu_items();

function page_title($t = '') {
    return $t ? h($t) . ' - ' . h(SITE_NAME) : h(SITE_NAME);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo !empty($metaTitle) ? h($metaTitle) : page_title($pageTitle ?? ''); ?></title>
<?php
$__metaDesc = !empty($metaDescription) ? $metaDescription : get_setting('site_tagline', '');
if ($__metaDesc):
?>
<meta name="description" content="<?php echo h($__metaDesc); ?>">
<meta property="og:description" content="<?php echo h($__metaDesc); ?>">
<?php endif; ?>
<meta property="og:title" content="<?php echo !empty($metaTitle) ? h($metaTitle) : page_title($pageTitle ?? ''); ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?php echo h(SITE_NAME); ?>">
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
</head>
<body>
<?php
$__marqueeOn = get_setting('marquee_enabled') === '1' && trim(get_setting('marquee_text')) !== '';
if ($__marqueeOn):
    $__mLink = trim(get_setting('marquee_link'));
    $__mBg   = get_setting('marquee_bg_color', '#6366f1');
    $__mFg   = get_setting('marquee_text_color', '#ffffff');
    $__mSpeed = max(5, (int) get_setting('marquee_speed_seconds', 18));
?>
<div class="site-marquee" style="background:<?php echo h($__mBg); ?>;">
  <?php if ($__mLink): ?><a href="<?php echo h((strpos($__mLink,'http')===0) ? $__mLink : SITE_URL . $__mLink); ?>" style="color:<?php echo h($__mFg); ?>;text-decoration:none;display:block;"><?php endif; ?>
  <div class="site-marquee-track" style="animation-duration:<?php echo (int)$__mSpeed; ?>s;color:<?php echo h($__mFg); ?>;">
    <span><?php echo h(get_setting('marquee_text')); ?></span>
    <span><?php echo h(get_setting('marquee_text')); ?></span>
  </div>
  <?php if ($__mLink): ?></a><?php endif; ?>
</div>
<?php endif; ?>
<header class="site-header">
  <div class="wrap header-inner">
    <a href="<?php echo SITE_URL; ?>/" class="brand"><?php echo h(SITE_NAME); ?></a>
    <nav class="main-nav">
      <?php foreach ($__menu_items as $m): ?>
        <a href="<?php echo (strpos($m['url'], 'http') === 0) ? h($m['url']) : SITE_URL . h($m['url']); ?>"
           <?php echo $m['target_blank'] ? 'target="_blank" rel="noopener"' : ''; ?>><?php echo h($m['label']); ?></a>
      <?php endforeach; ?>
      <?php foreach ($__pages_menu as $p): ?>
        <a href="<?php echo SITE_URL; ?>/page.php?slug=<?php echo h($p['slug']); ?>"><?php echo h($p['title']); ?></a>
      <?php endforeach; ?>
      <?php if ($__user): ?>
        <a href="<?php echo SITE_URL; ?>/dashboard.php" class="nav-cta">My Dashboard</a>
      <?php else: ?>
        <a href="<?php echo SITE_URL; ?>/login.php">Login</a>
        <a href="<?php echo SITE_URL; ?>/register.php" class="nav-cta">Join Now</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main>
<div class="wrap">
<?php $__flash = get_flash(); if ($__flash): ?>
  <div class="flash flash-<?php echo h($__flash['type']); ?>"><?php echo h($__flash['msg']); ?></div>
<?php endif; ?>
