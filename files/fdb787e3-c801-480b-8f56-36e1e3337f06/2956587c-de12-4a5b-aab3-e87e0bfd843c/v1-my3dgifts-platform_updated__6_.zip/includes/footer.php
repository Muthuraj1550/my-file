</div>
</main>
<footer class="site-footer">
  <div class="wrap">
    <p>&copy; <?php echo date('Y'); ?> <?php echo h(SITE_NAME); ?>. All rights reserved.</p>
  </div>
</footer>

<?php
$__popupOn = get_setting('popup_enabled') === '1' && (trim(get_setting('popup_title')) !== '' || trim(get_setting('popup_message')) !== '');
if ($__popupOn):
    $__pDelay = max(0, (int) get_setting('popup_delay_seconds', 2));
    $__pFreq  = max(1, (int) get_setting('popup_frequency_hours', 24));
    $__pImg   = get_setting('popup_image');
    $__pBtnText = trim(get_setting('popup_button_text'));
    $__pBtnUrl  = trim(get_setting('popup_button_url'));
?>
<div id="m3dgPopupOverlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:9999;align-items:center;justify-content:center;padding:20px;">
  <div style="background:var(--card,#151f38);border:1px solid var(--border,#27324a);border-radius:16px;max-width:420px;width:100%;padding:28px;position:relative;text-align:center;">
    <button id="m3dgPopupClose" style="position:absolute;top:10px;right:14px;background:none;border:none;color:var(--muted,#94a3b8);font-size:22px;cursor:pointer;line-height:1;">&times;</button>
    <?php if ($__pImg): ?><img src="<?php echo h($__pImg); ?>" style="max-width:100%;border-radius:10px;margin-bottom:16px;"><?php endif; ?>
    <?php if (get_setting('popup_title')): ?><h2 style="margin:0 0 10px;"><?php echo h(get_setting('popup_title')); ?></h2><?php endif; ?>
    <?php if (get_setting('popup_message')): ?><p style="color:var(--muted,#94a3b8);margin-bottom:20px;"><?php echo nl2br(h(get_setting('popup_message'))); ?></p><?php endif; ?>
    <?php if ($__pBtnText && $__pBtnUrl): ?>
      <a href="<?php echo h((strpos($__pBtnUrl,'http')===0) ? $__pBtnUrl : SITE_URL . $__pBtnUrl); ?>" class="btn" id="m3dgPopupBtn"><?php echo h($__pBtnText); ?></a>
    <?php endif; ?>
  </div>
</div>
<script>
(function(){
  function getCookie(name){
    var v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
    return v ? v[2] : null;
  }
  function setCookie(name, value, hours){
    var d = new Date(); d.setTime(d.getTime() + hours*60*60*1000);
    document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/';
  }
  if (getCookie('m3dg_popup_seen')) return;

  setTimeout(function(){
    var overlay = document.getElementById('m3dgPopupOverlay');
    if (!overlay) return;
    overlay.style.display = 'flex';
    function dismiss(){
      overlay.style.display = 'none';
      setCookie('m3dg_popup_seen', '1', <?php echo (int)$__pFreq; ?>);
    }
    document.getElementById('m3dgPopupClose').addEventListener('click', dismiss);
    overlay.addEventListener('click', function(e){ if (e.target === overlay) dismiss(); });
    var btn = document.getElementById('m3dgPopupBtn');
    if (btn) btn.addEventListener('click', dismiss);
  }, <?php echo (int)$__pDelay * 1000; ?>);
})();
</script>
<?php endif; ?>
</body>
</html>
