<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

require_login();
$user = current_user();
check_and_expire_user($user);

$pwdErrors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    csrf_check();
    $newPwd = $_POST['new_pwd'] ?? '';
    $confPwd = $_POST['conf_pwd'] ?? '';
    if (strlen($newPwd) < 6) {
        $pwdErrors[] = 'New password must be at least 6 characters.';
    } elseif ($newPwd !== $confPwd) {
        $pwdErrors[] = 'Passwords do not match.';
    } else {
        db()->prepare("UPDATE users SET password_hash=? WHERE id=?")
            ->execute([password_hash($newPwd, PASSWORD_DEFAULT), $user['id']]);
        flash('Password updated successfully.');
        redirect('/dashboard.php');
    }
}

$daysLeft  = plan_days_left($user);
$renewDays = (int) get_setting('renew_days_before', 5);
$planCoins      = (int)($user['plan_coins'] ?? 0);
$purchasedCoins = (int)($user['tripo_coins'] ?? 0);

$pageTitle = 'My Dashboard';
include __DIR__ . '/includes/header.php';
?>
<h1>Welcome, <?php echo h($user['name']); ?></h1>

<div class="stat-row">
  <div class="stat-box"><div class="num"><?php echo h($user['plan_name'] ?: 'Free'); ?></div><div class="lbl">Current Plan</div></div>
  <div class="stat-box"><div class="num"><?php echo $daysLeft >= 0 ? $daysLeft . 'd' : 'Expired'; ?></div><div class="lbl">Days Remaining</div></div>
  <div class="stat-box" style="background:linear-gradient(135deg,#3b82f622,#60a5fa22);border:1px solid #3b82f6;">
    <div class="num" style="color:#60a5fa;">🪙 <?php echo $planCoins; ?></div>
    <div class="lbl">Plan Coins (monthly)</div>
  </div>
  <div class="stat-box" style="background:linear-gradient(135deg,#f59e0b22,#fbbf2422);border:1px solid #f59e0b;">
    <div class="num" style="color:#fbbf24;">🪙 <?php echo $purchasedCoins; ?></div>
    <div class="lbl">Purchased Coins (lifetime)</div>
  </div>
</div>

<?php if ($daysLeft >= 0 && $daysLeft <= $renewDays): ?>
  <div class="flash flash-error">Your plan expires in <?php echo $daysLeft; ?> day(s). <a href="<?php echo SITE_URL; ?>/membership.php">Renew now</a> to avoid interruption.</div>
<?php endif; ?>

<div class="card">
  <h3>Manage Membership</h3>
  <p>Plan expiry date: <strong><?php echo h($user['plan_expiry']); ?></strong></p>
  <a href="<?php echo SITE_URL; ?>/membership.php" class="btn">View / Upgrade Plans</a>
  &nbsp;
  <a href="<?php echo SITE_URL; ?>/designer.php" class="btn btn-outline">Open 3D Designer</a>
</div>

<div class="card" style="max-width:420px;">
  <h3>Change Password</h3>
  <?php foreach ($pwdErrors as $e): ?><div class="flash flash-error"><?php echo h($e); ?></div><?php endforeach; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>New Password</label>
    <input type="password" name="new_pwd" required>
    <label>Confirm New Password</label>
    <input type="password" name="conf_pwd" required>
    <button type="submit" name="change_password" class="btn btn-block">Update Password</button>
  </form>
</div>

<p><a href="<?php echo SITE_URL; ?>/logout.php" class="btn btn-danger btn-sm">Logout</a></p>

<?php include __DIR__ . '/includes/footer.php'; ?>
