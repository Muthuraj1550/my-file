<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$slug = $_GET['slug'] ?? '';
$stmt = db()->prepare("SELECT * FROM posts WHERE slug = ? AND status='published' LIMIT 1");
$stmt->execute([$slug]);
$post = $stmt->fetch();

if (!$post) {
    http_response_code(404);
    $pageTitle = 'Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="card"><h1>Post not found</h1><p><a href="' . SITE_URL . '/blog.php">Back to blog</a></p></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = $post['title'];
$metaTitle = $post['meta_title'] ?: null;
$metaDescription = $post['meta_description'] ?: $post['excerpt'];
$viewId = record_view('post', $post['id']);
include __DIR__ . '/includes/header.php';
?>
<article class="card">
  <h1><?php echo h($post['title']); ?></h1>
  <div class="post-meta"><?php echo date('d M Y', strtotime($post['created_at'])); ?> · 👁 <?php echo view_count('post', $post['id']); ?> views</div>
  <?php if ($post['featured_image']): ?>
    <img src="<?php echo h($post['featured_image']); ?>" style="max-width:100%;border-radius:10px;margin:16px 0;">
  <?php endif; ?>
  <div class="post-content"><?php echo $post['content']; /* trusted admin HTML content */ ?></div>
  <?php if (!empty($post['button_text']) && !empty($post['button_url'])): ?>
    <p style="margin-top:20px;">
      <a href="<?php echo (strpos($post['button_url'],'http')===0) ? h($post['button_url']) : SITE_URL . h($post['button_url']); ?>"
         class="btn" <?php echo $post['button_new_tab'] ? 'target="_blank" rel="noopener"' : ''; ?>><?php echo h($post['button_text']); ?></a>
    </p>
  <?php endif; ?>
</article>
<p><a href="<?php echo SITE_URL; ?>/blog.php">← Back to blog</a></p>
<script>
(function(){
  var viewId = <?php echo (int)$viewId; ?>;
  var start = Date.now();
  function sendDuration(){
    var seconds = Math.round((Date.now() - start) / 1000);
    var payload = JSON.stringify({ view_id: viewId, type: 'post', seconds: seconds });
    if (navigator.sendBeacon) {
      navigator.sendBeacon('<?php echo SITE_URL; ?>/api/track-view.php', new Blob([payload], {type:'application/json'}));
    }
  }
  window.addEventListener('pagehide', sendDuration);
  document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') sendDuration(); });
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
