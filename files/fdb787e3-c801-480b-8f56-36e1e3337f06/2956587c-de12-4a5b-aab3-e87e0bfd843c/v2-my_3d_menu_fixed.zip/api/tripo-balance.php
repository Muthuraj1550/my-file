<?php
// api/tripo-balance.php
// Returns the user's Tripo AI coin balance split into two buckets:
//   plan_coins       — monthly membership coins (reset on every plan
//                      activation/renewal, ALWAYS spent first)
//   purchased_coins  — coins bought à la carte (lifetime, never expire)
// Actions:
//   ?action=check → { plan_coins, purchased_coins, total, cost_per_generation, allowed, logged_in }
//   ?action=debit → deducts cost_per_generation coins (plan first, then purchased)
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$user = current_user();
if ($user) check_and_expire_user($user);

$pdo = db();
$costRow = $pdo->query("SELECT setting_value FROM settings WHERE setting_key='tripo_cost_per_generation' LIMIT 1")->fetch();
$cost = $costRow ? max(1, (int)$costRow['setting_value']) : 10;

$action = $_GET['action'] ?? 'check';

if (!$user) {
    echo json_encode([
        'logged_in'           => false,
        'plan_coins'          => 0,
        'purchased_coins'     => 0,
        'coins'               => 0, // legacy alias = total
        'total'               => 0,
        'cost_per_generation' => $cost,
        'allowed'             => false,
        'reason'              => 'login_required',
    ]);
    exit;
}

$planCoins      = (int)($user['plan_coins'] ?? 0);
$purchasedCoins = (int)($user['tripo_coins'] ?? 0);
$total          = $planCoins + $purchasedCoins;

if ($action === 'debit') {
    // Coin charging is admin-configurable (see admin/settings.php > Tripo AI Coins):
    //   mode = 'markup' (default) → caller (designer) passes the actual Tripo
    //          credits spent on this generation via ?spent=N (or JSON {spent:N}
    //          in POST body); we add the admin-configured markup on top, so the
    //          user is charged (tripo_spent + markup). Falls back to the flat
    //          "cost_per_generation" setting when no spend info is available.
    //   mode = 'fixed' → always charge the flat "cost_per_generation" amount,
    //          regardless of what Tripo actually billed for the task.
    $chargeMode = get_setting('tripo_coin_charge_mode', 'markup');
    $markup     = max(0, (int)get_setting('tripo_coin_markup', 5));

    $spentRaw = null;
    if (isset($_GET['spent']))  $spentRaw = $_GET['spent'];
    if (isset($_POST['spent'])) $spentRaw = $_POST['spent'];
    $rawBody = file_get_contents('php://input');
    if ($rawBody) {
        $json = json_decode($rawBody, true);
        if (is_array($json) && isset($json['spent'])) $spentRaw = $json['spent'];
    }
    $spent = is_numeric($spentRaw) ? max(0, (int)$spentRaw) : 0;

    if ($chargeMode === 'fixed') {
        $charge = $cost;
    } else {
        $charge = $spent > 0 ? ($spent + $markup) : $cost;
    }
    $charge = max(1, (int)$charge);

    if ($total < $charge) {
        http_response_code(402);
        echo json_encode([
            'allowed'             => false,
            'plan_coins'          => $planCoins,
            'purchased_coins'     => $purchasedCoins,
            'coins'               => $total,
            'total'               => $total,
            'cost_per_generation' => $cost,
            'charged'             => $charge,
            'tripo_spent'         => $spent,
            'markup'              => $markup,
            'reason'              => 'insufficient_coins',
        ]);
        exit;
    }
    // Spend plan_coins first, then tripo_coins (purchased/lifetime).
    $fromPlan      = min($planCoins, $charge);
    $fromPurchased = $charge - $fromPlan;

    $pdo->beginTransaction();
    try {
        if ($fromPlan > 0) {
            $s = $pdo->prepare("UPDATE users SET plan_coins = plan_coins - :c WHERE id=:id AND plan_coins >= :c2");
            $s->execute([':c'=>$fromPlan, ':c2'=>$fromPlan, ':id'=>$user['id']]);
        }
        if ($fromPurchased > 0) {
            $s = $pdo->prepare("UPDATE users SET tripo_coins = tripo_coins - :c WHERE id=:id AND tripo_coins >= :c2");
            $s->execute([':c'=>$fromPurchased, ':c2'=>$fromPurchased, ':id'=>$user['id']]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['allowed'=>false, 'error'=>'db_error']);
        exit;
    }
    $planCoins      -= $fromPlan;
    $purchasedCoins -= $fromPurchased;
    $total = $planCoins + $purchasedCoins;
    echo json_encode([
        'allowed'             => true,
        'plan_coins'          => $planCoins,
        'purchased_coins'     => $purchasedCoins,
        'coins'               => $total,
        'total'               => $total,
        'cost_per_generation' => $cost,
        'charged'             => $charge,
        'tripo_spent'         => $spent,
        'markup'              => $markup,
    ]);
    exit;
}


// default: check
echo json_encode([
    'logged_in'           => true,
    'plan_coins'          => $planCoins,
    'purchased_coins'     => $purchasedCoins,
    'coins'               => $total,     // legacy alias
    'total'               => $total,
    'cost_per_generation' => $cost,
    'allowed'             => $total >= $cost,
]);
