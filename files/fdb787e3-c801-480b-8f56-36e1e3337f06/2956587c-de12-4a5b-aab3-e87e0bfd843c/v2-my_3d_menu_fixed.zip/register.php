<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) redirect('/dashboard.php');

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name  = trim($_POST['name'] ?? '');
    $email = trim(strtolower($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $addr  = trim($_POST['address'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';

    if ($name === '') $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($pass) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($pass !== $pass2) $errors[] = 'Passwords do not match.';

    if (!$errors) {
        $stmt = db()->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'An account with this email already exists. Please login instead.';
        }
    }

    if (!$errors) {
        $free = get_plan_by_name('Free');
        $expiry = date('Y-m-d', strtotime('+100 years'));
        $stmt = db()->prepare("INSERT INTO users (name, email, phone, address, password_hash, role, plan_id, plan_name, plan_expiry)
                                VALUES (?,?,?,?,?,'member',?,?,?)");
        $stmt->execute([
            $name, $email, $phone, $addr,
            password_hash($pass, PASSWORD_DEFAULT),
            $free ? $free['id'] : null,
            'Free',
            $expiry,
        ]);
        $uid = db()->lastInsertId();
        log_user_in($uid);
        flash('Welcome to ' . SITE_NAME . '! Your free account is ready.');
        redirect('/membership.php');
    }
}

$pageTitle = 'Register';
include __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:480px;margin:30px auto;">
  <h1 style="text-align:center;">Create Your Account</h1>
  <?php foreach ($errors as $e): ?>
    <div class="flash flash-error"><?php echo h($e); ?></div>
  <?php endforeach; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Full Name</label>
    <input type="text" name="name" value="<?php echo h($_POST['name'] ?? ''); ?>" required>
    <label>Email Address</label>
    <input type="email" name="email" value="<?php echo h($_POST['email'] ?? ''); ?>" required>
    <label>Phone Number</label>
    <input type="tel" name="phone" value="<?php echo h($_POST['phone'] ?? ''); ?>" required>
    <label>Address <small style="color:#64748b;font-weight:normal;">(optional)</small></label>
    <input type="text" name="address" value="<?php echo h($_POST['address'] ?? ''); ?>" placeholder="Street, city, PIN (optional)">
    <label>Password</label>
    <input type="password" name="password" required>
    <label>Confirm Password</label>
    <input type="password" name="password2" required>
    <button type="submit" class="btn btn-block">Register &amp; Continue</button>
  </form>
  <p style="text-align:center;margin-top:16px;">Already have an account? <a href="<?php echo SITE_URL; ?>/login.php">Login here</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
