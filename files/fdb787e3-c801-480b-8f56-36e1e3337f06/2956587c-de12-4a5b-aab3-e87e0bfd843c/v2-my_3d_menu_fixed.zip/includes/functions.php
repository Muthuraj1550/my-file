<?php
require_once __DIR__ . '/db.php';

function get_setting($key, $default = '') {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query("SELECT setting_key, setting_value FROM settings") as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function set_setting($key, $value) {
    $stmt = db()->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
                            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    $stmt->execute([$key, $value]);
}

function slugify($text) {
    $text = trim($text);
    // Keep Tamil/unicode letters, convert spaces to hyphens
    $text = preg_replace('/\s+/u', '-', $text);
    $text = preg_replace('/[^\p{L}\p{N}\-]/u', '', $text);
    $text = preg_replace('/-+/', '-', $text);
    $text = trim($text, '-');
    return $text !== '' ? mb_strtolower($text) : 'item-' . time();
}

function unique_slug($table, $base_slug, $ignore_id = null) {
    $slug = $base_slug;
    $i = 1;
    while (true) {
        $sql = "SELECT id FROM $table WHERE slug = ?" . ($ignore_id ? " AND id != ?" : "");
        $params = $ignore_id ? [$slug, $ignore_id] : [$slug];
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        if (!$stmt->fetch()) break;
        $i++;
        $slug = $base_slug . '-' . $i;
    }
    return $slug;
}

function h($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header('Location: ' . (strpos($path, 'http') === 0 ? $path : SITE_URL . $path));
    exit;
}

function flash($msg, $type = 'success') {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function all_plans() {
    return db()->query("SELECT * FROM plans ORDER BY sort_order ASC, price ASC")->fetchAll();
}

function get_plan($id) {
    $stmt = db()->prepare("SELECT * FROM plans WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function get_plan_by_name($name) {
    $stmt = db()->prepare("SELECT * FROM plans WHERE plan_name = ?");
    $stmt->execute([$name]);
    return $stmt->fetch();
}

/**
 * Downgrade a single user to Free plan if their plan_expiry has passed.
 * Called on login and dashboard load (lightweight, no cron needed on
 * shared hosting, but you can also wire this to a real cron hitting
 * /cron/expire.php for site-wide sweeps).
 */
function check_and_expire_user(&$user) {
    if (!$user || empty($user['plan_expiry'])) return;
    if (strtotime($user['plan_expiry']) < strtotime(date('Y-m-d'))) {
        $free = get_plan_by_name('Free');
        $stmt = db()->prepare("UPDATE users SET plan_id = ?, plan_name = 'Free', plan_expiry = ? WHERE id = ?");
        $stmt->execute([$free ? $free['id'] : null, date('Y-m-d', strtotime('+100 years')), $user['id']]);
        $user['plan_name']   = 'Free';
        $user['plan_expiry'] = date('Y-m-d', strtotime('+100 years'));
    }
}

/** Today's AI usage count for a logged-in user */
function ai_usage_today($user_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM ai_usage_log WHERE user_id = ? AND DATE(used_at) = CURDATE()");
    $stmt->execute([$user_id]);
    return (int) $stmt->fetch()['c'];
}

/** Today's AI usage count for an anonymous guest (tracked by cookie id) */
function ai_usage_today_guest($guest_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM ai_usage_log WHERE guest_id = ? AND user_id IS NULL AND DATE(used_at) = CURDATE()");
    $stmt->execute([$guest_id]);
    return (int) $stmt->fetch()['c'];
}

/** Daily AI limit for guests (not logged in), configurable in Admin > Settings */
function ai_daily_limit_guest() {
    return (int) get_setting('guest_ai_daily_limit', 2);
}

/** Log one AI generation - user_id if logged in, else guest_id */
function log_ai_usage($user_id, $guest_id, $prompt) {
    $stmt = db()->prepare("INSERT INTO ai_usage_log (user_id, guest_id, prompt, ip_address) VALUES (?,?,?,?)");
    $stmt->execute([$user_id ?: null, $user_id ? null : $guest_id, mb_substr(trim($prompt), 0, 500), $_SERVER['REMOTE_ADDR'] ?? '']);
}

/** Effective daily AI limit for a user (per-user override wins, else plan limit) */
function ai_daily_limit_for($user) {
    if (!empty($user['ai_limit_override'])) return (int) $user['ai_limit_override'];
    $plan = get_plan_by_name($user['plan_name']);
    return $plan ? (int) $plan['ai_daily_limit'] : 3;
}

function is_premium_designer_user($user) {
    if (!$user) return false;
    $plan = get_plan_by_name($user['plan_name']);
    return $plan && (int)$plan['premium_designer'] === 1 && has_active_plan($user);
}

/* ---------------------------------------------------------
 * Cloud Project Save + Recovery (login-based, capped at 10MB/user)
 * --------------------------------------------------------- */

const CLOUD_PROJECT_STORAGE_CAP_BYTES = 10 * 1024 * 1024; // 10 MB total per user
const CLOUD_PROJECT_AUTO_SLOT = '__auto__';

/** How many EXTRA named "Save As" slots (beyond the always-on auto-save) this user's plan allows. */
function get_user_named_slot_limit($user) {
    if (!$user) return 0;
    if (!has_active_plan($user)) return 0;
    $plan = get_plan_by_name($user['plan_name']);
    return $plan ? (int)($plan['project_slots'] ?? 0) : 0;
}

/** Whether the saved_projects table (migration-cloud-projects.sql) has been set up yet. */
function cloud_projects_table_ready() {
    static $ready = null;
    if ($ready === null) {
        try {
            db()->query("SELECT 1 FROM saved_projects LIMIT 1");
            $ready = true;
        } catch (Exception $e) {
            $ready = false;
        }
    }
    return $ready;
}

/* ---------------------------------------------------------
 * Analytics: post/page views + time spent
 * --------------------------------------------------------- */

/**
 * Classify an HTTP Referer URL into a human-friendly traffic source bucket,
 * e.g. 'Google Search', 'YouTube', 'Facebook / Instagram', 'Direct / App',
 * or the referring domain itself for anything else.
 */
function classify_referrer($refererUrl) {
    $refererUrl = trim((string)$refererUrl);
    if ($refererUrl === '') return 'Direct / App';
    $host = parse_url($refererUrl, PHP_URL_HOST);
    if (!$host) return 'Direct / App';
    $host = strtolower(preg_replace('/^www\./', '', $host));

    // Own site linking to itself shouldn't count as external traffic.
    $siteHost = strtolower(preg_replace('/^www\./', '', (string)parse_url(SITE_URL, PHP_URL_HOST)));
    if ($siteHost && $host === $siteHost) return 'Internal (same site)';

    $map = [
        'google.'      => 'Google Search',
        'bing.'        => 'Bing Search',
        'yahoo.'       => 'Yahoo Search',
        'duckduckgo.'  => 'DuckDuckGo Search',
        'youtube.'     => 'YouTube',
        'youtu.be'     => 'YouTube',
        'facebook.'    => 'Facebook / Instagram',
        'instagram.'   => 'Facebook / Instagram',
        'fb.'          => 'Facebook / Instagram',
        'wa.me'        => 'WhatsApp',
        'whatsapp.'    => 'WhatsApp',
        'twitter.'     => 'Twitter / X',
        'x.com'        => 'Twitter / X',
        't.co'         => 'Twitter / X',
        'linkedin.'    => 'LinkedIn',
        'pinterest.'   => 'Pinterest',
        'telegram.'    => 'Telegram',
        't.me'         => 'Telegram',
    ];
    foreach ($map as $needle => $label) {
        if (strpos($host, $needle) !== false) return $label;
    }
    return 'Other site: ' . $host;
}

/** Record a fresh view for a post/page/tool/etc and return the new row id (used to later update duration). */
function record_view($type, $content_id) {
    // Don't count the admin's own visits (logged into the front-end site as
    // an admin account) towards visitor/view/analytics numbers.
    if (function_exists('is_admin') && is_admin()) {
        return 0;
    }
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $source  = classify_referrer($referer);
    try {
        $stmt = db()->prepare("INSERT INTO content_views (content_type, content_id, ip_address, referrer_url, referrer_source) VALUES (?,?,?,?,?)");
        $stmt->execute([$type, $content_id, $_SERVER['REMOTE_ADDR'] ?? '', mb_substr($referer, 0, 500), $source]);
    } catch (Exception $e) {
        // referrer_url/referrer_source columns not migrated yet on this install -
        // fall back to the original columns so tracking still works.
        $stmt = db()->prepare("INSERT INTO content_views (content_type, content_id, ip_address) VALUES (?,?,?)");
        $stmt->execute([$type, $content_id, $_SERVER['REMOTE_ADDR'] ?? '']);
    }
    return db()->lastInsertId();
}

/** Record one click on a Tool Lab card (content_type='tool_click', content_id=tools.id). */
function record_tool_click($tool_id) {
    return record_view('tool_click', (int)$tool_id);
}

/** Click counts per tool: [tool_id => clicks] */
function tool_click_counts() {
    $stmt = db()->query("SELECT content_id, COUNT(*) c FROM content_views WHERE content_type='tool_click' GROUP BY content_id");
    $map = [];
    foreach ($stmt->fetchAll() as $r) $map[(int)$r['content_id']] = (int)$r['c'];
    return $map;
}

/** Total Tool Lab clicks across all tools */
function total_tool_clicks() {
    return (int) db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='tool_click'")->fetch()['c'];
}

/**
 * Traffic-source breakdown across all page views (post/page/designer/tool
 * page loads), grouped by classified source, most recent $days days
 * (0 = all time). Used by Admin > Analytics.
 */
function traffic_source_breakdown($days = 30) {
    if (!content_views_referrer_ready()) return [];
    $sql = "SELECT COALESCE(NULLIF(referrer_source,''),'Direct / App') AS source, COUNT(*) c
            FROM content_views
            WHERE content_type <> 'tool_click'";
    if ($days > 0) $sql .= " AND created_at >= NOW() - INTERVAL " . (int)$days . " DAY";
    $sql .= " GROUP BY source ORDER BY c DESC";
    return db()->query($sql)->fetchAll();
}

/** Whether content_views.referrer_source (migration-traffic-source.sql) has been added yet. */
function content_views_referrer_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT referrer_source FROM content_views LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Update how many seconds a visitor stayed on the page (called via sendBeacon on unload). */
function update_view_duration($view_id, $type, $seconds) {
    $seconds = max(0, min(3600, (int)$seconds)); // sanity clamp: 0 to 1 hour
    $stmt = db()->prepare("UPDATE content_views SET duration_seconds = ? WHERE id = ? AND content_type = ?");
    $stmt->execute([$seconds, (int)$view_id, $type]);
}

/** Total view count for one piece of content */
function view_count($type, $content_id) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM content_views WHERE content_type=? AND content_id=?");
    $stmt->execute([$type, $content_id]);
    return (int) $stmt->fetch()['c'];
}

/** Average minutes spent for one piece of content */
function avg_minutes($type, $content_id) {
    $stmt = db()->prepare("SELECT AVG(duration_seconds) a FROM content_views WHERE content_type=? AND content_id=? AND duration_seconds > 0");
    $stmt->execute([$type, $content_id]);
    $a = $stmt->fetch()['a'];
    return $a ? round($a / 60, 1) : 0;
}

/** Top posts or pages ranked by view count, with total minutes and avg minutes */
function top_content($type, $limit = 10) {
    $table = $type === 'post' ? 'posts' : 'pages';
    $sql = "SELECT c.title, c.slug,
                   COUNT(v.id) AS views,
                   COALESCE(SUM(v.duration_seconds), 0) AS total_seconds,
                   COALESCE(AVG(NULLIF(v.duration_seconds,0)), 0) AS avg_seconds
            FROM $table c
            LEFT JOIN content_views v ON v.content_type = ? AND v.content_id = c.id
            GROUP BY c.id
            ORDER BY views DESC, c.created_at DESC
            LIMIT " . (int)$limit;
    $stmt = db()->prepare($sql);
    $stmt->execute([$type]);
    return $stmt->fetchAll();
}

/** View counts map [content_id => views] for a whole table, used in admin list pages */
function view_counts_map($type) {
    $stmt = db()->prepare("SELECT content_id, COUNT(*) c FROM content_views WHERE content_type=? GROUP BY content_id");
    $stmt->execute([$type]);
    $map = [];
    foreach ($stmt->fetchAll() as $r) $map[$r['content_id']] = (int)$r['c'];
    return $map;
}

/** Aggregate usage stats for the 3D Designer page (content_id is always 0 - single page, no rows) */
function designer_analytics() {
    $total = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer'")->fetch()['c'];
    $last7 = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer' AND created_at >= NOW() - INTERVAL 7 DAY")->fetch()['c'];
    $today = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer' AND DATE(created_at)=CURDATE()")->fetch()['c'];
    $yesterday = db()->query("SELECT COUNT(*) c FROM content_views WHERE content_type='designer' AND DATE(created_at)=DATE_SUB(CURDATE(), INTERVAL 1 DAY)")->fetch()['c'];
    $avgSec = db()->query("SELECT AVG(NULLIF(duration_seconds,0)) a FROM content_views WHERE content_type='designer'")->fetch()['a'];
    $totalSec = db()->query("SELECT COALESCE(SUM(duration_seconds),0) s FROM content_views WHERE content_type='designer'")->fetch()['s'];

    $todayTime = db()->query("SELECT COALESCE(SUM(duration_seconds),0) s, AVG(NULLIF(duration_seconds,0)) a
                               FROM content_views WHERE content_type='designer' AND DATE(created_at)=CURDATE()")->fetch();
    $yesterdayTime = db()->query("SELECT COALESCE(SUM(duration_seconds),0) s, AVG(NULLIF(duration_seconds,0)) a
                               FROM content_views WHERE content_type='designer' AND DATE(created_at)=DATE_SUB(CURDATE(), INTERVAL 1 DAY)")->fetch();

    return [
        'total_views'     => (int)$total,
        'views_7d'        => (int)$last7,
        'views_today'     => (int)$today,
        'views_yesterday' => (int)$yesterday,
        'avg_seconds'     => $avgSec ? (float)$avgSec : 0,
        'total_seconds'   => (int)$totalSec,
        'total_seconds_today'     => (int)$todayTime['s'],
        'avg_seconds_today'       => $todayTime['a'] ? (float)$todayTime['a'] : 0,
        'total_seconds_yesterday' => (int)$yesterdayTime['s'],
        'avg_seconds_yesterday'   => $yesterdayTime['a'] ? (float)$yesterdayTime['a'] : 0,
    ];
}

/** Whether the posts.is_pinned column (migration-post-pin.sql) has been added yet. */
function posts_pin_column_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT is_pinned FROM posts LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/* ---------------------------------------------------------
 * Media / File Manager (admin/filemanager.php) - shared uploads/ folder
 * --------------------------------------------------------- */

/** File extensions the media manager will never allow (mirrors uploads/.htaccess deny list, plus other script types). */
function media_blocked_extensions() {
    return ['php','phtml','php3','php4','php5','php7','phar','pht','cgi','pl','py','exe','sh','asp','aspx','jsp','htaccess'];
}

/** Human-readable file size, e.g. "482 KB" / "1.3 MB". */
function format_file_size($bytes) {
    $bytes = (float)$bytes;
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 1) . ' GB';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024)       return round($bytes / 1024, 1) . ' KB';
    return $bytes . ' B';
}

/* ---------------------------------------------------------
 * Menu items (home page top navigation, admin-editable)
 * --------------------------------------------------------- */

function active_menu_items() {
    return db()->query("SELECT * FROM menu_items WHERE is_active = 1 ORDER BY sort_order ASC, id ASC")->fetchAll();
}

function all_menu_items() {
    return db()->query("SELECT * FROM menu_items ORDER BY sort_order ASC, id ASC")->fetchAll();
}

function get_menu_item($id) {
    $stmt = db()->prepare("SELECT * FROM menu_items WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/* ---------------------------------------------------------
 * Footer pages (migration-footer-pages.sql)
 * --------------------------------------------------------- */

/** Whether the pages.show_in_footer column has been added yet. */
function pages_footer_column_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT show_in_footer FROM pages LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/** Published pages picked to appear as links in the site footer. */
function footer_pages() {
    if (!pages_footer_column_ready()) return [];
    return db()->query("SELECT title, slug FROM pages WHERE status='published' AND show_in_footer=1 ORDER BY title ASC")->fetchAll();
}

/* ---------------------------------------------------------
 * Custom Form Builder (migration-custom-forms.sql)
 * Fields are stored as JSON: [{type,label,placeholder,options,required}, ...]
 * Supported types: text, email, phone, textarea, dropdown
 * --------------------------------------------------------- */

/** Whether the forms/form_submissions tables have been created yet. */
function forms_tables_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT id FROM forms LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

function all_forms() {
    if (!forms_tables_ready()) return [];
    return db()->query("SELECT * FROM forms ORDER BY created_at DESC")->fetchAll();
}

function get_form($id) {
    if (!forms_tables_ready()) return null;
    $stmt = db()->prepare("SELECT * FROM forms WHERE id=?");
    $stmt->execute([(int)$id]);
    $f = $stmt->fetch();
    if ($f) $f['fields'] = json_decode($f['fields_json'], true) ?: [];
    return $f ?: null;
}

/** Renders an HTML <form> for the given form_id, posting to api/form-submit.php */
function render_form_html($formId) {
    $form = get_form($formId);
    if (!$form) return '<p style="color:var(--muted);">(Form not found)</p>';

    $flashKey = 'form_ok_' . $form['id'];
    $justSubmitted = !empty($_GET[$flashKey]);

    $html = '<form class="custom-form" method="post" action="' . SITE_URL . '/api/form-submit.php">';
    $html .= '<input type="hidden" name="form_id" value="' . (int)$form['id'] . '">';
    $html .= '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
    $html .= '<input type="hidden" name="redirect_to" value="' . h($_SERVER['REQUEST_URI'] ?? '/') . '">';

    if ($justSubmitted) {
        $html .= '<div class="flash flash-success">' . h($form['success_message']) . '</div>';
    }

    foreach ($form['fields'] as $i => $f) {
        $name = 'f_' . $i;
        $label = h($f['label'] ?? '');
        $required = !empty($f['required']) ? 'required' : '';
        $placeholder = h($f['placeholder'] ?? '');
        $html .= '<label>' . $label . ($required ? ' *' : '') . '</label>';
        switch ($f['type'] ?? 'text') {
            case 'email':
                $html .= '<input type="email" name="' . $name . '" placeholder="' . $placeholder . '" ' . $required . '>';
                break;
            case 'phone':
                $html .= '<input type="tel" name="' . $name . '" placeholder="' . $placeholder . '" ' . $required . '>';
                break;
            case 'textarea':
                $html .= '<textarea name="' . $name . '" placeholder="' . $placeholder . '" ' . $required . '></textarea>';
                break;
            case 'dropdown':
                $html .= '<select name="' . $name . '" ' . $required . '>';
                $html .= '<option value="">-- Select --</option>';
                foreach (($f['options'] ?? []) as $opt) {
                    $html .= '<option value="' . h($opt) . '">' . h($opt) . '</option>';
                }
                $html .= '</select>';
                break;
            default:
                $html .= '<input type="text" name="' . $name . '" placeholder="' . $placeholder . '" ' . $required . '>';
        }
    }
    $html .= '<button type="submit" class="btn">' . h($form['submit_text']) . '</button>';
    $html .= '</form>';
    return $html;
}

/**
 * Replaces [form id=X] shortcodes inside trusted admin HTML content with a rendered <form>.
 * Used when printing pages.content / posts.content on the public site.
 */
function render_shortcodes($content) {
    if (strpos((string)$content, '[form') === false) return $content;
    return preg_replace_callback('/\[form\s+id=(\d+)\s*\]/i', function ($m) {
        return render_form_html((int)$m[1]);
    }, $content);
}
