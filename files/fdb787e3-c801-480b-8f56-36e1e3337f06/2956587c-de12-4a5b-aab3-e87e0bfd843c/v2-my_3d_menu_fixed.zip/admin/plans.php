<?php
$adminTitle = 'Membership Plans';
require_once __DIR__ . '/_layout_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_plan'])) {
    csrf_check();
    $name = trim($_POST['plan_name']);
    $data = [
        'plan_name'       => $name,
        'slug'            => unique_slug('plans', slugify($name), $_POST['edit_id'] ?: null),
        'price'           => (float)$_POST['price'],
        'validity_days'   => (int)$_POST['validity_days'],
        // ai_daily_limit is legacy; the UI no longer exposes it. Force unlimited
        // so old checks in api/ai-usage.php never block a member — Tripo coins
        // are now the only spend gate.
        'ai_daily_limit'  => 99999,
        'premium_designer'=> isset($_POST['premium_designer']) ? 1 : 0,
        'plan_bonus_coins'=> (int)($_POST['plan_bonus_coins'] ?? 0),
        'project_slots'   => (int)($_POST['project_slots'] ?? 0),
        'sort_order'      => (int)$_POST['sort_order'],
    ];
    if (!empty($_POST['edit_id'])) {
        db()->prepare("UPDATE plans SET plan_name=?, slug=?, price=?, validity_days=?, ai_daily_limit=?, premium_designer=?, plan_bonus_coins=?, project_slots=?, sort_order=? WHERE id=?")
            ->execute([...array_values($data), (int)$_POST['edit_id']]);
    } else {
        db()->prepare("INSERT INTO plans (plan_name, slug, price, validity_days, ai_daily_limit, premium_designer, plan_bonus_coins, project_slots, sort_order) VALUES (?,?,?,?,?,?,?,?,?)")
            ->execute(array_values($data));
    }
    flash('Plan saved.');
    redirect('/admin/plans.php');
}

if (isset($_GET['del'])) {
    db()->prepare("DELETE FROM plans WHERE id=?")->execute([(int)$_GET['del']]);
    flash('Plan deleted.');
    redirect('/admin/plans.php');
}

$editPlan = null;
if (!empty($_GET['edit'])) {
    $editPlan = get_plan((int)$_GET['edit']);
}
$plans = all_plans();
?>
<div class="card">
  <h3><?php echo $editPlan ? 'Edit Plan' : 'Add New Plan'; ?></h3>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="edit_id" value="<?php echo $editPlan ? (int)$editPlan['id'] : ''; ?>">
    <label>Plan Name</label>
    <input type="text" name="plan_name" value="<?php echo h($editPlan['plan_name'] ?? ''); ?>" required>
    <label>Price (₹, 0 = free plan)</label>
    <input type="number" step="0.01" name="price" value="<?php echo h($editPlan['price'] ?? '0'); ?>" required>
    <label>Validity (days)</label>
    <input type="number" name="validity_days" value="<?php echo h($editPlan['validity_days'] ?? '30'); ?>" required>
    <input type="hidden" name="ai_daily_limit" value="99999">
    <label>Cloud Project Save Slots
      <small style="color:#64748b;font-weight:normal;">(0 = no cloud save — only local auto-recover · 1+ = enable cloud save (works for Free plan too, set 1 for auto-recover only) · larger = more "Save As" projects)</small>
    </label>
    <input type="number" min="0" name="project_slots" value="<?php echo h($editPlan['project_slots'] ?? '0'); ?>">
    <label>Sort Order (lower = shown first)</label>
    <input type="number" name="sort_order" value="<?php echo h($editPlan['sort_order'] ?? '0'); ?>">
    <label>Monthly Tripo AI Coins (granted / reset on every plan activation & renewal)</label>
    <input type="number" min="0" name="plan_bonus_coins" value="<?php echo h($editPlan['plan_bonus_coins'] ?? '0'); ?>">
    <label><input type="checkbox" name="premium_designer" style="width:auto;display:inline-block;" <?php echo !empty($editPlan['premium_designer']) ? 'checked' : ''; ?>> Unlock Premium Designer Templates</label>
    <button type="submit" name="save_plan" class="btn">Save Plan</button>
    <?php if ($editPlan): ?><a href="plans.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <h3>Existing Plans</h3>
  <table>
    <thead><tr><th>Name</th><th>Price</th><th>Validity</th><th>Cloud Slots</th><th>Monthly Coins</th><th>Premium</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($plans as $p): ?>
      <tr>
        <td><?php echo h($p['plan_name']); ?></td>
        <td>₹<?php echo number_format($p['price'],2); ?></td>
        <td><?php echo (int)$p['validity_days']; ?> days</td>
        <td><?php echo (int)($p['project_slots'] ?? 0); ?></td>
        <td>🪙 <?php echo (int)($p['plan_bonus_coins'] ?? 0); ?></td>
        <td><?php echo $p['premium_designer'] ? '👑 Yes' : 'No'; ?></td>
        <td>
          <a href="?edit=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
          <a href="?del=<?php echo (int)$p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this plan? Existing members keep their current plan name but it will no longer be selectable.');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
