<?php
$adminTitle = 'Members';
require_once __DIR__ . '/_layout_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_member'])) {
    csrf_check();
    $mid = (int)$_POST['mid'];
    $stmt = db()->prepare("UPDATE users SET plan_name=?, plan_expiry=?, ai_limit_override=?, status=?, tripo_coins=?, plan_coins=? WHERE id=?");
    $stmt->execute([
        trim($_POST['plan_name']),
        $_POST['plan_expiry'] ?: null,
        $_POST['ai_limit_override'] !== '' ? (int)$_POST['ai_limit_override'] : null,
        $_POST['status'],
        (int)($_POST['tripo_coins'] ?? 0),
        (int)($_POST['plan_coins'] ?? 0),
        $mid,
    ]);
    flash('Member updated.');
    redirect('/admin/members.php');
}

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = db()->prepare("SELECT * FROM users WHERE role='member' AND (name LIKE ? OR email LIKE ?) ORDER BY created_at DESC LIMIT 200");
    $like = '%' . $search . '%';
    $stmt->execute([$like, $like]);
} else {
    $stmt = db()->query("SELECT * FROM users WHERE role='member' ORDER BY created_at DESC LIMIT 200");
}
$members = $stmt->fetchAll();
$allPlans = all_plans();
$totalMembersCount = (int) db()->query("SELECT COUNT(*) c FROM users WHERE role='member'")->fetch()['c'];
?>
<p style="color:var(--muted);font-size:13px;margin:-6px 0 14px;">👥 <?php echo $totalMembersCount; ?> total members</p>
<form method="get" style="margin-bottom:16px;max-width:340px;">
  <input type="text" name="q" placeholder="Search by name or email" value="<?php echo h($search); ?>">
</form>

<div class="card">
  <table>
    <thead><tr><th>Name</th><th>Email</th><th>Plan</th><th>Expiry</th><th>Status</th><th>Plan Coins</th><th>Purchased Coins</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach ($members as $m): ?>
      <?php $active = $m['plan_expiry'] && strtotime($m['plan_expiry']) >= strtotime(date('Y-m-d')); ?>
      <tr>
        <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="mid" value="<?php echo (int)$m['id']; ?>">
        <td><?php echo h($m['name']); ?></td>
        <td><?php echo h($m['email']); ?><br><small style="color:var(--muted)"><?php echo h($m['phone']); ?></small></td>
        <td>
          <select name="plan_name" style="margin:0;min-width:130px;">
            <?php $hasMatch = false; ?>
            <?php foreach ($allPlans as $p): $sel = ($p['plan_name'] === $m['plan_name']); if ($sel) $hasMatch = true; ?>
              <option value="<?php echo h($p['plan_name']); ?>" <?php echo $sel ? 'selected' : ''; ?>><?php echo h($p['plan_name']); ?></option>
            <?php endforeach; ?>
            <?php if (!$hasMatch && $m['plan_name'] !== ''): ?>
              <option value="<?php echo h($m['plan_name']); ?>" selected><?php echo h($m['plan_name']); ?> (not in current plans)</option>
            <?php endif; ?>
          </select>
        </td>
        <td><input type="date" name="plan_expiry" value="<?php echo h($m['plan_expiry']); ?>" style="margin:0;"></td>
        <td>
          <select name="status" style="margin:0;">
            <option value="active" <?php echo $m['status']==='active'?'selected':''; ?>>Active</option>
            <option value="blocked" <?php echo $m['status']==='blocked'?'selected':''; ?>>Blocked</option>
          </select>
        </td>
        <td>
          <input type="number" min="0" name="plan_coins" value="<?php echo (int)($m['plan_coins'] ?? 0); ?>" style="margin:0;width:80px;" title="Monthly membership coins (reset on renewal, spent first)">
        </td>
        <td>
          <input type="number" min="0" name="tripo_coins" value="<?php echo (int)($m['tripo_coins'] ?? 0); ?>" style="margin:0;width:80px;" title="Purchased coins (lifetime, never expire)">
        </td>
        <td>
          <input type="hidden" name="ai_limit_override" value="<?php echo h($m['ai_limit_override']); ?>">
          <button type="submit" name="update_member" class="btn btn-sm">Save</button>
        </td>
        </form>
      </tr>
    <?php endforeach; ?>
    <?php if (!$members): ?><tr><td colspan="8">No members found.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
