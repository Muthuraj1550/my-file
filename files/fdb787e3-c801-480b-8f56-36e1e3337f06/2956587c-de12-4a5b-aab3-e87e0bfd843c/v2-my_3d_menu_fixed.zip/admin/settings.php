<?php
$adminTitle = 'Settings';
require_once __DIR__ . '/_layout_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    set_setting('cashfree_mode', $_POST['cashfree_mode'] === 'production' ? 'production' : 'sandbox');
    set_setting('cashfree_app_id', trim($_POST['cashfree_app_id']));
    set_setting('cashfree_secret_key', trim($_POST['cashfree_secret_key']));
    set_setting('cashfree_api_version', trim($_POST['cashfree_api_version']) ?: '2023-08-01');
    set_setting('renew_days_before', (int)$_POST['renew_days_before']);
    set_setting('gemini_api_key', trim($_POST['gemini_api_key']));
    set_setting('tripo_api_key', trim($_POST['tripo_api_key']));
    set_setting('tripo_cost_per_generation', max(1, (int)($_POST['tripo_cost_per_generation'] ?? 10)));
    set_setting('tripo_coin_charge_mode', ($_POST['tripo_coin_charge_mode'] ?? 'markup') === 'fixed' ? 'fixed' : 'markup');
    set_setting('tripo_coin_markup', max(0, (int)($_POST['tripo_coin_markup'] ?? 5)));
    set_setting('coin_price_inr', max(0.01, (float)($_POST['coin_price_inr'] ?? 1)));
    set_setting('coin_min_purchase', max(1, (int)($_POST['coin_min_purchase'] ?? 10)));
    set_setting('site_tagline', trim($_POST['site_tagline']));
    // Keep guests unrestricted — the daily AI-designs limit UI has been removed.
    set_setting('guest_ai_daily_limit', 99999);
    flash('Settings saved.');
    redirect('/admin/settings.php');
}
?>
<div class="card" style="max-width:640px;">
  <h3>Cashfree Payment Gateway</h3>
  <p style="color:var(--muted);font-size:13px;">
    Get your keys from the <a href="https://merchant.cashfree.com/" target="_blank">Cashfree Merchant Dashboard</a>
    → Developers → API Keys. Use the <strong>Test/Sandbox</strong> keys first, then switch mode to
    Production with your live keys when you're ready to accept real payments.
    Webhook URL to configure in Cashfree dashboard: <code><?php echo SITE_URL; ?>/payment-webhook.php</code>
  </p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Mode</label>
    <select name="cashfree_mode">
      <option value="sandbox" <?php echo get_setting('cashfree_mode')==='sandbox'?'selected':''; ?>>Sandbox (Test)</option>
      <option value="production" <?php echo get_setting('cashfree_mode')==='production'?'selected':''; ?>>Production (Live)</option>
    </select>
    <label>App ID (Client ID)</label>
    <input type="text" name="cashfree_app_id" value="<?php echo h(get_setting('cashfree_app_id')); ?>">
    <label>Secret Key (Client Secret)</label>
    <input type="text" name="cashfree_secret_key" value="<?php echo h(get_setting('cashfree_secret_key')); ?>">
    <label>API Version</label>
    <input type="text" name="cashfree_api_version" value="<?php echo h(get_setting('cashfree_api_version', '2023-08-01')); ?>">

    <h3 style="margin-top:30px;">AI Designer</h3>
    <label><strong>Tripo AI API Key</strong> (PRIMARY — text/image → 3D generation, from <a href="https://developers.tripo3d.ai/en/keys" target="_blank">developers.tripo3d.ai</a>)</label>
    <input type="text" name="tripo_api_key" value="<?php echo h(get_setting('tripo_api_key')); ?>" placeholder="sk-...">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Tripo AI-ஐ தான் 3D generation-க்கு use பண்றோம். இந்த key server-ல மட்டும் இருக்கும், browser-க்கு அனுப்பப்படாது.</p>
    <label style="margin-top:14px;">Gemini API Key <span style="color:#94a3b8;font-weight:normal;">(optional / legacy — Tripo AI use ஆவதால் இது required இல்ல)</span></label>
    <input type="text" name="gemini_api_key" value="<?php echo h(get_setting('gemini_api_key')); ?>" placeholder="AIza... (optional)">

    <h3 style="margin-top:30px;">Tripo AI Coins</h3>

    <div style="background:#0a0f1e;border:1px solid #f59e0b;border-radius:8px;padding:12px;margin-bottom:16px;">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
        <div>
          <div style="font-size:11px;color:#fbbf24;text-transform:uppercase;font-weight:bold;letter-spacing:1px;">Tripo API Account Balance</div>
          <div style="font-size:12px;color:var(--muted);margin-top:2px;">Tripo AI-ல் நம்முடைய API key-க்கு எவ்வளவு credits மீதி இருக்கு என்று செக் பண்ணலாம் (இது site users-க்கான coins இல்ல — Tripo account-ல் இருக்கும் actual balance).</div>
        </div>
        <button type="button" id="tripoAcctCheckBtn" onclick="checkTripoAccountBalance()" style="width:auto;background:linear-gradient(135deg,#f59e0b,#fbbf24);color:#111;font-weight:bold;padding:9px 16px;">Check Balance</button>
      </div>
      <div id="tripoAcctBalanceResult" style="margin-top:10px;font-size:13px;color:#e2e8f0;"></div>
    </div>

    <label>Coins per Tripo generation (fallback flat cost)</label>
    <input type="number" min="1" name="tripo_cost_per_generation" value="<?php echo h(get_setting('tripo_cost_per_generation', 10)); ?>">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Tripo spend info கிடைக்காத சூழலில் (அல்லது "Fixed" mode கீழே தேர்ந்தால்) இந்த coins தான் ஒரு generation-க்கு charge ஆகும்.</p>

    <label style="margin-top:14px;">Coin charging mode</label>
    <select name="tripo_coin_charge_mode" id="tripoChargeModeSel" onchange="toggleTripoChargeModeFields()">
      <option value="markup" <?php echo get_setting('tripo_coin_charge_mode','markup')==='markup'?'selected':''; ?>>Tripo actual spend + Markup (dynamic — recommended)</option>
      <option value="fixed" <?php echo get_setting('tripo_coin_charge_mode','markup')==='fixed'?'selected':''; ?>>Fixed total coins per generation (ignore actual Tripo spend)</option>
    </select>

    <div id="tripoMarkupFieldWrap">
      <label>Markup coins (added on top of actual Tripo credits spent)</label>
      <input type="number" min="0" name="tripo_coin_markup" value="<?php echo h(get_setting('tripo_coin_markup', 5)); ?>">
      <p style="color:var(--muted);font-size:12px;margin-top:-10px;">
        Example: ஒரு generation-க்கு Tripo actual-ஆ 20 credits spend ஆனா, user-க்கு (20 + இந்த markup) coins debit ஆகும்.
      </p>
    </div>
    <script>
      function toggleTripoChargeModeFields(){
        var mode = document.getElementById('tripoChargeModeSel').value;
        document.getElementById('tripoMarkupFieldWrap').style.display = (mode === 'markup') ? 'block' : 'none';
      }
      document.addEventListener('DOMContentLoaded', toggleTripoChargeModeFields);

      function checkTripoAccountBalance(){
        var btn = document.getElementById('tripoAcctCheckBtn');
        var out = document.getElementById('tripoAcctBalanceResult');
        btn.disabled = true; btn.textContent = 'Checking...';
        out.innerHTML = '<span style="color:var(--muted);">Tripo API-யை contact பண்றோம்...</span>';
        fetch('tripo-account-balance.php', { credentials: 'include' })
          .then(function(r){ return r.json(); })
          .then(function(d){
            if (d && d.ok) {
              out.innerHTML = '<strong style="color:#22c55e;">Balance: ' + d.balance + '</strong>'
                + (d.frozen ? ' &nbsp;|&nbsp; Frozen: ' + d.frozen : '')
                + '<div style="font-size:11px;color:var(--muted);margin-top:4px;">Source: ' + (d.source || '') + '</div>';
            } else {
              out.innerHTML = '<span style="color:#ef4444;">❌ ' + (d && (d.message || d.detail || d.error) || 'Balance check failed') + '</span>';
            }
          })
          .catch(function(e){ out.innerHTML = '<span style="color:#ef4444;">❌ Network error: ' + e.message + '</span>'; })
          .finally(function(){ btn.disabled = false; btn.textContent = 'Check Balance'; });
      }
    </script>

    <label style="margin-top:14px;">Price per coin (₹)</label>
    <input type="number" min="0.01" step="0.01" name="coin_price_inr" value="<?php echo h(get_setting('coin_price_inr', '1')); ?>">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Used on the membership page for the "Buy Coins" custom-amount box.</p>
    <label>Minimum coin purchase</label>
    <input type="number" min="1" name="coin_min_purchase" value="<?php echo h(get_setting('coin_min_purchase', '10')); ?>">

    <h3 style="margin-top:30px;">General</h3>
    <label>Site Tagline (shown on homepage)</label>
    <input type="text" name="site_tagline" value="<?php echo h(get_setting('site_tagline')); ?>">
    <label>Show Renew Reminder (days before expiry)</label>
    <input type="number" name="renew_days_before" value="<?php echo h(get_setting('renew_days_before', 5)); ?>">

    <button type="submit" class="btn">Save Settings</button>
  </form>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
