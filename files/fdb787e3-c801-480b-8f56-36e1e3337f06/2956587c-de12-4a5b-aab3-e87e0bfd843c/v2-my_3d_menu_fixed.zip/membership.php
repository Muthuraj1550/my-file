<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cashfree.php';

$user = current_user();
if ($user) check_and_expire_user($user);
$checkoutSessionId = null;
$checkoutError = null;

// Handle "buy this plan" click
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['buy_plan_id'])) {
    csrf_check();
    if (!$user) {
        redirect('/register.php');
    }
    $plan = get_plan((int)$_POST['buy_plan_id']);
    if (!$plan) {
        $checkoutError = 'Plan not found.';
    } elseif ((float)$plan['price'] <= 0) {
        // Free plan - activate instantly, no payment needed.
        // Reset monthly plan coins (not additive); purchased tripo_coins untouched.
        $expiry = date('Y-m-d', strtotime('+' . (int)$plan['validity_days'] . ' days'));
        $stmt = db()->prepare("UPDATE users SET plan_id=?, plan_name=?, plan_expiry=? WHERE id=?");
        $stmt->execute([$plan['id'], $plan['plan_name'], $expiry, $user['id']]);
        $bonus = (int)($plan['plan_bonus_coins'] ?? 0);
        db()->prepare("UPDATE users SET plan_coins = ? WHERE id=?")
            ->execute([$bonus, $user['id']]);
        flash('Plan activated: ' . $plan['plan_name'] . ($bonus > 0 ? ' (' . $bonus . ' 🪙 monthly coins)' : ''));
        redirect('/dashboard.php');
    } else {
        $orderId = 'M3DG' . $user['id'] . 'T' . time();
        $cfResp = cashfree_create_order($orderId, $plan['price'], $user);
        if (!empty($cfResp['error'])) {
            $checkoutError = 'Payment gateway error: ' . $cfResp['error'] . ' (Check Cashfree keys in Admin > Settings)';
        } elseif (!empty($cfResp['payment_session_id'])) {
            $stmt = db()->prepare("INSERT INTO orders (user_id, plan_id, cf_order_id, amount, status) VALUES (?,?,?,?,'created')");
            $stmt->execute([$user['id'], $plan['id'], $orderId, $plan['price']]);
            $checkoutSessionId = $cfResp['payment_session_id'];
        } else {
            $checkoutError = 'Could not create payment order. Please try again shortly.';
        }
    }
}

// Handle "buy Tripo coin pack" click (separate from membership plans — Tripo is coin-based)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['buy_coin_pack_id'])) {
    csrf_check();
    if (!$user) redirect('/register.php');
    $pstmt = db()->prepare("SELECT * FROM tripo_coin_packs WHERE id=? AND active=1 LIMIT 1");
    $pstmt->execute([(int)$_POST['buy_coin_pack_id']]);
    $pack = $pstmt->fetch();
    if (!$pack) {
        $checkoutError = 'Coin pack not found.';
    } else {
        $orderId = 'TRPC' . $user['id'] . 'T' . time();
        $cfResp  = cashfree_create_order($orderId, (float)$pack['price'], $user);
        if (!empty($cfResp['error'])) {
            $checkoutError = 'Payment gateway error: ' . $cfResp['error'];
        } elseif (!empty($cfResp['payment_session_id'])) {
            $ins = db()->prepare("INSERT INTO tripo_coin_orders (user_id, pack_id, coins, amount, cf_order_id, status) VALUES (?,?,?,?,?,'created')");
            $ins->execute([$user['id'], $pack['id'], (int)$pack['coins'], (float)$pack['price'], $orderId]);
            $checkoutSessionId = $cfResp['payment_session_id'];
        } else {
            $checkoutError = 'Could not create payment order.';
        }
    }
}

// Handle "buy custom coin amount" — priced at the admin-configured coin_price_inr rate.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['buy_custom_coins'])) {
    csrf_check();
    if (!$user) redirect('/register.php');
    $rate    = max(0.01, (float) get_setting('coin_price_inr', '1'));
    $minBuy  = max(1, (int) get_setting('coin_min_purchase', '10'));
    $coinsQty = max(0, (int) $_POST['coin_qty']);
    if ($coinsQty < $minBuy) {
        $checkoutError = 'Minimum purchase is ' . $minBuy . ' coins.';
    } else {
        $amount = round($coinsQty * $rate, 2);
        $orderId = 'TRPX' . $user['id'] . 'T' . time();
        $cfResp  = cashfree_create_order($orderId, $amount, $user);
        if (!empty($cfResp['error'])) {
            $checkoutError = 'Payment gateway error: ' . $cfResp['error'];
        } elseif (!empty($cfResp['payment_session_id'])) {
            $ins = db()->prepare("INSERT INTO tripo_coin_orders (user_id, pack_id, coins, amount, cf_order_id, status) VALUES (?,NULL,?,?,?,'created')");
            $ins->execute([$user['id'], $coinsQty, $amount, $orderId]);
            $checkoutSessionId = $cfResp['payment_session_id'];
        } else {
            $checkoutError = 'Could not create payment order.';
        }
    }
}

// Load Tripo coin packs (safe if migration not yet run)
$coinPacks = [];
try {
    $coinPacks = db()->query("SELECT * FROM tripo_coin_packs WHERE active=1 ORDER BY sort_order, price")->fetchAll();
} catch (Throwable $e) { /* table may not exist yet */ }
$myPlanCoins      = $user ? (int)($user['plan_coins'] ?? 0)  : 0;
$myPurchasedCoins = $user ? (int)($user['tripo_coins'] ?? 0) : 0;
$myCoins          = $myPlanCoins + $myPurchasedCoins;
$coinRate         = max(0.01, (float) get_setting('coin_price_inr', '1'));
$coinMinBuy       = max(1, (int) get_setting('coin_min_purchase', '10'));

$pageTitle = 'Membership Plans';
include __DIR__ . '/includes/header.php';
$plans = all_plans();
?>
<div class="hero" style="padding-top:20px;">
  <h1>Membership Plans</h1>
  <p>Choose a plan for monthly coins &amp; premium 3D templates.</p>
</div>

<?php if ($checkoutError): ?>
  <div class="flash flash-error"><?php echo h($checkoutError); ?></div>
<?php endif; ?>

<?php if ($checkoutSessionId): ?>
  <div class="card" style="text-align:center;">
    <h2>Redirecting to secure payment...</h2>
    <p>Please wait, do not close this window.</p>
  </div>
  <script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
  <script>
    const cashfree = Cashfree({ mode: "<?php echo get_setting('cashfree_mode','sandbox') === 'production' ? 'production' : 'sandbox'; ?>" });
    cashfree.checkout({
      paymentSessionId: "<?php echo h($checkoutSessionId); ?>",
      redirectTarget: "_self"
    });
  </script>
<?php else: ?>

<div class="plans-grid">
  <?php foreach ($plans as $p): ?>
    <?php $isCurrent = $user && $user['plan_name'] === $p['plan_name']; ?>
    <div class="plan-card <?php echo $p['premium_designer'] ? 'featured' : ''; ?>">
      <?php if ($p['premium_designer']): ?><div class="badge badge-gold">POPULAR</div><?php endif; ?>
      <h3><?php echo h($p['plan_name']); ?></h3>
      <div class="plan-price">₹<?php echo number_format($p['price'],0); ?> <span>/ <?php echo (int)$p['validity_days']; ?> days</span></div>
      <ul>
        <li>🪙 <strong><?php echo (int)($p['plan_bonus_coins'] ?? 0); ?></strong> monthly Tripo AI coins</li>
        <li><?php echo $p['premium_designer'] ? '👑 Premium templates unlocked' : 'Free templates only'; ?></li>
        <li><?php echo (int)($p['project_slots'] ?? 0) > 0 ? (int)$p['project_slots'] . ' cloud project slot(s)' : 'Local auto-recover only'; ?></li>
        <li>3D Designer &amp; export tools</li>
      </ul>
      <?php if ($isCurrent): ?>
        <button class="btn btn-outline btn-block" disabled>Current Plan</button>
      <?php else: ?>
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="buy_plan_id" value="<?php echo (int)$p['id']; ?>">
          <button type="submit" class="btn btn-block"><?php echo (float)$p['price'] > 0 ? 'Choose Plan' : 'Activate Free'; ?></button>
        </form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<!-- ═══ TRIPO AI COINS ═══ -->
<div class="hero" style="padding-top:40px;">
  <h1 style="background:linear-gradient(135deg,#f59e0b,#fbbf24);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Tripo AI Coins</h1>
  <p><strong>Monthly plan coins</strong> get spent first, then your <strong>purchased coins</strong> (lifetime, never expire).</p>
  <?php if ($user): ?>
    <p style="font-size:16px;">
      Plan coins: <strong style="color:#60a5fa;"><?php echo $myPlanCoins; ?></strong>
      &nbsp;·&nbsp; Purchased: <strong style="color:#fbbf24;"><?php echo $myPurchasedCoins; ?></strong>
      &nbsp;·&nbsp; Total: <strong><?php echo $myCoins; ?></strong>
    </p>
  <?php endif; ?>
</div>

<!-- Custom coin amount at admin-configured rupees-per-coin -->
<div class="card" style="max-width:520px;margin:0 auto 24px;background:linear-gradient(135deg,#1e293b,#0f172a);border:1px solid #f59e0b;">
  <h3 style="color:#fbbf24;margin-top:0;">Buy Coins</h3>
  <p style="color:#94a3b8;font-size:13px;margin-top:0;">Rate: <strong style="color:#fbbf24;">₹<?php echo number_format($coinRate, 2); ?></strong> per coin · Minimum <?php echo $coinMinBuy; ?> coins.</p>
  <form method="post" id="customCoinForm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="buy_custom_coins" value="1">
    <label>Coins</label>
    <input type="number" id="coinQtyInput" name="coin_qty" min="<?php echo $coinMinBuy; ?>" value="<?php echo $coinMinBuy; ?>" required>
    <p style="font-size:14px;color:#94a3b8;">Total: ₹<strong id="coinTotalPreview" style="color:#fbbf24;"><?php echo number_format($coinMinBuy * $coinRate, 2); ?></strong></p>
    <button type="submit" class="btn btn-block" style="background:linear-gradient(135deg,#f59e0b,#fbbf24);color:#111;font-weight:bold;">Proceed to Payment</button>
  </form>
  <script>
    (function(){
      var rate = <?php echo json_encode($coinRate); ?>;
      var qty  = document.getElementById('coinQtyInput');
      var out  = document.getElementById('coinTotalPreview');
      function upd(){ var q = Math.max(0, parseInt(qty.value||'0',10)); out.textContent = (q * rate).toFixed(2); }
      qty.addEventListener('input', upd);
    })();
  </script>
</div>

<?php if (!empty($coinPacks)): ?>
<div class="plans-grid">
  <?php foreach ($coinPacks as $pack): ?>
    <div class="plan-card">
      <?php if (!empty($pack['bonus_label'])): ?><div class="badge badge-gold"><?php echo h($pack['bonus_label']); ?></div><?php endif; ?>
      <h3><?php echo h($pack['pack_name']); ?></h3>
      <div class="plan-price">₹<?php echo number_format($pack['price'],0); ?></div>
      <ul>
        <li><strong><?php echo (int)$pack['coins']; ?> coins</strong></li>
        <li>One-time purchase</li>
        <li>Never expires</li>
      </ul>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="buy_coin_pack_id" value="<?php echo (int)$pack['id']; ?>">
        <button type="submit" class="btn btn-block" style="background:linear-gradient(135deg,#f59e0b,#fbbf24);color:#111;font-weight:bold;">Buy Pack</button>
      </form>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
