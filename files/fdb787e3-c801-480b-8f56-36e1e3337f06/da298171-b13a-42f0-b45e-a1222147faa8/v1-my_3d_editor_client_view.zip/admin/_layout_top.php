<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();
$__admin = current_user();
$__active = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($adminTitle ?? 'Admin'); ?> - <?php echo h(SITE_NAME); ?> Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
</head>
<body>
<div class="admin-shell">
  <aside class="admin-sidebar">
    <div style="padding:0 22px 16px;font-weight:800;color:var(--gold);">⚙️ Admin</div>
    <a href="index.php" class="<?php echo $__active==='index.php'?'active':''; ?>"><span class="txt">Dashboard</span></a>
    <a href="homepage.php" class="<?php echo $__active==='homepage.php'?'active':''; ?>"><span class="txt">Homepage</span></a>
    <a href="plans.php" class="<?php echo $__active==='plans.php'?'active':''; ?>"><span class="txt">Membership Plans</span></a>
    <a href="members.php" class="<?php echo $__active==='members.php'?'active':''; ?>"><span class="txt">Members</span></a>
    <a href="posts.php" class="<?php echo $__active==='posts.php'?'active':''; ?>"><span class="txt">Posts</span></a>
    <a href="pages.php" class="<?php echo $__active==='pages.php'?'active':''; ?>"><span class="txt">Pages</span></a>
    <a href="forms.php" class="<?php echo $__active==='forms.php'?'active':''; ?>"><span class="txt">Forms</span></a>
    <a href="filemanager.php" class="<?php echo $__active==='filemanager.php'?'active':''; ?>"><span class="txt">File Manager</span></a>
    <a href="menu.php" class="<?php echo $__active==='menu.php'?'active':''; ?>"><span class="txt">Menu</span></a>
    <a href="announcements.php" class="<?php echo $__active==='announcements.php'?'active':''; ?>"><span class="txt">Announcements</span></a>
    <a href="analytics.php" class="<?php echo $__active==='analytics.php'?'active':''; ?>"><span class="txt">Analytics</span></a>
    <a href="usage.php" class="<?php echo $__active==='usage.php'?'active':''; ?>"><span class="txt">AI Usage Logs</span></a>
    <a href="tools.php" class="<?php echo $__active==='tools.php'?'active':''; ?>"><span class="txt">Tools (Tool Lab)</span></a>
    <a href="course-access.php" class="<?php echo $__active==='course-access.php'?'active':''; ?>"><span class="txt">Course Site Access</span></a>
    <a href="settings.php" class="<?php echo $__active==='settings.php'?'active':''; ?>"><span class="txt">Settings</span></a>
    <a href="account.php" class="<?php echo $__active==='account.php'?'active':''; ?>"><span class="txt">My Account</span></a>
    <a href="<?php echo SITE_URL; ?>/" target="_blank"><span class="txt">View Site ↗</span></a>
    <a href="logout.php"><span class="txt">Logout</span></a>
  </aside>
  <div class="admin-content">
    <div class="admin-topbar">
      <h2 style="margin:0;"><?php echo h($adminTitle ?? 'Dashboard'); ?></h2>
      <div style="color:var(--muted);font-size:13px;">Logged in as <?php echo h($__admin['name']); ?></div>
    </div>
    <?php $__flash = get_flash(); if ($__flash): ?>
      <div class="flash flash-<?php echo h($__flash['type']); ?>"><?php echo h($__flash['msg']); ?></div>
    <?php endif; ?>
