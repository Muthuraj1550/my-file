<?php
// Pay for a membership plan (?plan=ID) or Tripo coins (?coins=QTY) with Razorpay Standard Checkout.
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/rzp_pay.php';
require_login('/login.php');
rzp_pay_ensure();

$user = current_user();
$err = ''; $rzp = null; $title = ''; $price = 0.0;
$phone = substr(preg_replace('/\D/', '', (string)($user['phone'] ?? '')), -10);

if (!rzp_pay_mode_on()) {
    $err = 'Online payment is not available right now. Please contact support.';
} else {
    $kind = isset($_GET['plan']) ? 'plan' : (isset($_GET['coins']) ? 'coins' : '');
    $planId = null; $coins = 0;
    if ($kind === 'plan') {
        $plan = get_plan((int)$_GET['plan']);
        if (!$plan || (float)$plan['price'] <= 0) { $err = 'Plan not found.'; }
        else { $planId = (int)$plan['id']; $price = round((float)$plan['price'], 2); $title = $plan['plan_name'] . ' — ' . (int)$plan['validity_days'] . ' days'; }
    } elseif ($kind === 'coins') {
        $coins = (int)$_GET['coins'];
        $min = max(1, (int)get_setting('coin_min_purchase', 10));
        if ($coins < $min) { http_response_code(400); $err = 'Minimum purchase is ' . $min . ' coins.'; }
        elseif ($coins > 100000) { http_response_code(400); $err = 'Too many coins in one purchase.'; }
        else { $price = round($coins * (float)get_setting('coin_price_inr', 1), 2); $title = $coins . ' Tripo AI coins'; }
    } else { $err = 'Nothing to pay for.'; }

    if (!$err) {
        $paise = (int)round($price * 100);
        if ($paise < 100) { http_response_code(400); $err = 'The minimum payment is ₹1.'; }   // Razorpay minimum = 100 paise
        else {
            $receipt = ($kind === 'plan' ? 'PL' . $planId : 'CN' . $coins) . 'U' . $user['id'] . 'T' . time();
            $res = rzp_create_order($receipt, $paise, ['kind' => $kind, 'user_id' => (string)$user['id'], 'plan_id' => (string)$planId, 'coins' => (string)$coins]);
            if (empty($res['data']['id'])) {
                error_log('Razorpay order failed ' . $receipt . ' (key ' . rzp_key_id() . '): ' . $res['error']);
                if ((int)$res['code'] === 401) { http_response_code(401); $err = 'Payment gateway authentication failed. Please contact the site admin.'; }
                else { http_response_code(500); $err = 'Could not start the payment. Please try again later.'; }
            } else {
                db()->prepare("INSERT INTO rzp_orders (kind, user_id, plan_id, coins, amount, rzp_order_id, status) VALUES (?,?,?,?,?,?, 'pending')")
                    ->execute([$kind, $user['id'], $planId, $coins, $price, $res['data']['id']]);
                $rzp = ['key' => rzp_key_id(), 'amount' => $paise, 'order_id' => $res['data']['id']];
            }
        }
    }
}
$pageTitle = 'Payment';
include __DIR__ . '/includes/header.php';
?>
<div class="wrap" style="max-width:520px;margin:40px auto;text-align:center;">
  <div class="card">
  <?php if ($err): ?>
    <h2>⚠️ <?php echo h($err); ?></h2>
    <a class="btn btn-outline" href="<?php echo SITE_URL; ?>/membership.php">← Membership</a>
  <?php else: ?>
    <h2><?php echo h($title); ?></h2>
    <h1 style="margin:10px 0;">₹<?php echo rtrim(rtrim(number_format($price, 2, '.', ''), '0'), '.'); ?></h1>
    <p id="pmsg" style="color:var(--muted)">Opening the payment window…</p>
    <button class="btn" id="rzpBtn" type="button" style="display:none;">Pay now</button>
    <form id="rzpForm" method="post" action="<?php echo SITE_URL; ?>/pay-return.php">
      <input type="hidden" name="razorpay_payment_id" id="f_pid"><input type="hidden" name="razorpay_order_id" id="f_oid"><input type="hidden" name="razorpay_signature" id="f_sig">
    </form>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
      var rz = new Razorpay({
        key: <?php echo json_encode($rzp['key']); ?>, amount: <?php echo (int)$rzp['amount']; ?>, currency: 'INR',
        name: 'My 3D Gifts', description: <?php echo json_encode($title); ?>, order_id: <?php echo json_encode($rzp['order_id']); ?>,
        prefill: { name: <?php echo json_encode((string)$user['name']); ?>, email: <?php echo json_encode((string)$user['email']); ?>, contact: <?php echo json_encode($phone); ?> },
        theme: { color: '#f59e0b' },
        handler: function (r) {
          document.getElementById('pmsg').textContent = 'Confirming your payment…';
          document.getElementById('f_pid').value = r.razorpay_payment_id; document.getElementById('f_oid').value = r.razorpay_order_id; document.getElementById('f_sig').value = r.razorpay_signature;
          document.getElementById('rzpForm').submit();
        },
        modal: { ondismiss: function () { document.getElementById('pmsg').textContent = 'Payment cancelled. You can try again.'; document.getElementById('rzpBtn').style.display = 'inline-block'; } }
      });
      rz.on('payment.failed', function (resp) {
        var m = (resp && resp.error && resp.error.description) ? resp.error.description : 'Payment failed.';
        var el = document.getElementById('pmsg'); el.style.color = '#fca5a5'; el.textContent = '❌ ' + m + ' Please try again.';
        document.getElementById('rzpBtn').style.display = 'inline-block';
      });
      document.getElementById('rzpBtn').onclick = function () { rz.open(); };
      rz.open();
    </script>
  <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
