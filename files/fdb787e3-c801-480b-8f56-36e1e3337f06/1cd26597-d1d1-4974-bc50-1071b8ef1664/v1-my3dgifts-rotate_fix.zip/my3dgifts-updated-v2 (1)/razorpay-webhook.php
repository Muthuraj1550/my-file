<?php
// Razorpay webhook (backup confirmation if the buyer closes the browser before returning).
// Handles template purchases, membership plans and coin purchases.
// Razorpay Dashboard > Developers > Webhooks:  URL = https://my3dgifts.com/razorpay-webhook.php
// Events: payment.captured, order.paid.  Secret = same value as in Admin > Earn Money > Payment gateway.
require_once __DIR__ . '/includes/market.php';
require_once __DIR__ . '/includes/razorpay.php';
require_once __DIR__ . '/includes/rzp_pay.php';

$raw    = file_get_contents('php://input');
$secret = rzp_webhook_secret();
$sig    = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';
if ($secret === '' || !hash_equals(hash_hmac('sha256', $raw, $secret), $sig)) { http_response_code(400); echo 'bad signature'; exit; }

market_ready();
$e = json_decode($raw, true) ?: [];
if (in_array($e['event'] ?? '', ['payment.captured', 'order.paid'], true)) {
    $pay = $e['payload']['payment']['entity'] ?? [];
    $oid = $pay['order_id'] ?? ''; $pid = $pay['id'] ?? '';
    if ($oid !== '') {
        $s = db()->prepare("SELECT * FROM market_purchases WHERE gateway = 'razorpay' AND gateway_order_id = ?");
        $s->execute([$oid]);
        if ($p = $s->fetch()) {
            if ($p['status'] !== 'paid' && (int)($pay['amount'] ?? 0) === (int)round($p['amount'] * 100)) market_mark_paid($p['id'], $pid);
        }
    }
    // Membership plan / coin purchases
    if ($oid !== '') {
        try {
            rzp_pay_ensure();
            $s = db()->prepare("SELECT * FROM rzp_orders WHERE rzp_order_id = ?");
            $s->execute([$oid]);
            if ($o = $s->fetch()) {
                if ($o['status'] !== 'paid' && (int)($pay['amount'] ?? 0) === (int)round($o['amount'] * 100)) rzp_pay_fulfil($o, $pid);
            }
        } catch (Throwable $e) { error_log('webhook rzp_orders: ' . $e->getMessage()); }
    }
}
http_response_code(200);
echo 'ok';
