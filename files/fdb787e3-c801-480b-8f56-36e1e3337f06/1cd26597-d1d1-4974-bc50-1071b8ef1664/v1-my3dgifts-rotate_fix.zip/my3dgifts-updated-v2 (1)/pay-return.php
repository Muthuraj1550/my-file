<?php
// Razorpay Checkout callback for plan / coin payments. Verifies server-side; never trusts the browser.
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/rzp_pay.php';
require_login('/login.php');
rzp_pay_ensure();

$msg = 'Order not found.'; $o = null;
$oid = (string)($_POST['razorpay_order_id'] ?? ''); $pid = (string)($_POST['razorpay_payment_id'] ?? ''); $sig = (string)($_POST['razorpay_signature'] ?? '');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || $oid === '' || $pid === '' || $sig === '') {
    http_response_code(400);                                   // missing fields
    $msg = 'Missing payment details.';
} else {
    $s = db()->prepare("SELECT * FROM rzp_orders WHERE rzp_order_id = ? AND user_id = ?");
    $s->execute([$oid, $_SESSION['uid']]);
    $o = $s->fetch();
    if ($o) {
        if ($o['status'] === 'paid') { redirect('/membership.php?payment=success&kind=' . $o['kind']); }
        if (!rzp_verify_checkout_signature($oid, $pid, $sig)) {
            http_response_code(400);                           // mismatch: NOT marked paid
            $msg = 'Payment signature could not be verified. If money was deducted, contact support — it will be reconciled.';
        } else {
            $r = rzp_pay_confirm($o, $pid);
            if ($r === 'paid') redirect('/membership.php?payment=success&kind=' . $o['kind']);
            $msg = $r === 'error' ? 'Payment received but activation failed — please contact support with payment id ' . h($pid) . '.'
                                  : 'Payment is still being confirmed (' . h($r) . '). It will activate automatically within a minute.';
        }
    }
}
$pageTitle = 'Payment';
include __DIR__ . '/includes/header.php';
?>
<div class="wrap" style="max-width:520px;margin:40px auto;text-align:center;">
  <div class="card">
    <h2>ℹ️ <?php echo $msg; ?></h2>
    <a class="btn btn-outline" href="<?php echo SITE_URL; ?>/membership.php">← Membership</a>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
