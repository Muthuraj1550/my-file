<?php
// Buyer pays for a paid template — Razorpay only. The creator's share is split to the creator's
// Razorpay Route linked account automatically; this site never receives money to pass on later.
// Only works after the admin switches on "paid templates" (Admin > Earn Money > Payment gateway).
require_once __DIR__ . '/includes/market.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/razorpay.php';
require_login('/login.php');
market_ready();

$id = (int)($_GET['id'] ?? 0);
$s = db()->prepare("SELECT t.*, u.name creator_name FROM market_templates t JOIN users u ON u.id=t.user_id WHERE t.id=? AND t.status='approved'");
$s->execute([$id]);
$t = $s->fetch();
$user = current_user();
$err = ''; $rzp = null; $phone = '';

if (!$t) { $err = 'Template not found.'; }
elseif (market_row_price($t) <= 0 || (int)$t['user_id'] === (int)$user['id'] || market_user_owns($user['id'], $id)) {
    redirect('/designer.php?market=' . $id);          // free, your own, or already unlocked
} elseif (!rzp_configured()) {
    $err = 'Payments are not available right now.';
} else {
    $acc = market_linked_account($t['user_id']);
    $price = round(market_row_price($t), 2);
    $paise = (int)round($price * 100);
    $creatorPaise = (int)round($price * market_creator_pct() / 100 * 100);
    $splitOk = $acc !== '' && $creatorPaise > 0 && $creatorPaise <= $paise;
    if ($paise < 100) {                                   // Razorpay minimum is 100 paise (₹1)
        http_response_code(400);
        $err = 'The minimum payment is ₹1.';
    } elseif (!$splitOk && !rzp_is_test()) {              // live keys: never take money we cannot split
        $err = 'This template cannot be purchased right now.';
    } else {
        $orderId = 'MKT' . $id . 'U' . $user['id'] . 'T' . time();
        $phone = substr(preg_replace('/\D/', '', (string)($user['phone'] ?? '')), -10);
        $transfers = null;
        if ($splitOk) {
            $tr = ['account' => $acc, 'amount' => $creatorPaise, 'currency' => 'INR',
                   'notes' => ['template_id' => (string)$id, 'order' => $orderId], 'on_hold' => false];
            $hold = (int)get_setting('rzp_hold_days', 0);
            if ($hold > 0) { $tr['on_hold'] = true; $tr['on_hold_until'] = time() + $hold * 86400; }
            $transfers = [$tr];
        }
        $res = rzp_create_order($orderId, $paise, ['template_id' => (string)$id, 'buyer_id' => (string)$user['id'], 'order' => $orderId], $transfers);
        if (empty($res['data']['id'])) {
            error_log('Razorpay order failed ' . $orderId . ': ' . $res['error']);
            if ((int)$res['code'] === 401) { http_response_code(401); $err = 'Payment gateway authentication failed. Please contact the site admin.'; }
            else { http_response_code(500); $err = 'Could not start the payment. Please try again later.'; }
        } else {
            db()->prepare("INSERT INTO market_purchases (template_id, buyer_id, creator_id, amount, creator_amount, cf_order_id, status, gateway, gateway_order_id, split_auto)
                           VALUES (?,?,?,?,?,?, 'pending', 'razorpay', ?, ?)")
                ->execute([$id, $user['id'], $t['user_id'], $price, round($creatorPaise / 100, 2), $orderId, $res['data']['id'], $transfers ? 1 : 0]);
            $rzp = ['key' => rzp_key_id(), 'amount' => $paise, 'order_id' => $res['data']['id']];
        }
    }
}
$pageTitle = 'Pay for template';
include __DIR__ . '/includes/header.php';
?>
<div class="wrap" style="max-width:520px;margin:40px auto;text-align:center;">
  <div class="card">
  <?php if ($err): ?>
    <h2>⚠️ <?php echo h($err); ?></h2>
    <a class="btn btn-outline" href="<?php echo SITE_URL; ?>/designer.php">← Designer</a>
  <?php else: ?>
    <h2>🧩 <?php echo h($t['title']); ?></h2>
    <p style="color:var(--muted)">by <?php echo h($t['creator_name']); ?></p>
    <h1 style="margin:10px 0;"><?php echo h(market_price_label(market_row_price($t))); ?></h1>
    <p>Once the payment is complete, this template is unlocked for you permanently.</p>
    <p id="pmsg" style="color:var(--muted)">Opening the payment window…</p>
    <button class="btn" id="rzpBtn" type="button" style="display:none;">Pay now</button>
    <form id="rzpForm" method="post" action="<?php echo SITE_URL; ?>/market-pay-return.php">
      <input type="hidden" name="razorpay_payment_id" id="f_pid"><input type="hidden" name="razorpay_order_id" id="f_oid"><input type="hidden" name="razorpay_signature" id="f_sig">
    </form>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
      var rz = new Razorpay({
        key: <?php echo json_encode($rzp['key']); ?>, amount: <?php echo (int)$rzp['amount']; ?>, currency: 'INR',
        name: 'My 3D Gifts', description: <?php echo json_encode($t['title']); ?>, order_id: <?php echo json_encode($rzp['order_id']); ?>,
        prefill: { name: <?php echo json_encode((string)$user['name']); ?>, email: <?php echo json_encode((string)$user['email']); ?>, contact: <?php echo json_encode($phone); ?> },
        theme: { color: '#f59e0b' },
        handler: function (r) {
          document.getElementById('pmsg').textContent = 'Confirming your payment…';
          document.getElementById('f_pid').value = r.razorpay_payment_id; document.getElementById('f_oid').value = r.razorpay_order_id; document.getElementById('f_sig').value = r.razorpay_signature;
          document.getElementById('rzpForm').submit();
        },
        modal: { ondismiss: function () { document.getElementById('pmsg').textContent = 'Payment cancelled. You can try again.'; document.getElementById('rzpBtn').style.display = 'inline-block'; } }
      });
      rz.on('payment.failed', function (resp) {
        var m = (resp && resp.error && resp.error.description) ? resp.error.description : 'Payment failed.';
        var el = document.getElementById('pmsg'); el.style.color = '#fca5a5'; el.textContent = '❌ ' + m + ' Please try again.';
        document.getElementById('rzpBtn').style.display = 'inline-block';
      });
      document.getElementById('rzpBtn').onclick = function () { rz.open(); };
      rz.open();
    </script>
  <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
