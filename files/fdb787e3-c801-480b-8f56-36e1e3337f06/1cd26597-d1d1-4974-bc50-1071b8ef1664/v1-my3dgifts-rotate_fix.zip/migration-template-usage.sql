-- =========================================================
--  "See Full Templates" — how many times each template was used
--
--  One row per template (free / premium + template name). Every time a
--  visitor clicks a template in the designer's template list and it
--  actually opens, use_count goes up by 1. The popup shows it as "🔥 N".
--
--  Run once (phpMyAdmin). Safe to re-run.
-- =========================================================
CREATE TABLE IF NOT EXISTS template_usage (
    kind          ENUM('free','premium') NOT NULL,
    template_name VARCHAR(190) NOT NULL,
    use_count     INT UNSIGNED NOT NULL DEFAULT 0,
    last_used_at  DATETIME NULL,
    PRIMARY KEY (kind, template_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
