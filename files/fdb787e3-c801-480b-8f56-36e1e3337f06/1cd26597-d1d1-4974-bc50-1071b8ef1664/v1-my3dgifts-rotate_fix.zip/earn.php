<?php
require_once __DIR__ . '/includes/market.php';
require_once __DIR__ . '/includes/auth.php';

if (!market_ready()) { die('Run migration-marketplace.sql in phpMyAdmin first.'); }

$user   = is_logged_in() ? current_user() : null;
$uid    = $user ? (int)$user['id'] : 0;
$q      = trim((string)($_GET['q'] ?? ''));
$sort   = in_array($_GET['sort'] ?? '', ['trending','newest','price_low'], true) ? $_GET['sort'] : 'trending';
$type   = in_array($_GET['type'] ?? '', ['all','free','paid'], true) ? $_GET['type'] : 'all';
$page   = max(1, (int)($_GET['page'] ?? 1));
$per    = 24;

$where = ["t.status = 'approved'"]; $args = [];
if ($q !== '') {
    $like = '%' . str_replace(['%','_'], ['\%','\_'], $q) . '%';
    $where[] = "(t.title LIKE ? OR t.description LIKE ? OR u.name LIKE ?)";
    array_push($args, $like, $like, $like);
}
if ($type === 'free') $where[] = 't.price <= 0';
if ($type === 'paid') $where[] = 't.price > 0';
$order = ['trending' => 't.use_count DESC, t.approved_at DESC', 'newest' => 't.approved_at DESC', 'price_low' => 't.price ASC, t.use_count DESC'][$sort];
$whereSql = implode(' AND ', $where);

$c = db()->prepare("SELECT COUNT(*) FROM market_templates t JOIN users u ON u.id=t.user_id WHERE $whereSql");
$c->execute($args);
$total = (int)$c->fetchColumn();
$pages = max(1, (int)ceil($total / $per));
$page  = min($page, $pages);

$st = db()->prepare("SELECT t.*, u.name AS creator_name FROM market_templates t JOIN users u ON u.id=t.user_id
                     WHERE $whereSql ORDER BY $order LIMIT $per OFFSET " . (($page - 1) * $per));
$st->execute($args);
$rows = $st->fetchAll();

$owned = [];
if ($uid) {
    $o = db()->prepare("SELECT DISTINCT template_id FROM market_purchases WHERE buyer_id = ? AND status = 'paid'");
    $o->execute([$uid]);
    $owned = array_flip(array_map('intval', $o->fetchAll(PDO::FETCH_COLUMN)));
}
$paidOn = market_paid_enabled();
$tot = ($uid && $paidOn) ? market_creator_totals($uid) : null;
if (!$paidOn) { $type = 'all'; if ($sort === 'price_low') $sort = 'trending'; }
$tut = market_tutorial_url();

function earn_url($over = []) {
    $p = array_merge(['q' => $_GET['q'] ?? '', 'sort' => $_GET['sort'] ?? '', 'type' => $_GET['type'] ?? '', 'page' => 1], $over);
    return '?' . http_build_query(array_filter($p, function($v){ return $v !== '' && $v !== null; }));
}

$pageTitle = 'Earn Money';
include __DIR__ . '/includes/header.php';
?>
<style>
.earn-hero{display:flex;flex-wrap:wrap;gap:14px;align-items:center;justify-content:space-between;margin-bottom:18px;}
.earn-actions{display:flex;gap:10px;flex-wrap:wrap;}
.earn-amount{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:10px 18px;text-align:center;}
.earn-amount b{display:block;font-size:22px;color:var(--gold);}
.earn-amount a{font-size:12px;}
.mk-bar{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0 20px;}
.mk-bar input[type=text]{flex:1;min-width:220px;margin:0;}
.mk-bar select{width:auto;margin:0;}
.mk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:16px;}
.mk-card{background:var(--card);border:1px solid var(--border);border-radius:14px;overflow:hidden;display:flex;flex-direction:column;}
.mk-card .tt{height:140px;background:#0b1120;display:flex;align-items:center;justify-content:center;font-size:40px;}
.mk-card .tt img{width:100%;height:100%;object-fit:cover;display:block;}
.mk-card .tb{padding:12px;display:flex;flex-direction:column;gap:6px;flex:1;}
.mk-card .tb b{font-size:14px;line-height:1.3;}
.mk-desc{font-size:12px;color:var(--muted);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:32px;}
.mk-meta{display:flex;justify-content:space-between;font-size:12px;color:var(--muted);}
.mk-price{font-weight:700;color:var(--gold);}
.mk-pager{display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin:26px 0;}
</style>
<div class="wrap" style="max-width:1100px;margin:30px auto;">
  <div class="earn-hero">
    <div>
      <h1 style="margin:0 0 6px;">💰 Earn Money</h1>
      <?php if ($paidOn): ?>
      <p style="color:var(--muted);margin:0;">Create 3D templates, publish them, and earn <b><?php echo market_creator_pct(); ?>%</b> every time someone buys one — paid to you automatically.</p>
      <?php else: ?>
      <p style="color:var(--muted);margin:0;">Create 3D templates and share them with everyone. All templates are <b>free</b> for now — paid templates and earnings are coming soon.</p>
      <?php endif; ?>
    </div>
    <?php if ($tot): ?>
    <div class="earn-amount">
      <b>₹<?php echo number_format($tot['total'], 2); ?></b>
      Total earned
      <div><a href="<?php echo SITE_URL; ?>/dashboard.php#earnings">Manage in My Dashboard →</a></div>
    </div>
    <?php endif; ?>
  </div>

  <div class="earn-actions">
    <a class="btn" href="<?php echo SITE_URL; ?>/designer.php?post=1">➕ Create Template</a>
    <?php if ($tut): ?>
      <a class="btn btn-outline" href="<?php echo h($tut); ?>" target="_blank" rel="noopener">🎬 How to create a template (Tutorial)</a>
    <?php endif; ?>
    <?php if (!$user): ?><a class="btn btn-outline" href="<?php echo SITE_URL; ?>/login.php?next=<?php echo urlencode('/earn.php'); ?>">Login</a><?php endif; ?>
  </div>

  <?php if (!market_enabled()): ?><div class="flash flash-error">The Earn Money feature is currently turned off.</div><?php endif; ?>

  <h2 style="margin-top:34px;">🛍️ Template Marketplace</h2>
  <form method="get" class="mk-bar">
    <input type="text" name="q" value="<?php echo h($q); ?>" placeholder="Search templates, creators…">
    <?php if ($paidOn): ?>
    <select name="type">
      <option value="all" <?php echo $type==='all'?'selected':''; ?>>All</option>
      <option value="free" <?php echo $type==='free'?'selected':''; ?>>Free</option>
      <option value="paid" <?php echo $type==='paid'?'selected':''; ?>>Paid</option>
    </select>
    <?php endif; ?>
    <select name="sort">
      <option value="trending" <?php echo $sort==='trending'?'selected':''; ?>>Most used</option>
      <option value="newest" <?php echo $sort==='newest'?'selected':''; ?>>Newest</option>
      <?php if ($paidOn): ?><option value="price_low" <?php echo $sort==='price_low'?'selected':''; ?>>Price: low to high</option><?php endif; ?>
    </select>
    <button class="btn" type="submit">Search</button>
  </form>

  <?php if (!$rows): ?>
    <div class="card" style="text-align:center;color:var(--muted);"><?php echo $q !== '' ? 'No templates match your search.' : 'No templates published yet — be the first!'; ?></div>
  <?php else: ?>
  <div class="mk-grid">
    <?php foreach ($rows as $t):
      $eff  = market_row_price($t);
      $paid = $eff > 0;
      $mine = (int)$t['user_id'] === $uid;
      $has  = !$paid || $mine || isset($owned[(int)$t['id']]);
    ?>
    <div class="mk-card">
      <div class="tt"><?php if ($t['thumb_file']): ?><img src="<?php echo h(market_thumb_url($t)); ?>" alt="<?php echo h($t['title']); ?>" loading="lazy"><?php else: ?>🧩<?php endif; ?></div>
      <div class="tb">
        <b><?php echo h($t['title']); ?></b>
        <div class="mk-desc"><?php echo h($t['description']); ?></div>
        <div class="mk-meta"><span>by <?php echo h($t['creator_name']); ?></span><span>🔥 <?php echo (int)$t['use_count']; ?></span></div>
        <div class="mk-meta">
          <span class="mk-price"><?php echo $has && $paid ? '✔ Owned' : h(market_price_label($eff)); ?></span>
        </div>
        <a class="btn btn-sm btn-block" style="margin-top:auto;" href="<?php echo SITE_URL; ?>/designer.php?market=<?php echo (int)$t['id']; ?>"><?php echo $has ? 'Use Template' : 'Buy &amp; Use'; ?></a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <?php if ($pages > 1): ?>
  <div class="mk-pager">
    <?php if ($page > 1): ?><a class="btn btn-sm btn-outline" href="<?php echo h(earn_url(['page' => $page - 1])); ?>">← Prev</a><?php endif; ?>
    <span style="align-self:center;color:var(--muted);">Page <?php echo $page; ?> of <?php echo $pages; ?></span>
    <?php if ($page < $pages): ?><a class="btn btn-sm btn-outline" href="<?php echo h(earn_url(['page' => $page + 1])); ?>">Next →</a><?php endif; ?>
  </div>
  <?php endif; endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
