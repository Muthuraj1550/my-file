<?php
// Minimal Razorpay REST wrapper (Orders + Route transfers). Keys live in Admin > Earn Money > Payment gateway.
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/env.php';

// Credentials: keys saved in Admin (Settings / Earn Money > Payment gateway) win; .env / environment is the fallback.
// Key ID and Secret are always taken as a PAIR from the same source, so a test ID can never be mixed with a live secret.
function rzp_creds() {
    static $c = null;
    if ($c !== null) return $c;
    $aId = trim((string)get_setting('rzp_key_id', ''));  $aSec = trim((string)get_setting('rzp_key_secret', ''));
    $eId = trim((string)app_env('RAZORPAY_KEY_ID'));     $eSec = trim((string)app_env('RAZORPAY_KEY_SECRET'));
    if ($aId !== '' && $aSec !== '')      $c = ['id' => $aId, 'secret' => $aSec];
    elseif ($eId !== '' && $eSec !== '')  $c = ['id' => $eId, 'secret' => $eSec];
    else                                  $c = ['id' => $aId ?: $eId, 'secret' => $aSec ?: $eSec];
    return $c;
}
function rzp_key_id()     { return rzp_creds()['id']; }
function rzp_key_secret() { return rzp_creds()['secret']; }
function rzp_webhook_secret() { return trim((string)(get_setting('rzp_webhook_secret', '') ?: app_env('RAZORPAY_WEBHOOK_SECRET'))); }
/** Test keys (rzp_test_…) never move real money. */
function rzp_is_test()    { return strpos(rzp_key_id(), 'rzp_test_') === 0; }
function rzp_configured() { return rzp_key_id() !== '' && rzp_key_secret() !== ''; }

/** Returns ['code'=>int,'data'=>array|null,'error'=>string]. Paths starting with /v2/ use the v2 base (Route accounts). */
function rzp_api($method, $path, $body = null, array $extraHeaders = []) {
    $url = (strpos($path, '/v2/') === 0 ? 'https://api.razorpay.com' : 'https://api.razorpay.com/v1') . $path;
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_USERPWD        => rzp_key_id() . ':' . rzp_key_secret(),
        CURLOPT_HTTPHEADER     => array_merge(['Content-Type: application/json'], $extraHeaders),
        CURLOPT_CUSTOMREQUEST  => $method,
    ];
    if ($body !== null) $opts[CURLOPT_POSTFIELDS] = json_encode($body);
    curl_setopt_array($ch, $opts);
    $res = curl_exec($ch); $err = curl_error($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = json_decode((string)$res, true);
    $msg = $err ?: ($code >= 400 ? ($data['error']['description'] ?? ('HTTP ' . $code)) : '');
    return ['code' => $code, 'data' => is_array($data) ? $data : null, 'error' => $msg];
}

/** Create an order. $transfers = Route transfers array (or null for no split). Amount in paise. */
function rzp_create_order($receipt, $amountPaise, array $notes, $transfers = null) {
    $body = ['amount' => (int)$amountPaise, 'currency' => 'INR', 'receipt' => $receipt, 'notes' => $notes];
    if ($transfers) $body['transfers'] = $transfers;
    return rzp_api('POST', '/orders', $body);
}

function rzp_verify_checkout_signature($orderId, $paymentId, $signature) {
    $expected = hash_hmac('sha256', $orderId . '|' . $paymentId, rzp_key_secret());
    return hash_equals($expected, (string)$signature);
}

function rzp_fetch_payment($paymentId) { return rzp_api('GET', '/payments/' . rawurlencode($paymentId)); }

/**
 * Route "composite" onboarding: creates a linked account + Route product + settlement destination
 * (UPI id or bank account) in ONE call. PAN / bank details go straight to Razorpay and are never stored here.
 * $c = ['uid','name','email','phone10','pan','method'=>'upi'|'bank','vpa','upi_name','acc_no','ifsc','bank_name']
 */
function rzp_create_linked_account(array $c) {
    if ($c['method'] === 'upi') {
        $settle = ['method' => 'upi', 'upi' => ['vpa' => $c['vpa'], 'beneficiary_name' => $c['upi_name'], 'currency' => 'INR', 'is_default' => true]];
    } else {
        $settle = ['method' => 'bank_account', 'bank_account' => ['account_number' => $c['acc_no'], 'beneficiary_name' => $c['bank_name'],
                   'code_type' => 'ifsc', 'code' => $c['ifsc'], 'currency' => 'INR', 'is_default' => true]];
    }
    $body = [
        'type' => 'route', 'tnc_accepted' => true, 'reference_id' => 'mk_u' . (int)$c['uid'],
        'legal_business_name' => $c['name'], 'business_type' => 'individual',
        'email' => $c['email'], 'phone' => '+91' . $c['phone10'],
        'legal_info' => ['pan' => $c['pan']],
        'notes' => ['user_id' => (string)(int)$c['uid']],
        'settlement_accounts' => [$settle],
    ];
    $idem = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4));
    return rzp_api('POST', '/v2/accounts', $body, ['Idempotency-Key: ' . $idem]);
}
