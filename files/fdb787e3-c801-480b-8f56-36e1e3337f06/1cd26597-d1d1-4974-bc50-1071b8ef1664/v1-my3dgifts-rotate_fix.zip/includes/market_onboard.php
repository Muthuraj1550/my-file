<?php
// Creator payout setup (Razorpay Route linked account via API) + manual UPI option.
require_once __DIR__ . '/market.php';
require_once __DIR__ . '/razorpay.php';

/** Validate the creator's payout form. Returns [errors[], clean[]]. */
function market_payout_validate(array $in) {
    $e = []; $c = [];
    $c['name']  = trim(preg_replace('/\s+/', ' ', (string)($in['legal_name'] ?? '')));
    $c['pan']   = strtoupper(trim((string)($in['pan'] ?? '')));
    $c['phone10'] = substr(preg_replace('/\D/', '', (string)($in['phone'] ?? '')), -10);
    $c['email'] = trim((string)($in['email'] ?? ''));
    $c['method'] = ($in['method'] ?? 'upi') === 'bank' ? 'bank' : 'upi';
    if (mb_strlen($c['name']) < 4 || mb_strlen($c['name']) > 200) $e[] = 'Enter your full name exactly as on your PAN card (at least 4 characters).';
    if (!preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/', $c['pan'])) $e[] = 'PAN must be 10 characters like ABCDE1234F.';
    elseif ($c['pan'][3] !== 'P') $e[] = 'Only an individual PAN (4th letter "P") is supported here. Companies/firms should contact the admin.';
    if (!preg_match('/^[6-9][0-9]{9}$/', $c['phone10'])) $e[] = 'Enter a valid 10-digit mobile number.';
    if (!filter_var($c['email'], FILTER_VALIDATE_EMAIL)) $e[] = 'Enter a valid email address.';
    if ($c['method'] === 'upi') {
        $c['vpa'] = trim((string)($in['vpa'] ?? ''));
        $c['upi_name'] = trim((string)($in['upi_name'] ?? '')) ?: $c['name'];
        if (!preg_match('/^[A-Za-z0-9._\-]{2,100}@[A-Za-z][A-Za-z0-9]{1,63}$/', $c['vpa'])) $e[] = 'UPI ID must look like name@bank.';
    } else {
        $c['acc_no'] = preg_replace('/\s+/', '', (string)($in['acc_no'] ?? ''));
        $c['ifsc'] = strtoupper(trim((string)($in['ifsc'] ?? '')));
        $c['bank_name'] = trim((string)($in['bank_name'] ?? '')) ?: $c['name'];
        if (!preg_match('/^[0-9]{5,20}$/', $c['acc_no'])) $e[] = 'Enter a valid bank account number.';
        if (!preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $c['ifsc'])) $e[] = 'IFSC must look like HDFC0000317.';
    }
    if (empty($in['tnc'])) $e[] = 'Please accept the payout terms.';
    return [$e, $c];
}

/** Run the whole flow. Returns ['ok'=>bool,'message'=>string]. Nothing sensitive is stored locally. */
function market_onboard_creator(array $user, array $in) {
    list($errs, $c) = market_payout_validate($in);
    if ($errs) return ['ok' => false, 'message' => implode(' ', $errs)];
    if (market_linked_account($user['id']) !== '') return ['ok' => false, 'message' => 'Your payout account is already set up. Contact the admin to change it.'];
    if (!rzp_configured()) return ['ok' => false, 'message' => 'Payout setup is not available yet. Please contact the admin.'];

    // simple throttle: 5 attempts / hour / session
    if (session_status() === PHP_SESSION_NONE) @session_start();
    $_SESSION['mk_onb'] = array_values(array_filter($_SESSION['mk_onb'] ?? [], function($t){ return $t > time() - 3600; }));
    if (count($_SESSION['mk_onb']) >= 5) return ['ok' => false, 'message' => 'Too many attempts. Please try again in an hour.'];
    $_SESSION['mk_onb'][] = time();

    $c['uid'] = $user['id'];
    $r = rzp_create_linked_account($c);
    $acc = $r['data']['id'] ?? '';
    if ($acc === '' || strpos($acc, 'acc_') !== 0) {
        error_log('Linked account create failed for user ' . $user['id'] . ' (' . $r['code'] . '): ' . $r['error']);
        if ($r['code'] === 403) return ['ok' => false, 'message' => 'Automatic payout setup is not enabled on our Razorpay account yet. Please contact the admin.'];
        if ($r['code'] === 409) return ['ok' => false, 'message' => 'An account already exists for this PAN or profile. Please contact the admin to link it.'];
        return ['ok' => false, 'message' => 'Razorpay could not verify the details: ' . ($r['error'] ?: 'unknown error')];
    }
    $label = $c['method'] === 'upi' ? 'UPI ' . $c['vpa'] : 'Bank ••••' . substr($c['acc_no'], -4);
    db()->prepare("INSERT INTO market_linked_accounts (user_id, razorpay_account_id, source, payout_label) VALUES (?,?, 'auto', ?)
                   ON DUPLICATE KEY UPDATE razorpay_account_id = VALUES(razorpay_account_id), source = 'auto', payout_label = VALUES(payout_label)")
        ->execute([$user['id'], $acc, mb_substr($label, 0, 80)]);
    return ['ok' => true, 'message' => 'Payout account created ✅ (' . $label . '). Your share of every sale is now sent there automatically.'];
}
