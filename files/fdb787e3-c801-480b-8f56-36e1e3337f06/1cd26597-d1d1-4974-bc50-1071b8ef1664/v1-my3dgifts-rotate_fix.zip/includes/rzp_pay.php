<?php
// Razorpay payments for MEMBERSHIP PLANS and TRIPO COINS on this site (no redirect to the course/design site).
// Keys: .env (RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET) or Admin > Settings > Razorpay.
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/razorpay.php';

/** Admin > Settings > "Plans & coins payment" = Razorpay AND keys present. */
function rzp_pay_mode_on() {
    return get_setting('payments_gateway', 'course_site') === 'razorpay' && rzp_configured();
}

/** Creates the order table on first use (no manual SQL needed). */
function rzp_pay_ensure() {
    static $done = false;
    if ($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS rzp_orders (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        kind ENUM('plan','coins') NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        plan_id INT UNSIGNED NULL,
        coins INT UNSIGNED NOT NULL DEFAULT 0,
        amount DECIMAL(10,2) NOT NULL,
        rzp_order_id VARCHAR(60) NOT NULL,
        rzp_payment_id VARCHAR(60) NOT NULL DEFAULT '',
        status ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        paid_at DATETIME NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_rzp_order (rzp_order_id),
        KEY idx_user (user_id, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done = true;
}

/** Grant what was bought. Idempotent: only the first call after payment grants anything. */
function rzp_pay_fulfil(array $o, $paymentId) {
    $pdo = db();
    $first = false;
    $pdo->beginTransaction();
    try {
        $u = $pdo->prepare("UPDATE rzp_orders SET status='paid', rzp_payment_id=?, paid_at=NOW() WHERE id=? AND status<>'paid'");
        $u->execute([$paymentId, $o['id']]);
        if ($u->rowCount() === 1) {
            $first = true;
            if ($o['kind'] === 'plan') {
                $plan = get_plan((int)$o['plan_id']);
                if (!$plan) throw new RuntimeException('Plan missing');
                $expiry = date('Y-m-d', strtotime('+' . (int)$plan['validity_days'] . ' days'));
                $pdo->prepare("UPDATE users SET plan_id=?, plan_name=?, plan_expiry=?, plan_coins=? WHERE id=?")
                    ->execute([$plan['id'], $plan['plan_name'], $expiry, (int)($plan['plan_bonus_coins'] ?? 0), $o['user_id']]);
            } else {
                $pdo->prepare("UPDATE users SET tripo_coins = tripo_coins + ? WHERE id=?")->execute([(int)$o['coins'], $o['user_id']]);
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('rzp_pay_fulfil failed for order ' . $o['id'] . ': ' . $e->getMessage());
        return false;
    }
    if ($first) { // show the sale in Admin > Dashboard revenue (best-effort, like api/activate-plan.php does)
        try {
            db()->prepare("INSERT INTO orders (user_id, plan_id, amount, status, cf_order_id, created_at) VALUES (?, ?, ?, 'paid', ?, NOW())")
                ->execute([$o['user_id'], $o['kind'] === 'plan' ? $o['plan_id'] : null, $o['amount'], $o['rzp_order_id']]);
        } catch (Throwable $e) { /* non-fatal */ }
    }
    return true;
}

/** Confirm with Razorpay that this payment is captured for exactly this order & amount, then fulfil. */
function rzp_pay_confirm(array $o, $paymentId) {
    $d = (rzp_fetch_payment($paymentId)['data'] ?? []);
    if (($d['order_id'] ?? '') === $o['rzp_order_id'] && (int)($d['amount'] ?? 0) === (int)round($o['amount'] * 100) && ($d['status'] ?? '') === 'captured') {
        return rzp_pay_fulfil($o, $paymentId) ? 'paid' : 'error';
    }
    return $d['status'] ?? 'unknown';
}
