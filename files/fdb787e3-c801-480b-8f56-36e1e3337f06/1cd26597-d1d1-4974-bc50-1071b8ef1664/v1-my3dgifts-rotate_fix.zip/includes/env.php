<?php
// Tiny .env reader (no Composer needed). Looks for .env in the project root, then one level above it
// (best: keep .env OUTSIDE the web root). Real environment variables win over the file.
function app_env($key, $default = '') {
    static $file = null;
    $v = getenv($key);
    if ($v !== false && $v !== '') return $v;
    if (isset($_ENV[$key]) && $_ENV[$key] !== '') return $_ENV[$key];
    if ($file === null) {
        $file = [];
        foreach ([dirname(__DIR__) . '/.env', dirname(dirname(__DIR__)) . '/.env'] as $path) {
            if (!is_readable($path)) continue;
            foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) continue;
                list($k, $val) = explode('=', $line, 2);
                $file[trim($k)] = trim(trim($val), "\"'");
            }
            break;
        }
    }
    return (isset($file[$key]) && $file[$key] !== '') ? $file[$key] : $default;
}
