<?php
// Creator earnings → Tripo AI coins.
// Until Razorpay Route is approved, a creator's share stays on the platform as a RUPEE balance.
// The creator may move any part of it into Tripo AI coins at the admin-set rate
// (setting: market_rupees_per_tripo_coin). The cash GPay claim comes later, after Razorpay approval.
require_once __DIR__ . '/market.php';

function market_redeem_ensure() {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS market_redemptions (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id     INT UNSIGNED NOT NULL,
            rupees      DECIMAL(10,2) NOT NULL,
            tripo_coins INT UNSIGNED NOT NULL,
            rate        DECIMAL(10,2) NOT NULL,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) { /* retried on next request */ }
}

/** ₹ per 1 Tripo AI coin, as set by the admin. */
function market_redeem_rate() {
    $r = (float) get_setting('market_rupees_per_tripo_coin', '2');
    return $r > 0 ? round($r, 2) : 2.0;
}

/**
 * Creator money still held on the platform (₹).
 * = paid sales not yet paid out  −  amounts already moved to Tripo coins.
 */
function market_claimable_balance($userId, $pdo = null) {
    market_redeem_ensure();
    $pdo = $pdo ?: db();
    $s = $pdo->prepare("SELECT COALESCE((SELECT SUM(creator_amount) FROM market_purchases
                                          WHERE creator_id = ? AND status = 'paid' AND payout_status = 'unpaid'), 0)
                              - COALESCE((SELECT SUM(rupees) FROM market_redemptions WHERE user_id = ?), 0)");
    $s->execute([(int)$userId, (int)$userId]);
    return max(0.0, round((float) $s->fetchColumn(), 2));
}

/**
 * Move `$coins` Tripo coins' worth of the creator's rupee balance into their Tripo AI coins.
 * Returns ['ok' => bool, 'message' => string].
 */
function market_redeem_tripo(array $user, $coins) {
    $coins = (int) $coins;
    if ($coins < 1) return ['ok' => false, 'message' => 'Enter at least 1 Tripo coin.'];

    $rate   = market_redeem_rate();
    $rupees = round($coins * $rate, 2);

    market_redeem_ensure();
    $pdo = db();
    try {
        $pdo->beginTransaction();
        // Lock the user row so two quick clicks cannot spend the same balance twice.
        $pdo->prepare("SELECT id FROM users WHERE id = ? FOR UPDATE")->execute([(int)$user['id']]);
        $bal = market_claimable_balance($user['id'], $pdo);
        if ($rupees > $bal + 0.001) {
            $pdo->rollBack();
            return ['ok' => false, 'message' => 'Not enough balance. You have ₹' . number_format($bal, 2) . ' available.'];
        }
        $pdo->prepare("INSERT INTO market_redemptions (user_id, rupees, tripo_coins, rate) VALUES (?, ?, ?, ?)")
            ->execute([(int)$user['id'], $rupees, $coins, $rate]);
        // Added to the purchased (lifetime) bucket, so these coins never expire.
        $pdo->prepare("UPDATE users SET tripo_coins = tripo_coins + ? WHERE id = ?")
            ->execute([$coins, (int)$user['id']]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('Tripo redeem failed for user ' . $user['id'] . ': ' . $e->getMessage());
        return ['ok' => false, 'message' => 'Could not convert right now. Please try again.'];
    }
    return ['ok' => true, 'message' => $coins . ' Tripo AI coins added to your account (₹' . number_format($rupees, 2) . ' used).'];
}
