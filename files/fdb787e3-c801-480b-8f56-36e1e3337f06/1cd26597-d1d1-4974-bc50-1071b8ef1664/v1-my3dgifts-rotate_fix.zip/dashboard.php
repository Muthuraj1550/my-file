<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/market.php';
require_once __DIR__ . '/includes/market_onboard.php';
require_once __DIR__ . '/includes/market_redeem.php';

require_login();
$user = current_user();
check_and_expire_user($user);

$pwdErrors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    csrf_check();
    $newPwd = $_POST['new_pwd'] ?? '';
    $confPwd = $_POST['conf_pwd'] ?? '';
    if (strlen($newPwd) < 6) {
        $pwdErrors[] = 'New password must be at least 6 characters.';
    } elseif ($newPwd !== $confPwd) {
        $pwdErrors[] = 'Passwords do not match.';
    } else {
        db()->prepare("UPDATE users SET password_hash=? WHERE id=?")
            ->execute([password_hash($newPwd, PASSWORD_DEFAULT), $user['id']]);
        flash('Password updated successfully.');
        redirect('/dashboard.php');
    }
}


// ───────── Earn Money (templates) actions ─────────
$mkReady = market_ready();
if ($mkReady && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['setup_payout'])) {
        csrf_check();
        if (!market_paid_enabled()) { flash('Payout setup opens when paid templates are enabled.', 'error'); }
        else { $r = market_onboard_creator($user, $_POST); flash($r['message'], $r['ok'] ? 'success' : 'error'); }
        redirect('/dashboard.php#earnings');
    }
    if (isset($_POST['redeem_tripo'])) {
        csrf_check();
        if (!market_enabled()) { flash('Earn Money is turned off.', 'error'); }
        else { $r = market_redeem_tripo($user, $_POST['coins'] ?? 0); flash($r['message'], $r['ok'] ? 'success' : 'error'); }
        redirect('/dashboard.php#earnings');
    }
    if (isset($_POST['update_template'])) {
        csrf_check();
        $price = round((float)($_POST['price'] ?? 0), 2);
        if (!market_paid_enabled()) {
            flash('Paid templates are not enabled yet — all templates are free for now.', 'error');
        } elseif ($price < 0 || ($price > 0 && $price < 1) || $price > market_max_price()) {
            flash('Price must be between 0 and ₹' . market_max_price() . '.', 'error');
        } else {
            // Price applies to future buyers only; people who already paid keep access.
            $u = db()->prepare("UPDATE market_templates SET price = ? WHERE id = ? AND user_id = ?");
            $u->execute([$price, (int)$_POST['template_id'], $user['id']]);
            flash('Template price updated.');
        }
        redirect('/dashboard.php#earnings');
    }
    if (isset($_POST['delete_template'])) {
        csrf_check();
        $q = db()->prepare("SELECT * FROM market_templates WHERE id = ? AND user_id = ?");
        $q->execute([(int)$_POST['template_id'], $user['id']]);
        if ($t = $q->fetch()) {
            $c = db()->prepare("SELECT COUNT(*) FROM market_purchases WHERE template_id = ? AND status = 'paid'");
            $c->execute([$t['id']]);
            if ((int)$c->fetchColumn() > 0) flash('A template that has been purchased cannot be deleted.', 'error');
            else { market_delete_files($t); db()->prepare("DELETE FROM market_templates WHERE id = ?")->execute([$t['id']]); flash('Template deleted.'); }
        }
        redirect('/dashboard.php#earnings');
    }
}

$daysLeft  = plan_days_left($user);
$renewDays = (int) get_setting('renew_days_before', 5);
$planCoins      = (int)($user['plan_coins'] ?? 0);
$purchasedCoins = (int)($user['tripo_coins'] ?? 0);

$pageTitle = 'My Dashboard';
include __DIR__ . '/includes/header.php';
?>
<h1>Welcome, <?php echo h($user['name']); ?></h1>

<?php if ($mkReady && market_enabled()):
  $mkBalTop  = market_claimable_balance($user['id']);
  $mkRateTop = market_redeem_rate(); ?>
<div class="flash" style="background:rgba(59,130,246,.12);border:1px solid #1d4ed8;color:#bfdbfe;">
  🔔 Your creator earnings: <b>₹<?php echo number_format($mkBalTop, 2); ?></b>.
  You can convert this into <b>Tripo AI coins</b> now (1 coin = ₹<?php echo number_format($mkRateTop, 2); ?>).
  Cash payout to your GPay will be available after Razorpay approval.
  <a href="#earnings" style="color:#fff;text-decoration:underline;">Convert now →</a>
</div>
<?php endif; ?>

<div class="stat-row">
  <div class="stat-box"><div class="num"><?php echo h($user['plan_name'] ?: 'Free'); ?></div><div class="lbl">Current Plan</div></div>
  <div class="stat-box"><div class="num"><?php echo $daysLeft >= 0 ? $daysLeft . 'd' : 'Expired'; ?></div><div class="lbl">Days Remaining</div></div>
  <div class="stat-box" style="background:linear-gradient(135deg,#3b82f622,#60a5fa22);border:1px solid #3b82f6;">
    <div class="num" style="color:#60a5fa;">🪙 <?php echo $planCoins; ?></div>
    <div class="lbl">Plan Coins (monthly)</div>
  </div>
  <div class="stat-box" style="background:linear-gradient(135deg,#f59e0b22,#fbbf2422);border:1px solid #f59e0b;">
    <div class="num" style="color:#fbbf24;">🪙 <?php echo $purchasedCoins; ?></div>
    <div class="lbl">Purchased Coins (lifetime)</div>
  </div>
</div>

<?php if ($daysLeft >= 0 && $daysLeft <= $renewDays): ?>
  <div class="flash flash-error">Your plan expires in <?php echo $daysLeft; ?> day(s). <a href="<?php echo SITE_URL; ?>/membership.php">Renew now</a> to avoid interruption.</div>
<?php endif; ?>

<div class="card">
  <h3>Manage Membership</h3>
  <p>Plan expiry date: <strong><?php echo h($user['plan_expiry']); ?></strong></p>
  <a href="<?php echo SITE_URL; ?>/membership.php" class="btn">View / Upgrade Plans</a>
  &nbsp;
  <a href="<?php echo SITE_URL; ?>/designer" class="btn btn-outline">Open 3D Designer</a>
</div>


<?php if ($mkReady && market_enabled()):
  $creator = market_creator($user['id']);
  $tot = market_creator_totals($user['id']);
  $q = db()->prepare("SELECT t.*, (SELECT COUNT(*) FROM market_purchases p WHERE p.template_id = t.id AND p.status='paid') AS sales,
                             (SELECT COALESCE(SUM(creator_amount),0) FROM market_purchases p WHERE p.template_id = t.id AND p.status='paid') AS earned
                      FROM market_templates t WHERE t.user_id = ? ORDER BY t.created_at DESC");
  $q->execute([$user['id']]);
  $myTpls = $q->fetchAll();
?>
<style>
.dm-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:14px 0;}
.dm-stat{background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:14px;text-align:center;}
.dm-stat b{display:block;font-size:22px;color:var(--gold);}
.dm-thumb{width:64px;height:48px;object-fit:cover;border-radius:6px;background:#0b1120;display:block;}
.dm-wrap{overflow-x:auto;}
.dm-price{display:flex;gap:6px;align-items:center;}
.dm-price input{width:90px;margin:0;padding:7px 9px;}
.st-pending{background:rgba(245,158,11,.18);color:#fcd34d}.st-approved{background:rgba(34,197,94,.15);color:#86efac}.st-rejected{background:rgba(239,68,68,.15);color:#fca5a5}
</style>
<div class="card" id="earnings">
  <h3 style="margin-top:0;">💰 My Templates<?php echo market_paid_enabled() ? ' &amp; Earnings' : ''; ?></h3>
  <?php $paidOn = market_paid_enabled(); $isLinked = isset(market_linked_ids()[(int)$user['id']]); $totUses = array_sum(array_map(function($x){ return (int)$x['use_count']; }, $myTpls)); ?>
  <div class="dm-grid">
    <div class="dm-stat"><b><?php echo count($myTpls); ?></b>Templates</div>
    <div class="dm-stat"><b><?php echo $totUses; ?></b>Total uses</div>
    <?php if ($paidOn || (int)$tot['sales'] > 0): ?>
    <div class="dm-stat"><b>₹<?php echo number_format($tot['total'], 2); ?></b>Total earned</div>
    <div class="dm-stat"><b><?php echo (int)$tot['sales']; ?></b>Sales</div>
    <?php endif; ?>
  </div>
  <?php
    $mkBal = market_claimable_balance($user['id']);
    $mkRate = market_redeem_rate();
    $mkMaxCoins = (int) floor($mkBal / $mkRate + 1e-9);
  ?>
  <div style="border:1px solid var(--border);border-radius:10px;padding:14px;margin:10px 0;">
    <b>🪙 Convert earnings to Tripo AI coins</b>
    <div style="font-size:13px;color:var(--muted);margin:4px 0 10px;">
      Available: <b>₹<?php echo number_format($mkBal, 2); ?></b> · 1 Tripo coin = ₹<?php echo number_format($mkRate, 2); ?> · max <?php echo $mkMaxCoins; ?> coins
    </div>
    <?php if ($mkMaxCoins > 0): ?>
    <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;"><?php echo csrf_field(); ?>
      <input type="number" name="coins" min="1" max="<?php echo $mkMaxCoins; ?>" step="1" value="<?php echo $mkMaxCoins; ?>" style="width:120px;margin:0;">
      <button class="btn btn-sm" name="redeem_tripo" value="1">Convert to Tripo coins</button>
    </form>
    <?php endif; ?>
    <button class="btn btn-sm btn-outline" disabled style="margin-top:8px;opacity:.6;" title="Available after Razorpay approval">💸 Claim cash to GPay (coming soon)</button>
  </div>
  <?php if (!$paidOn): ?>
    <div class="flash" style="background:rgba(34,197,94,.1);border:1px solid #166534;color:#86efac;">🆓 Every template is <b>free</b> for now. Setting your own price will be available once the admin enables paid templates.</div>
  <?php elseif (market_payout_mode($user['id']) === ''): ?>
    <div class="flash" style="background:rgba(245,158,11,.1);border:1px solid #92400e;color:#fcd34d;">Paid templates are enabled, but you have no payout set up yet — your templates stay <b>free</b> until you set up payout below.</div>
  <?php endif; ?>


  <?php if ($paidOn):
      $payMode = market_payout_mode($user['id']);
      $accRow = null;
      if ($payMode === 'auto') { $q2 = db()->prepare("SELECT * FROM market_linked_accounts WHERE user_id = ?"); $q2->execute([$user['id']]); $accRow = $q2->fetch(); }
  ?>
  <h4 style="margin-top:22px;">💸 How you get paid</h4>
  <?php if ($payMode === 'auto'): ?>
    <div class="flash" style="background:rgba(34,197,94,.1);border:1px solid #166534;color:#86efac;">
      ✅ <b>Automatic payout is active</b><?php echo !empty($accRow['payout_label']) ? ' — ' . h($accRow['payout_label']) : ''; ?>. Your <?php echo market_creator_pct(); ?>% share of every sale is sent to your account by Razorpay at the time of sale.
    </div>
  <?php else: ?>
    <details <?php echo $payMode === '' ? 'open' : ''; ?> style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:14px;margin-bottom:12px;">
      <summary style="cursor:pointer;font-weight:700;">⚡ Set up automatic payout (recommended — you get <?php echo market_creator_pct(); ?>%)</summary>
      <p style="color:var(--muted);font-size:13px;">Your details are sent securely to Razorpay for verification. We do <b>not</b> store your PAN or bank details. Needed once, so your share can be transferred to you automatically.</p>
      <form method="post"><?php echo csrf_field(); ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
          <div><label>Full name (exactly as on PAN)</label><input type="text" name="legal_name" required minlength="4" value="<?php echo h($user['name'] ?? ''); ?>"></div>
          <div><label>PAN (individual)</label><input type="text" name="pan" required maxlength="10" placeholder="ABCDE1234F" style="text-transform:uppercase;"></div>
          <div><label>Mobile number</label><input type="text" name="phone" required value="<?php echo h($user['phone'] ?? ''); ?>"></div>
          <div><label>Email</label><input type="email" name="email" required value="<?php echo h($user['email'] ?? ''); ?>"></div>
        </div>
        <label style="margin-top:10px;">Where should we send your money?</label>
        <select name="method" id="pmethod" onchange="document.getElementById('pUpi').style.display=this.value==='upi'?'grid':'none';document.getElementById('pBank').style.display=this.value==='bank'?'grid':'none';">
          <option value="upi">UPI ID</option><option value="bank">Bank account</option>
        </select>
        <div id="pUpi" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
          <div><label>UPI ID</label><input type="text" name="vpa" placeholder="yourname@okhdfcbank"></div>
          <div><label>Name registered on that UPI</label><input type="text" name="upi_name" placeholder="same as PAN name"></div>
        </div>
        <div id="pBank" style="display:none;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;">
          <div><label>Account number</label><input type="text" name="acc_no" autocomplete="off"></div>
          <div><label>IFSC</label><input type="text" name="ifsc" placeholder="HDFC0000317" style="text-transform:uppercase;"></div>
          <div><label>Account holder name</label><input type="text" name="bank_name"></div>
        </div>
        <label style="display:flex;gap:8px;align-items:flex-start;margin-top:12px;"><input type="checkbox" name="tnc" value="1" style="width:auto;margin-top:3px;"> I confirm these details are mine and accept Razorpay's terms for receiving payouts.</label>
        <button class="btn" name="setup_payout" value="1" style="margin-top:8px;">Create payout account</button>
      </form>
    </details>
  <?php endif; ?>
  <?php endif; ?>

  <h4 style="margin-top:22px;">My templates</h4>
  <div class="dm-wrap">
  <table>
    <tr><th></th><th>Template</th><th>Status</th><th>Price (₹)</th><th>Uses</th><th>Sales</th><th>Earned</th><th></th></tr>
    <?php foreach ($myTpls as $t): ?>
    <tr>
      <td><?php if ($t['thumb_file']): ?><img class="dm-thumb" src="<?php echo h(market_thumb_url($t)); ?>" alt=""><?php endif; ?></td>
      <td><b><?php echo h($t['title']); ?></b>
        <?php if ($t['status']==='rejected' && $t['reject_reason']): ?><br><small style="color:#fca5a5">❌ <?php echo h($t['reject_reason']); ?></small><?php endif; ?></td>
      <td><span class="badge st-<?php echo h($t['status']); ?>"><?php echo $t['status']==='pending'?'⏳ Pending':($t['status']==='approved'?'✅ Live':'❌ Rejected'); ?></span><?php if ($t['auto_approved']): ?> <small>(auto)</small><?php endif; ?></td>
      <td>
        <?php if (!$paidOn): ?>
          <span style="color:#86efac;">🆓 Free</span>
        <?php else: ?>
        <form method="post" class="dm-price"><?php echo csrf_field(); ?>
          <input type="hidden" name="template_id" value="<?php echo (int)$t['id']; ?>">
          <input type="number" name="price" min="0" max="<?php echo market_max_price(); ?>" step="1" value="<?php echo h((float)$t['price']); ?>" title="0 = Free">
          <button class="btn btn-sm" name="update_template" value="1">Update</button>
        </form>
        <?php endif; ?>
      </td>
      <td><?php echo (int)$t['use_count']; ?></td>
      <td><?php echo (int)$t['sales']; ?></td>
      <td>₹<?php echo number_format($t['earned'], 2); ?></td>
      <td><?php if ((int)$t['sales'] === 0): ?>
        <form method="post" onsubmit="return confirm('Delete this template?')"><?php echo csrf_field(); ?>
          <input type="hidden" name="template_id" value="<?php echo (int)$t['id']; ?>">
          <button class="btn btn-danger btn-sm" name="delete_template" value="1">🗑</button></form>
      <?php endif; ?></td>
    </tr>
    <?php endforeach; if (!$myTpls): ?>
    <tr><td colspan="8" style="color:var(--muted);text-align:center;padding:22px;">No templates yet. Design something in the 3D Designer and click <b>🚀 Post &amp; Earn</b>.</td></tr>
    <?php endif; ?>
  </table>
  </div>
  <p style="color:var(--muted);font-size:13px;margin-bottom:0;">
    <?php if ($paidOn): ?>Set the price to 0 to make a template free. A price change applies to new buyers only. Your share of each sale is <?php echo market_creator_pct(); ?>%, sent to your account automatically by Razorpay.<?php endif; ?>
    <?php $n = market_auto_after(); if ($n > 0): ?> After <?php echo $n; ?> approved templates, your new templates are approved automatically (approved so far: <?php echo market_approved_count($user['id']); ?>).<?php endif; ?>
  </p>
  <p style="margin-bottom:0;"><a class="btn btn-outline btn-sm" href="<?php echo SITE_URL; ?>/earn.php">Browse Earn Money marketplace →</a></p>
</div>
<?php endif; ?>

<div class="card" style="max-width:420px;">
  <h3>Change Password</h3>
  <?php foreach ($pwdErrors as $e): ?><div class="flash flash-error"><?php echo h($e); ?></div><?php endforeach; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>New Password</label>
    <input type="password" name="new_pwd" required>
    <label>Confirm New Password</label>
    <input type="password" name="conf_pwd" required>
    <button type="submit" name="change_password" class="btn btn-block">Update Password</button>
  </form>
</div>

<p><a href="<?php echo SITE_URL; ?>/logout.php" class="btn btn-danger btn-sm">Logout</a></p>

<?php include __DIR__ . '/includes/footer.php'; ?>
