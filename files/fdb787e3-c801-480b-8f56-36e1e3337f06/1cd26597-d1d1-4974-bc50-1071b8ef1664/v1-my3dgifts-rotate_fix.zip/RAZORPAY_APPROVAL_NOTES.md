# Razorpay approval notes — My 3D Gifts template marketplace (my3dgifts.com)

Use this document when you apply for the Razorpay account / **Route** (marketplace split payments).
Copy the "Business description" and "Money flow" text into the application or send it to the Razorpay support / onboarding team.

---

## 1. Business description (paste-ready)

> My 3D Gifts (my3dgifts.com) is an online platform for 3D-printing design tools. Registered users design customisable 3D models in our browser-based 3D Designer. Users can publish their own design templates to our marketplace, either free or at a price they set (₹0–₹999). Other users can use a template inside the Designer; paid templates are unlocked after an online payment. The product is a **digital file (template) delivered instantly online** — no physical goods are shipped by us for marketplace purchases.
> Template creators earn a fixed percentage of each sale (default 70%); the platform keeps the remainder as its commission.

## 2. Money flow — split method (paste-ready)

> We use **Razorpay Route**. We do not collect creators' money into our own account and pay it out manually.
>
> 1. The buyer pays the full price on our website through Razorpay Checkout.
> 2. When we create the Razorpay Order we pass a `transfers` array: one transfer to the **creator's linked account** for the creator's share (e.g. 70% of the price) — the remaining amount (platform commission) stays with our account.
> 3. On successful capture, Razorpay transfers the creator's share to the creator's linked account automatically and settles it to the creator's own bank account. No manual payout is involved.
> 4. Each creator is onboarded as a **linked account** on Razorpay Route and completes their own KYC/bank verification with Razorpay. We do not store creators' bank, PAN or card details.
> 5. Settlement to creators can optionally be put on hold (`on_hold` / `on_hold_until`, configurable 0–30 days) to cover the refund window; transfers can be reversed for refunds.
> 6. Payment is confirmed on our server by verifying the Razorpay signature and fetching the payment from the Razorpay API, plus a webhook (`payment.captured`, `order.paid`) as a backup.

Example (price ₹200, creator share 70%):
`order amount = 20000 paise` → `transfers[0] = { account: "acc_xxxx", amount: 14000, currency: "INR", on_hold: false }` → creator receives ₹140, platform keeps ₹60 (before Razorpay fees).

## 3. Things Razorpay usually checks on the website (do these before applying)

Have these pages live and linked in the footer of **my3dgifts.com**:

- [ ] **Terms & Conditions** — marketplace rules, creator responsibilities, commission %, who owns the template content, prohibited content (no copyrighted/trademarked designs, no weapons, etc.)
- [ ] **Privacy Policy**
- [ ] **Refund & Cancellation Policy** — state clearly the policy for digital templates (e.g. "non-refundable once unlocked, except if the file is faulty/not delivered; refund requests within X days"). Match the `hold days` you choose.
- [ ] **Contact Us** — real address, phone, e-mail
- [ ] **Shipping/Delivery policy** — "digital delivery, instant after payment"
- [ ] Prices shown in INR on the Earn Money / template pages
- [ ] Business PAN / GST (if applicable), bank account, website ownership proof — as per Razorpay's KYC
- [ ] Working login + a test template Razorpay's reviewer can open (create a free test template and one paid test template)

## 4. Honest notes / risks

- **Route is enabled separately.** Normal Razorpay approval does not automatically include Route. Ask Razorpay (dashboard → Route, or support) to activate it for a marketplace; they may ask for the description above, sample creators, and your refund/dispute process.
- **Automatic split is the default.** Creator shares move through Razorpay Route to each creator's own linked account, created from the creator's Dashboard (PAN + UPI/bank, verified by Razorpay; we store none of it).  There is no manual payout option.
- **Fees:** Razorpay's gateway fee (and any Route transfer fee) is charged to your account on the whole payment. The creator share is calculated on the **gross price**, so those fees come out of your commission. Check Razorpay's current pricing and set the creator % accordingly.
- **A creator can sell only after you link their Razorpay account.** If a transfer cannot be created the order is not started (no money is taken).
- **Currency:** Route supports INR only.
- User-uploaded designs: keep the approval step ON for new creators — it is also your protection against copyrighted/illegal models.

## 5. Technical setup (when Razorpay approves you)

1. Razorpay Dashboard → Settings → API Keys → generate **Live** key. 
2. Dashboard → Developers → Webhooks → add `https://my3dgifts.com/razorpay-webhook.php`, events **payment.captured** and **order.paid**, choose a secret.
3. my3dgifts Admin → **Earn Money → ⚙️ Paid templates (Razorpay)**: enter Key ID, Key Secret, Webhook secret → **Test Razorpay keys**.
4. Dashboard → Route → create a **linked account** for each creator → copy `acc_…` into Admin → Earn Money → **Creators & splits**.
5. Tick **Enable paid templates** and save. Do one real ₹1–₹10 template test purchase between two accounts and check: purchase shows paid, the sale appears in Creators & splits, and the transfer is visible in Razorpay → Route → Transfers.

## 6. Until Razorpay is approved

Leave **Enable paid templates** OFF (the default). All templates are free, users cannot set a price, and no payment of any kind is taken on my3dgifts.com. Nothing else is needed.
