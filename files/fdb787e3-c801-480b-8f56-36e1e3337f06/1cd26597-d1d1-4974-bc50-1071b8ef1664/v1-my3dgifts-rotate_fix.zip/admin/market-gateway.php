<?php
$adminTitle = 'Earn Money — Paid templates (Razorpay)';
require_once __DIR__ . '/_layout_top.php';
require_once __DIR__ . '/../includes/market.php';
require_once __DIR__ . '/../includes/razorpay.php';
if (!market_ready()) { echo '<div class="card">Run <b>migration-marketplace.sql</b> first.</div>'; require __DIR__ . '/_layout_bottom.php'; exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (isset($_POST['save_gateway'])) {
        set_setting('rzp_key_id', trim($_POST['rzp_key_id'] ?? ''));
        if (trim($_POST['rzp_key_secret'] ?? '') !== '')     set_setting('rzp_key_secret', trim($_POST['rzp_key_secret']));
        if (trim($_POST['rzp_webhook_secret'] ?? '') !== '') set_setting('rzp_webhook_secret', trim($_POST['rzp_webhook_secret']));
        set_setting('rzp_hold_days', max(0, min(30, (int)($_POST['rzp_hold_days'] ?? 0))));
        $want = isset($_POST['market_paid_enabled']);
        if ($want && !rzp_configured()) { $want = false; flash('Enter the Razorpay Key ID and Key Secret before enabling paid templates.', 'error'); }
        elseif ($want && trim((string)get_setting('rzp_webhook_secret', '')) === '') { $want = false; flash('Set the Razorpay webhook secret before enabling paid templates.', 'error'); }
        else flash($want ? 'Saved. Paid templates are ON — creators with a linked account can now set prices.' : 'Saved. Paid templates are OFF — every template is free.');
        set_setting('market_paid_enabled', $want ? '1' : '0');
    }
    if (isset($_POST['test_rzp'])) {
        if (!rzp_configured()) flash('Enter Razorpay key id + secret first.', 'error');
        else { $r = rzp_api('GET', '/orders?count=1'); flash($r['code'] === 200 ? 'Razorpay keys work ✅' : 'Razorpay error: ' . $r['error'], $r['code'] === 200 ? 'success' : 'error'); }
    }
    redirect('/admin/market-gateway.php');
}
$on = get_setting('market_paid_enabled', '0') === '1';
?>
<a class="btn btn-sm btn-outline" href="market.php">← Templates</a>
<form method="post" class="card" style="margin-top:12px;"><?php echo csrf_field(); ?>
  <h3 style="margin-top:0;">Paid templates</h3>
  <p style="color:var(--muted);">Right now every template is <b>free</b> and users cannot set a price. Turn this on <b>only after Razorpay (with Route) is approved</b>. Money is collected by Razorpay and the creator's share is split automatically to the creator's own Razorpay linked account — this site never collects money to pass on later.</p>
  <label style="font-size:15px;"><input type="checkbox" name="market_paid_enabled" value="1" <?php echo $on ? 'checked' : ''; ?>>
    <b>Enable paid templates</b> — status: <?php echo $on ? '<span style="color:#86efac">ON</span>' : '<span style="color:#fca5a5">OFF (all free)</span>'; ?></label>
  <p style="color:var(--muted);font-size:13px;">Even when ON, a template is sold only if its creator has a Razorpay linked account saved (Creators &amp; splits page); otherwise it stays free.</p>

  <h4>Razorpay</h4>
  <?php if (app_env('RAZORPAY_KEY_ID') !== ''): ?>
    <p style="color:#86efac;font-size:13px;">🔐 Active keys (<?php echo rzp_is_test() ? '<b>TEST mode</b> — no real money' : '<b>LIVE mode</b>'; ?>). Keys saved below take priority over <code>.env</code>.</p>
  <?php endif; ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;">
    <div><label>Key ID</label><input type="text" name="rzp_key_id" value="<?php echo h(rzp_key_id()); ?>" placeholder="rzp_live_xxxxx"></div>
    <div><label>Key Secret <?php echo rzp_key_secret() ? '(set ✔)' : ''; ?></label><input type="password" name="rzp_key_secret" autocomplete="new-password" placeholder="leave blank to keep"></div>
    <div><label>Webhook secret <?php echo get_setting('rzp_webhook_secret','') ? '(set ✔)' : ''; ?></label><input type="password" name="rzp_webhook_secret" autocomplete="new-password" placeholder="leave blank to keep"></div>
  </div>
  <label>Hold creator settlement for N days (refund window, 0 = no hold)</label>
  <input type="number" name="rzp_hold_days" min="0" max="30" value="<?php echo (int)get_setting('rzp_hold_days', 0); ?>" style="max-width:120px;">
  <p style="color:var(--muted);font-size:13px;">Webhook URL for Razorpay Dashboard → Webhooks: <code><?php echo h(SITE_URL); ?>/razorpay-webhook.php</code> — events <b>payment.captured</b> and <b>order.paid</b>.</p>

  <button class="btn" name="save_gateway" value="1">Save</button>
  <button class="btn btn-outline" name="test_rzp" value="1">Test Razorpay keys</button>
</form>
<?php require __DIR__ . '/_layout_bottom.php'; ?>
