<?php
$adminTitle = 'Settings';
require_once __DIR__ . '/_layout_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    set_setting('cashfree_mode', $_POST['cashfree_mode'] === 'production' ? 'production' : 'sandbox');
    set_setting('cashfree_app_id', trim($_POST['cashfree_app_id']));
    set_setting('cashfree_secret_key', trim($_POST['cashfree_secret_key']));
    set_setting('cashfree_api_version', trim($_POST['cashfree_api_version']) ?: '2023-08-01');
    // Razorpay (plans, coins & marketplace). Secrets are kept when the field is left blank.
    set_setting('payments_gateway', ($_POST['payments_gateway'] ?? '') === 'razorpay' ? 'razorpay' : 'course_site');
    set_setting('rzp_key_id', trim($_POST['rzp_key_id'] ?? ''));
    if (trim($_POST['rzp_key_secret'] ?? '') !== '')     set_setting('rzp_key_secret', trim($_POST['rzp_key_secret']));
    if (trim($_POST['rzp_webhook_secret'] ?? '') !== '') set_setting('rzp_webhook_secret', trim($_POST['rzp_webhook_secret']));
    set_setting('renew_days_before', (int)$_POST['renew_days_before']);
    set_setting('gemini_api_key', trim($_POST['gemini_api_key']));
    set_setting('tripo_api_key', trim($_POST['tripo_api_key']));
    set_setting('tripo_cost_per_generation', max(1, (int)($_POST['tripo_cost_per_generation'] ?? 10)));
    set_setting('tripo_image_cost_per_generation', max(1, (int)($_POST['tripo_image_cost_per_generation'] ?? 15)));
    set_setting('tripo_coin_charge_mode', ($_POST['tripo_coin_charge_mode'] ?? 'markup') === 'fixed' ? 'fixed' : 'markup');
    set_setting('tripo_coin_markup', max(0, (int)($_POST['tripo_coin_markup'] ?? 5)));
    set_setting('coin_price_inr', max(0.01, (float)($_POST['coin_price_inr'] ?? 1)));
    set_setting('coin_min_purchase', max(1, (int)($_POST['coin_min_purchase'] ?? 10)));
    set_setting('site_tagline', trim($_POST['site_tagline']));
    set_setting('plans_redirect_enabled', isset($_POST['plans_redirect_enabled']) ? '1' : '0');
    set_setting('plans_redirect_url', trim($_POST['plans_redirect_url'] ?? ''));
    set_setting('plan_limits_expand_enabled', isset($_POST['plan_limits_expand_enabled']) ? '1' : '0');
    // Keep guests unrestricted — the daily AI-designs limit UI has been removed.
    set_setting('guest_ai_daily_limit', 99999);
    set_setting('github_templates_token', trim($_POST['github_templates_token'] ?? ''));
    set_setting('github_templates_free_repo', trim($_POST['github_templates_free_repo'] ?? '') ?: 'Muthuraj1550/free-Template');
    set_setting('github_templates_premium_repo', trim($_POST['github_templates_premium_repo'] ?? '') ?: 'Muthuraj1550/paid-template');
    flash('Settings saved.');
    redirect('/admin/settings.php');
}
?>
<div class="card" style="max-width:640px;">
  <h3>Cashfree Payment Gateway</h3>
  <p style="color:var(--muted);font-size:13px;">
    Get your keys from the <a href="https://merchant.cashfree.com/" target="_blank">Cashfree Merchant Dashboard</a>
    → Developers → API Keys. Use the <strong>Test/Sandbox</strong> keys first, then switch mode to
    Production with your live keys when you're ready to accept real payments.
    Webhook URL to configure in Cashfree dashboard: <code><?php echo SITE_URL; ?>/payment-webhook.php</code>
  </p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Mode</label>
    <select name="cashfree_mode">
      <option value="sandbox" <?php echo get_setting('cashfree_mode')==='sandbox'?'selected':''; ?>>Sandbox (Test)</option>
      <option value="production" <?php echo get_setting('cashfree_mode')==='production'?'selected':''; ?>>Production (Live)</option>
    </select>
    <label>App ID (Client ID)</label>
    <input type="text" name="cashfree_app_id" value="<?php echo h(get_setting('cashfree_app_id')); ?>">
    <label>Secret Key (Client Secret)</label>
    <input type="text" name="cashfree_secret_key" value="<?php echo h(get_setting('cashfree_secret_key')); ?>">
    <label>API Version</label>
    <input type="text" name="cashfree_api_version" value="<?php echo h(get_setting('cashfree_api_version', '2023-08-01')); ?>">

    <h3 style="margin-top:30px;">Razorpay Payment Gateway</h3>
    <?php require_once __DIR__ . '/../includes/razorpay.php'; ?>
    <p style="color:var(--muted);font-size:13px;">
      Get keys from <a href="https://dashboard.razorpay.com/app/keys" target="_blank">Razorpay Dashboard → Account &amp; Settings → API Keys</a>
      (Test keys start with <code>rzp_test_</code>, Live keys with <code>rzp_live_</code>).
      Webhook URL: <code><?php echo SITE_URL; ?>/razorpay-webhook.php</code> — events <b>payment.captured</b> and <b>order.paid</b>.
    </p>
    <?php if (app_env('RAZORPAY_KEY_ID') !== ''): ?>
      <p style="color:#86efac;font-size:13px;">🔐 Active keys: <?php echo rzp_is_test() ? 'TEST mode' : 'LIVE mode'; ?> — keys saved below take priority; the server <code>.env</code> file is only a fallback.</p>
    <?php endif; ?>
    <label>Razorpay Key ID</label>
    <input type="text" name="rzp_key_id" value="<?php echo h(get_setting('rzp_key_id')); ?>" placeholder="rzp_live_xxxxxxxxxxxx">
    <label>Razorpay Key Secret <?php echo get_setting('rzp_key_secret') ? '<small style="color:#86efac">(saved ✔ — leave blank to keep)</small>' : ''; ?></label>
    <input type="password" name="rzp_key_secret" autocomplete="new-password" placeholder="<?php echo get_setting('rzp_key_secret') ? '••••••••••••' : 'paste Key Secret'; ?>">
    <label>Webhook secret <?php echo get_setting('rzp_webhook_secret') ? '<small style="color:#86efac">(saved ✔ — leave blank to keep)</small>' : ''; ?></label>
    <input type="password" name="rzp_webhook_secret" autocomplete="new-password" placeholder="same secret you typed in the Razorpay webhook">
    <label>Payment gateway for Membership Plans &amp; Coin purchases</label>
    <select name="payments_gateway">
      <option value="razorpay" <?php echo get_setting('payments_gateway','course_site')==='razorpay'?'selected':''; ?>>Razorpay — pay directly on this site (no redirect)</option>
      <option value="course_site" <?php echo get_setting('payments_gateway','course_site')!=='razorpay'?'selected':''; ?>>Course site billing (old redirect to the course/design site)</option>
    </select>
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">
      Razorpay mode uses the plan prices from Admin → Plans and the <b>₹ per coin</b> / <b>minimum coins</b> set in the “Tripo AI Coins” section below.
      It needs the Razorpay keys above (or in <code>.env</code>) — otherwise the old redirect stays in use.
    </p>

    <h3 style="margin-top:30px;">Membership Plans Redirect (Course Site)</h3>
    <p style="color:var(--muted);font-size:13px;">
      Indha site la paid plans innum ready illana, <b>ON</b> pannunga — user "Upgrade / Plans"
      click panna, course site oda purchase page kku pogum. <b>OFF</b> pannina, normal
      <code>membership.php</code> plan page kaatum.
    </p>
    <label style="display:flex;align-items:center;gap:8px;">
      <input type="checkbox" name="plans_redirect_enabled" value="1" style="width:auto;"
             <?php echo get_setting('plans_redirect_enabled','0')==='1'?'checked':''; ?>>
      <span>Redirect ON</span>
    </label>
    <label>Course site purchase / plans URL</label>
    <input type="text" name="plans_redirect_url" placeholder="https://mycourse.com/products.php"
           value="<?php echo h(get_setting('plans_redirect_url','')); ?>">

    <h3 style="margin-top:30px;">Membership Plan Card Details (visitor-facing)</h3>
    <p style="color:var(--muted);font-size:13px;">
      Membership plans page (membership.php) la ஒவ்வொரு plan card-லயும் cloud storage slots, monthly Tripo coins
      போன்ற limit details தற்போது நேரடியா காட்டும். இந்த toggle ON பண்ணினா, அந்த details ஒரு ▾ arrow-க்கு பின்னாடி
      collapse ஆகி, click பண்ணா தான் expand ஆகி காட்டும் ("இந்த plan வாங்கினா இவை எல்லாம் கிடைக்கும்" ஸ்டைல்).
    </p>
    <p style="color:var(--muted);font-size:12px;">
      தற்போதைக்கு <strong>OFF</strong>-ஆ வையுங்க — இப்போ இருக்கிற plain display தான் ஓகே. Future-ல ஒரு சில options-ஐ
      ஒரு சில plans-க்கு மட்டும்னு restrict பண்ணும்போது, இதை ON பண்ணி அந்த plan-க்கு என்ன எல்லாம் கிடைக்கும்னு
      arrow-ல list பண்ணலாம்.
    </p>
    <label style="display:flex;align-items:center;gap:8px;">
      <input type="checkbox" name="plan_limits_expand_enabled" value="1" style="width:auto;"
             <?php echo get_setting('plan_limits_expand_enabled','0')==='1'?'checked':''; ?>>
      <span>Show plan limit details behind an expand/collapse arrow</span>
    </label>

    <h3 style="margin-top:30px;">AI Designer</h3>
    <label><strong>Tripo AI API Key</strong> (PRIMARY — text/image → 3D generation, from <a href="https://developers.tripo3d.ai/en/keys" target="_blank">developers.tripo3d.ai</a>)</label>
    <input type="text" name="tripo_api_key" value="<?php echo h(get_setting('tripo_api_key')); ?>" placeholder="sk-...">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Tripo AI-ஐ தான் 3D generation-க்கு use பண்றோம். இந்த key server-ல மட்டும் இருக்கும், browser-க்கு அனுப்பப்படாது.</p>
    <label style="margin-top:14px;">Gemini API Key <span style="color:#94a3b8;font-weight:normal;">(optional / legacy — Tripo AI use ஆவதால் இது required இல்ல)</span></label>
    <input type="text" name="gemini_api_key" value="<?php echo h(get_setting('gemini_api_key')); ?>" placeholder="AIza... (optional)">

    <h3 style="margin-top:30px;">Tripo AI Coins</h3>

    <div style="background:#0a0f1e;border:1px solid #f59e0b;border-radius:8px;padding:12px;margin-bottom:16px;">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
        <div>
          <div style="font-size:11px;color:#fbbf24;text-transform:uppercase;font-weight:bold;letter-spacing:1px;">Tripo API Account Balance</div>
          <div style="font-size:12px;color:var(--muted);margin-top:2px;">Tripo AI-ல் நம்முடைய API key-க்கு எவ்வளவு credits மீதி இருக்கு என்று செக் பண்ணலாம் (இது site users-க்கான coins இல்ல — Tripo account-ல் இருக்கும் actual balance).</div>
        </div>
        <button type="button" id="tripoAcctCheckBtn" onclick="checkTripoAccountBalance()" style="width:auto;background:linear-gradient(135deg,#f59e0b,#fbbf24);color:#111;font-weight:bold;padding:9px 16px;">Check Balance</button>
      </div>
      <div id="tripoAcctBalanceResult" style="margin-top:10px;font-size:13px;color:#e2e8f0;"></div>
    </div>

    <label>Coins per Tripo generation (fallback flat cost)</label>
    <input type="number" min="1" name="tripo_cost_per_generation" value="<?php echo h(get_setting('tripo_cost_per_generation', 10)); ?>">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Text → 3D. Tripo spend info கிடைக்காத சூழலில் (அல்லது "Fixed" mode கீழே தேர்ந்தால்) இந்த coins தான் ஒரு generation-க்கு charge ஆகும்.</p>

    <label style="margin-top:14px;">Coins per Image → 3D generation (fallback flat cost)</label>
    <input type="number" min="1" name="tripo_image_cost_per_generation" value="<?php echo h(get_setting('tripo_image_cost_per_generation', 15)); ?>">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Image → 3D uploads usually cost more on Tripo's side than text prompts — set this separately.</p>

    <label style="margin-top:14px;">Coin charging mode</label>
    <select name="tripo_coin_charge_mode" id="tripoChargeModeSel" onchange="toggleTripoChargeModeFields()">
      <option value="markup" <?php echo get_setting('tripo_coin_charge_mode','markup')==='markup'?'selected':''; ?>>Tripo actual spend + Markup (dynamic — recommended)</option>
      <option value="fixed" <?php echo get_setting('tripo_coin_charge_mode','markup')==='fixed'?'selected':''; ?>>Fixed total coins per generation (ignore actual Tripo spend)</option>
    </select>

    <div id="tripoMarkupFieldWrap">
      <label>Markup coins (added on top of actual Tripo credits spent)</label>
      <input type="number" min="0" name="tripo_coin_markup" value="<?php echo h(get_setting('tripo_coin_markup', 5)); ?>">
      <p style="color:var(--muted);font-size:12px;margin-top:-10px;">
        Example: ஒரு generation-க்கு Tripo actual-ஆ 20 credits spend ஆனா, user-க்கு (20 + இந்த markup) coins debit ஆகும்.
      </p>
    </div>
    <script>
      function toggleTripoChargeModeFields(){
        var mode = document.getElementById('tripoChargeModeSel').value;
        document.getElementById('tripoMarkupFieldWrap').style.display = (mode === 'markup') ? 'block' : 'none';
      }
      document.addEventListener('DOMContentLoaded', toggleTripoChargeModeFields);

      function checkTripoAccountBalance(){
        var btn = document.getElementById('tripoAcctCheckBtn');
        var out = document.getElementById('tripoAcctBalanceResult');
        btn.disabled = true; btn.textContent = 'Checking...';
        out.innerHTML = '<span style="color:var(--muted);">Tripo API-யை contact பண்றோம்...</span>';
        fetch('tripo-account-balance.php', { credentials: 'include' })
          .then(function(r){ return r.json(); })
          .then(function(d){
            if (d && d.ok) {
              out.innerHTML = '<strong style="color:#22c55e;">Balance: ' + d.balance + '</strong>'
                + (d.frozen ? ' &nbsp;|&nbsp; Frozen: ' + d.frozen : '')
                + '<div style="font-size:11px;color:var(--muted);margin-top:4px;">Source: ' + (d.source || '') + '</div>';
            } else {
              out.innerHTML = '<span style="color:#ef4444;">❌ ' + (d && (d.message || d.detail || d.error) || 'Balance check failed') + '</span>';
            }
          })
          .catch(function(e){ out.innerHTML = '<span style="color:#ef4444;">❌ Network error: ' + e.message + '</span>'; })
          .finally(function(){ btn.disabled = false; btn.textContent = 'Check Balance'; });
      }
    </script>

    <label style="margin-top:14px;">Price per coin (₹)</label>
    <input type="number" min="0.01" step="0.01" name="coin_price_inr" value="<?php echo h(get_setting('coin_price_inr', '1')); ?>">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">Used on the membership page for the "Buy Coins" custom-amount box.</p>
    <label>Minimum coin purchase</label>
    <input type="number" min="1" name="coin_min_purchase" value="<?php echo h(get_setting('coin_min_purchase', '10')); ?>">

    <h3 style="margin-top:30px;">General</h3>
    <label>Site Tagline (shown on homepage)</label>
    <input type="text" name="site_tagline" value="<?php echo h(get_setting('site_tagline')); ?>">
    <label>Show Renew Reminder (days before expiry)</label>
    <input type="number" name="renew_days_before" value="<?php echo h(get_setting('renew_days_before', 5)); ?>">

    <h3 style="margin-top:30px;">3D Designer — GitHub Templates</h3>
    <p style="color:var(--muted);font-size:13px;">
      "See Full Templates" popup (Designer-ல) இந்த இரண்டு GitHub repos-லேர்ந்து தான் free + paid template
      XML files-ஐ காட்டும். இங்க token கொடுத்தா, Designer-ல் <strong>admin login பண்ணி</strong> இருக்கும்போது,
      current project-ஐ direct-ஆ "Save Current Project to GitHub" button மூலமா இந்த repo-க்கு push பண்ணலாம்
      (matching thumbnail image-உம் automatic-ஆ upload ஆகும்).
    </p>
    <label>GitHub Personal Access Token <span style="color:#94a3b8;font-weight:normal;">(needs "Contents: Read and write" permission on both repos below)</span></label>
    <input type="text" name="github_templates_token" value="<?php echo h(get_setting('github_templates_token')); ?>" placeholder="ghp_...">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">
      Create at <a href="https://github.com/settings/tokens?type=beta" target="_blank">github.com/settings/tokens</a> (fine-grained,
      repo access limited to the 2 template repos below). Server-side மட்டும் use ஆகும், browser-க்கு அனுப்பப்படாது.
    </p>
    <label style="margin-top:14px;">Free Templates repo</label>
    <input type="text" name="github_templates_free_repo"
           value="<?php echo h(get_setting('github_templates_free_repo', 'Muthuraj1550/free-Template')); ?>"
           placeholder="owner/repo">
    <label>Premium Templates repo</label>
    <input type="text" name="github_templates_premium_repo"
           value="<?php echo h(get_setting('github_templates_premium_repo', 'Muthuraj1550/paid-template')); ?>"
           placeholder="owner/repo">
    <p style="color:var(--muted);font-size:12px;margin-top:-10px;">
      "owner/repo" format-ல் மட்டும் போடுங்க (எ.கா. <code>Muthuraj1550/free-Template</code>) — full github.com URL
      கொடுத்தாலும் பரவாயில்ல, தானாகவே பிரித்துக்கும். Repo default branch <code>main</code>-ஆ இருக்கணும்.
    </p>

    <button type="submit" class="btn">Save Settings</button>
  </form>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
