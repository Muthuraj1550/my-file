<?php
$adminTitle = 'Creators & automatic splits (Razorpay Route)';
require_once __DIR__ . '/_layout_top.php';
require_once __DIR__ . '/../includes/market.php';
if (!market_ready()) { echo '<div class="card">Run migration-marketplace.sql first.</div>'; require __DIR__ . '/_layout_bottom.php'; exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_acc'])) {
    csrf_check();
    $uid = (int)$_POST['user_id']; $acc = trim($_POST['acc'] ?? '');
    if ($acc === '') { db()->prepare("DELETE FROM market_linked_accounts WHERE user_id=?")->execute([$uid]); flash('Linked account removed — this creator\'s templates are free again.'); }
    elseif (preg_match('/^acc_[A-Za-z0-9]{8,30}$/', $acc)) {
        db()->prepare("INSERT INTO market_linked_accounts (user_id, razorpay_account_id) VALUES (?,?) ON DUPLICATE KEY UPDATE razorpay_account_id=VALUES(razorpay_account_id)")->execute([$uid, $acc]);
        flash('Linked account saved. This creator can now sell paid templates (when paid templates are enabled).');
    } else flash('Linked account id looks like acc_XXXXXXXXXXXXXX.', 'error');
    redirect('/admin/market-payouts.php');
}

$creators = db()->query("SELECT u.id, u.name, u.email, la.razorpay_account_id AS acc, la.source AS acc_source, la.payout_label,
                           (SELECT COUNT(*) FROM market_templates t WHERE t.user_id=u.id AND t.status='approved') live
                         FROM users u LEFT JOIN market_linked_accounts la ON la.user_id=u.id
                         WHERE EXISTS (SELECT 1 FROM market_templates t WHERE t.user_id=u.id) ORDER BY live DESC, u.name")->fetchAll();
$sales = db()->query("SELECT p.created_at, p.amount, p.creator_amount, p.gateway_payment_id, p.payout_status, p.payout_ref, p.split_auto,
                             t.title, b.name AS buyer, c.name AS creator
                      FROM market_purchases p JOIN market_templates t ON t.id=p.template_id
                      JOIN users b ON b.id=p.buyer_id JOIN users c ON c.id=p.creator_id
                      WHERE p.status='paid' ORDER BY p.id DESC LIMIT 100")->fetchAll();
?>
<a class="btn btn-sm btn-outline" href="market.php">← Templates</a>
<a class="btn btn-sm btn-outline" href="market-gateway.php">⚙️ Paid templates / Razorpay</a>
<h3>🔗 Creators — Razorpay linked accounts</h3>
<p style="color:var(--muted);font-size:13px;">Create each creator as a <b>linked account</b> in Razorpay Dashboard → Route (the creator completes their own KYC there), then paste the <code>acc_…</code> id. On every paid sale Razorpay splits their share to that account automatically. Creators without a linked account keep their templates free.</p>
<table>
  <tr><th>Creator</th><th>Live templates</th><th>Linked account (acc_…)</th></tr>
  <?php foreach ($creators as $c): ?>
  <tr><td><?php echo h($c['name']); ?><br><small style="color:var(--muted)"><?php echo h($c['email']); ?></small></td>
      <td><?php echo (int)$c['live']; ?></td>
      <td><?php if (!empty($c['acc'])): ?><small style="color:#86efac;"><?php echo ($c['acc_source'] ?? '') === 'auto' ? 'Self-onboarded' : 'Added by admin'; ?><?php echo !empty($c['payout_label']) ? ' · ' . h($c['payout_label']) : ''; ?></small><?php endif; ?>
        <form method="post" style="display:flex;gap:6px;"><?php echo csrf_field(); ?><input type="hidden" name="user_id" value="<?php echo (int)$c['id']; ?>">
        <input type="text" name="acc" value="<?php echo h($c['acc'] ?? ''); ?>" placeholder="acc_XXXXXXXXXXXXXX" style="margin:0;"><button class="btn btn-sm" name="save_acc" value="1">Save</button></form></td></tr>
  <?php endforeach; if (!$creators): ?><tr><td colspan="3" style="color:var(--muted);text-align:center;">No creators yet.</td></tr><?php endif; ?>
</table>
<h3>🧾 Paid sales</h3>
<table>
  <tr><th>Date</th><th>Template</th><th>Buyer</th><th>Creator</th><th>Amount</th><th>Creator share</th><th>Payout</th><th>Payment id</th></tr>
  <?php foreach ($sales as $x): ?><tr><td><?php echo h($x['created_at']); ?></td><td><?php echo h($x['title']); ?></td><td><?php echo h($x['buyer']); ?></td><td><?php echo h($x['creator']); ?></td>
    <td>₹<?php echo number_format($x['amount'],2); ?></td><td>₹<?php echo number_format($x['creator_amount'],2); ?></td>
    <td><?php echo $x['split_auto'] ? '⚡ Auto-split' : '— (test, no split)'; ?></td><td><small><?php echo h($x['gateway_payment_id']); ?></small></td></tr>
  <?php endforeach; if (!$sales): ?><tr><td colspan="8" style="color:var(--muted);text-align:center;">No paid sales yet.</td></tr><?php endif; ?>
</table>
<?php require __DIR__ . '/_layout_bottom.php'; ?>
