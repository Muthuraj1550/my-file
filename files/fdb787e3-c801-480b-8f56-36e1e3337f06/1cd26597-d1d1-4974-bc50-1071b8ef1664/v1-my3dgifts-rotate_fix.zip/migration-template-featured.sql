-- =========================================================
--  Admin templates — "⭐ Featured" mark
--
--  The admin can star a Free / Paid GitHub template inside the designer's
--  "See Full Templates" popup. Starred templates show in the one-row
--  "Featured Templates" section on the home page.
--
--  Run once (phpMyAdmin). Safe to re-run.
-- =========================================================
CREATE TABLE IF NOT EXISTS template_featured (
    kind          ENUM('free','premium') NOT NULL,
    template_name VARCHAR(190) NOT NULL,
    featured_at   DATETIME NULL,
    PRIMARY KEY (kind, template_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
