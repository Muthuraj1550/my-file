<?php
// A logged-in user posts the current designer project as a marketplace template.
// Called through designer.php's postMessage relay (same-origin, session cookie).
require_once __DIR__ . '/../includes/market.php';
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');

function out($a) { echo json_encode($a); exit; }

if (!market_enabled())              out(['ok'=>false,'error'=>'disabled','message'=>'The Earn Money feature is currently turned off.']);
if (!is_logged_in())                out(['ok'=>false,'error'=>'login_required','message'=>'Please log in.']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); out(['ok'=>false,'error'=>'method']); }

$len = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
$ini = trim(ini_get('post_max_size')); $max = (int)$ini * (stripos($ini,'g')!==false ? 1073741824 : (stripos($ini,'m')!==false ? 1048576 : 1024));
if ($max > 0 && $len > $max) out(['ok'=>false,'error'=>'too_large','message'=>'Template exceeds the server upload limit (post_max_size). Use a smaller custom font.']);

$u    = current_user();
$body = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $body['action'] ?? 'submit';

// ---- status: what the Post & Earn popup should show ----
if ($action === 'status') {
    out(['ok'=>true, 'paid_enabled'=>market_paid_enabled(), 'linked'=>isset(market_linked_ids()[(int)$u['id']]),
         'max_price'=>market_max_price(), 'pct'=>market_creator_pct(),
         'auto'=>market_should_auto_approve($u['id']), 'auto_after'=>market_auto_after(),
         'tutorial'=>market_tutorial_url()]);
}

$title = sanitize_plain_text($body['title'] ?? '', 120);
$desc  = sanitize_plain_text($body['description'] ?? '', 500);
// Until the admin enables paid templates (after Razorpay approval) every template is free.
$price = market_paid_enabled() ? round((float)($body['price'] ?? 0), 2) : 0.0;
$xml   = (string)($body['xml'] ?? '');
$thumb = (string)($body['thumbnail'] ?? '');

if ($title === '' || mb_strlen($title) < 3) out(['ok'=>false,'error'=>'title','message'=>'Template name is required (at least 3 characters).']);
if ($price < 0 || ($price > 0 && $price < 1) || $price > market_max_price()) out(['ok'=>false,'error'=>'price','message'=>'Price must be between 0 and ₹' . market_max_price() . '.']);
if (strlen($xml) < 50 || strpos($xml, '<project') === false) out(['ok'=>false,'error'=>'xml','message'=>'The project is empty or invalid.']);
if (strlen($xml) > market_max_bytes()) out(['ok'=>false,'error'=>'too_large','message'=>'Template is ' . round(strlen($xml)/1048576,1) . ' MB. Maximum is ' . (market_max_bytes()/1048576) . ' MB.']);
// Other users load this XML in their editor — never allow embedded script/HTML payloads.
if (preg_match('/<\s*script|javascript:|on(error|load|click)\s*=/i', $xml)) out(['ok'=>false,'error'=>'unsafe','message'=>'The template contains disallowed code.']);

// ---- simple anti-flood: max 10 pending per user ----
$s = db()->prepare("SELECT COUNT(*) FROM market_templates WHERE user_id = ? AND status = 'pending'");
$s->execute([$u['id']]);
if ((int)$s->fetchColumn() >= 10) out(['ok'=>false,'error'=>'too_many_pending','message'=>'You already have 10 templates waiting for approval.']);

// ---- save files on OUR server ----
$rand = bin2hex(random_bytes(8));
$xmlFile = 't_' . $rand . '.xml';
if (file_put_contents(market_dir() . '/' . $xmlFile, $xml, LOCK_EX) === false) out(['ok'=>false,'error'=>'write','message'=>'Could not save on the server (check storage/ folder permissions).']);

$thumbFile = '';
if ($thumb !== '' && preg_match('/^data:image\/(png|jpe?g|webp);base64,(.+)$/', $thumb, $m)) {
    $bytes = base64_decode($m[2], true);
    if ($bytes !== false && strlen($bytes) < 1500000 && @getimagesizefromstring($bytes)) {
        $ext = strtolower($m[1]) === 'jpeg' ? 'jpg' : strtolower($m[1]);
        $thumbFile = 'p_' . $rand . '.' . $ext;
        file_put_contents(market_dir() . '/' . $thumbFile, $bytes, LOCK_EX);
    }
}

$auto   = market_should_auto_approve($u['id']);
$status = $auto ? 'approved' : 'pending';
db()->prepare("INSERT INTO market_templates (user_id, title, description, price, status, auto_approved, xml_file, thumb_file, size_bytes, approved_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, " . ($auto ? 'NOW()' : 'NULL') . ")")
    ->execute([$u['id'], $title, $desc, $price, $status, $auto ? 1 : 0, $xmlFile, $thumbFile, strlen($xml)]);

out(['ok'=>true, 'status'=>$status, 'id'=>(int)db()->lastInsertId(),
     'message'=> $auto ? '✅ Your template is live (auto-approved)!' : '✅ Submitted! It will go live after admin approval.']);
