<?php
// Approved community templates for the designer's "See Full Templates" popup.
require_once __DIR__ . '/../includes/market.php';
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');
if (!market_enabled()) { echo json_encode(['ok'=>true,'items'=>[]]); exit; }

$uid = is_logged_in() ? (int)$_SESSION['uid'] : 0;
$rows = db()->query("SELECT t.id, t.title, t.description, t.price, t.use_count, t.user_id, t.thumb_file, u.name AS creator
                     FROM market_templates t JOIN users u ON u.id = t.user_id
                     WHERE t.status = 'approved' ORDER BY t.use_count DESC, t.approved_at DESC LIMIT 300")->fetchAll();
$owned = [];
if ($uid) {
    $s = db()->prepare("SELECT DISTINCT template_id FROM market_purchases WHERE buyer_id = ? AND status = 'paid'");
    $s->execute([$uid]);
    $owned = array_flip(array_map('intval', $s->fetchAll(PDO::FETCH_COLUMN)));
}
$items = [];
foreach ($rows as $r) {
    $eff = market_row_price($r);
    $items[] = [
        'id' => (int)$r['id'], 'name' => $r['title'], 'desc' => $r['description'],
        'price' => $eff, 'uses' => (int)$r['use_count'],
        'creator' => $r['creator'], 'thumb' => market_thumb_url($r),
        'unlocked' => ($eff <= 0) || isset($owned[(int)$r['id']]) || (int)$r['user_id'] === $uid,
    ];
}
echo json_encode(['ok'=>true, 'items'=>$items]);
