<?php
// Serves a template thumbnail (approved ones to everyone; own / any for admin).
require_once __DIR__ . '/../includes/market.php';
require_once __DIR__ . '/../includes/auth.php';
$id = (int)($_GET['id'] ?? 0);
$s = db()->prepare("SELECT * FROM market_templates WHERE id = ?");
$s->execute([$id]);
$t = $s->fetch();
$uid = is_logged_in() ? (int)$_SESSION['uid'] : 0;
if (!$t || !$t['thumb_file'] || ($t['status'] !== 'approved' && !is_admin() && (int)$t['user_id'] !== $uid)) { http_response_code(404); exit; }
$path = market_dir() . '/' . basename($t['thumb_file']);
if (!is_file($path)) { http_response_code(404); exit; }
$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
header('Content-Type: ' . ($ext === 'png' ? 'image/png' : ($ext === 'webp' ? 'image/webp' : 'image/jpeg')));
header('Cache-Control: public, max-age=86400');
readfile($path);
