<?php
// Returns a template's XML if the caller may use it:
//   free  -> everyone (guests too)    paid -> creator, admin, or a buyer who has paid.
// Otherwise answers payment_required with the price. Counts the "use".
require_once __DIR__ . '/../includes/market.php';
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');

$body = json_decode(file_get_contents('php://input'), true) ?: [];
$id   = (int)($body['id'] ?? ($_GET['id'] ?? 0));
$s = db()->prepare("SELECT * FROM market_templates WHERE id = ?");
$s->execute([$id]);
$t = $s->fetch();
$uid = is_logged_in() ? (int)$_SESSION['uid'] : 0;

if (!$t || ($t['status'] !== 'approved' && !is_admin() && (int)$t['user_id'] !== $uid)) {
    echo json_encode(['ok'=>false,'error'=>'not_found','message'=>'Template not found.']); exit;
}
$price = market_row_price($t);   // 0 while paid templates are not enabled
$can = $price <= 0 || is_admin() || (int)$t['user_id'] === $uid || ($uid && market_user_owns($uid, $id));
if (!$can) {
    if (!$uid) { echo json_encode(['ok'=>false,'error'=>'login_required','price'=>$price,'message'=>'This is a paid template — please log in and pay to use it.']); exit; }
    echo json_encode(['ok'=>false,'error'=>'payment_required','price'=>$price,'name'=>$t['title'],'id'=>$id]); exit;
}
$path = market_dir() . '/' . basename($t['xml_file']);
if (!is_file($path)) { echo json_encode(['ok'=>false,'error'=>'file_missing','message'=>'Template file is missing — please contact the admin.']); exit; }

if ($t['status'] === 'approved' && (int)$t['user_id'] !== $uid && !is_admin()) market_count_use($id);
echo json_encode(['ok'=>true,'name'=>$t['title'],'xml'=>file_get_contents($path)]);
