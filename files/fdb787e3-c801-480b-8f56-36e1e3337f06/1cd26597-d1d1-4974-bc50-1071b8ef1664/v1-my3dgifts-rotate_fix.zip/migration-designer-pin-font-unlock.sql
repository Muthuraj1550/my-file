-- =========================================================
--  Custom Parameter panel — Premium Font Lock/Unlock switch
--
--  Right-side Custom Parameters now work for EVERYONE (size, move, rotate,
--  scale, bend, offset, extrude, array ...). Only the FONT parameter is
--  lock-based:
--    * 🔒 LOCKED   -> free/guest users get free fonts + the one premium font
--                     that was baked into the template.
--    * 🔓 UNLOCKED -> everyone can use ALL premium fonts on that parameter.
--
--  This adds ONE row: who may flip that 🔒/🔓 switch. Set it on
--  Admin -> Designer Access -> "Fonts" group -> "Pinned Font Lock/Unlock
--  switch" (tick Allowed for premium plans). Default = fully_locked, so
--  nobody but admin accounts can flip it until you tick a plan.
--
--  Run AFTER migration-designer-feature-gate-v11.sql. Safe to re-run.
-- =========================================================
INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order) VALUES
('pin_font_unlock', 'Pinned Font Lock/Unlock switch (premium creators)', 'fully_locked', 275);
