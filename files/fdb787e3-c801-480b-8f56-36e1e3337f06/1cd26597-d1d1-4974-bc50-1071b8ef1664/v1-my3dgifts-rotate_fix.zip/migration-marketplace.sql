-- =========================================================
--  MIGRATION: "Earn Money" Template Marketplace
--  Users post templates from the designer ("Post & Earn"),
--  admin approves, other users use them (free or paid),
--  admin pays creators manually by UPI.
--  Run once in phpMyAdmin. Safe to re-run.
-- =========================================================

CREATE TABLE IF NOT EXISTS market_creators (
    user_id       INT UNSIGNED NOT NULL,
    upi_number    VARCHAR(40) NOT NULL,
    confirmed_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS market_templates (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id       INT UNSIGNED NOT NULL,
    title         VARCHAR(120) NOT NULL,
    description   VARCHAR(500) NOT NULL DEFAULT '',
    price         DECIMAL(10,2) NOT NULL DEFAULT 0,          -- 0 = free
    status        ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    reject_reason VARCHAR(255) NOT NULL DEFAULT '',
    auto_approved TINYINT(1) NOT NULL DEFAULT 0,
    use_count     INT UNSIGNED NOT NULL DEFAULT 0,
    xml_file      VARCHAR(80) NOT NULL,                      -- file inside /storage/market/
    thumb_file    VARCHAR(80) NOT NULL DEFAULT '',
    size_bytes    INT UNSIGNED NOT NULL DEFAULT 0,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approved_at   DATETIME NULL,
    last_used_at  DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_status_use (status, use_count),
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row per paid purchase (also tracks the creator's payout)
CREATE TABLE IF NOT EXISTS market_purchases (
    id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    template_id    INT UNSIGNED NOT NULL,
    buyer_id       INT UNSIGNED NOT NULL,
    creator_id     INT UNSIGNED NOT NULL,
    amount         DECIMAL(10,2) NOT NULL,
    creator_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    cf_order_id    VARCHAR(60) NOT NULL,
    status         ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
    payout_status  ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',
    payout_ref     VARCHAR(80) NOT NULL DEFAULT '',
    gateway            VARCHAR(20) NOT NULL DEFAULT 'cashfree',   -- cashfree | cashfree_bridge | razorpay
    gateway_order_id   VARCHAR(60) NOT NULL DEFAULT '',
    gateway_payment_id VARCHAR(60) NOT NULL DEFAULT '',
    split_auto         TINYINT(1) NOT NULL DEFAULT 0,             -- 1 = Razorpay Route paid the creator automatically
    paid_out_at    DATETIME NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_order (cf_order_id),
    KEY idx_buyer_tpl (buyer_id, template_id, status),
    KEY idx_creator_payout (creator_id, status, payout_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Razorpay Route linked account per creator (admin pastes acc_xxx)
CREATE TABLE IF NOT EXISTS market_linked_accounts (
    user_id INT UNSIGNED NOT NULL,
    razorpay_account_id VARCHAR(40) NOT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Header menu link
INSERT INTO menu_items (label, url, sort_order, is_active)
SELECT * FROM (SELECT '💰 Earn Money' AS label, '/earn.php' AS url, 5 AS sort_order, 1 AS is_active) t
WHERE NOT EXISTS (SELECT 1 FROM menu_items WHERE url = '/earn.php');
