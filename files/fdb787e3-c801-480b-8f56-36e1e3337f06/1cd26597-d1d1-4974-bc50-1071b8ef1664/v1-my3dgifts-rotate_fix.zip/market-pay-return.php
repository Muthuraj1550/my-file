<?php
// Buyer lands here after paying. We NEVER trust the browser: every path verifies server-side
// (Razorpay: HMAC signature + payment lookup from the Razorpay API; webhook is a backup).
require_once __DIR__ . '/includes/market.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/razorpay.php';
require_login('/login.php');
market_ready();

$ok = false; $msg = 'Order not found.'; $p = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (empty($_POST['razorpay_order_id']) || empty($_POST['razorpay_payment_id']) || empty($_POST['razorpay_signature']))) {
    http_response_code(400);                       // missing fields
    $msg = 'Missing payment details.';
} elseif (!empty($_POST['razorpay_order_id'])) {
    // ---- Razorpay Checkout callback ----
    $rOrder = (string)$_POST['razorpay_order_id']; $rPay = (string)($_POST['razorpay_payment_id'] ?? ''); $rSig = (string)($_POST['razorpay_signature'] ?? '');
    $s = db()->prepare("SELECT * FROM market_purchases WHERE gateway = 'razorpay' AND gateway_order_id = ? AND buyer_id = ?");
    $s->execute([$rOrder, $_SESSION['uid']]);
    $p = $s->fetch();
    if ($p) {
        if ($p['status'] === 'paid') { $ok = true; $msg = 'Payment was already confirmed.'; }
        elseif (!rzp_verify_checkout_signature($rOrder, $rPay, $rSig)) { http_response_code(400); /* signature mismatch: NOT marked paid */ $msg = 'Payment signature could not be verified. If money was deducted, contact support — it will be reconciled.'; }
        else {
            $pay = rzp_fetch_payment($rPay);
            $d = $pay['data'] ?? [];
            if (($d['order_id'] ?? '') === $rOrder && (int)($d['amount'] ?? 0) === (int)round($p['amount'] * 100) && in_array($d['status'] ?? '', ['captured'], true)) {
                market_mark_paid($p['id'], $rPay);
                $ok = true; $msg = 'Payment successful! Template unlocked.';
            } else { $msg = 'Payment is still being confirmed (' . h($d['status'] ?? 'unknown') . '). Refresh in a minute — it unlocks automatically.'; }
        }
    }
}
$pageTitle = 'Payment';
include __DIR__ . '/includes/header.php';
?>
<div class="wrap" style="max-width:520px;margin:40px auto;text-align:center;">
  <div class="card">
    <h2><?php echo $ok ? '✅' : 'ℹ️'; ?> <?php echo $msg; ?></h2>
    <?php if ($ok && $p): ?>
      <a class="btn" href="<?php echo SITE_URL; ?>/designer.php?market=<?php echo (int)$p['template_id']; ?>">🎨 Open in Designer</a>
    <?php else: ?>
      <a class="btn btn-outline" href="<?php echo SITE_URL; ?>/designer.php">← Designer</a>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
