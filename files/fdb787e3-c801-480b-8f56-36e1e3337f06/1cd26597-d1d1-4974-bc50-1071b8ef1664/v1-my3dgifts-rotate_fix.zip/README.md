# My 3D Gifts - Standalone Platform (WordPress இல்லாமல்)

இது உங்க my3dgifts.com-க்கு WordPress இல்லாமல் இயங்கும் full PHP + MySQL website.
Login/Register, Membership Plans (Cashfree payment), Admin Panel (Posts/Pages/Plans/Members),
AI Usage Control, மற்றும் உங்க 3D Designer tool எல்லாம் இதுல ஒன்றாக integrate ஆகி இருக்கு.

---

## 1. Hosting Requirements (cPanel/shared hosting-ல் இருக்கணும்)

- PHP 7.4 அல்லது அதுக்கு மேல (8.x recommended)
- MySQL / MariaDB database
- PHP extensions: `pdo_mysql`, `curl`, `mbstring` (எல்லா cPanel hosting-லயும் default-ஆ இருக்கும்)
- SSL (https) - Cashfree-க்கு https அவசியம்

## 2. Database Setup

1. cPanel → **MySQL Databases** → புது database create பண்ணுங்க (e.g. `my3dgifts_db`)
2. புது DB user create பண்ணி, அந்த DB-க்கு "All Privileges" கொடுங்க
3. cPanel → **phpMyAdmin** → அந்த database-ஐ select பண்ணி → **Import** → `db.sql` file-ஐ upload பண்ணுங்க

இது தானாகவே create பண்ணும்:
- Default Free/Silver/Gold membership plans
- Default admin login: **admin@my3dgifts.com / Admin@123** ⚠️ **உடனே இதை மாத்துங்க**
Admin Panel → **My Account** page-ல் இருந்தே name/email/password மாத்திடலாம் (SQL edit தேவை இல்ல).

> **ஏற்கனவே இந்த site-ஐ ஒரு தடவை live பண்ணி db.sql import பண்ணி இருந்தீங்கன்னா** (இப்போ Analytics
> feature புதுசா சேர்த்திருக்கேன்), முழுசா `db.sql`-ஐ மறுபடியும் import பண்ண வேண்டாம் — அதனால old data
> போயிடும். அதுக்கு பதிலா `migration-content-views.sql` file-ஐ மட்டும் phpMyAdmin-ல் import பண்ணுங்க,
> அது `content_views` table-ஐ மட்டும் புதுசா add பண்ணும்.
>
> **Designer usage tracking + admin-editable menu புதுசா சேர்த்திருக்கேன்னா** (இந்த round-ல),
> `migration-designer-menu.sql`-ஐயும் இதே மாதிரி import பண்ணுங்க — இது `content_views.content_type`
> column-ஐ 'designer' track பண்ண widen பண்ணும், மற்றும் `menu_items` table-ஐ (existing menu-ஐ
> அப்படியே seed பண்ணி) புதுசா add பண்ணும்.
>
> **Guest Designer access + Homepage Customizer + SEO/Button fields புதுசா சேர்த்திருக்கேன்னா**
> (இந்த round-ல), `migration-guest-seo-homepage.sql`-ஐ import பண்ணுங்க — இது:
> - `ai_usage_log.user_id`-ஐ nullable ஆக்கி `guest_id` column சேர்க்கும் (login இல்லாம designer use பண்ணுறவங்களுக்கு)
> - `posts` / `pages` table-ல SEO (meta title/description) + CTA button fields சேர்க்கும்
> - Homepage customizer settings (hero title/buttons/custom HTML/SEO) seed பண்ணும்
>
> ⚠️ இந்த migration file-ல `ADD COLUMN IF NOT EXISTS` syntax பயன்படுத்தி இருக்கேன் — பழைய MySQL
> (5.7-க்கு கீழ) version-ல இது வேலை செய்யாம போகலாம். Error வந்தா, அந்த ஒரு line-ல இருந்து
> "IF NOT EXISTS" வார்த்தையை மட்டும் நீக்கிட்டு மறுபடியும் run பண்ணுங்க.
>
> **Popup Notification + Top Scrolling Text புதுசா சேர்த்திருக்கேன்னா** (இந்த round-ல),
> `migration-announcements.sql`-ஐ import பண்ணுங்க — இது settings-ல் புது keys மட்டும் seed பண்ணும்
> (existing data-ஐ தொடாது, safe).
>
> **Content Block Builder (Image/Paragraph/HTML blocks) + Custom Form Builder + Footer Page Links
> புதுசா சேர்த்திருக்கேன்னா** (இந்த round-ல), இரண்டு migration files import பண்ணுங்க:
> - `migration-footer-pages.sql` — `pages` table-ல `show_in_footer` column சேர்க்கும். இது run
>   ஆனா பிறகு, Admin → Pages-ல் "About" / "Contact Us" போன்ற pages-ஐ edit பண்ணி "Show in site
>   footer" checkbox-ஐ tick பண்ணுங்க — அப்போ footer-ல automatic-ஆ button link வந்துடும்.
> - `migration-custom-forms.sql` — `forms` மற்றும் `form_submissions` புது tables சேர்க்கும்.
>   இது run ஆனா பிறகு Admin sidebar-ல் புது **Forms** menu வரும் — அங்க field builder-ல் Name,
>   Email, Phone, Text, Dropdown, Textarea fields வச்சு form create பண்ணி, அந்த form-ஐ
>   `[form id=X]` shortcode-ஆ (அல்லது content builder-ல "+ Form" block-ஆ) எந்த Page/Post-ல்ல
>   வேணும்னாலும் paste பண்ணிடலாம். Submit ஆன entries அதே Forms பக்கத்திலேயே "View Submissions"-ல் காணும்.
>
> Admin → Pages/Posts-ல் இப்போ Content field ஒரு **block builder**-ஆ maறிடுச்சு — "+ Image",
> "+ Paragraph", "+ HTML" (எ.கா. download button, custom title) buttons வச்சு வரிசையா blocks
> சேர்க்கலாம், up/down arrows வச்சு reorder பண்ணலாம். ஏற்கனவே இருக்குற content (எ.கா. Contact Us
> பக்கத்துல இருக்குற ஒரே பெரிய paragraph) தானாகவே ஒரு editable HTML block-ஆ காட்டும் — அத
> சுத்தி Image/Paragraph blocks சேர்த்துக்கலாம். இதுக்கு எந்த migration தேவை இல்ல, ஆனா image
> block-ல upload பண்ண Admin login தேவை.

## 3. File Upload

1. இந்த zip-ல உள்ள எல்லா files/folders-ஐயும் உங்க domain-ன public_html (அல்லது subdomain folder) க்குள் FTP/File Manager மூலம் upload பண்ணுங்க.
2. `/uploads/` folder-க்கு **write permission (755 அல்லது 775)** கொடுங்க — post/page featured images இங்க save ஆகும்.

## 4. config.php Edit பண்ணுங்க

`config.php` file-ல் நீங்க கொடுத்த DB credentials (`mydgifts_editor` DB name/user, password) ஏற்கனவே
நான் போட்டு வச்சிருக்கேன், மேலும் ஒரு புது random `APP_SECRET` generate பண்ணி வச்சிருக்கேன் — கூடுதலா
நீங்க எதுவும் மாத்த வேண்டியதில்ல. மட்டும் இதை சரிபாருங்க:

```php
define('DB_HOST', 'localhost');   // உங்க hosting-ல வேற மாதிரி இருந்தா மாத்துங்க
define('SITE_URL', 'https://my3dgifts.com');   // trailing slash வேண்டாம்

define('APP_DEBUG', false);   // site live ஆனதும் (testing முடிஞ்சதும்) false ஆ மாத்துங்க
```

## 5. Cashfree Payment Setup (Sandbox முதலில்)

1. https://merchant.cashfree.com/ - இல் account create பண்ணுங்க (already இருந்தா login)
2. **Developers → API Keys → Test/Sandbox keys** எடுங்க (App ID + Secret Key)
3. Site-ல் `/admin/settings.php` க்கு போய் அந்த keys-ஐ paste பண்ணுங்க, Mode: **Sandbox**
4. Cashfree Dashboard-ல் **Webhooks** section-ல் இந்த URL-ஐ add பண்ணுங்க:
   `https://my3dgifts.com/payment-webhook.php`
5. Sandbox mode-ல ஒரு test plan வாங்கி பாருங்க (Cashfree test cards: https://docs.cashfree.com/docs/test-credit-card-details)
6. எல்லாம் சரியா வேலை செஞ்சா, Cashfree-ல் **Live/Production keys** வாங்கி, Mode: **Production**-ஆ மாத்துங்க

## 6. Gemini AI Key (உங்க Designer tool-க்கு)

`/admin/settings.php` → "Gemini API Key" field-ல் உங்க Google Gemini API key-ஐ (AIza... எண்ணுல ஆரம்பிக்கும்) போடுங்க.
இது Designer tool-க்கு பின்னணியில automatic-ஆ pass ஆகும் (உங்க HTML file-ல key hardcode பண்ண வேண்டாம்).

## 7. இது என்ன பண்ணுது (Features Overview)

| Feature | File(s) | Notes |
|---|---|---|
| Homepage (customizable) | `index.php`, `admin/homepage.php` | Hero text/buttons, optional custom HTML block, and SEO tags - all editable in Admin > Homepage; recent blog posts show below |
| Register/Login | `register.php`, `login.php` | Session-based auth, bcrypt password |
| Membership Plans + Payment | `membership.php`, `payment-return.php`, `payment-webhook.php` | Cashfree Orders API v3 |
| Member Dashboard | `dashboard.php` | Plan status, renew reminder, password change |
| 3D Designer (open to everyone, full-screen) | `designer.php`, `engine-stream.php`, `protected/engine.html` | **No login required** - opens full-screen (no site header/footer) for guests and members alike; premium templates + higher AI limits unlock with a paid plan; has its own 🏠 Home button to return to the site |
| AI Usage Limits | `api/ai-usage.php` | Guests get a small free daily quota (cookie-tracked); logged-in members get their plan's limit; resets at midnight |
| Blog | `blog.php`, `post.php` | Public posts, with optional SEO tags + a CTA button per post |
| Static Pages | `page.php` | About/Contact etc, auto-shown in top menu, with optional SEO tags + a CTA button per page |
| Admin Panel | `/admin/*` | Homepage, Plans, Members, Posts, Pages, Menu, Analytics, AI Logs, Settings, My Account |
| Analytics (views + time on page) | `admin/analytics.php`, `api/track-view.php` | Top posts/pages by views, total & avg minutes spent, plus 3D Designer usage (sessions + time spent, guests included) |
| Home Page Menu (admin-editable) | `admin/menu.php` | Add/edit/reorder/hide top navigation links, no code editing needed |
| Admin Account Settings | `admin/account.php` | Change admin name/email/password from the panel itself |
| Clean URLs for uploaded .html files | root `.htaccess` | Upload any `page.html` via FTP, link to it as `/page` (no extension) anywhere - `/page.html` auto-redirects to `/page` |
| Popup Notification (offer/announcement) | `admin/announcements.php` | Centered popup with title/message/image/button, configurable delay + repeat frequency |
| Top Scrolling Text (marquee) | `admin/announcements.php` | Thin scrolling announcement bar at the top of every public page, with optional link + custom colors |

## 8. Designer Tool Security Note

உங்க upload பண்ண `.html` designer file-ஐ `/protected/engine.html` -ல் வச்சிருக்கேன்.
அந்த folder-ல `.htaccess` (Apache) மூலம் **direct URL access block** பண்ணி இருக்கேன் —
`engine-stream.php` மூலமா மட்டும் தான் அந்த file serve ஆகும்.

**Designer இப்போ login இல்லாமலேயே எல்லாருக்கும் திறந்திருக்கு** (guest access):
- Login இல்லாதவங்க: Free templates + சின்ன daily AI quota (default 2/day, Admin > Settings-ல் மாத்தலாம் - cookie மூலம் track ஆகும்)
- Login பண்ணி premium plan வாங்கினவங்க: Premium templates + அவங்க plan-ஓட AI limit
இதனால designer page-ஐ யாரும் use பண்ணலாம், ஆனா premium features + அதிக AI generations-க்கு
login/upgrade பண்ணணும்-ன்னு prompt வரும்.

**⚠️ இது Apache/cPanel hosting (.htaccess support) இருந்தா தான் வேலை செய்யும்.** உங்க hosting
Nginx-ஆ இருந்தா, `.htaccess` இல் உள்ள rules-ஐ Nginx config-ல் manually add பண்ணணும்
(உங்க hosting provider support-ஐ கேளுங்க).

## 8.5. Homepage Customizer + SEO/Button fields (புதுசு)

- **Admin → Homepage**: Hero title/subtitle, இரண்டு hero buttons (text+URL தனித்தனியா மாத்தலாம்),
  ஒரு optional custom HTML block (banner/embed/எதுவும் paste பண்ணலாம்), மற்றும் homepage-க்கான
  SEO title/description — எல்லாம் code touch பண்ணாம admin panel-ல் இருந்தே மாத்தலாம்.
- **Admin → Posts / Pages**: ஒவ்வொரு post/page-க்கும் தனியா SEO Title + Meta Description,
  மற்றும் ஒரு Call-to-Action button (text + URL + new tab option) சேர்க்கலாம் — அது content-க்கு
  கீழ ஒரு button-ஆ காட்டும்.
- Homepage-ல் "AI" prominent-ஆ highlight பண்ணாம மாத்தி இருக்கேன் (AI option இன்னும் fully polish
  ஆகாததால) — hero section-ல் இப்போ neutral wording தான் இருக்கு, Admin > Homepage-ல் எப்போ வேணும்னாலும் மாத்தலாம்.

## 8.6. Menu/Button-ல் .html file link கொடுக்கும் போது (clean URL)

Menu item-ஆ இருந்தாலும், Post/Page CTA button-ஆ இருந்தாலும், ஒரு plain `.html` file-ஐ (உங்க own
static promo page, template preview, etc.) நேரடியா FTP/File Manager மூலம் site-ன் root
folder-க்கு (அல்லது எந்த folder-க்கும்) upload பண்ணிட்டு:

1. அந்த file-ஐ `offer.html` -ன்னு பெயர் வச்சு upload பண்ணுங்க
2. Menu/Button URL field-ல் `.html` **இல்லாம** `/offer`-ன்னு மட்டும் போடுங்க

இப்போ யாராவது `/offer` visit பண்ணா `offer.html`-ஐ காட்டும், `.html` extension address bar-ல
தெரியாது. யாராவது தப்பா `/offer.html`-ன்னு direct URL type பண்ணினாலும், அதை தானாகவே `/offer`-க்கு
redirect பண்ணிடும் (root `.htaccess`-ல் இந்த rule சேர்த்திருக்கேன்).

**⚠️ இதுவும் Apache/cPanel hosting (.htaccess + mod_rewrite) இருந்தா தான் வேலை செய்யும்.**

## 8.7. Popup Notification + Top Scrolling Text (Admin → Announcements)

- **Popup Notification**: Title, message, optional image, optional button (text+URL), எவ்வளவு
  நேரம் கழிச்சு காட்டணும் (delay), மற்றும் ஒரு visitor-க்கு எத்தனை மணி நேரத்துக்கு repeat ஆகக்கூடாது
  (frequency) - எல்லாம் admin panel-ல் set பண்ணலாம். Full-screen Designer page-ல் இது காட்டாது.
- **Top Scrolling Text**: ஒரு thin marquee bar site-ன் top-ல், text/link/background color/text
  color/scroll speed எல்லாம் admin panel-ல் மாத்தலாம்.
- இரண்டுமே **default-ஆ OFF** — Admin → Announcements-ல் "Enable" checkbox tick பண்ணி Save
  பண்ணினா தான் site-ல் தெரியும்.

## 9. உங்க Original WordPress Plugins vs இது — என்ன simplify பண்ணி இருக்கேன்

- **Renew/Upgrade logic**: ஒரே plan-ஐ renew பண்ணா, remaining days-ல இருந்து extend ஆகும்.
  வேற plan-க்கு upgrade/downgrade பண்ணா, இன்னிக்கு இருந்து புது validity start ஆகும்
  (partial-day proration இல்ல — உங்க business rule வேற மாதிரி வேணும்னா சொல்லுங்க, மாத்தி தரேன்).
- **GitHub XML Premium Templates**: உங்க designer HTML file-லயே already built-in ஆ
  GitHub free/paid repos-ல இருந்து fetch பண்ணும் logic இருக்கு (`GH_CONFIG.repoUrl` /
  `premiumRepoUrl`). நான் வெறும் `hasAccess: true/false` flag-ஐ மட்டும் அனுப்புறேன் plan-ஐ பொறுத்து —
  repo URLs-ஐ மாத்தணும்னா `designer.php`-ல `hasAccess` flag அனுப்புற இடத்துல
  `repoUrl`/`premiumRepoUrl` fields-ஐயும் சேர்த்து அனுப்பலாம்.
- **Cron-based daily expiry sweep**: தற்போது ஒவ்வொரு login/dashboard/membership visit-லயும்
  அந்த ஒரு user-க்கு expiry check நடக்குது (lightweight, cron தேவை இல்ல). Site-wide daily
  sweep வேணும்னா, cPanel → Cron Jobs-ல ஒரு simple `cron/expire-all.php` file எழுதி
  தினமும் ஓட வைக்கலாம் (கேட்டா அதையும் சேர்த்து தரேன்).


## 10. Next Steps பரிந்துரை

1. Sandbox-ல எல்லாம் test பண்ணுங்க (register → buy plan → dashboard-ல plan update ஆகுதான்னு பாருங்க)
2. Default admin password மாத்துங்க
3. Blog posts/pages உங்க content போட்டு publish பண்ணுங்க
4. Live-ஆனதும் Cashfree production keys + APP_DEBUG=false மாத்துங்க

## 11. இந்த Round-ல Fix + புது Features (Bug fixes, Cloud Save, Theme, Mobile, Tripo AI)

**⚠️ இதுக்கு 2 migration files run பண்ணணும் (phpMyAdmin-ல, ஏற்கனவே இருக்கும் data பாதிக்காது):**
1. `migration-guest-seo-homepage.sql` — ஏற்கனவே சேர்த்திருந்தது, ஆனா run ஆகாததால `admin/usage.php` fatal error கொடுத்துச்சு. இப்போ run பண்ணலனாலும் crash ஆகாது (auto-fallback பண்ணும்), ஆனா guest unique-visitor count சரியா வர இதை run பண்ணுங்க.
2. `migration-cloud-projects.sql` — புதுசு, Cloud Project Save/Recovery-க்காக.

- **AI Usage Logs fatal error** – Fixed. Migration run ஆகாதவரை "Migration Pending" notice மட்டும் காட்டும், crash ஆகாது.
- **Gold + Purple Theme** – `assets/css/style.css` முழுசா recolor (site + admin panel), Cinzel/Poppins fonts.
- **Mobile Designer fix** – Toggle/lock buttons screen-ன் middle-ல இருந்து top corners-க்கு மாத்தி, 3D view rotate பண்ணும்போது கை படாம பாத்துக்கிட்டேன். Long-press native "shortcut" popup mobile-ல disable பண்ணிருக்கேன்.
- **Cloud Project Save/Recovery** (login-based, 10MB/account cap):
  - Login பண்ணினா last project auto-ஆ cloud-ல save ஆகும் (`saved_projects` table), வேற device/browser-ல login பண்ணும்போதும் recover ஆகும்.
  - Free plan: auto-recovery மட்டும். Silver: 5 named "Save As" slots. Gold: 20 named slots (Admin > Membership Plans-ல plan edit பண்ணும்போது `project_slots` column மாத்தலாம்).
  - Guests (login இல்லாதவங்க): ஏற்கனவே இருந்த local-browser-only recovery அப்படியே தொடரும்.
- **🤖 Tripo AI (Text → 3D)** – Import Tools section-ல் **கடைசி item**-ஆ சேர்த்திருக்கேன். வேலை செய்ய `/admin/settings.php` → "Tripo AI API Key" field-ல் உங்க key போடணும் (இல்லனா "key not set up" error காட்டும்). Key [developers.tripo3d.ai/en/keys](https://developers.tripo3d.ai/en/keys)-ல வாங்கலாம். இது ஏற்கனவே இருக்கிற daily AI quota-வையே (Gemini-ஓட) share பண்ணும்.


---

## Course Site Login (API key ENTER pannurathu — generate illa)

1. Course site → **Admin → Tool Sites & Access** → `main_editor` site oda **API key** copy pannunga.
2. Indha site → **Admin → Course Site Access** → Course Site URL + API key paste → Save.
   - "Course user kku kudukka vendiya Plan" select pannunga (premium templates + limits adhula irundhu varum).
   - "Test Connection" la oru course username/password check pannalaam.
3. Course vaanguna user, **Login** page la avanga **course username + password** podanum
   (email illama). Login aana odane antha plan apply aagum.
4. Optional: `migration-course-login.sql` import pannina, course username member row la store aagum.

## Membership Plans Redirect (ON / OFF)

**Admin → Settings → Membership Plans Redirect (Course Site)**

- **ON** + course site purchase URL → user "Upgrade / Plans" click panna course site kku pogum.
- **OFF** → normal `membership.php` plan page kaatum.

## v11 — Designer feature control per plan (Aug 2026)

1. Import `migration-designer-feature-gate-v11.sql` in phpMyAdmin
   (after the earlier `migration-designer-feature-gate*.sql` files).
2. Admin → **Designer Access ★** = one grid, all features × all plans,
   one Save. Columns: Guest/No plan + every membership plan.
   Cell values: Locked / Preview (use but no export) / Allowed.

Newly gated features:
- Shape Corner Radius (Bevel), Import SVG, High Quality Bend (text)
- Multi-Axis Extrude, Multi Extrude (2nd+ axis)
- Array Tool, Multi-Array (2nd+ axis), Offset Extrude (Shell), Add Plugin
- Fonts individually: Dancing Script, Pacifico, Yellowtail, Satisfy,
  Lobster, Great Vibes
- AI Panel, AI Text to 3D, AI Image to 3D (separate buttons/gates)
- Export: Separate, Selection Only, OBJ, GLB, FBX
- **Diamond Pin → Custom Parameter Panel** — pinning a locked tool's value
  to the right panel no longer bypasses the lock; pinned rows re-check the
  same gate on every edit. Lock this row to remove the shortcut entirely.

## v13 — Custom Font Upload (TTF/OTF, install from device) — புதுசு

Designer-ல் "Extra: Font Selection" panel-ல் இப்போ ஒரு புது button இருக்கு:
**📁 + Install Custom Font (TTF/OTF)**.

**இது எப்படி வேலை செய்யுது:**
- User தன் device-ல் இருந்து ஒரு `.ttf` அல்லது `.otf` font file-ஐ select
  பண்றாங்க (max 6MB). இந்த file **எங்க server-க்கும் upload ஆகாது** —
  browser-லேயே (`opentype.js`) parse பண்ணி, real 3D extruded text-ஆ மாத்தி,
  அதே browser-ஓட `localStorage`-ல் (இந்த device-க்கு மட்டும்) save ஆகும்.
  Cloud/online storage எதுவும் தேவை இல்ல — அடுத்த தடவை அதே device/browser-ல்
  designer-ஐ திறந்தா அந்த font தானாகவே திரும்ப load ஆகிடும்.
- Font-ல் என்ன மொழி (Tamil, Hindi, Arabic, English, etc.) இருக்குதோ, அந்த
  மொழியையும் 3D text-ஆ ஆதரிக்கும் — ஏன்னா இது ஏற்கனவே இருக்குற Tamil/cursive
  font pipeline-ஐயே (opentype → real 3D geometry) use பண்றது, எந்த மொழிக்கும்
  தனி code தேவை இல்ல.
- ஒரு தடவைக்கு ஒரு device-ல் max 12 custom fonts வரைக்கும் install
  பண்ணலாம் (localStorage full ஆகாம இருக்க).

**Admin control (subscription-based):**
1. `migration-designer-custom-font-feature.sql`-ஐ phpMyAdmin-ல் import
   பண்ணுங்க (v11/v12 migrations-க்கு அப்புறம்).
2. Admin → **Designer Access** → "Fonts" group-ல் புதுசா ஒரு row வரும்:
   **"Custom Font Upload (TTF/OTF, install from device)"**.
3. Default-ஆ இது எல்லா plan-க்கும் **Locked** — யாரும் custom font upload
   பண்ண முடியாது. எந்த plan(s)-க்கு இந்த feature வேணும்னு நினைக்கிறீங்களோ,
   அந்த column-ல **Allowed** ஆ மாத்துங்க. Guest/Free-ஐ Locked-ஆயே வச்சு,
   உங்க paid plan(s)-க்கு மட்டும் Allowed பண்ணலாம் — அப்போ இது ஒரு premium,
   subscription-only feature-ஆ இருக்கும்.
4. Locked plan-ல் இருக்கிற user button-ஐ click பண்ணா, upgrade popup தான்
   வரும் — file picker திறக்காது.

**Custom Font → Cloud Save / Template-ஓட சேர்ந்து சேவ் (புதுசு):**
- முன்னாடி custom font "இந்த device-ல மட்டும்" (localStorage) இருந்துச்சு
  — அதனால அதே design-ஐ Cloud Save பண்ணி வேற device/browser-ல திறந்தா,
  அல்லது ஒரு Template-ஆ save பண்ணி பிறகு அப்ளை பண்ணா, custom font
  காணாம போயிடும் (default font-க்கு மாறிடும்).
- இப்போ **Export XML, Cloud Save (auto-save + named slots), Admin's
  "Save Current Project to GitHub" (Template)** — இந்த மூணு save path-லயும்,
  design-ல எந்தெந்த custom font(s) use ஆகுதோ, அந்த font file bytes-ஐயே
  (base64-ஆ) `<customFonts>` block-ஆ XML-க்குள்ளயே சேர்த்து save பண்ணும்.
- திரும்ப அந்த project/template-ஐ Load பண்ணும்போது (Import XML, Cloud
  Load, Template Apply) — அந்த `<customFonts>` block-ல் இருந்து font-ஐ
  உடனே (synchronous-ஆ) load பண்ணிடும், இந்த device-ல அந்த font
  install பண்ணி இல்லைன்னாலும் சரியா தெரியும். அதுக்கு அப்புறம் இந்த
  device-லயும் அது localStorage-ல தானா save ஆகிடும்.
- இதுக்கு "Custom Font Upload" permission தேவை இல்ல — ஏன்னா இது ஒரு
  already-saved design-ஐ திறக்குறது, புதுசா font install பண்றது இல்ல.
- Note: font file பெரிசா இருந்தா (few MB), XML size-உம் அதுக்கு தகுந்த
  மாதிரி பெருசாகும் — Cloud Save-க்கு already இருக்குற 10MB/account cap,
  அதுக்குள்ளயே இருக்கணும்.


---

## Custom Parameter panel update (font-only lock)

- Right-side Custom Parameters: ellaa parameter-um (size/move/rotate/scale/bend/offset/extrude/array) free & guest users-kum work aagum.
- Font parameter mattum lock-based (premium fonts). 💎 Diamond click-la mattum admin gate warning varum.
- Pinned font row-la irukkura 🔒/🔓 switch: admin tick panna premium plan-kum (mattum) use pannalam.
- **Import `migration-designer-pin-font-unlock.sql`**, then Admin -> Designer Access -> Fonts -> "Pinned Font Lock/Unlock switch" -> premium plans-ku Allowed set pannunga.

## Plugin preview fix (Roll/Sweep bend)

- Root cause was inside the plugin file `v1-text-roll-extrude-v3-sweep-path`: its `cutAtZ()` re-ordered triangle vertices, so ~1/3 of the cut triangles got FLIPPED winding. STL export hides this (weld + slicer repair), but the 3D preview culls back faces -> jagged sawtooth / see-through shards.
- Fixed plugin: `plugins/v1-text-roll-extrude-v3-sweep-path-FIXED.effect` (same plugin name, so saved projects keep working). Replace the old .effect file (wherever you host/load it) with this one.
- The fixed plugin also self-corrects when a bend mirrors the mesh. `applyPluginEffect` in protected/engine.html has the same mirror safeguard for every plugin.

## Template use counter ("See Full Templates")

- Every free / paid template row shows "🔥 N" = how many times visitors clicked it and it opened (only shown when N > 0).
- Counted from the popup list and the compact dropdown. Locked premium clicks (upgrade popup) and admin clicks are NOT counted; the same visitor re-opening the same template within 30 min counts once.
- **Import `migration-template-usage.sql`** (creates table `template_usage`). New files: `api/template-usage.php`; relay added in `designer.php`; UI in `protected/engine.html`.
- Deleting a template (🗑) also removes its counter.

## Custom font travels with the template

- Save path (Save to GitHub / cloud / export / autosave) embeds the used custom font in `<customFonts>`; opening it on any device installs the font first.
- Hardened: the font is embedded even if this device's font list lost it (raw bytes kept in memory), admin gets a warning if a used custom font cannot be embedded, and a clear message if the template is too big for the server (`post_max_size`, usually 8 MB).
- After "Save to GitHub" the status line shows "Custom font embedded: <name>" so you can see it worked.

---

## 💰 Earn Money — Template Marketplace

Users design in the 3D Designer and click **🚀 Post & Earn** to publish a template. Admin approves it (after N approved templates, new ones auto-approve — Admin setting). Everyone can browse/search all published templates on `earn.php` and use them in the Designer.

**Right now every template is FREE.** Users cannot set a price. Paid templates stay OFF until you switch them on after Razorpay (with Route) is approved. This site never collects template money through Cashfree and never pays creators manually.

**Setup (once):**
1. phpMyAdmin → import `migration-marketplace.sql` (tables + "💰 Earn Money" menu link). New columns/table for payments are added automatically on first load.
2. Give `storage/` write permission. `storage/.htaccess` blocks direct downloads — template files are served only via `api/market-use.php`.
3. Admin → **Earn Money (Templates)** → set auto-approve count, max price, tutorial video link (the "How to create a template" button).

**Pages**
- `earn.php` (public): Create Template + Tutorial buttons, Template Marketplace grid with search/sort/pagination. Earnings box and Free/Paid filter appear only when paid templates are ON.
- **My Dashboard → My Templates**: own templates with status (Pending / Live / Rejected + reason), uses, delete. Price editing appears only when paid templates are ON.
- Home page: 🔥 Trending Templates (creators' templates, most used) and, in a separate row below, ⭐ Admin Templates — Free & Paid (the admin's own GitHub templates, most used; counted by the "See Full Templates" use counter, so `migration-template-usage.sql` must be imported). Clicking a card opens `designer.php?tpl=free|premium&name=…` (premium still needs a plan).
- Admin → Earn Money: approve/reject (+preview), **Creators & splits**, **Paid templates (Razorpay)**.

**Turning on paid templates (after Razorpay + Route approval)** — see `RAZORPAY_APPROVAL_NOTES.md`:
1. Admin → Earn Money → ⚙️ Paid templates (Razorpay): enter Key ID / Key Secret / webhook secret → *Test Razorpay keys* → tick **Enable paid templates** → Save.
2. For each creator: create a Razorpay Route **linked account**, paste the `acc_…` id in Admin → Creators & splits.
3. Users can now set prices (Post & Earn popup / Dashboard). A template is sold only if its creator has a linked account — otherwise it stays free. Each sale: Razorpay collects the full price, splits the creator share (default 70%) to the creator's linked account automatically, and the rest stays with you.
4. Switch the option OFF at any time → everything becomes free again (people who already bought keep access).

---

## 🧪 Razorpay Standard Checkout — keys, .env and testing

Razorpay was already integrated for template payments (cURL, no Composer/SDK needed): `market-pay.php` creates the order and opens Checkout, `market-pay-return.php` verifies the signature, `razorpay-webhook.php` is the backup. This update adds `.env` support and hardening.

**Keys:** `.env` in the project root (or one folder above `public_html` — safer) holds `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` (optional `RAZORPAY_WEBHOOK_SECRET`). Loaded by `includes/env.php`; `.env` wins over Admin settings. Only the Key ID ever reaches the browser. `.env` is in `.gitignore`.

**⚠️ Block web access to `.env`** — add to your server's `.htaccess` (merge, don't overwrite an existing one):
```
<Files ".env">
    Require all denied
</Files>
```
Then open `https://your-site/.env` — it must give 403/404.

**Test (test keys, no real money):**
1. Admin → Earn Money → ⚙️ Paid templates → tick *Enable paid templates* (the *Test Razorpay keys* button should say "work ✅") and set a webhook secret.
2. Make a template with price ≥ ₹1 (Admin approve screen price box, or the creator's Dashboard once paid mode is on). With **test keys** a template sells even without a creator linked account (no split); live keys always need the linked account.
3. Log in as a *different* user → Earn Money → Use/Buy → Razorpay window opens. Test card: `4111 1111 1111 1111`, any future expiry, any CVV; UPI test id `success@razorpay`.
4. After paying you land on "Payment successful", the template unlocks, and the sale appears in Admin → Creators & splits. Cancel the window / use `failure@razorpay` to see the cancelled / `payment.failed` messages.

**Before going live:** generate **live** keys, replace them in `.env`, rotate the test secret (it has been shared in chat), and finish the Route steps in `RAZORPAY_APPROVAL_NOTES.md`.

---

## 💳 Razorpay for Membership Plans & Coins (no redirect to the subdomain)

Razorpay is approved on my3dgifts.com, so plans and coins are paid **directly on this site**.

**Switch it on:** Admin → **Settings** → *Razorpay Payment Gateway* (right below the Cashfree keys):
1. Paste **Key ID** and **Key Secret** (or keep them in the server `.env` — `.env` wins).
2. Paste the **Webhook secret** (same one typed in Razorpay Dashboard → Webhooks; URL `https://my3dgifts.com/razorpay-webhook.php`, events `payment.captured` + `order.paid`).
3. *Payment gateway for Membership Plans & Coin purchases* → **Razorpay** → Save.
(Choosing "Course site billing" brings back the old redirect.)

**How it works**
- Plan: Membership page → *Choose Plan* → `pay.php?plan=ID` → Razorpay Checkout → `pay-return.php` verifies signature + payment with Razorpay → plan, expiry and monthly plan coins are applied (same fields the old flow set).
- Coins: Membership page → quantity → `pay.php?coins=N`. Price = **₹ per coin × quantity** (Admin → Settings → Tripo AI Coins: *coin_price_inr*, *minimum purchase*). Purchased coins are added to the user's lifetime coins.
- Safe against double credit: the webhook and the return page both confirm; only the first one grants anything.
- Sales are also logged in the `orders` table so Admin → Dashboard revenue shows them. A small `rzp_orders` table is created automatically on first payment.
- Cashfree keys/pages are untouched; Cashfree can stay as an alternative.

---

## 💸 How creators get paid (automatic split only)

**Automatic (recommended)** — Dashboard → *How you get paid* → *Set up automatic payout*. The creator enters: full name as on PAN, **individual PAN**, mobile, email, and where money should go (**UPI ID** + name on UPI, **or** bank account + IFSC), and accepts the terms. The site calls Razorpay's Route *composite linked-account API* (`POST /v2/accounts`) which creates the linked account and verifies the UPI/bank. Only the resulting `acc_…` id is saved here — **PAN, UPI and bank details are never stored**. After that every sale splits automatically to the creator. Admin can still paste an `acc_…` id manually in Admin → Creators & splits.
Needs Route enabled on your Razorpay account (otherwise the creator sees "not enabled yet"). Try with test keys first. Companies/firms (non-"P" PAN) must be onboarded by the admin in the Razorpay dashboard.

A creator's templates are sold only after their automatic payout account is set up (test keys: always sellable, for trying checkout). There is no manual payout — every payment is split by Razorpay.


## Designer additions (Cone, quick views, multi-layer Custom Parameter buttons)
- **Cone** (Objects strip, after Cylinder): params `r` (bottom radius), `tr` (top radius, 0 = pointed), `h`. Formula tokens: `Name.rr`, `Name.tr`, `Name.ht` (`.ht` also works on Cylinder). Saved/loaded in project XML like other shapes; gizmo/Dimension resizing updates the real params; the AI XML prompt knows `cone`.
- **View bar** (top-right, left of the right panel): Front / Back / Left / Right / Top / Bottom / Iso / ⤢ Fit. Moves only the camera, framing all visible objects.
- **Custom Parameter button**: select several layers (Shift-click / Select All) → the creator box says "N layers" → tick to add ONE button that selects all those layers together (also after XML save/load). With nothing selected you can still add a link button — the **link is now optional**.
