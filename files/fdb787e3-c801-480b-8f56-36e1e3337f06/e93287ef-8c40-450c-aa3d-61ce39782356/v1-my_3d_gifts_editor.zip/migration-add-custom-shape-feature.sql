-- =========================================================
--  Add Custom Shape Feature Control
--
--  Adds designer feature gating for the "Add Custom Shape (Baked)"
--  functionality, allowing admins to control which plans can
--  add custom shapes with boolean baking.
-- =========================================================

INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order) VALUES
('add_custom_shape',   'Add Custom Shape (Baked)',    'fully_locked', 48);

UPDATE designer_features SET sort_order = 48 WHERE feature_key = 'add_custom_shape';
