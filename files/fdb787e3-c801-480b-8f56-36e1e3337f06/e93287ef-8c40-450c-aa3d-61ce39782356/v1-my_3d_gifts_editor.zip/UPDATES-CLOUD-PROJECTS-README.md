# Cloud Projects & Custom Shape Updates

## Overview

This update adds cloud project sharing/importing and improves the Add Custom Shape (Baked) functionality. All enhancements are backward compatible.

## Files Modified/Added

### Database
1. **migration-cloud-project-sharing.sql** - NEW
   - Creates `project_shares` table for managing share codes
   - Allows users to generate unique share links for their projects
   - Recipients can import shared projects into their own account

2. **migration-add-custom-shape-feature.sql** - NEW
   - Adds "Add Custom Shape (Baked)" to designer feature controls
   - Admins can now control which plans have access to this feature
   - Integrated with Designer Access admin panel

### PHP Files

3. **designer.php** - MODIFIED
   - Updated cloud_project_request handler to support SHARE and IMPORT actions
   - Added share_code parameter passing

4. **api/project-store.php** - MODIFIED
   - New `share` action: Generates unique share code for a project
   - New `import` action: Allows importing shared projects
   - Returns share_url or share_code for clipboard sharing
   - Security: Validates user ownership of projects being shared

### HTML/JavaScript (engine.html)

5. **protected/engine.html** - MODIFIED
   - **UI Enhancements:**
     - Added "📂 New" button next to "☁ Save to Cloud" to quickly create new projects from existing ones
     - Added context menu (⋮ button) on each project row for quick actions
     - Project rows now show: Load (📂), More Options (⋮), Delete (🗑)
   
   - **New Functions:**
     - `window.showCloudContextMenu()` - Shows context menu near cursor
     - `window.hideCloudContextMenu()` - Hides context menu
     - `window.cloudContextAction()` - Executes context menu actions
     - `window.toggleCloudNewProject()` - Quick project template loading
     - `window.cloudShareSlot()` - Generates and copies share link
     - `window.cloudImportSlot()` - Imports a shared project as new save
   
   - **Context Menu Options:**
     - 📂 Load - Open the project
     - 🔗 Share - Generate shareable link (copies to clipboard)
     - 📥 Import Copy - Create a local copy of shared project
     - 🗑 Delete - Remove the project from cloud

## Features

### 1. Cloud Project Sharing

**How it works:**
- Right-click or click "⋮" on any saved project
- Select "🔗 Share"
- A unique share link is copied to clipboard
- Share the link with others - they can click it to import your project

**Import Process:**
- Recipient clicks share link or uses "📥 Import Copy" from context menu
- Project is duplicated into their cloud storage
- Original author credit is preserved in metadata

### 2. New Project Creation

**Quick Template Loading:**
- Click "📂 New" button next to Save to Cloud
- Loads list of existing projects
- Select one to load as template
- Modify and save with new name

### 3. Designer Access Control

**Admin Panel:**
- Admin → Designer Access now includes "Add Custom Shape (Baked)"
- Control per plan whether users can:
  - Locked: Cannot use (upgrade popup)
  - Preview: Can use but export blocked
  - Allowed: Full use and export

**Feature Details:**
- Position: Shapes & Tools section
- Feature Key: `add_custom_shape`
- Default: `fully_locked` (requires plan upgrade)

### 4. Improved Boolean Layer Handling

The "Add Custom Shape (Baked)" feature now properly:
- Detects boolean layer operations
- Automatically bakes them into a single mesh
- Handles complex multi-layer booleans correctly
- Works with nested boolean groups

## Setup Instructions

### 1. Database Migrations

Run these migrations in order:

```sql
-- First, ensure feature gating is set up (if not already done)
-- Run: migration-designer-feature-gate.sql
-- Then: migration-designer-feature-gate-fix.sql
-- Then: migration-designer-feature-gate-rename-stylish.sql
-- Then: migration-designer-feature-gate-per-plan-access.sql
-- Then: migration-designer-feature-gate-v11.sql

-- Now run new migrations:
source migration-cloud-project-sharing.sql
source migration-add-custom-shape-feature.sql
```

### 2. File Deployment

Replace these files:
- `designer.php`
- `protected/engine.html`
- `api/project-store.php`

### 3. Configuration

No additional configuration needed. Features are enabled by default once migrations run.

### 4. Admin Setup

1. Go to Admin Panel → Designer Access
2. Find "Add Custom Shape (Baked)" in the feature list
3. Set access level for each plan:
   - Free users: Leave as "Locked"
   - Paid plans: Set to "Allowed" or "Preview"
4. Save

## API Endpoints

### POST /api/project-store.php?action=share
**Request:**
```json
{
  "slot": "Project Name"
}
```

**Response:**
```json
{
  "ok": true,
  "share_code": "abc123def456...",
  "share_url": "https://my3dgifts.com/?import_project=abc123def456..."
}
```

### POST /api/project-store.php?action=import
**Request:**
```json
{
  "share_code": "abc123def456..."
}
```

**Response:**
```json
{
  "ok": true,
  "slot_name": "Shared Project Name",
  "xml": "<xml>...</xml>",
  "author_id": 12345
}
```

## User Documentation

### Sharing Your Project

1. In the Designer, find your saved project in "☁ Restore Project" list
2. Click the "⋮" button on the project row
3. Select "🔗 Share"
4. The share link is copied to your clipboard
5. Paste the link in chat, email, forum, etc.
6. Recipient clicks the link to open Designer with import options

### Importing a Shared Project

**Method 1: Via Share Link**
- Click the share link (should have `?import_project=...` in URL)
- Designer loads with import prompt
- Click "Load Shared Project"
- Choose name for your copy
- Project saves to your cloud storage

**Method 2: Via Context Menu**
- In Designer, click "☁ Restore Project" to expand
- Find the shared project you want to import
- Click "⋮" → "📥 Import Copy"
- Choose name for your copy
- Project saves automatically

### Quick Project Duplication

1. Click "📂 New" button (next to "☁ Save to Cloud")
2. Select an existing project to use as template
3. Modify the design as needed
4. Click "☁ Save to Cloud" to save as new project

## Security Considerations

- Share codes are 20-character random hex strings
- Share codes are unique per project
- Share codes can be disabled per project (admin only)
- Importing doesn't give access to original, only creates copy
- User authentication required for all operations

## Troubleshooting

**Share link not working:**
- Ensure shared project still exists in owner's account
- Check that share is enabled (admin can disable)
- Try using the "📥 Import Copy" method instead

**Import creates blank project:**
- Original project may have been modified/deleted
- Try re-sharing from the original owner
- Check browser console for errors

**Add Custom Shape still locked:**
- Run migrations (especially `migration-add-custom-shape-feature.sql`)
- Check Designer Access admin panel - feature should be there
- Verify your plan's access level is "Allowed"

## Backward Compatibility

✅ All existing cloud projects work unchanged
✅ Auto-save slot (auto-recover) works as before
✅ No impact on local project recovery
✅ Existing user data is preserved
✅ Free users can still use auto-save

## Rollback

If needed to rollback:
1. Revert `designer.php` and `protected/engine.html`
2. Remove API changes from `api/project-store.php`
3. Keep database tables (won't hurt)
4. Migrations can be run again anytime (safe)

## Future Enhancements

Possible additions:
- Shared project edit/collaboration
- Share link expiration
- Download shared projects as STL
- Public project gallery
- Project versioning

## Support

For issues or questions:
1. Check admin logs
2. Verify database migrations ran successfully
3. Check browser console for JavaScript errors
4. Verify user authentication works

---

**Version:** 1.0  
**Date:** 2026-09-11  
**Compatibility:** my_3d_course platform with designer feature gating
