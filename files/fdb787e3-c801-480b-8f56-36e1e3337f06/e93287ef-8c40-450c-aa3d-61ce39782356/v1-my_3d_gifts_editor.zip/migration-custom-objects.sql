-- Custom objects table (scoped per user, 1MB limit check)
CREATE TABLE IF NOT EXISTS `user_custom_objects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `object_data` MEDIUMTEXT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin plan feature gate
ALTER TABLE `plans` ADD COLUMN IF NOT EXISTS `allow_custom_objects` TINYINT(1) DEFAULT 0;
