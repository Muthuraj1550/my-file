<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cashfree.php';
require_once __DIR__ . '/includes/course_link.php';

$user = current_user();
if ($user) check_and_expire_user($user);
$checkoutError = null;

// Handle "buy this plan" click
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['buy_plan_id'])) {
    csrf_check();
    if (!$user) {
        redirect('/register.php');
    }
    $plan = get_plan((int)$_POST['buy_plan_id']);
    if (!$plan) {
        $checkoutError = 'Plan not found.';
    } elseif ((float)$plan['price'] <= 0) {
        // Free plan - activate instantly, no payment needed.
        $expiry = date('Y-m-d', strtotime('+' . (int)$plan['validity_days'] . ' days'));
        $stmt = db()->prepare("UPDATE users SET plan_id=?, plan_name=?, plan_expiry=? WHERE id=?");
        $stmt->execute([$plan['id'], $plan['plan_name'], $expiry, $user['id']]);
        $bonus = (int)($plan['plan_bonus_coins'] ?? 0);
        db()->prepare("UPDATE users SET plan_coins = ? WHERE id=?")
            ->execute([$bonus, $user['id']]);
        flash('Plan activated: ' . $plan['plan_name'] . ($bonus > 0 ? ' (' . $bonus . ' 🪙 monthly coins)' : ''));
        redirect('/dashboard.php');
    } else {
        // We have no payment gateway of our own — send the user to the
        // course site to pay, then they land back here once it's done.
        $payUrl = course_site_plan_pay_url($plan, $user);
        if (!$payUrl) {
            $checkoutError = 'Payment isn\'t configured yet. Please contact support.';
        } else {
            header('Location: ' . $payUrl);
            exit;
        }
    }
}

// Handle "buy coins" click — Main Editor picks quantity, course site handles payment.
$coinBuyUrl = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['buy_coins_qty'])) {
    csrf_check();
    if (!$user) redirect('/register.php');
    $qty = max(1, (int) $_POST['buy_coins_qty']);
    $payUrl = course_site_coins_pay_url($qty, $user);
    if (!$payUrl) {
        $checkoutError = 'Coin purchase isn\'t configured yet. Please contact support.';
    } else {
        header('Location: ' . $payUrl);
        exit;
    }
}

$myPlanCoins      = $user ? (int)($user['plan_coins'] ?? 0)  : 0;
$myPurchasedCoins = $user ? (int)($user['tripo_coins'] ?? 0) : 0;
$myCoins          = $myPlanCoins + $myPurchasedCoins;

$pageTitle = 'Membership Plans';
include __DIR__ . '/includes/header.php';
$plans = all_plans();
// Auto-detect, per plan, which designer features are newly unlocked compared
// to the plan just below it (Guest baseline for the cheapest plan) — powers
// the "See Full Features" section below so higher plans show what they add,
// without repeating everything the lower plan already had.
$planUpsellFeatures = designer_plan_upsell_features($plans);
// Custom Shape access is a big enough selling point that we surface it as
// its own always-visible line on the plan card (not buried inside the
// collapsible "See Full Features" list), so members can tell at a glance
// which plan lets them save/add Custom Shapes in the 3D Designer.
// Guest / not-logged-in users are always locked for this feature by design.
$planCustomShapeStatus = [];
if (designer_features_ready()) {
    foreach ($plans as $p) {
        $fmap = designer_plan_feature_access_map((int) $p['id']);
        $planCustomShapeStatus[(int) $p['id']] = $fmap['add_custom_shape']['status'] ?? 'locked';
    }
}
?>
<div class="hero" style="padding-top:20px;">
  <h1>Membership Plans</h1>
  <p>Choose a plan for monthly coins &amp; premium 3D templates. Paying is handled securely on our billing site — you'll land right back here once it's done.</p>
</div>

<?php if (isset($_GET['payment']) && $_GET['payment'] === 'success'): ?>
  <div class="flash flash-success">✅ Payment received — your plan is now active. Enjoy!</div>
<?php elseif (isset($_GET['payment']) && $_GET['payment'] === 'pending'): ?>
  <div class="flash">⏳ Payment received, activation is in progress — refresh in a minute if it's not showing yet.</div>
<?php endif; ?>

<?php if ($checkoutError): ?>
  <div class="flash flash-error"><?php echo h($checkoutError); ?></div>
<?php endif; ?>

<div class="plans-grid">
  <?php $showLimitsExpand = get_setting('plan_limits_expand_enabled', '0') === '1'; ?>
  <?php foreach ($plans as $p): ?>
    <?php $isCurrent = $user && $user['plan_name'] === $p['plan_name']; ?>
    <div class="plan-card <?php echo $p['premium_designer'] ? 'featured' : ''; ?>">
      <?php if ($p['premium_designer']): ?><div class="badge badge-gold">POPULAR</div><?php endif; ?>
      <h3><?php echo h($p['plan_name']); ?></h3>
      <div class="plan-price">₹<?php echo number_format($p['price'],0); ?> <span>/ <?php echo (int)$p['validity_days']; ?> days</span></div>
      <?php if ($showLimitsExpand): ?>
        <?php $planDetailsId = 'planLimits' . (int)$p['id']; ?>
        <ul>
          <li><?php echo $p['premium_designer'] ? '👑 Premium templates unlocked' : 'Free templates only'; ?></li>
          <li>3D Designer &amp; export tools</li>
        </ul>
        <button type="button" class="btn btn-outline btn-block plan-limits-toggle" data-target="<?php echo $planDetailsId; ?>" style="font-size:13px;padding:8px;margin-bottom:10px;">
          What's included <span class="plan-limits-arrow">▾</span>
        </button>
        <ul id="<?php echo $planDetailsId; ?>" class="plan-limits-details" style="display:none;">
          <li>🪙 <strong><?php echo (int)($p['plan_bonus_coins'] ?? 0); ?></strong> monthly Tripo AI coins</li>
          <li><?php echo (int)($p['project_slots'] ?? 0) > 0 ? (int)$p['project_slots'] . ' cloud project slot(s)' : 'Local auto-recover only'; ?></li>
          <?php if (($planCustomShapeStatus[(int)$p['id']] ?? 'locked') === 'allowed'): ?>
            <li>🎨 <strong>Custom Shape Covered</strong></li>
          <?php elseif (($planCustomShapeStatus[(int)$p['id']] ?? 'locked') === 'preview'): ?>
            <li>🎨 Custom Shape <small style="color:#fbbf24;">(preview only)</small></li>
          <?php endif; ?>
        </ul>
      <?php else: ?>
        <ul>
          <li>🪙 <strong><?php echo (int)($p['plan_bonus_coins'] ?? 0); ?></strong> monthly Tripo AI coins</li>
          <li><?php echo $p['premium_designer'] ? '👑 Premium templates unlocked' : 'Free templates only'; ?></li>
          <li><?php echo (int)($p['project_slots'] ?? 0) > 0 ? (int)$p['project_slots'] . ' cloud project slot(s)' : 'Local auto-recover only'; ?></li>
          <li>3D Designer &amp; export tools</li>
          <?php if (($planCustomShapeStatus[(int)$p['id']] ?? 'locked') === 'allowed'): ?>
            <li>🎨 <strong>Custom Shape Covered</strong></li>
          <?php elseif (($planCustomShapeStatus[(int)$p['id']] ?? 'locked') === 'preview'): ?>
            <li>🎨 Custom Shape <small style="color:#fbbf24;">(preview only)</small></li>
          <?php endif; ?>
        </ul>
      <?php endif; ?>

      <?php
        $fullFeaturesId = 'planFullFeatures' . (int) $p['id'];
        $upsells = $planUpsellFeatures[(int) $p['id']] ?? [];
        $hasExtra = !empty($upsells) || !empty($p['upsell_text']);
      ?>
      <?php if ($hasExtra): ?>
        <button type="button" class="btn btn-outline btn-block plan-limits-toggle" data-target="<?php echo $fullFeaturesId; ?>" style="font-size:13px;padding:8px;margin-bottom:10px;">
          See Full Features <span class="plan-limits-arrow">▾</span>
        </button>
        <div id="<?php echo $fullFeaturesId; ?>" class="plan-limits-details" style="display:none;text-align:left;">
          <?php if (!empty($upsells)): ?>
            <p style="font-weight:600;color:#4ade80;margin:6px 0 4px;font-size:13px;">✨ New in this plan:</p>
            <ul>
              <?php foreach ($upsells as $feat): ?>
                <li><?php echo h($feat['name']); ?><?php echo $feat['status'] === 'preview' ? ' <small style="color:#fbbf24;">(preview only, export locked)</small>' : ''; ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
          <?php if (!empty($p['upsell_text'])): ?>
            <p style="white-space:pre-wrap;margin-top:8px;color:#cbd5e1;font-size:13px;"><?php echo h($p['upsell_text']); ?></p>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <?php if ($isCurrent): ?>
        <button class="btn btn-outline btn-block" disabled>Current Plan</button>
      <?php else: ?>
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="buy_plan_id" value="<?php echo (int)$p['id']; ?>">
          <button type="submit" class="btn btn-block"><?php echo (float)$p['price'] > 0 ? 'Choose Plan' : 'Activate Free'; ?></button>
        </form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<script>
document.addEventListener('click', function(e){
  var btn = e.target.closest('.plan-limits-toggle');
  if (!btn) return;
  var target = document.getElementById(btn.dataset.target);
  if (!target) return;
  var open = target.style.display !== 'none';
  target.style.display = open ? 'none' : 'block';
  var arrow = btn.querySelector('.plan-limits-arrow');
  if (arrow) arrow.textContent = open ? '▾' : '▴';
});
</script>


<!-- ═══ TRIPO AI COINS ═══ -->
<div class="hero" style="padding-top:40px;">
  <h1 style="background:linear-gradient(135deg,#f59e0b,#fbbf24);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Tripo AI Coins</h1>
  <p><strong>Monthly plan coins</strong> get spent first, then your <strong>purchased coins</strong> (lifetime, never expire).</p>
  <?php if ($user): ?>
    <p style="font-size:16px;">
      Plan coins: <strong style="color:#60a5fa;"><?php echo $myPlanCoins; ?></strong>
      &nbsp;·&nbsp; Purchased: <strong style="color:#fbbf24;"><?php echo $myPurchasedCoins; ?></strong>
      &nbsp;·&nbsp; Total: <strong><?php echo $myCoins; ?></strong>
    </p>
  <?php endif; ?>
  <?php if (course_link_url() !== ''): ?>
    <form method="post" style="max-width:320px;margin:16px auto 0;">
      <?php echo csrf_field(); ?>
      <label style="font-size:12px;color:#94a3b8;">How many coins do you need?</label>
      <input type="number" name="buy_coins_qty" min="1" value="50" style="text-align:center;">
      <button type="submit" class="btn btn-block" style="background:linear-gradient(135deg,#f59e0b,#fbbf24);color:#111;font-weight:bold;">Buy Coins ↗</button>
      <p style="color:#64748b;font-size:12px;margin-top:6px;">You'll pay securely on our billing site, then land right back here — coins are added automatically.</p>
    </form>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
