-- =========================================================
--  MIGRATION: Enhanced SEO Search Engine Traffic Tracking
--  Run this if you want more detailed SEO analytics for:
--  Google, Yahoo, Bing, Baidu, DuckDuckGo
--
--  This migration adds enhanced content_views columns for 
--  tracking search engine details including:
--  - search_engine: The search engine name (Google, Bing, Yahoo, etc.)
--  - search_query: The search query (if available in referrer)
--  - ranking_position: The estimated position in search results (if trackable)
--
--  Note: The admin/analytics.php page will automatically detect
--  and display SEO traffic from these search engines based on
--  the existing referrer_source field. No new columns are required
--  for basic SEO tracking—this migration is for enhanced tracking.
-- =========================================================

-- Add new columns for enhanced SEO tracking (optional)
ALTER TABLE content_views
    ADD COLUMN IF NOT EXISTS search_engine VARCHAR(50) DEFAULT NULL AFTER referrer_source,
    ADD COLUMN IF NOT EXISTS search_query VARCHAR(500) DEFAULT NULL AFTER search_engine,
    ADD COLUMN IF NOT EXISTS ranking_position INT DEFAULT NULL AFTER search_query;

-- Add indexes for better query performance
ALTER TABLE content_views
    ADD KEY IF NOT EXISTS search_engine_idx (search_engine),
    ADD KEY IF NOT EXISTS search_query_idx (search_query);

-- Update search_engine field based on referrer_source if migrating from old setup
UPDATE content_views 
SET search_engine = 'Google' 
WHERE search_engine IS NULL AND referrer_source LIKE '%Google%';

UPDATE content_views 
SET search_engine = 'Bing' 
WHERE search_engine IS NULL AND referrer_source LIKE '%Bing%';

UPDATE content_views 
SET search_engine = 'Yahoo' 
WHERE search_engine IS NULL AND referrer_source LIKE '%Yahoo%';

UPDATE content_views 
SET search_engine = 'Baidu' 
WHERE search_engine IS NULL AND referrer_source LIKE '%Baidu%';

UPDATE content_views 
SET search_engine = 'DuckDuckGo' 
WHERE search_engine IS NULL AND referrer_source LIKE '%DuckDuckGo%';

-- Create a view for SEO traffic summary
CREATE OR REPLACE VIEW seo_traffic_summary AS
SELECT 
    COALESCE(search_engine, 'Direct/Other') as engine,
    COUNT(*) as total_visits,
    COUNT(DISTINCT ip_address) as unique_visitors,
    COALESCE(SUM(duration_seconds), 0) as total_time_seconds,
    COALESCE(AVG(NULLIF(duration_seconds, 0)), 0) as avg_time_seconds,
    DATE(MAX(created_at)) as last_visit
FROM content_views
WHERE content_type <> 'tool_click'
GROUP BY search_engine
ORDER BY total_visits DESC;

-- Create a view for daily SEO traffic
CREATE OR REPLACE VIEW seo_traffic_daily AS
SELECT 
    DATE(created_at) as visit_date,
    COALESCE(search_engine, 'Direct/Other') as engine,
    COUNT(*) as visits,
    COUNT(DISTINCT ip_address) as unique_visitors
FROM content_views
WHERE content_type <> 'tool_click'
GROUP BY DATE(created_at), search_engine
ORDER BY visit_date DESC, visits DESC;
