-- Adds an admin-editable free-text field per plan, shown inside the
-- "See Full Features" expandable section on membership.php alongside the
-- auto-detected list of designer features newly unlocked in that plan.
-- Safe to run on a fresh install or a live upgrade (checks column first).
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'plans' AND COLUMN_NAME = 'upsell_text'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE plans ADD COLUMN upsell_text TEXT NULL AFTER premium_designer',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
