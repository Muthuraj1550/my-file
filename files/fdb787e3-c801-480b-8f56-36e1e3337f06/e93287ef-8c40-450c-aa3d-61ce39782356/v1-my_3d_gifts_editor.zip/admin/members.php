<?php
$adminTitle = 'Members';
require_once __DIR__ . '/_layout_top.php';
require_once __DIR__ . '/../includes/course_link.php';

$newCreds = null; // shown once right after Admin creates a local member

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_member'])) {
    csrf_check();
    if (!local_username_ready()) {
        flash('Run migration-local-username.sql in phpMyAdmin first (adds the local_username column).', 'error');
        redirect('/admin/members.php');
    }
    $username = trim($_POST['new_username'] ?? '');
    $email    = trim(strtolower($_POST['new_email'] ?? ''));
    $pass     = $_POST['new_password'] ?? '';
    $name     = trim($_POST['new_name'] ?? '') ?: $username;

    $errors = [];
    if ($username === '' || !preg_match('/^[a-zA-Z0-9_.]{3,40}$/', $username)) {
        $errors[] = 'Username must be 3-40 characters (letters, numbers, dot, underscore only).';
    }
    if (strlen($pass) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'That email address doesn\'t look valid.';

    if (!$errors) {
        $chk = db()->prepare("SELECT id FROM users WHERE local_username = ?");
        $chk->execute([$username]);
        if ($chk->fetch()) $errors[] = 'That username is already taken.';
    }
    if (!$errors && $email !== '') {
        $chk = db()->prepare("SELECT id FROM users WHERE email = ?");
        $chk->execute([$email]);
        if ($chk->fetch()) $errors[] = 'That email is already registered.';
    }

    if ($errors) {
        flash(implode(' ', $errors), 'error');
        redirect('/admin/members.php');
    }

    // Email is NOT NULL/UNIQUE in the schema - when Admin leaves it blank,
    // fall back to a private placeholder so the row still saves cleanly;
    // login always works via the username either way.
    $storedEmail = $email !== '' ? $email : ($username . '@local.' . preg_replace('/^https?:\/\//', '', parse_url(SITE_URL, PHP_URL_HOST) ?: 'my3dgifts.com'));

    $free = get_plan_by_name('Free');
    $expiry = date('Y-m-d', strtotime('+100 years'));
    $stmt = db()->prepare("INSERT INTO users (name, email, local_username, password_hash, role, plan_id, plan_name, plan_expiry)
                            VALUES (?,?,?,?,'member',?,?,?)");
    $stmt->execute([
        $name, $storedEmail, $username,
        password_hash($pass, PASSWORD_DEFAULT),
        $free ? $free['id'] : null,
        'Free',
        $expiry,
    ]);

    $_SESSION['new_member_creds'] = ['username' => $username, 'name' => $name];
    flash('Member "' . $name . '" created.');
    redirect('/admin/members.php');
}

if (!empty($_SESSION['new_member_creds'])) {
    $newCreds = $_SESSION['new_member_creds'];
    unset($_SESSION['new_member_creds']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_member'])) {
    csrf_check();
    $mid = (int)$_POST['mid'];
    $stmt = db()->prepare("UPDATE users SET plan_name=?, plan_expiry=?, ai_limit_override=?, status=?, tripo_coins=?, plan_coins=? WHERE id=?");
    $stmt->execute([
        trim($_POST['plan_name']),
        $_POST['plan_expiry'] ?: null,
        $_POST['ai_limit_override'] !== '' ? (int)$_POST['ai_limit_override'] : null,
        $_POST['status'],
        (int)($_POST['tripo_coins'] ?? 0),
        (int)($_POST['plan_coins'] ?? 0),
        $mid,
    ]);
    flash('Member updated.');
    redirect('/admin/members.php');
}

$search = trim($_GET['q'] ?? '');
$srcFilter = $_GET['src'] ?? 'all'; // all | course | local | direct
$where = "role='member'";
$params = [];
if ($search !== '') {
    $where .= " AND (name LIKE ? OR email LIKE ?)";
    $like = '%' . $search . '%';
    $params[] = $like; $params[] = $like;
}
if ($srcFilter === 'course' && course_link_ready()) {
    $where .= " AND course_username IS NOT NULL AND course_username <> ''";
} elseif ($srcFilter === 'local' && local_username_ready()) {
    $where .= " AND local_username IS NOT NULL AND local_username <> ''" . (course_link_ready() ? " AND (course_username IS NULL OR course_username = '')" : "");
} elseif ($srcFilter === 'direct') {
    if (course_link_ready()) $where .= " AND (course_username IS NULL OR course_username = '')";
    if (local_username_ready()) $where .= " AND (local_username IS NULL OR local_username = '')";
}
$stmt = db()->prepare("SELECT * FROM users WHERE $where ORDER BY created_at DESC LIMIT 200");
$stmt->execute($params);
$members = $stmt->fetchAll();
$allPlans = all_plans();
$totalMembersCount = (int) db()->query("SELECT COUNT(*) c FROM users WHERE role='member'")->fetch()['c'];
$courseCount = course_link_ready() ? (int) db()->query("SELECT COUNT(*) c FROM users WHERE role='member' AND course_username IS NOT NULL AND course_username <> ''")->fetch()['c'] : 0;
$localCount  = local_username_ready() ? (int) db()->query("SELECT COUNT(*) c FROM users WHERE role='member' AND local_username IS NOT NULL AND local_username <> ''")->fetch()['c'] : 0;
?>
<p style="color:var(--muted);font-size:13px;margin:-6px 0 14px;">👥 <?php echo $totalMembersCount; ?> total members<?php if ($courseCount): ?> · 🎓 <?php echo $courseCount; ?> from Course<?php endif; ?><?php if ($localCount): ?> · 🛠️ <?php echo $localCount; ?> created here<?php endif; ?></p>

<?php if ($newCreds): ?>
<div class="card" style="border:2px solid #16a34a;background:#f0fdf4;margin-bottom:16px;">
  <h3 style="margin-top:0;">✅ Member Created — <?php echo h($newCreds['name']); ?></h3>
  <p style="margin:6px 0;">They can log in with username <code style="background:#dcfce7;padding:2px 8px;border-radius:4px;"><?php echo h($newCreds['username']); ?></code> and the password you just set.</p>
</div>
<?php endif; ?>

<?php if (!local_username_ready()): ?>
<div class="card" style="border:1px solid #f59e0b;background:#fffbeb;margin-bottom:16px;">
  <b>⚠ Migration Pending:</b> run <code>migration-local-username.sql</code> in phpMyAdmin to enable "Add New Member" (create a login here with just a username + password).
</div>
<?php else: ?>
<div class="card" style="margin-bottom:16px;max-width:420px;">
  <h3 style="margin-top:0;">➕ Add New Member</h3>
  <p style="color:var(--muted);font-size:12px;margin-top:-6px;">Create a login directly here — separate from Course-site buyers, who get added automatically the first time they log in with their course credentials.</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <label>Username</label>
    <input type="text" name="new_username" placeholder="e.g. arun.k" required>
    <label>Display Name <span style="font-weight:normal;color:var(--muted);">(optional — defaults to username)</span></label>
    <input type="text" name="new_name" placeholder="Full name">
    <label>Gmail / Email <span style="font-weight:normal;color:var(--muted);">(optional)</span></label>
    <input type="email" name="new_email" placeholder="name@gmail.com">
    <label>Password</label>
    <input type="text" name="new_password" placeholder="Set a password (min 6 characters)" required>
    <button type="submit" name="create_member" class="btn" style="margin-top:8px;">Create Member</button>
  </form>
</div>
<?php endif; ?>

<div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;margin-bottom:16px;">
  <form method="get" style="max-width:340px;">
    <input type="hidden" name="src" value="<?php echo h($srcFilter); ?>">
    <input type="text" name="q" placeholder="Search by name or email" value="<?php echo h($search); ?>">
  </form>
  <div style="display:flex;gap:6px;">
    <?php foreach (['all'=>'All','course'=>'🎓 Course','local'=>'🛠️ Local','direct'=>'✉️ Direct'] as $k=>$label): ?>
      <a href="?src=<?php echo $k; ?><?php echo $search!==''?'&q='.urlencode($search):''; ?>"
         class="btn btn-sm <?php echo $srcFilter===$k?'':'btn-outline'; ?>"><?php echo $label; ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div style="overflow-x:auto;">
  <table class="members-table" style="table-layout:fixed;">
    <colgroup>
      <col style="width:13%;"><col style="width:16%;"><col style="width:8%;"><col style="width:12%;"><col style="width:11%;">
      <col style="width:7%;"><col style="width:8%;"><col style="width:8%;"><col style="width:8%;">
    </colgroup>
    <thead><tr><th>Name</th><th>Email</th><th>Source</th><th>Plan</th><th>Expiry</th><th>Status</th><th>Plan Coins</th><th>Purchased Coins</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach ($members as $m): ?>
      <?php
        $active = $m['plan_expiry'] && strtotime($m['plan_expiry']) >= strtotime(date('Y-m-d'));
        $rowFormId = 'mf-' . (int)$m['id'];
      ?>
      <!-- Row edits post via this standalone form (referenced below with form="<?php echo $rowFormId; ?>")
           instead of wrapping <tr> — a <form> cannot legally contain <tr>/<td> as a direct table-row child,
           and browsers silently re-parent it, which was breaking this page's layout. -->
      <form id="<?php echo $rowFormId; ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="mid" value="<?php echo (int)$m['id']; ?>">
        <input type="hidden" name="ai_limit_override" value="<?php echo h($m['ai_limit_override']); ?>">
      </form>
      <tr>
        <td class="mem-cell-clip" title="<?php echo h($m['name']); ?>"><?php echo h($m['name']); ?></td>
        <td class="mem-cell-clip" title="<?php echo h($m['email']); ?>"><?php echo h($m['email']); ?><br><small style="color:var(--muted)"><?php echo h($m['phone']); ?></small></td>
        <td style="font-size:12.5px;white-space:nowrap;" title="<?php echo h(($m['course_username'] ?? '') ?: ($m['local_username'] ?? '')); ?>"><?php echo member_source_label($m); ?></td>
        <td>
          <select form="<?php echo $rowFormId; ?>" name="plan_name" style="margin:0;min-width:120px;max-width:100%;">
            <?php $hasMatch = false; ?>
            <?php foreach ($allPlans as $p): $sel = ($p['plan_name'] === $m['plan_name']); if ($sel) $hasMatch = true; ?>
              <option value="<?php echo h($p['plan_name']); ?>" <?php echo $sel ? 'selected' : ''; ?>><?php echo h($p['plan_name']); ?></option>
            <?php endforeach; ?>
            <?php if (!$hasMatch && $m['plan_name'] !== ''): ?>
              <option value="<?php echo h($m['plan_name']); ?>" selected><?php echo h($m['plan_name']); ?> (not in current plans)</option>
            <?php endif; ?>
          </select>
        </td>
        <td><input form="<?php echo $rowFormId; ?>" type="date" name="plan_expiry" value="<?php echo h($m['plan_expiry']); ?>" style="margin:0;width:100%;"></td>
        <td>
          <select form="<?php echo $rowFormId; ?>" name="status" style="margin:0;">
            <option value="active" <?php echo $m['status']==='active'?'selected':''; ?>>Active</option>
            <option value="blocked" <?php echo $m['status']==='blocked'?'selected':''; ?>>Blocked</option>
          </select>
        </td>
        <td>
          <input form="<?php echo $rowFormId; ?>" type="number" min="0" name="plan_coins" value="<?php echo (int)($m['plan_coins'] ?? 0); ?>" style="margin:0;width:100%;" title="Monthly membership coins (reset on renewal, spent first)">
        </td>
        <td>
          <input form="<?php echo $rowFormId; ?>" type="number" min="0" name="tripo_coins" value="<?php echo (int)($m['tripo_coins'] ?? 0); ?>" style="margin:0;width:100%;" title="Purchased coins (lifetime, never expire)">
        </td>
        <td>
          <button form="<?php echo $rowFormId; ?>" type="submit" name="update_member" class="btn btn-sm">Save</button>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$members): ?><tr><td colspan="9">No members found.</td></tr><?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<style>
  /* Long spam-injected values (fake names/links) get clipped with an ellipsis
     instead of blowing up the row height / column width — full value is
     still visible on hover via the title attribute. */
  .mem-cell-clip { max-width:1px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .members-table td, .members-table th { overflow:hidden; }
</style>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
