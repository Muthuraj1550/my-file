<style>
.cb-wrap{border:1px solid var(--border,#27324a);border-radius:10px;padding:12px;background:rgba(255,255,255,.02);}
.cb-block{border:1px solid var(--border,#27324a);border-radius:8px;padding:12px;margin-bottom:10px;background:var(--card,#151f38);}
.cb-block.cb-dragging{opacity:.4;}
.cb-block.cb-drag-over{border-color:var(--accent,#6366f1);border-style:dashed;}
.cb-block-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;}
.cb-block-head-left{display:flex;align-items:center;gap:8px;}
.cb-drag-handle{cursor:grab;color:var(--muted,#94a3b8);font-size:15px;user-select:none;}
.cb-drag-handle:active{cursor:grabbing;}
.cb-block-tag{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--gold,#e6c25c);}
.cb-block-actions button{background:none;border:1px solid var(--border,#27324a);color:var(--muted,#94a3b8);border-radius:6px;padding:3px 8px;font-size:12px;cursor:pointer;margin-left:4px;}
.cb-block-actions button:hover{color:#fff;}
.cb-block textarea, .cb-block input[type=text], .cb-block select{width:100%;}
.cb-block textarea{min-height:90px;font-family:inherit;}
.cb-block.cb-html textarea{font-family:monospace;min-height:140px;}
.cb-heading-row{display:flex;gap:8px;margin-bottom:6px;}
.cb-heading-row select{width:auto;flex:0 0 auto;}
.cb-heading-row label{display:flex;align-items:center;gap:4px;font-size:12px;color:var(--muted,#94a3b8);white-space:nowrap;}
.cb-heading-row input[type=text]{flex:1;font-weight:700;}
.cb-toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;}
.cb-toolbar button{background:var(--accent,#6366f1);color:#fff;border:none;border-radius:8px;padding:8px 14px;font-size:13px;cursor:pointer;}
.cb-toolbar button.outline{background:none;border:1px solid var(--border,#27324a);color:var(--muted,#94a3b8);}
.cb-toolbar button:disabled{opacity:.4;cursor:not-allowed;}
.cb-img-preview{max-width:220px;border-radius:8px;display:block;margin:8px 0;}
.cb-empty{color:var(--muted,#94a3b8);font-size:13px;padding:10px 2px;}
.cb-html-preview-toggle{font-size:12px;color:var(--muted,#94a3b8);margin-top:6px;display:flex;align-items:center;gap:6px;cursor:pointer;}
.cb-html-preview{margin-top:6px;border:1px solid var(--border,#27324a);border-radius:8px;padding:8px;max-height:220px;overflow:auto;background:rgba(0,0,0,.15);}
.cb-html-preview iframe, .cb-html-preview video, .cb-html-preview img{max-width:100%;max-height:200px;}
.cb-html-preview embed{max-width:100%;}
</style>
<script>
window.M3DGContentBuilder = (function(){

  function esc(s){ var d=document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }

  function serializeBlocks(blocks){
    return blocks.map(function(b){
      if (b.type === 'paragraph') {
        var html = '<p>' + esc(b.text).replace(/\n/g,'<br>') + '</p>';
        return '<!--BLOCK:paragraph-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'heading') {
        var level = (b.level === 'h1') ? 'h1' : 'h2';
        var inner = esc(b.text);
        if (b.bold) inner = '<strong>' + inner + '</strong>';
        var html = '<' + level + '>' + inner + '</' + level + '>';
        return '<!--BLOCK:heading-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'image') {
        var html = b.url ? ('<img src="' + b.url + '" alt="' + esc(b.alt) + '" style="max-width:100%;border-radius:10px;">') : '';
        return '<!--BLOCK:image-->' + html + '<!--/BLOCK-->';
      }
      if (b.type === 'form') {
        return '<!--BLOCK:form-->' + (b.formId ? ('[form id=' + b.formId + ']') : '') + '<!--/BLOCK-->';
      }
      // html
      return '<!--BLOCK:html-->' + (b.html || '') + '<!--/BLOCK-->';
    }).join('\n');
  }

  function parseBlocks(content){
    content = content || '';
    var re = /<!--BLOCK:(paragraph|heading|image|html|form)-->([\s\S]*?)<!--\/BLOCK-->/g;
    var blocks = [];
    var m, found = false;
    while ((m = re.exec(content)) !== null) {
      found = true;
      var type = m[1], inner = m[2];
      if (type === 'paragraph') {
        var tmp = document.createElement('div'); tmp.innerHTML = inner;
        blocks.push({ type:'paragraph', text: (tmp.textContent || '').replace(/\n{2,}/g,'\n') });
      } else if (type === 'heading') {
        var tmpH = document.createElement('div'); tmpH.innerHTML = inner;
        var hEl = tmpH.querySelector('h1,h2,h3,h4');
        var level = hEl ? hEl.tagName.toLowerCase() : 'h2';
        if (level !== 'h1') level = 'h2';
        var isBold = false, text = '';
        if (hEl) {
          var strongEl = hEl.querySelector('strong,b');
          if (strongEl && strongEl.textContent.trim() === hEl.textContent.trim()) {
            isBold = true;
            text = strongEl.textContent;
          } else {
            text = hEl.textContent;
          }
        }
        blocks.push({ type:'heading', level: level, bold: isBold, text: text });
      } else if (type === 'image') {
        var tmp2 = document.createElement('div'); tmp2.innerHTML = inner;
        var img = tmp2.querySelector('img');
        blocks.push({ type:'image', url: img ? img.getAttribute('src') : '', alt: img ? (img.getAttribute('alt')||'') : '' });
      } else if (type === 'form') {
        var fm = inner.match(/\[form\s+id=(\d+)\]/i);
        blocks.push({ type:'form', formId: fm ? fm[1] : '' });
      } else {
        blocks.push({ type:'html', html: inner });
      }
    }
    if (!found && content.trim() !== '') {
      // Legacy content saved before the block builder existed - keep it fully editable as one HTML block.
      blocks.push({ type:'html', html: content });
    }
    return blocks;
  }

  function attach(textareaId, forms){
    var ta = document.getElementById(textareaId);
    if (!ta) return;
    forms = forms || [];

    var blocks = parseBlocks(ta.value);
    var clipboard = null; // { block } for cut/paste
    var dragFromIndex = null;
    ta.style.display = 'none';

    var wrap = document.createElement('div');
    wrap.className = 'cb-wrap';
    var list = document.createElement('div');
    wrap.appendChild(list);

    var toolbar = document.createElement('div');
    toolbar.className = 'cb-toolbar';
    toolbar.innerHTML =
      '<button type="button" data-add="paragraph">+ Paragraph</button>' +
      '<button type="button" data-add="heading" data-level="h2">+ Heading</button>' +
      '<button type="button" data-add="heading" data-level="h1">+ Heading 1</button>' +
      '<button type="button" data-add="image">+ Image</button>' +
      '<button type="button" data-add="html">+ HTML</button>' +
      (forms.length ? '<button type="button" data-add="form">+ Form</button>' : '') +
      '<button type="button" class="outline" data-paste disabled>Paste</button>' +
      '<button type="button" class="outline" data-sync>Preview HTML ↓</button>';
    wrap.appendChild(toolbar);

    ta.parentNode.insertBefore(wrap, ta);

    var pasteBtn = toolbar.querySelector('[data-paste]');

    function updatePasteBtn(){
      pasteBtn.disabled = !clipboard;
      pasteBtn.textContent = clipboard ? ('Paste (' + clipboard.block.type + ')') : 'Paste';
    }

    function render(){
      list.innerHTML = '';
      if (!blocks.length) {
        var empty = document.createElement('div');
        empty.className = 'cb-empty';
        empty.textContent = 'No content blocks yet - add an image, a paragraph, or raw HTML below.';
        list.appendChild(empty);
      }
      blocks.forEach(function(b, i){ list.appendChild(renderBlock(b, i)); });
      updatePasteBtn();
      sync();
    }

    function renderBlock(b, i){
      var el = document.createElement('div');
      el.className = 'cb-block cb-' + b.type;
      el.setAttribute('draggable', 'true');
      el.dataset.index = i;

      var head = document.createElement('div');
      head.className = 'cb-block-head';
      var tagNames = { paragraph:'Paragraph', heading:'Heading', image:'Image', html:'HTML', form:'Form' };
      var headLeft = document.createElement('div');
      headLeft.className = 'cb-block-head-left';
      headLeft.innerHTML = '<span class="cb-drag-handle" title="Drag to move">⠿⠿</span><span class="cb-block-tag">' + tagNames[b.type] + (b.type === 'heading' ? (' (' + b.level.toUpperCase() + ')') : '') + '</span>';
      head.appendChild(headLeft);

      var actions = document.createElement('div');
      actions.className = 'cb-block-actions';
      var actionsHtml =
        '<button type="button" data-act="up" title="Move up">↑</button>' +
        '<button type="button" data-act="down" title="Move down">↓</button>' +
        '<button type="button" data-act="copy" title="Duplicate">⧉</button>' +
        '<button type="button" data-act="cut" title="Cut">✂</button>';
      if (b.type === 'paragraph' || b.type === 'heading') {
        actionsHtml += '<button type="button" data-act="convert" title="Switch Paragraph / Heading">⇄</button>';
      }
      actionsHtml += '<button type="button" data-act="del" title="Delete">✕</button>';
      actions.innerHTML = actionsHtml;
      head.appendChild(actions);
      el.appendChild(head);

      var body = document.createElement('div');
      if (b.type === 'paragraph') {
        body.innerHTML = '<textarea placeholder="Write a paragraph...">' + esc(b.text) + '</textarea>';
        body.querySelector('textarea').addEventListener('input', function(e){ b.text = e.target.value; sync(); });
      } else if (b.type === 'heading') {
        body.innerHTML =
          '<div class="cb-heading-row">' +
            '<select data-role="level">' +
              '<option value="h1"' + (b.level==='h1'?' selected':'') + '>Heading 1</option>' +
              '<option value="h2"' + (b.level==='h2'?' selected':'') + '>Heading</option>' +
            '</select>' +
            '<label><input type="checkbox" data-role="bold" style="width:auto;"' + (b.bold?' checked':'') + '> Bold</label>' +
          '</div>' +
          '<input type="text" data-role="text" value="' + esc(b.text) + '" placeholder="Heading text...">';
        body.querySelector('[data-role=level]').addEventListener('change', function(e){ b.level = e.target.value; render(); });
        body.querySelector('[data-role=bold]').addEventListener('change', function(e){ b.bold = e.target.checked; sync(); });
        body.querySelector('[data-role=text]').addEventListener('input', function(e){ b.text = e.target.value; sync(); });
      } else if (b.type === 'html') {
        var showPreview = b._showPreview !== false;
        body.innerHTML =
          '<textarea placeholder="&lt;div&gt;...raw HTML, download buttons, embeds, etc...&lt;/div&gt;">' + esc(b.html) + '</textarea>' +
          '<label class="cb-html-preview-toggle"><input type="checkbox" data-role="preview-toggle" style="width:auto;"' + (showPreview?' checked':'') + '> Show preview (YouTube / other embeds are shown small here so this page does not scroll too much)</label>' +
          (showPreview ? '<div class="cb-html-preview" data-role="preview">' + (b.html || '<span style="color:var(--muted,#94a3b8);font-size:12px;">Nothing to preview yet.</span>') + '</div>' : '');
        body.querySelector('textarea').addEventListener('input', function(e){
          b.html = e.target.value;
          var pv = body.querySelector('[data-role=preview]');
          if (pv) pv.innerHTML = b.html || '<span style="color:var(--muted,#94a3b8);font-size:12px;">Nothing to preview yet.</span>';
          sync();
        });
        body.querySelector('[data-role=preview-toggle]').addEventListener('change', function(e){ b._showPreview = e.target.checked; render(); });
      } else if (b.type === 'image') {
        var previewHtml = b.url ? ('<img class="cb-img-preview" src="' + b.url + '">') : '';
        body.innerHTML =
          previewHtml +
          '<input type="file" accept="image/*" data-role="file">' +
          '<div style="margin-top:6px;color:var(--muted);font-size:12px;">or paste an image URL:</div>' +
          '<input type="text" data-role="url" value="' + esc(b.url) + '" placeholder="https://...">' +
          '<div style="margin-top:6px;">Alt text: <input type="text" data-role="alt" value="' + esc(b.alt) + '" placeholder="Describe the image"></div>';
        body.querySelector('[data-role=url]').addEventListener('input', function(e){ b.url = e.target.value; render(); });
        body.querySelector('[data-role=alt]').addEventListener('input', function(e){ b.alt = e.target.value; sync(); });
        body.querySelector('[data-role=file]').addEventListener('change', function(e){
          var file = e.target.files[0];
          if (!file) return;
          var fd = new FormData();
          fd.append('image', file);
          fd.append('csrf', document.querySelector('input[name=csrf]').value);
          el.style.opacity = '0.5';
          fetch('ajax-upload-image.php', { method:'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(res){
              el.style.opacity = '1';
              if (res.ok) { b.url = res.url; render(); }
              else alert(res.error || 'Upload failed.');
            })
            .catch(function(){ el.style.opacity = '1'; alert('Upload failed.'); });
        });
      } else if (b.type === 'form') {
        var opts = forms.map(function(f){
          return '<option value="' + f.id + '"' + (String(b.formId)===String(f.id)?' selected':'') + '>' + esc(f.name) + '</option>';
        }).join('');
        body.innerHTML = '<select data-role="form-select"><option value="">-- Select a form --</option>' + opts + '</select>' +
          '<div style="margin-top:6px;color:var(--muted);font-size:12px;">Create/manage forms under Admin &gt; Forms.</div>';
        body.querySelector('[data-role=form-select]').addEventListener('change', function(e){ b.formId = e.target.value; sync(); });
      }
      el.appendChild(body);

      actions.querySelector('[data-act=up]').addEventListener('click', function(){ if (i>0){ blocks.splice(i-1,0,blocks.splice(i,1)[0]); render(); } });
      actions.querySelector('[data-act=down]').addEventListener('click', function(){ if (i<blocks.length-1){ blocks.splice(i+1,0,blocks.splice(i,1)[0]); render(); } });
      actions.querySelector('[data-act=copy]').addEventListener('click', function(){
        var dup = JSON.parse(JSON.stringify(b));
        blocks.splice(i+1, 0, dup);
        render();
      });
      actions.querySelector('[data-act=cut]').addEventListener('click', function(){
        clipboard = { block: JSON.parse(JSON.stringify(b)) };
        blocks.splice(i,1);
        render();
      });
      var convertBtn = actions.querySelector('[data-act=convert]');
      if (convertBtn) {
        convertBtn.addEventListener('click', function(){
          if (b.type === 'paragraph') {
            blocks[i] = { type:'heading', level:'h2', bold:false, text: b.text || '' };
          } else {
            blocks[i] = { type:'paragraph', text: b.text || '' };
          }
          render();
        });
      }
      actions.querySelector('[data-act=del]').addEventListener('click', function(){ if (confirm('Remove this block?')) { blocks.splice(i,1); render(); } });

      el.addEventListener('dragstart', function(e){
        dragFromIndex = i;
        el.classList.add('cb-dragging');
        e.dataTransfer.effectAllowed = 'move';
        try { e.dataTransfer.setData('text/plain', String(i)); } catch(err){}
      });
      el.addEventListener('dragend', function(){
        el.classList.remove('cb-dragging');
        list.querySelectorAll('.cb-drag-over').forEach(function(x){ x.classList.remove('cb-drag-over'); });
        dragFromIndex = null;
      });
      el.addEventListener('dragover', function(e){
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        el.classList.add('cb-drag-over');
      });
      el.addEventListener('dragleave', function(){ el.classList.remove('cb-drag-over'); });
      el.addEventListener('drop', function(e){
        e.preventDefault();
        el.classList.remove('cb-drag-over');
        if (dragFromIndex === null || dragFromIndex === i) return;
        var moved = blocks.splice(dragFromIndex, 1)[0];
        var target = i > dragFromIndex ? i - 1 : i;
        blocks.splice(target + 1, 0, moved);
        render();
      });

      return el;
    }

    function sync(){ ta.value = serializeBlocks(blocks); }

    toolbar.querySelectorAll('[data-add]').forEach(function(btn){
      btn.addEventListener('click', function(){
        var type = btn.getAttribute('data-add');
        var nb;
        if (type === 'heading') {
          nb = { type:'heading', level: btn.getAttribute('data-level') || 'h2', bold:false, text:'' };
        } else {
          nb = { type:type, text:'', html:'', url:'', alt:'', formId:'' };
        }
        blocks.push(nb);
        render();
      });
    });
    pasteBtn.addEventListener('click', function(){
      if (!clipboard) return;
      blocks.push(JSON.parse(JSON.stringify(clipboard.block)));
      render();
    });
    toolbar.querySelector('[data-sync]').addEventListener('click', function(){
      sync();
      alert(ta.value || '(empty)');
    });

    var formEl = ta.closest('form');
    if (formEl) formEl.addEventListener('submit', sync);

    render();
  }

  return { attach: attach };
})();
</script>
