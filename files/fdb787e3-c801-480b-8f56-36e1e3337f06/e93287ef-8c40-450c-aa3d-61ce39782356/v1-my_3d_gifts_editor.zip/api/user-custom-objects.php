<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Please login to use custom objects']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

try {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_custom_objects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        name VARCHAR(255) NOT NULL,
        object_data MEDIUMTEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
} catch(Exception $e) {
    if ($action === 'list') {
        echo json_encode(['success' => true, 'objects' => []]);
        exit;
    }
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    exit;
}

if ($action === 'list') {
    try {
        $stmt = $pdo->prepare('SELECT id, name, created_at FROM user_custom_objects WHERE user_id = ? ORDER BY id DESC');
        $stmt->execute([$user['id']]);
        echo json_encode(['success' => true, 'objects' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    } catch(Exception $e) {
        echo json_encode(['success' => true, 'objects' => []]);
    }
    exit;
}

if ($action === 'get') {
    $id = intval($_GET['id'] ?? 0);
    try {
        $stmt = $pdo->prepare('SELECT id, name, object_data FROM user_custom_objects WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $user['id']]);
        $obj = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($obj) {
            echo json_encode(['success' => true, 'object' => $obj]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Object not found']);
        }
    } catch(Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'save') {
    $input = json_decode(file_get_contents('php://input'), true);
    $data = $input['data'] ?? '';
    $name = trim($input['name'] ?? 'Custom Object');

    if (strlen($data) > 3145728) {
        echo json_encode(['success' => false, 'error' => 'File size exceeds 3MB limit.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare('INSERT INTO user_custom_objects (user_id, name, object_data) VALUES (?, ?, ?)');
        $stmt->execute([$user['id'], $name, $data]);
        echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
    } catch(Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    try {
        $stmt = $pdo->prepare('DELETE FROM user_custom_objects WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $user['id']]);
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid action']);
