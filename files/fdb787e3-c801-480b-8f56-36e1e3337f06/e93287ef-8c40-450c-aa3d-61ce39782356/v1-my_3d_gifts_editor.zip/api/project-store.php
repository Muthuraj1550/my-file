<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$user = current_user();
if ($user) check_and_expire_user($user);

// Cloud save/recovery is only for logged-in members (guests keep the existing
// browser-only localStorage recovery already built into the Designer).
if (!$user) {
    http_response_code(401);
    echo json_encode(['error' => 'login_required']);
    exit;
}

if (!cloud_projects_table_ready()) {
    http_response_code(503);
    echo json_encode(['error' => 'migration_needed', 'message' => 'migration-cloud-projects.sql இன்னும் run ஆகல - Admin-கிட்ட சொல்லுங்க.']);
    exit;
}

$action        = $_GET['action'] ?? ($_POST['action'] ?? '');
$namedLimit    = get_user_named_slot_limit($user); // extra named "Save As" slots on top of auto-save
$userId        = (int) $user['id'];

function _current_total_bytes($userId) {
    $stmt = db()->prepare("SELECT COALESCE(SUM(size_bytes),0) t FROM saved_projects WHERE user_id = ?");
    $stmt->execute([$userId]);
    return (int) $stmt->fetch()['t'];
}

function _named_slot_count($userId) {
    $stmt = db()->prepare("SELECT COUNT(*) c FROM saved_projects WHERE user_id = ? AND slot_name <> ?");
    $stmt->execute([$userId, CLOUD_PROJECT_AUTO_SLOT]);
    return (int) $stmt->fetch()['c'];
}

if ($action === 'list') {
    $stmt = db()->prepare("SELECT slot_name, size_bytes, updated_at FROM saved_projects WHERE user_id = ? ORDER BY (slot_name = ?) DESC, updated_at DESC");
    $stmt->execute([$userId, CLOUD_PROJECT_AUTO_SLOT]);
    $rows = $stmt->fetchAll();
    echo json_encode([
        'ok'             => true,
        'projects'       => $rows,
        'named_limit'    => $namedLimit,
        'named_used'     => _named_slot_count($userId),
        'total_bytes'    => _current_total_bytes($userId),
        'cap_bytes'      => CLOUD_PROJECT_STORAGE_CAP_BYTES,
    ]);
    exit;
}

if ($action === 'load') {
    $slot = trim($_GET['slot'] ?? CLOUD_PROJECT_AUTO_SLOT);
    $stmt = db()->prepare("SELECT slot_name, xml_data, updated_at FROM saved_projects WHERE user_id = ? AND slot_name = ?");
    $stmt->execute([$userId, $slot]);
    $row = $stmt->fetch();
    if (!$row) {
        echo json_encode(['ok' => true, 'found' => false]);
        exit;
    }
    echo json_encode(['ok' => true, 'found' => true, 'slot_name' => $row['slot_name'], 'xml' => $row['xml_data'], 'updated_at' => $row['updated_at']]);
    exit;
}

if ($action === 'save') {
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $slot = trim($body['slot'] ?? CLOUD_PROJECT_AUTO_SLOT);
    $xml  = (string) ($body['xml'] ?? '');

    if ($slot === '') $slot = CLOUD_PROJECT_AUTO_SLOT;
    if ($xml === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'empty_project']);
        exit;
    }

    $isAuto     = ($slot === CLOUD_PROJECT_AUTO_SLOT);
    $newBytes   = strlen($xml);

    // Free plan (named_limit = 0) can only ever use the auto-save slot.
    if (!$isAuto && $namedLimit <= 0) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'named_saves_require_paid_plan']);
        exit;
    }

    // Check named-slot count limit (only relevant for a brand-new named slot).
    $existingStmt = db()->prepare("SELECT id, size_bytes FROM saved_projects WHERE user_id = ? AND slot_name = ?");
    $existingStmt->execute([$userId, $slot]);
    $existing = $existingStmt->fetch();

    $evicted = null;
    if (!$isAuto && !$existing && _named_slot_count($userId) >= $namedLimit) {
        // rotate_oldest: auto-delete the oldest named slot to make room (user-requested behavior).
        if (!empty($body['rotate_oldest'])) {
            $oldestStmt = db()->prepare("SELECT id, slot_name FROM saved_projects WHERE user_id = ? AND slot_name <> ? ORDER BY updated_at ASC LIMIT 1");
            $oldestStmt->execute([$userId, CLOUD_PROJECT_AUTO_SLOT]);
            $oldest = $oldestStmt->fetch();
            if ($oldest) {
                $delStmt = db()->prepare("DELETE FROM saved_projects WHERE id = ?");
                $delStmt->execute([$oldest['id']]);
                $evicted = $oldest['slot_name'];
            }
        } else {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'named_slot_limit_reached', 'limit' => $namedLimit]);
            exit;
        }
    }

    // Check total 10MB/user cap (subtract the row we're about to overwrite, if any).
    $currentTotal = _current_total_bytes($userId) - ($existing ? (int)$existing['size_bytes'] : 0);
    if ($currentTotal + $newBytes > CLOUD_PROJECT_STORAGE_CAP_BYTES) {
        http_response_code(413);
        echo json_encode(['ok' => false, 'error' => 'storage_cap_exceeded', 'cap_bytes' => CLOUD_PROJECT_STORAGE_CAP_BYTES]);
        exit;
    }

    $stmt = db()->prepare("INSERT INTO saved_projects (user_id, slot_name, xml_data, size_bytes)
                            VALUES (?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE xml_data = VALUES(xml_data), size_bytes = VALUES(size_bytes)");
    $stmt->execute([$userId, $slot, $xml, $newBytes]);

    echo json_encode(['ok' => true, 'slot_name' => $slot, 'size_bytes' => $newBytes, 'evicted' => $evicted]);
    exit;
}

if ($action === 'delete') {
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $slot = trim($body['slot'] ?? '');
    if ($slot === '' || $slot === CLOUD_PROJECT_AUTO_SLOT) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'cannot_delete_auto_slot']);
        exit;
    }
    $stmt = db()->prepare("DELETE FROM saved_projects WHERE user_id = ? AND slot_name = ?");
    $stmt->execute([$userId, $slot]);
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'share') {
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $slot = trim($body['slot'] ?? '');
    if ($slot === '' || $slot === CLOUD_PROJECT_AUTO_SLOT) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'cannot_share_auto_slot']);
        exit;
    }
    
    $stmt = db()->prepare("SELECT id FROM saved_projects WHERE user_id = ? AND slot_name = ?");
    $stmt->execute([$userId, $slot]);
    $project = $stmt->fetch();
    
    if (!$project) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'project_not_found']);
        exit;
    }
    
    // Generate a unique share code (20 chars alphanumeric)
    $shareCode = bin2hex(random_bytes(10)); // 20 hex chars
    $projectId = (int) $project['id'];
    
    // Store share record (or update if exists)
    $stmtShare = db()->prepare("INSERT INTO project_shares (project_id, share_code, user_id, created_at)
                               VALUES (?, ?, ?, NOW())
                               ON DUPLICATE KEY UPDATE share_code = ?, updated_at = NOW()");
    $stmtShare->execute([$projectId, $shareCode, $userId, $shareCode]);
    
    // Build a share link using the already-working /designer?load_xml=<url>
    // auto-loader, pointed at our public share-xml.php resolver, instead of
    // the old /?import_project= route which nothing on the site handled.
    $resolverUrl = SITE_URL . '/api/share-xml.php?code=' . $shareCode;
    $shareUrl = SITE_URL . '/designer?load_xml=' . rawurlencode($resolverUrl);
    echo json_encode(['ok' => true, 'share_code' => $shareCode, 'share_url' => $shareUrl]);
    exit;
}

if ($action === 'import') {
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $shareCode = trim($body['share_code'] ?? '');
    
    if ($shareCode === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'invalid_share_code']);
        exit;
    }
    
    // Find the shared project
    $stmtFind = db()->prepare("SELECT sp.project_id, sp.user_id, p.slot_name, p.xml_data 
                              FROM project_shares sp
                              JOIN saved_projects p ON sp.project_id = p.id
                              WHERE sp.share_code = ? AND sp.share_enabled = 1");
    $stmtFind->execute([$shareCode]);
    $share = $stmtFind->fetch();
    
    if (!$share) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'share_not_found']);
        exit;
    }
    
    // Return the shared project data
    echo json_encode([
        'ok' => true,
        'slot_name' => $share['slot_name'],
        'xml' => $share['xml_data'],
        'author_id' => (int) $share['user_id']
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'unknown_action']);
