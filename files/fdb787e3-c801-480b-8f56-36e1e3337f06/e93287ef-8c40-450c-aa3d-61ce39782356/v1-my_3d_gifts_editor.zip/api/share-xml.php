<?php
// Public, unauthenticated endpoint — resolves a project share_code to the
// raw project XML, in the exact same format an external XML URL (e.g. a
// GitHub raw link) would return. This lets share links reuse the existing,
// already-working `/designer?load_xml=<url>` auto-loader instead of needing
// a brand-new client-side import flow.
//
// Anyone with the share link can VIEW the project this way (same as anyone
// with a GitHub raw link could) — the link only exists if the owner pressed
// "Share" for that project, which is treated as consent to share it.

require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/xml; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$code = trim($_GET['code'] ?? '');
if ($code === '' || !preg_match('/^[a-f0-9]{1,64}$/i', $code)) {
    http_response_code(400);
    exit;
}

$stmt = db()->prepare("SELECT p.xml_data
                        FROM project_shares sp
                        JOIN saved_projects p ON sp.project_id = p.id
                        WHERE sp.share_code = ? AND sp.share_enabled = 1
                        LIMIT 1");
$stmt->execute([$code]);
$row = $stmt->fetch();

if (!$row) {
    http_response_code(404);
    exit;
}

echo $row['xml_data'];
