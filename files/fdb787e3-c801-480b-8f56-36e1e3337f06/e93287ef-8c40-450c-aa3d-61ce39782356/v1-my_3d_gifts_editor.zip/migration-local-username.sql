-- =========================================================
--  Main Editor - Local Username Login (optional)
--  Lets Admin create a member account directly here with a
--  username + password (email optional) - separate from
--  course_username, which is only ever set automatically when
--  someone logs in with their course-site credentials.
--  Import once in phpMyAdmin. Only ADDS a column.
-- =========================================================

SET NAMES utf8mb4;

ALTER TABLE users ADD COLUMN IF NOT EXISTS local_username VARCHAR(60) DEFAULT NULL AFTER email;
ALTER TABLE users ADD UNIQUE KEY IF NOT EXISTS local_username (local_username);

-- Older MySQL/MariaDB la "IF NOT EXISTS" error kudutha, antha vaarthai-ya
-- remove panniddu marubadiyum run pannunga.
