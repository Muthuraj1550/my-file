<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/course_link.php';

if (is_logged_in()) redirect('/dashboard.php');

$errors = [];
$next = $_GET['next'] ?? ($_POST['next'] ?? '/dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = trim(strtolower($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';

    $stmt = db()->prepare("SELECT * FROM users WHERE email = ? AND role='member' LIMIT 1");
    $stmt->execute([$email]);
    $u = $stmt->fetch();

    // Locally-created member (Admin > Members > Add New Member): try the typed value as a local_username too.
    if ((!$u || !password_verify($pass, $u['password_hash'])) && local_username_ready()) {
        $stmt = db()->prepare("SELECT * FROM users WHERE local_username = ? AND role='member' LIMIT 1");
        $stmt->execute([trim($_POST['email'] ?? '')]);
        $byUsername = $stmt->fetch();
        if ($byUsername && password_verify($pass, $byUsername['password_hash'])) $u = $byUsername;
    }

    // Course site members: email illama, course username + password podalaam.
    if ((!$u || !password_verify($pass, $u['password_hash'])) && course_link_enabled()) {
        $courseName = trim($_POST['email'] ?? '');
        $check = course_link_verify($courseName, $pass);
        if (!empty($check['valid'])) {
            $newId = course_link_provision($courseName, $check);
            if ($newId) {
                log_user_in($newId);
                redirect($next ?: '/dashboard.php');
            }
            $errors[] = 'This course account is blocked here. Please contact support.';
        }
    }

    if ($errors) {
        // already handled above
    } elseif (!$u || !password_verify($pass, $u['password_hash'])) {
        $errors[] = course_link_enabled()
            ? 'Incorrect login. Members: email + password. Course buyers: course username + password.'
            : 'Incorrect email or password.';
    } elseif ($u['status'] === 'blocked') {
        $errors[] = 'This account has been blocked. Please contact support.';
    } else {
        log_user_in($u['id']);
        redirect($next ?: '/dashboard.php');
    }
}

$pageTitle = 'Login';
include __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:420px;margin:30px auto;">
  <h1 style="text-align:center;">Member Login</h1>
  <?php foreach ($errors as $e): ?>
    <div class="flash flash-error"><?php echo h($e); ?></div>
  <?php endforeach; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="next" value="<?php echo h($next); ?>">
    <label>Email Address <span style="font-weight:normal;color:#94a3b8;">(or username)</span></label>
    <input type="text" name="email" required>
    <label>Password</label>
    <input type="password" name="password" required>
    <button type="submit" class="btn btn-block">Login</button>
  </form>
  <?php if (course_link_enabled()): ?>
  <p style="text-align:center;margin-top:10px;color:#94a3b8;font-size:13px;">Course vaangunavanga: unga <b>course username + password</b> podunga.</p>
  <?php endif; ?>
  <p style="text-align:center;margin-top:16px;">New member? <a href="<?php echo SITE_URL; ?>/register.php">Register here</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
