-- =========================================================
--  Cloud Project Sharing
--
--  Adds support for sharing cloud-saved projects with
--  others via unique share codes. Recipients can import
--  the project into their own account.
-- =========================================================

CREATE TABLE IF NOT EXISTS project_shares (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    share_code VARCHAR(100) UNIQUE NOT NULL,
    share_enabled TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES saved_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX (share_code),
    INDEX (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
