<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/course_link.php';

header('Content-Type: application/json');

// Same-origin JSON login used by the 3D Designer's in-editor login popup
// (postMessage-relayed via designer.php) so a user can log in without
// leaving/reloading the designer and losing their in-progress project.
// Mirrors the logic in login.php exactly.

// Build the extra designer-access fields the 3D Designer needs to unlock
// premium templates / coins / save-slots immediately after login, without
// requiring a page refresh (designer.php only computes these once, at the
// initial page load, from the PHP session that existed before login).
function m3dg_login_access_payload($u) {
    return [
        'hasAccess'            => is_premium_designer_user($u),
        'isAdmin'              => (($u['role'] ?? '') === 'admin'),
        'namedSlotLimit'       => get_user_named_slot_limit($u),
        'tripoLoggedIn'        => true,
        'tripoCoins'           => (int)(($u['plan_coins'] ?? 0) + ($u['tripo_coins'] ?? 0)),
        'tripoPlanCoins'       => (int)($u['plan_coins'] ?? 0),
        'tripoPurchasedCoins'  => (int)($u['tripo_coins'] ?? 0),
        'featureAccess'        => designer_user_feature_access($u),
    ];
}

if (is_logged_in()) {
    $u = current_user();
    echo json_encode(array_merge(['ok' => true, 'name' => $u['name'] ?? ''], m3dg_login_access_payload($u)));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed.']);
    exit;
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) $data = $_POST;

$email = trim(strtolower((string)($data['email'] ?? '')));
$pass  = (string)($data['password'] ?? '');

if ($email === '' || $pass === '') {
    echo json_encode(['ok' => false, 'error' => 'Please enter both fields.']);
    exit;
}

$stmt = db()->prepare("SELECT * FROM users WHERE email = ? AND role='member' LIMIT 1");
$stmt->execute([$email]);
$u = $stmt->fetch();

// Course site members: email illama, course username + password podalaam.
if ((!$u || !password_verify($pass, $u['password_hash'])) && course_link_enabled()) {
    $courseName = trim((string)($data['email'] ?? ''));
    $check = course_link_verify($courseName, $pass);
    if (!empty($check['valid'])) {
        $newId = course_link_provision($courseName, $check);
        if ($newId) {
            log_user_in($newId);
            $u2 = current_user();
            echo json_encode(array_merge(['ok' => true, 'name' => $u2['name'] ?? ''], m3dg_login_access_payload($u2)));
            exit;
        }
        echo json_encode(['ok' => false, 'error' => 'This course account is blocked here. Please contact support.']);
        exit;
    }
}

if (!$u || !password_verify($pass, $u['password_hash'])) {
    $msg = course_link_enabled()
        ? 'Incorrect login. Members: email + password. Course buyers: course username + password.'
        : 'Incorrect email or password.';
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

if ($u['status'] === 'blocked') {
    echo json_encode(['ok' => false, 'error' => 'This account has been blocked. Please contact support.']);
    exit;
}

log_user_in($u['id']);
$uFresh = current_user();
echo json_encode(array_merge(['ok' => true, 'name' => $uFresh['name'] ?? ($u['name'] ?? '')], m3dg_login_access_payload($uFresh)));
