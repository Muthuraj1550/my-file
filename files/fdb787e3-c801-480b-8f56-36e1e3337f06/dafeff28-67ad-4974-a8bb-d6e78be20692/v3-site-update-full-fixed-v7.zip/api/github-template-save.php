<?php
// Admin-only. Called (via designer.php's postMessage relay, same-origin,
// session cookie included) from the 3D Designer's "See Full Templates"
// popup — the admin-only "💾 Save Current Project to GitHub" button.
//
// Pushes the current project as <name>.xml into the configured free or
// premium GitHub template repo, and — when the browser could capture one —
// a matching <name>.png thumbnail right alongside it. protected/engine.html's
// template list already auto-pairs same-named .xml + image files, so no
// extra wiring is needed on the read side once this lands the files.

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!is_logged_in() || !is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'admin_required', 'message' => 'Admin login தேவை.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'method_not_allowed']);
    exit;
}

$token = trim((string) get_setting('github_templates_token', ''));
if ($token === '') {
    http_response_code(503);
    echo json_encode([
        'ok' => false,
        'error' => 'not_configured',
        'message' => 'GitHub template token admin/settings.php-ல set பண்ணப்படல.',
    ]);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true) ?: [];

$repoChoice = ($body['repo'] ?? 'free') === 'premium' ? 'premium' : 'free';
$rawName    = trim((string) ($body['name'] ?? ''));
$xml        = (string) ($body['xml'] ?? '');
$thumbData  = (string) ($body['thumbnail'] ?? '');

// ── Sanitize the template name into a safe file basename ────────────────
// Strip a user-typed .xml/.png extension, path separators, control chars;
// collapse whitespace; cap length so it stays a sane GitHub filename.
$name = preg_replace('/\.(xml|png|jpe?g|webp)$/i', '', $rawName);
$name = str_replace(['/', '\\'], '-', $name);
$name = preg_replace('/[\x00-\x1F\x7F]/', '', $name);
$name = preg_replace('/\s+/', ' ', trim($name));
if (mb_strlen($name) > 100) $name = mb_substr($name, 0, 100);

if ($name === '') {
    echo json_encode(['ok' => false, 'error' => 'invalid_name', 'message' => 'Template name தேவை.']);
    exit;
}
if ($xml === '') {
    echo json_encode(['ok' => false, 'error' => 'invalid_xml', 'message' => 'Project XML காலியா இருக்கு.']);
    exit;
}

$repoSlug = trim((string) get_setting(
    $repoChoice === 'premium' ? 'github_templates_premium_repo' : 'github_templates_free_repo',
    $repoChoice === 'premium' ? 'Muthuraj1550/paid-template' : 'Muthuraj1550/free-Template'
));
// Accept either "owner/repo" or a full github.com URL in the setting.
if (preg_match('~github\.com/([^/]+/[^/]+)~i', $repoSlug, $m)) $repoSlug = $m[1];
$repoSlug = trim($repoSlug, '/');

if ($repoSlug === '' || strpos($repoSlug, '/') === false) {
    echo json_encode(['ok' => false, 'error' => 'bad_repo_config', 'message' => 'GitHub repo setting தவறா இருக்கு (owner/repo வேணும்).']);
    exit;
}

/** One GitHub Contents API call. $method is GET or PUT. $body (PUT only) is an assoc array. */
function gh_api_call($method, $repoSlug, $path, $token, $body = null) {
    $url = 'https://api.github.com/repos/' . $repoSlug . '/contents/' . rawurlencode($path);
    // rawurlencode also encodes '/', but our filenames never contain one — safe as-is.
    $ch = curl_init($url);
    $headers = [
        'Authorization: Bearer ' . $token,
        'Accept: application/vnd.github+json',
        'User-Agent: My3DGifts-Designer',
        'Content-Type: application/json',
    ];
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 25);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if ($method === 'PUT') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) return [null, 0, $err];
    return [json_decode($resp, true), $code, null];
}

/** Create or update one file in the repo (fetches current sha first so an
 *  existing template with the same name gets overwritten, not rejected). */
function gh_put_file($repoSlug, $path, $rawContent, $commitMsg, $token) {
    list($existing, $getCode) = gh_api_call('GET', $repoSlug, $path, $token);
    $sha = ($getCode === 200 && isset($existing['sha'])) ? $existing['sha'] : null;

    $payload = [
        'message' => $commitMsg,
        'content' => base64_encode($rawContent),
    ];
    if ($sha) $payload['sha'] = $sha;

    list($result, $code, $err) = gh_api_call('PUT', $repoSlug, $path, $token, $payload);
    if ($err) return ['ok' => false, 'error' => $err];
    if ($code >= 200 && $code < 300) return ['ok' => true];
    $msg = is_array($result) && isset($result['message']) ? $result['message'] : ('HTTP ' . $code);
    return ['ok' => false, 'error' => $msg];
}

// ── Save the XML ─────────────────────────────────────────────────────────
$xmlResult = gh_put_file($repoSlug, $name . '.xml', $xml, 'Add/update template: ' . $name, $token);
if (!$xmlResult['ok']) {
    echo json_encode(['ok' => false, 'error' => 'github_xml_failed', 'message' => $xmlResult['error']]);
    exit;
}

// ── Save the thumbnail (best-effort — the template still saves fine without it) ──
$thumbWarning = null;
if ($thumbData !== '' && preg_match('/^data:image\/(png|jpe?g|webp);base64,(.+)$/', $thumbData, $tm)) {
    $ext   = strtolower($tm[1]) === 'jpg' ? 'jpeg' : strtolower($tm[1]);
    $bytes = base64_decode($tm[2]);
    if ($bytes !== false) {
        $thumbResult = gh_put_file($repoSlug, $name . '.' . ($ext === 'jpeg' ? 'jpg' : $ext), $bytes, 'Add/update thumbnail: ' . $name, $token);
        if (!$thumbResult['ok']) $thumbWarning = $thumbResult['error'];
    }
}

echo json_encode([
    'ok'   => true,
    'name' => $name,
    'repo' => $repoChoice,
    'thumbnail_warning' => $thumbWarning,
]);
