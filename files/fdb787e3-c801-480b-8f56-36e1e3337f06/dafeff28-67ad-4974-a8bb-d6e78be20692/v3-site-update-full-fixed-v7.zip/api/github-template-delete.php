<?php
// Admin-only. Same relay pattern as api/github-template-save.php — removes
// <name>.xml (and a same-named .png/.jpg/.jpeg/.webp thumbnail, if one
// exists) from the configured free/premium GitHub template repo.

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!is_logged_in() || !is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'admin_required', 'message' => 'Admin login தேவை.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'method_not_allowed']);
    exit;
}

$token = trim((string) get_setting('github_templates_token', ''));
if ($token === '') {
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => 'not_configured', 'message' => 'GitHub template token admin/settings.php-ல set பண்ணப்படல.']);
    exit;
}

$body       = json_decode(file_get_contents('php://input'), true) ?: [];
$repoChoice = ($body['repo'] ?? 'free') === 'premium' ? 'premium' : 'free';
$rawName    = trim((string) ($body['name'] ?? ''));

$name = preg_replace('/\.(xml|png|jpe?g|webp)$/i', '', $rawName);
$name = str_replace(['/', '\\'], '-', $name);
$name = preg_replace('/[\x00-\x1F\x7F]/', '', $name);
$name = preg_replace('/\s+/', ' ', trim($name));

if ($name === '') {
    echo json_encode(['ok' => false, 'error' => 'invalid_name', 'message' => 'Template name தேவை.']);
    exit;
}

$repoSlug = trim((string) get_setting(
    $repoChoice === 'premium' ? 'github_templates_premium_repo' : 'github_templates_free_repo',
    $repoChoice === 'premium' ? 'Muthuraj1550/paid-template' : 'Muthuraj1550/free-Template'
));
if (preg_match('~github\.com/([^/]+/[^/]+)~i', $repoSlug, $m)) $repoSlug = $m[1];
$repoSlug = trim($repoSlug, '/');

if ($repoSlug === '' || strpos($repoSlug, '/') === false) {
    echo json_encode(['ok' => false, 'error' => 'bad_repo_config', 'message' => 'GitHub repo setting தவறா இருக்கு (owner/repo வேணும்).']);
    exit;
}

function gh_api_call2($method, $repoSlug, $path, $token, $body = null) {
    $url = 'https://api.github.com/repos/' . $repoSlug . '/contents/' . rawurlencode($path);
    $ch = curl_init($url);
    $headers = [
        'Authorization: Bearer ' . $token,
        'Accept: application/vnd.github+json',
        'User-Agent: My3DGifts-Designer',
        'Content-Type: application/json',
    ];
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 25);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if ($method === 'DELETE') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($err) return [null, 0, $err];
    return [json_decode($resp, true), $code, null];
}

/** Deletes one file if it exists; silently no-ops (ok) if it doesn't. */
function gh_delete_file($repoSlug, $path, $commitMsg, $token) {
    list($existing, $getCode) = gh_api_call2('GET', $repoSlug, $path, $token);
    if ($getCode === 404) return ['ok' => true, 'skipped' => true]; // nothing to delete
    if ($getCode !== 200 || !isset($existing['sha'])) {
        $msg = is_array($existing) && isset($existing['message']) ? $existing['message'] : ('HTTP ' . $getCode);
        return ['ok' => false, 'error' => $msg];
    }
    list($result, $code, $err) = gh_api_call2('DELETE', $repoSlug, $path, $token, [
        'message' => $commitMsg,
        'sha'     => $existing['sha'],
    ]);
    if ($err) return ['ok' => false, 'error' => $err];
    if ($code >= 200 && $code < 300) return ['ok' => true];
    $msg = is_array($result) && isset($result['message']) ? $result['message'] : ('HTTP ' . $code);
    return ['ok' => false, 'error' => $msg];
}

$xmlResult = gh_delete_file($repoSlug, $name . '.xml', 'Delete template: ' . $name, $token);
if (!$xmlResult['ok']) {
    echo json_encode(['ok' => false, 'error' => 'github_delete_failed', 'message' => $xmlResult['error']]);
    exit;
}

// Best-effort — try every thumbnail extension we might have saved; ignore failures.
foreach (['png', 'jpg', 'jpeg', 'webp'] as $ext) {
    gh_delete_file($repoSlug, $name . '.' . $ext, 'Delete thumbnail: ' . $name, $token);
}

echo json_encode(['ok' => true, 'name' => $name, 'repo' => $repoChoice]);
