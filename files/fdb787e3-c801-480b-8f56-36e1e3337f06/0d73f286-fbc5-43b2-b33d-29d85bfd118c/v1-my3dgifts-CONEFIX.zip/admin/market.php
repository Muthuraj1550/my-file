<?php
$adminTitle = 'Earn Money — Templates';
require_once __DIR__ . '/_layout_top.php';
require_once __DIR__ . '/../includes/market.php';

if (!market_ready()) { echo '<div class="card">Run <b>migration-marketplace.sql</b> in phpMyAdmin first.</div>'; require __DIR__ . '/_layout_bottom.php'; exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (isset($_POST['save_settings'])) {
        set_setting('market_enabled', isset($_POST['market_enabled']) ? '1' : '0');
        set_setting('market_creator_percent', min(100, max(0, (int)$_POST['market_creator_percent'])));
        set_setting('market_auto_approve_after', max(0, (int)$_POST['market_auto_approve_after']));
        set_setting('market_max_price', max(1, (int)$_POST['market_max_price']));
        set_setting('market_tutorial_url', trim($_POST['market_tutorial_url']));
        flash('Settings saved.');
    }
    $id = (int)($_POST['id'] ?? 0);
    if ($id && isset($_POST['approve'])) {
        $price = max(0, min(market_max_price(), round((float)$_POST['price'], 2)));
        db()->prepare("UPDATE market_templates SET status='approved', reject_reason='', price=?, approved_at=NOW() WHERE id=?")->execute([$price, $id]);
        flash('Approved ✅');
    }
    if ($id && isset($_POST['reject'])) {
        db()->prepare("UPDATE market_templates SET status='rejected', reject_reason=? WHERE id=?")
            ->execute([mb_substr(trim($_POST['reason'] ?? ''), 0, 255) ?: 'Quality / rules பூர்த்தியாகல', $id]);
        flash('Rejected.');
    }
    if ($id && isset($_POST['delete'])) {
        $s = db()->prepare("SELECT * FROM market_templates WHERE id=?"); $s->execute([$id]);
        if ($t = $s->fetch()) { market_delete_files($t); db()->prepare("DELETE FROM market_templates WHERE id=?")->execute([$id]); flash('Deleted.'); }
    }
    redirect('/admin/market.php' . (isset($_GET['f']) ? '?f=' . urlencode($_GET['f']) : ''));
}

$filter = in_array($_GET['f'] ?? '', ['pending','approved','rejected','all'], true) ? $_GET['f'] : 'pending';
$where = $filter === 'all' ? '' : "WHERE t.status = " . db()->quote($filter);
$rows = db()->query("SELECT t.*, u.name creator_name, u.email creator_email,
        (SELECT COUNT(*) FROM market_templates x WHERE x.user_id=t.user_id AND x.status='approved') creator_approved,
        (SELECT COUNT(*) FROM market_purchases p WHERE p.template_id=t.id AND p.status='paid') sales
        FROM market_templates t JOIN users u ON u.id=t.user_id $where ORDER BY t.created_at DESC LIMIT 200")->fetchAll();
$pendingN = (int)db()->query("SELECT COUNT(*) FROM market_templates WHERE status='pending'")->fetchColumn();
?>
<div class="card">
  <h3 style="margin-top:0">⚙️ Settings</h3>
  <form method="post"><?php echo csrf_field(); ?>
    <label><input type="checkbox" name="market_enabled" value="1" <?php echo get_setting('market_enabled','1')==='1'?'checked':''; ?>> Earn Money feature ON</label><br>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;">
      <div><label>Creator share (%)</label><input type="number" name="market_creator_percent" min="0" max="100" value="<?php echo market_creator_pct(); ?>"></div>
      <div><label>Auto-approve after N approved templates (0 = எப்பவும் manual)</label><input type="number" name="market_auto_approve_after" min="0" value="<?php echo market_auto_after(); ?>"></div>
      <div><label>Max price per template (₹)</label><input type="number" name="market_max_price" min="1" value="<?php echo market_max_price(); ?>"></div>
    </div>
    <label>🎬 Tutorial video link ("How to create template" button)</label>
    <input type="text" name="market_tutorial_url" value="<?php echo h(market_tutorial_url()); ?>" placeholder="https://youtu.be/...">
    <button class="btn" name="save_settings" value="1">Save settings</button>
  </form>
</div>

<div style="margin:10px 0;display:flex;gap:8px;flex-wrap:wrap;">
  <?php foreach (['pending'=>"⏳ Pending ($pendingN)", 'approved'=>'✅ Approved', 'rejected'=>'❌ Rejected', 'all'=>'All'] as $k => $lbl): ?>
    <a class="btn btn-sm <?php echo $filter===$k ? '' : 'btn-outline'; ?>" href="?f=<?php echo $k; ?>"><?php echo $lbl; ?></a>
  <?php endforeach; ?>
  <a class="btn btn-sm btn-outline" href="market-payouts.php">🔗 Creators &amp; splits →</a>
  <a class="btn btn-sm btn-outline" href="market-gateway.php">⚙️ Paid templates (Razorpay)</a>
</div>

<?php foreach ($rows as $t): ?>
<div class="card" style="padding:16px;display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start;">
  <div style="width:150px;height:110px;background:#0b1120;border-radius:8px;overflow:hidden;flex-shrink:0;">
    <?php if ($t['thumb_file']): ?><img src="<?php echo h(market_thumb_url($t)); ?>" style="width:100%;height:100%;object-fit:cover" alt=""><?php endif; ?>
  </div>
  <div style="flex:1;min-width:220px;">
    <b style="font-size:16px;"><?php echo h($t['title']); ?></b>
    <span class="badge <?php echo $t['status']==='approved'?'badge-active':($t['status']==='rejected'?'badge-expired':'badge-gold'); ?>"><?php echo h($t['status']); ?></span>
    <div style="color:var(--muted);font-size:13px;margin:4px 0;"><?php echo h($t['description']); ?></div>
    <div style="font-size:12px;color:var(--muted)">By <?php echo h($t['creator_name']); ?> (<?php echo h($t['creator_email']); ?>) · approved so far: <?php echo (int)$t['creator_approved']; ?> · <?php echo round($t['size_bytes']/1024); ?> KB · uses <?php echo (int)$t['use_count']; ?> · sales <?php echo (int)$t['sales']; ?></div>
    <div style="margin-top:8px;"><a class="btn btn-sm btn-outline" target="_blank" href="<?php echo SITE_URL; ?>/designer.php?market=<?php echo (int)$t['id']; ?>">👁 Open in designer</a></div>
  </div>
  <form method="post" style="width:230px;"><?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$t['id']; ?>">
    <label>Price ₹ (0 = free; used only when paid templates are ON)</label><input type="number" step="1" min="0" name="price" value="<?php echo h((float)$t['price']); ?>" style="margin-bottom:8px;">
    <input type="text" name="reason" placeholder="Reject reason" style="margin-bottom:8px;" value="<?php echo h($t['reject_reason']); ?>">
    <div style="display:flex;gap:6px;flex-wrap:wrap;">
      <?php if ($t['status'] !== 'approved'): ?><button class="btn btn-sm" name="approve" value="1">✅ Approve</button><?php endif; ?>
      <?php if ($t['status'] !== 'rejected'): ?><button class="btn btn-sm btn-danger" name="reject" value="1">❌ Reject</button><?php endif; ?>
      <button class="btn btn-sm btn-outline" name="delete" value="1" onclick="return confirm('Delete?')">🗑</button>
    </div>
  </form>
</div>
<?php endforeach; if (!$rows): ?><div class="card" style="color:var(--muted)">இங்க எதுவும் இல்ல.</div><?php endif; ?>
<?php require __DIR__ . '/_layout_bottom.php'; ?>
