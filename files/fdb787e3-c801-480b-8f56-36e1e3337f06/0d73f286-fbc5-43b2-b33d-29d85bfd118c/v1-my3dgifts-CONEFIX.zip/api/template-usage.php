<?php
// Template "use" counter for the designer's "See Full Templates" list.
//
//   POST {action:'hit',  kind:'free'|'premium', name:'<template name>'}  -> +1
//   GET  ?action=list                                                    -> {free:{name:count}, premium:{name:count}}
//
// Called through designer.php's postMessage relay (same-origin), like the
// other GitHub-template APIs. Never breaks the designer: on any DB problem
// (e.g. migration not imported yet) it just answers ok:false.

require_once __DIR__ . '/../includes/functions.php';
if (file_exists(__DIR__ . '/../includes/auth.php')) require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');

$body   = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $body['action'] ?? ($_GET['action'] ?? 'list');

try {
    if ($action === 'hit') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok' => false]); exit; }

        $kind = ($body['kind'] ?? '') === 'premium' ? 'premium' : 'free';
        $name = preg_replace('/\.(xml|png|jpe?g|webp)$/i', '', trim((string)($body['name'] ?? '')));
        $name = preg_replace('/[\x00-\x1F\x7F]/', '', $name);
        if (mb_strlen($name) > 190) $name = mb_substr($name, 0, 190);
        if ($name === '') { echo json_encode(['ok' => false, 'error' => 'invalid_name']); exit; }

        // Admin's own clicks (reviewing / managing templates) don't count.
        if (function_exists('is_admin') && is_admin()) { echo json_encode(['ok' => true, 'counted' => false]); exit; }

        // Same visitor re-opening the same template within 30 min = 1 use
        // (stops F5 / double-click inflation).
        if (session_status() === PHP_SESSION_NONE) @session_start();
        $key = 'tplhit_' . $kind . '_' . md5($name);
        $now = time();
        if (!empty($_SESSION[$key]) && ($now - (int)$_SESSION[$key]) < 1800) {
            echo json_encode(['ok' => true, 'counted' => false]);
            exit;
        }
        $_SESSION[$key] = $now;
        if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

        $stmt = db()->prepare(
            "INSERT INTO template_usage (kind, template_name, use_count, last_used_at)
             VALUES (?, ?, 1, NOW())
             ON DUPLICATE KEY UPDATE use_count = use_count + 1, last_used_at = NOW()"
        );
        $stmt->execute([$kind, $name]);
        echo json_encode(['ok' => true, 'counted' => true]);
        exit;
    }

    // action = list
    $out = ['free' => new stdClass(), 'premium' => new stdClass()];
    $free = []; $prem = [];
    foreach (db()->query("SELECT kind, template_name, use_count FROM template_usage")->fetchAll() as $r) {
        if ($r['kind'] === 'premium') $prem[$r['template_name']] = (int)$r['use_count'];
        else                          $free[$r['template_name']] = (int)$r['use_count'];
    }
    echo json_encode(['ok' => true, 'free' => (object)$free, 'premium' => (object)$prem]);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'error' => 'db_error']);
}
