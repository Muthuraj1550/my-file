<?php
// Earn Money / Template Marketplace helpers.
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/razorpay.php';

function market_ready() {
    static $ok = null;
    if ($ok !== null) return $ok;
    try { db()->query("SELECT 1 FROM market_templates LIMIT 1"); $ok = true; }
    catch (Throwable $e) { $ok = false; }
    if ($ok && get_setting('market_schema_v', '') !== '3') market_ensure_schema();
    return $ok;
}

/** Adds the payment-gateway columns / table on existing installs. Idempotent, runs once. */
function market_ensure_schema() {
    try {
        $pdo = db();
        $has = function ($table, $col) use ($pdo) {
            $q = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
            $q->execute([$table, $col]);
            return (int)$q->fetchColumn() > 0;
        };
        $add = [
            ['gateway',            "VARCHAR(20) NOT NULL DEFAULT 'cashfree'"],
            ['gateway_order_id',   "VARCHAR(60) NOT NULL DEFAULT ''"],
            ['gateway_payment_id', "VARCHAR(60) NOT NULL DEFAULT ''"],
            ['split_auto',         "TINYINT(1) NOT NULL DEFAULT 0"],
        ];
        foreach ($add as $a) {
            if (!$has('market_purchases', $a[0])) $pdo->exec("ALTER TABLE market_purchases ADD COLUMN {$a[0]} {$a[1]}");
        }
        $pdo->exec("CREATE TABLE IF NOT EXISTS market_linked_accounts (
            user_id INT UNSIGNED NOT NULL,
            razorpay_account_id VARCHAR(40) NOT NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        foreach ([['source', "VARCHAR(10) NOT NULL DEFAULT 'admin'"], ['payout_label', "VARCHAR(80) NOT NULL DEFAULT ''"]] as $a) {
            if (!$has('market_linked_accounts', $a[0])) $pdo->exec("ALTER TABLE market_linked_accounts ADD COLUMN {$a[0]} {$a[1]}");
        }
        set_setting('market_schema_v', '3');
    } catch (Throwable $e) { /* retried on next request */ }
}
function market_enabled()        { return market_ready() && get_setting('market_enabled', '1') === '1'; }
function market_creator_pct()    { return min(100, max(0, (int) get_setting('market_creator_percent', 70))); }
function market_auto_after()     { return max(0, (int) get_setting('market_auto_approve_after', 3)); } // 0 = never auto
function market_max_price()      { return max(1, (int) get_setting('market_max_price', 999)); }
function market_tutorial_url()   { return trim((string) get_setting('market_tutorial_url', '')); }
function market_max_bytes()      { return 7 * 1024 * 1024; }

function market_dir() {
    $d = __DIR__ . '/../storage/market';
    if (!is_dir($d)) @mkdir($d, 0755, true);
    return $d;
}

function market_creator($userId) {
    $s = db()->prepare("SELECT * FROM market_creators WHERE user_id = ?");
    $s->execute([$userId]);
    return $s->fetch() ?: null;
}

function market_approved_count($userId) {
    $s = db()->prepare("SELECT COUNT(*) FROM market_templates WHERE user_id = ? AND status = 'approved'");
    $s->execute([$userId]);
    return (int) $s->fetchColumn();
}

/** True if this creator's NEW post should be approved automatically. */
function market_should_auto_approve($userId) {
    $n = market_auto_after();
    return $n > 0 && market_approved_count($userId) >= $n;
}

function market_user_owns($userId, $tplId) {
    $s = db()->prepare("SELECT 1 FROM market_purchases WHERE buyer_id = ? AND template_id = ? AND status = 'paid' LIMIT 1");
    $s->execute([$userId, $tplId]);
    return (bool) $s->fetchColumn();
}

function market_thumb_url($t) {
    return $t['thumb_file'] ? SITE_URL . '/api/market-thumb.php?id=' . (int)$t['id'] : '';
}

function market_price_label($price) {
    return ((float)$price) > 0 ? '₹' . rtrim(rtrim(number_format((float)$price, 2, '.', ''), '0'), '.') : 'FREE';
}

/**
 * Approved templates, most used first (home page rows).
 * $by = 'community' (made by normal users), 'admin' (made by admin accounts, free + paid) or 'all'.
 */
function market_trending($limit = 6, $by = 'community') {
    if (!market_enabled()) return [];
    $where = "t.status = 'approved'";
    if ($by === 'admin')          $where .= " AND u.role = 'admin'";
    elseif ($by === 'community')  $where .= " AND (u.role IS NULL OR u.role <> 'admin')";
    $s = db()->prepare("SELECT t.*, u.name AS creator_name FROM market_templates t
                        JOIN users u ON u.id = t.user_id
                        WHERE $where ORDER BY t.use_count DESC, t.approved_at DESC LIMIT " . (int)$limit);
    $s->execute();
    return $s->fetchAll();
}

/**
 * Admin's own GitHub templates (free + paid), most used first, from the designer's
 * "See Full Templates" use counter (template_usage). Returns rows with a ready thumbnail base URL.
 */
function admin_template_trending($limit = 6) {
    try {
        $s = db()->prepare("SELECT kind, template_name, use_count FROM template_usage WHERE use_count > 0
                            ORDER BY use_count DESC, last_used_at DESC LIMIT " . (int)$limit);
        $s->execute();
        $rows = $s->fetchAll();
    } catch (Throwable $e) { return []; }   // migration-template-usage.sql not imported yet
    $repos = [
        'free'    => trim((string)get_setting('github_templates_free_repo', 'Muthuraj1550/free-Template')),
        'premium' => trim((string)get_setting('github_templates_premium_repo', 'Muthuraj1550/paid-template')),
    ];
    foreach ($rows as &$r) {
        $repo = preg_replace('~^https?://github\.com/~i', '', $repos[$r['kind']] ?? '');
        $repo = trim($repo, '/');
        $r['thumb_base'] = $repo !== '' ? 'https://raw.githubusercontent.com/' . $repo . '/main/' . rawurlencode($r['template_name']) : '';
    }
    unset($r);
    return $rows;
}

/** Count a "use" (same visitor, same template within 30 min = 1). */
function market_count_use($tplId) {
    if (session_status() === PHP_SESSION_NONE) @session_start();
    $key = 'mkuse_' . (int)$tplId; $now = time();
    if (!empty($_SESSION[$key]) && ($now - (int)$_SESSION[$key]) < 1800) return;
    $_SESSION[$key] = $now;
    db()->prepare("UPDATE market_templates SET use_count = use_count + 1, last_used_at = NOW() WHERE id = ?")->execute([$tplId]);
}

function market_delete_files($t) {
    foreach (['xml_file', 'thumb_file'] as $k) {
        if (!empty($t[$k])) @unlink(market_dir() . '/' . basename($t[$k]));
    }
}

/** Creator earnings summary: [total, unpaid, paid, sales]. */
function market_creator_totals($userId) {
    $s = db()->prepare("SELECT COALESCE(SUM(creator_amount),0) total,
                               COALESCE(SUM(CASE WHEN payout_status='unpaid' THEN creator_amount END),0) unpaid,
                               COALESCE(SUM(CASE WHEN payout_status='paid' THEN creator_amount END),0) paid,
                               COUNT(*) sales
                        FROM market_purchases WHERE creator_id = ? AND status = 'paid'");
    $s->execute([$userId]);
    return $s->fetch();
}


// ───────── Payment gateway helpers ─────────
/**
 * Paid templates are OFF until the admin switches them on (after Razorpay approval).
 * While OFF, every template is free and nobody can set a price.
 */
function market_paid_enabled() {
    return get_setting('market_paid_enabled', '0') === '1'
        && rzp_configured();
}

/** user_ids that have a Razorpay Route linked account (needed for the automatic split). */
function market_linked_ids() {
    static $ids = null;
    if ($ids === null) {
        try { $ids = array_flip(array_map('intval', db()->query("SELECT user_id FROM market_linked_accounts")->fetchAll(PDO::FETCH_COLUMN))); }
        catch (Throwable $e) { $ids = []; }
    }
    return $ids;
}

/** 'auto' (Razorpay Route linked account) or '' (no payout set up yet). */
function market_payout_mode($userId) {
    return isset(market_linked_ids()[(int)$userId]) ? 'auto' : '';
}

/** Can this creator's templates be sold? Only with paid mode ON and a linked account for the auto split. */
function market_sellable($creatorId) {
    if (!market_paid_enabled()) return false;
    return market_payout_mode($creatorId) !== '' || rzp_is_test();   // test keys: sell without any payout setup so checkout can be tried
}

/** The price a buyer actually sees/pays for a template row (0 = free). */
function market_row_price($t) { return market_sellable($t['user_id']) ? (float)$t['price'] : 0.0; }

/** Creator's Razorpay Route linked account id (acc_xxx) or ''. */
function market_linked_account($userId) {
    try {
        $s = db()->prepare("SELECT razorpay_account_id FROM market_linked_accounts WHERE user_id = ?");
        $s->execute([$userId]);
        return (string)($s->fetchColumn() ?: '');
    } catch (Throwable $e) { return ''; }
}

/** Mark a purchase paid (idempotent). Auto-split purchases are also marked as paid out to the creator. */
function market_mark_paid($purchaseId, $paymentId = '') {
    db()->prepare("UPDATE market_purchases
                   SET status = 'paid',
                       gateway_payment_id = ?,
                       payout_status = IF(split_auto = 1, 'paid', payout_status),
                       payout_ref    = IF(split_auto = 1, CONCAT('Razorpay Route ', ?), payout_ref),
                       paid_out_at   = IF(split_auto = 1, NOW(), paid_out_at)
                   WHERE id = ? AND status <> 'paid'")
        ->execute([$paymentId, $paymentId, $purchaseId]);
}
