-- =========================================================
--  Designer feature gate: 3MF (Multicolor) export
--
--  Adds ONE row to designer_features for the new "3MF (Multicolor)"
--  option in the 3D Designer's Export format dropdown. Same mechanism as
--  the OBJ / GLB / FBX rows on Admin -> Designer Access -> "Export" group.
--
--  Default: 'fully_locked' (OFF for Guests and every plan you have not
--  unlocked). Go to Admin -> Designer Access -> "Export - 3MF Format (Multicolor)"
--  and set it to Allowed for whichever plan(s) should get it.
--
--  NOTE: if you do NOT run this migration, the feature key is simply missing
--  and the designer treats it as ALLOWED for everyone (fail-open).
--
--  Run AFTER migration-designer-feature-gate-v11.sql. Safe to re-run (INSERT IGNORE).
-- =========================================================

INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order) VALUES
('export_3mf', 'Export - 3MF Format (Multicolor)', 'fully_locked', 315);
