-- =========================================================
--  Custom Font Upload (TTF / OTF) — admin/subscription-controlled gate
--
--  Adds ONE new row to the existing designer_features table for the new
--  "Install Custom Font" button inside the 3D Designer's Font Selection
--  panel. The font file itself is NEVER uploaded to your server — the
--  person's browser parses it locally (opentype.js) and stores it in
--  that browser's own localStorage on their device. This migration only
--  adds the ON/OFF + per-plan gate for the *feature* (who is allowed to
--  install a custom font at all), using the exact same mechanism as
--  every other row on Admin → Designer Access.
--
--  Default: 'fully_locked' — i.e. OFF for Guests and any plan you haven't
--  explicitly unlocked yet. Go to Admin → Designer Access → "Fonts" group
--  → "Custom Font Upload (TTF/OTF)" row and set it to Allowed for
--  whichever paid plan(s) should get this feature.
--
--  Run AFTER migration-designer-feature-gate.sql (and its follow-ups:
--  -fix, -rename-stylish, -per-plan-access, -v11, -v12) have already been
--  imported. Safe to re-run (INSERT IGNORE).
-- =========================================================

INSERT IGNORE INTO designer_features (feature_key, feature_name, lock_mode, sort_order) VALUES
('custom_font_upload', 'Custom Font Upload (TTF/OTF, install from device)', 'fully_locked', 270);
