<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/course_link.php';

header('Content-Type: application/json');

// Called SERVER-TO-SERVER by the course site right after a Main Editor
// plan payment succeeds there (it has no gateway of its own — see
// membership.php / course_site_plan_pay_url()). Verified with the same
// api_key both sides already exchange for course logins.

/**
 * Every call in here — success OR failure — gets written to
 * logs/activate-plan.log so a silent "member didn't get access" report
 * can actually be traced (was the call ever received? bad signature?
 * no matching account? etc). Never let logging itself break activation.
 */
function activate_plan_log($line) {
    try {
        $dir = __DIR__ . '/../logs';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $entry = '[' . date('Y-m-d H:i:s') . '] ' . $line . "\n";
        @file_put_contents($dir . '/activate-plan.log', $entry, FILE_APPEND | LOCK_EX);
    } catch (Throwable $e) { /* never block on logging */ }
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) $data = $_POST;

$email    = trim((string) ($data['email'] ?? ''));
$planName = trim((string) ($data['plan_name'] ?? ''));
$days     = max(1, (int) ($data['days'] ?? 30));
$coins    = max(0, (int) ($data['coins'] ?? 0));
$ts       = (int) ($data['ts'] ?? 0);
$sig      = (string) ($data['sig'] ?? '');

activate_plan_log("Incoming: email=$email plan=$planName days=$days coins=$coins ts=$ts from_ip=" . ($_SERVER['REMOTE_ADDR'] ?? '?'));

if ($email === '' || $planName === '') {
    activate_plan_log("REJECTED: missing fields (email or plan_name empty)");
    echo json_encode(['ok' => false, 'msg' => 'Missing fields']);
    exit;
}
if (abs(time() - $ts) > 900) {
    activate_plan_log("REJECTED: request expired (ts=$ts, server_time=" . time() . ", diff=" . abs(time() - $ts) . "s — check both sites' server clocks match)");
    echo json_encode(['ok' => false, 'msg' => 'Request expired']);
    exit;
}
$sigParams = ['email' => $email, 'plan_name' => $planName, 'days' => $days, 'coins' => $coins, 'ts' => $ts];
if (course_link_key() === '' || !hash_equals(course_site_sign($sigParams), $sig)) {
    activate_plan_log("REJECTED: invalid signature (course_api_key empty or doesn't match the key configured on the course/design site's side — Admin > Course Site Access on both sites must have the SAME key)");
    http_response_code(403);
    echo json_encode(['ok' => false, 'msg' => 'Invalid signature']);
    exit;
}

$stmt = db()->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user) {
    activate_plan_log("REJECTED: no Main Editor account for email=$email — user must register here first before/after paying on the design site");
    echo json_encode(['ok' => false, 'msg' => 'No Main Editor account with this email yet — user must register first.']);
    exit;
}

$expiry = date('Y-m-d', strtotime('+' . $days . ' days'));
db()->prepare("UPDATE users SET plan_name = ?, plan_expiry = ?, plan_coins = ? WHERE id = ?")
    ->execute([$planName, $expiry, $coins, $user['id']]);

// Point plan_id at a matching local plan row too, if one exists by name (cosmetic/for admin lists).
$planId = null;
$planPrice = 0;
try {
    $p = db()->prepare("SELECT id, price FROM plans WHERE plan_name = ? LIMIT 1");
    $p->execute([$planName]);
    if ($row = $p->fetch()) {
        $planId = (int) $row['id'];
        $planPrice = (float) $row['price'];
        db()->prepare("UPDATE users SET plan_id = ? WHERE id = ?")->execute([$planId, $user['id']]);
    }
} catch (Exception $e) { /* non-fatal */ }

// Log this cross-site payment into the LOCAL orders table too. The actual
// Cashfree checkout runs on the design/course site (it holds the approved
// gateway), so nothing was ever writing to Main Editor's own `orders`
// table before this — which is exactly why Admin > Dashboard revenue and
// "Recent Orders" always showed 0 / empty here, even though real payments
// were going through. Best-effort: never blocks plan activation if it fails.
try {
    db()->prepare("INSERT INTO orders (user_id, plan_id, amount, status, cf_order_id, created_at)
                   VALUES (?, ?, ?, 'paid', ?, NOW())")
        ->execute([$user['id'], $planId, $planPrice, 'CROSS-' . $user['id'] . '-' . $ts]);
} catch (Throwable $e) {
    activate_plan_log("NOTE: plan activated OK but local orders-table insert failed (" . $e->getMessage() . ") — revenue dashboard won't reflect this order");
}

activate_plan_log("OK: activated plan=$planName for user_id={$user['id']} email=$email expiry=$expiry coins=$coins");
echo json_encode(['ok' => true, 'msg' => 'Plan activated', 'user_id' => (int) $user['id']]);
