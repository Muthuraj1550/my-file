<?php
/**
 * =========================================================
 *  COURSE SITE LINK  (Main Editor side)
 * =========================================================
 *  Ithu API key GENERATE panradhu illa.
 *  Course site la generate panna API key-a inga ENTER pannuvom
 *  (Admin -> Course Site Access).
 *
 *  Course site la course vaangunavanga kku auto generate aagura
 *  username + password vachu, ANGAYE verify panni, inga editor
 *  la login aaguvanga. Login aana odane avangaluku admin select
 *  panna plan (premium templates + feature limits) apply aagum.
 */

require_once __DIR__ . '/db.php';

/* ---------- settings helpers ---------- */

function course_link_url()      { return rtrim((string) get_setting('course_api_url', ''), '/'); }
function course_link_key()      { return trim((string) get_setting('course_api_key', '')); }
function course_link_site_id()  { return trim((string) get_setting('course_api_site', 'main_editor')) ?: 'main_editor'; }
function course_link_plan_id()  { return (int) get_setting('course_plan_id', 0); }
function course_link_days()     { return max(1, (int) get_setting('course_plan_days', 30)); }

/** Course login enabled only when URL + key both entered. */
function course_link_enabled() {
    return get_setting('course_login_enabled', '1') === '1'
        && course_link_url() !== '' && course_link_key() !== '';
}

/** Extra users.course_username column present? (migration-course-login.sql) */
function course_link_ready() {
    static $ready = null;
    if ($ready === null) {
        try { db()->query("SELECT course_username FROM users LIMIT 1"); $ready = true; }
        catch (Exception $e) { $ready = false; }
    }
    return $ready;
}

/* ---------- the actual API call ---------- */

/**
 * Ask the course site: is this username/password a real course buyer?
 * Returns ['valid'=>true, 'user_name'=>..,'product'=>..,'plan'=>[..]] or
 * ['valid'=>false,'reason'=>'...'].
 */
function course_link_verify($username, $password) {
    if (!course_link_enabled()) return ['valid' => false, 'reason' => 'Course login is off.'];

    $endpoint = course_link_url() . '/api/verify-license.php';
    $payload  = json_encode([
        'api_key'  => course_link_key(),
        'site'     => course_link_site_id(),
        'username' => $username,
        'password' => $password,
    ]);

    $body = null;
    if (function_exists('curl_init')) {
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $body = curl_exec($ch);
        if ($body === false) {
            $err = curl_error($ch);
            curl_close($ch);
            return ['valid' => false, 'reason' => 'Course site contact fail: ' . $err];
        }
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/json\r\n",
            'content' => $payload,
            'timeout' => 15,
            'ignore_errors' => true,
        ]]);
        $body = @file_get_contents($endpoint, false, $ctx);
        if ($body === false) return ['valid' => false, 'reason' => 'Course site contact fail.'];
    }

    $data = json_decode((string) $body, true);
    if (!is_array($data)) return ['valid' => false, 'reason' => 'Course site gave an unexpected reply.'];
    if (empty($data['valid'])) {
        return ['valid' => false, 'reason' => $data['reason'] ?? 'Wrong username or password.'];
    }
    return $data;
}

/**
 * Course la valid nu vandha piragu — inga local member row create/update
 * pannitu, adhoda id return pannum. Plan apply aagum, so premium templates
 * + limits ellam normal paid member maadhiriye work aagum.
 */
function course_link_provision($username, $data) {
    $username = trim((string) $username);
    if ($username === '') return null;

    $email = 'course_' . preg_replace('/[^a-z0-9_.-]/i', '', strtolower($username)) . '@course.local';
    $name  = trim((string) ($data['user_name'] ?? '')) ?: $username;

    // Which local plan should course members get?
    $plan = null;
    if (course_link_plan_id() > 0) $plan = get_plan(course_link_plan_id());
    if (!$plan) {
        // fall back to the highest premium plan available
        foreach (all_plans() as $p) { if ((int)$p['premium_designer'] === 1) { $plan = $p; break; } }
    }
    $planId   = $plan ? (int)$plan['id'] : null;
    $planName = $plan ? $plan['plan_name'] : null;
    $expiry   = date('Y-m-d', strtotime('+' . course_link_days() . ' days'));

    $stmt = db()->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $u = $stmt->fetch();

    if (!$u) {
        $ins = db()->prepare("INSERT INTO users (name, email, password_hash, role, plan_id, plan_name, plan_expiry, status)
                              VALUES (?,?,?, 'member', ?,?,?, 'active')");
        $ins->execute([$name, $email, password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT), $planId, $planName, $expiry]);
        $id = (int) db()->lastInsertId();
    } else {
        $id = (int) $u['id'];
        if ($u['status'] === 'blocked') return null;
        db()->prepare("UPDATE users SET name = ?, plan_id = ?, plan_name = ?, plan_expiry = ? WHERE id = ?")
            ->execute([$name, $planId, $planName, $expiry, $id]);
    }

    if (course_link_ready()) {
        try { db()->prepare("UPDATE users SET course_username = ? WHERE id = ?")->execute([$username, $id]); }
        catch (Exception $e) { /* ignore */ }
    }

    // Monthly plan coins refresh (if that migration is installed).
    // Prefer the coin count the course site just told us about (per-buyer,
    // driven by whichever membership plan they actually bought there);
    // fall back to this local plan's own bonus coins if the course site
    // didn't send any (e.g. older course-site version).
    $coins = null;
    if (isset($data['plan']['plan_bonus_coins'])) {
        $coins = (int) $data['plan']['plan_bonus_coins'];
    } elseif ($plan && isset($plan['plan_bonus_coins'])) {
        $coins = (int) $plan['plan_bonus_coins'];
    }
    if ($coins !== null) {
        try { db()->prepare("UPDATE users SET plan_coins = ? WHERE id = ?")->execute([$coins, $id]); } catch (Exception $e) {}
    }

    return $id;
}

/* ---------- Membership plans redirect (on / off) ---------- */

/** ON aana, paid access click panna course site kku anuppum. */
function plans_redirect_on() {
    return get_setting('plans_redirect_enabled', '0') === '1'
        && trim((string) get_setting('plans_redirect_url', '')) !== '';
}

/** The course-site purchase URL entered in Admin -> Settings. */
function plans_redirect_target_url() {
    return trim((string) get_setting('plans_redirect_url', ''));
}

/** Where should a "view plans / upgrade" click go? */
function plans_link() {
    if (plans_redirect_on()) return trim((string) get_setting('plans_redirect_url', ''));
    return SITE_URL . '/membership.php';
}

/* ---------- Plan payment handoff (Main Editor has no gateway of its own) ---------- */

/**
 * Course site pays us via api/activate-plan.php using the SAME api_key
 * we already send it for course logins (course_link_key()) — no new
 * secret to configure, both sides already have this exact string.
 */
function course_site_sign(array $params) {
    $secret = course_link_key();
    unset($params['sig']);
    ksort($params);
    return hash_hmac('sha256', http_build_query($params), $secret);
}

/**
 * Build a signed link to the course site's guest checkout for this plan.
 * $user must have at least 'email'. Returns null if course-site link
 * isn't configured (course_api_url/course_api_key empty).
 */
function course_site_plan_pay_url(array $plan, array $user) {
    if (course_link_url() === '' || course_link_key() === '') return null;
    $params = [
        'email'      => $user['email'],
        'plan_name'  => $plan['plan_name'],
        'price'      => (float) $plan['price'],
        'days'       => (int) $plan['validity_days'],
        'coins'      => (int) ($plan['plan_bonus_coins'] ?? 0),
        'return_url' => SITE_URL . '/membership.php',
        'ts'         => time(),
    ];
    $params['sig'] = course_site_sign($params);
    return course_link_url() . '/main-editor-pay.php?' . http_build_query($params);
}

/**
 * Build a signed link to the course site's guest checkout for a coin
 * top-up. Course site computes the actual ₹ amount itself (it owns the
 * per-coin rate) — we only send how many coins are wanted.
 */
function course_site_coins_pay_url($coinsQty, array $user) {
    if (course_link_url() === '' || course_link_key() === '') return null;
    $params = [
        'kind'       => 'coins',
        'email'      => $user['email'],
        'coins_qty'  => max(1, (int) $coinsQty),
        'return_url' => SITE_URL . '/membership.php',
        'ts'         => time(),
    ];
    $params['sig'] = course_site_sign($params);
    return course_link_url() . '/main-editor-pay.php?' . http_build_query($params);
}

/* ---------- Push new registrations to the Course/Design site (optional) ---------- */

/**
 * When ON (Admin -> Course Site Access -> "sync_registration_to_course_site"),
 * every fresh Main Editor registration gets pushed here so the Course site's
 * Admin -> Main Editor Members page can show them (support/lookup use case).
 * $plainPassword is only ever available right here, right after registration
 * (before it gets one-way hashed) — never re-derivable later. Best-effort:
 * short timeout, wrapped so a slow/unreachable course site never blocks or
 * fails the person's registration.
 */
function notify_course_site_registration(array $user, $plainPassword) {
    if (get_setting('sync_registration_to_course_site', '0') !== '1') return;
    if (course_link_url() === '' || course_link_key() === '') return;

    $params = [
        'name'           => (string) $user['name'],
        'email'          => (string) $user['email'],
        'phone'          => (string) ($user['phone'] ?? ''),
        'address'        => (string) ($user['address'] ?? ''),
        'password_plain' => (string) $plainPassword,
        'ts'             => time(),
    ];
    $params['sig'] = course_site_sign($params);

    try {
        $ch = curl_init(course_link_url() . '/api/main-editor-register.php');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($params),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 6, // never let a slow course site delay registration noticeably
        ]);
        curl_exec($ch);
        curl_close($ch);
    } catch (Throwable $e) { /* best-effort — registration must succeed regardless */ }
}
