# MY 3D Gifts — V23 Release Notes

## 🐛 Bug Fix 1: Shopping Page Image Broken

### Root Cause
`api/fix-images.php` (v22) bug — products table-ல் **`image` (main cover column) fix ஆகவில்லை**.
Only `images` (JSON array) மற்றும் `options` JSON fix ஆகுது. அதனால் old products-ல்
`http://localhost/uploads/img_xxx.jpg` என்று absolute URL இருந்தால் shopping page-ல் broken image காட்டும்.

Admin panel-ல் media library preview-ல் `imgUrl()` function இல்லாமல் broken காட்டுவதும் இதே காரணம்.

### Files Changed
- `api/fix-images.php` — products.image column + media table URLs-ஐயும் fix செய்யும்படி update
- `admin-app.html` — `imgUrl()` helper function add + media preview-ல் use
- `admin-app.html` — `renderPImagePreview()` function-ல் imgUrl() use

### ⚡ Deploy பிறகு ONE-TIME Action Required
Admin panel-ல் ஒரு முறை POST செய்யுங்கள்:
```
POST /api/fix-images.php
Header: X-Admin-Key: <your key>
```
இது database-ல் உள்ள அனைத்து absolute URLs-ஐயும் relative paths-ஆக மாற்றும்.
(முதலில் GET செய்து dry-run பார்க்கலாம்)

---

## ✨ New Feature: Coins Cash Redeem

### User Side (index.html)
- Account → Loyalty Coins section-ல் balance ≥ minRedeem என்றால் "💸 Coins-ஐ பணமாக மாற்றவும்" section காட்டும்
- Coins amount type செய்தால் ₹ மதிப்பு live preview
- Submit செய்தால் admin-க்கு request போகும், coins உடனே deduct ஆகும்
- Admin approve பிறகு UPI/Bank transfer

### Admin Side (admin-app.html + api/coins.php)
- Loyalty Coins page-ல் "💸 Cash Redeem Requests" table
- Pending badge with count
- ✅ Paid / ❌ Reject buttons
- Reject செய்தால் coins automatically refund ஆகும்

### New API Endpoints
- `POST /api/coins/cashredeem` — user request submit
- `GET  /api/coins/cashredeem-list` — admin list (requires X-Admin-Key)
- `POST /api/coins/cashredeem-status` — admin approve/reject (requires X-Admin-Key)

### New DB Table (auto-created)
```sql
cash_redeem_requests (id, user_id, user_name, phone, coins, rupees, status, admin_note, created_at)
```
