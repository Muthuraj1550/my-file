# MY 3D Gifts — Hosting Pack v12

## What's new in v12 (vs v11)

✅ **Storefront restored** — full v10.1 features brought back:
- Filament Color Library — global colors auto-sync to all "sync"-mode products
- Per-product color mode: **Sync** (use library) or **Custom** (own palette)
- 3D viewer + GLB / glTF model + animation autoplay support
- GIF & video preview options
- Buy Now → WhatsApp toggle
- Quick-Buy from product cards
- Cart abandonment recovery (backend table + admin recovery page)
- Courier tracking display on Track Order page
- Custom popup notifications

✅ **Admin login fixed** — storefront "Admin" button now opens `admin-login.html` (PHP API auth via `/api/admin-auth.php`). No more demo localStorage admin.

✅ **Admin Console rebuilt** with all v10 features:
- Dashboard, Orders (+ Courier + Tracking + WhatsApp send), Cart Recovery
- Products (with Color Mode, GLB, animation toggles)
- Customers, Analytics
- Coupons, Flash Sale, Popups
- Filament Colors (global library — single source of truth for all products)
- Shipping Zones + Courier partners
- Payment toggles + Cashfree configuration
- Navigation builder (bottom nav + side panel)
- Custom Pages, About / Contact, Theme, Settings
- Buy Behaviour toggles (Buy Now → WhatsApp / Quick Buy / 3D Viewer)

✅ **No more "Load failed: Invalid JSON"** — robust error parsing shows actual server message

## Setup (cPanel hosting)

1. Upload all files in `my3dgifts-v12/` to `public_html/`
2. Edit `config.php`:
   - `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`
   - `ADMIN_USERNAME`, `ADMIN_PASSWORD`
3. phpMyAdmin → SQL → paste `install.sql` → Go
4. Visit `healthcheck.php` to verify DB. Then DELETE it.
5. Storefront: `https://yourdomain.com/`
6. Admin: storefront ☰ → "Admin Panel" OR direct `https://yourdomain.com/admin-login.html`
   - Login with **Username + Password** (auto-fetches API key)

## File structure

```
public_html/
├── index.html              ← Storefront (full v10.1 features + online sync)
├── admin-login.html        ← Admin login → uses api/admin-auth.php
├── admin-app.html          ← Admin Console v12 (16 sections)
├── config.php              ← ★ Edit DB + admin credentials
├── install.sql             ← Run once in phpMyAdmin
├── healthcheck.php         ← Run once, DELETE after
├── setup.php               ← Optional auto-installer
├── .htaccess               ← URL rewriting
├── assets/
│   ├── api-bridge.js       ← Storefront ↔ PHP sync
│   └── cart-media-patch.js
├── api/
│   ├── index.php           ← Router
│   ├── admin-auth.php      ← Username/password login
│   ├── settings.php        ← Includes filament colors, couriers, cashfree, nav
│   ├── theme.php
│   ├── products.php
│   ├── orders.php          ← Includes courier tracking
│   ├── users.php
│   ├── coupons.php
│   ├── flash.php
│   ├── popups.php
│   ├── pages.php
│   ├── abandoned.php       ← NEW: Cart abandonment
│   ├── wishlist.php
│   ├── views.php
│   ├── upload.php
│   └── track.php
└── uploads/
```

## Key features explained

### Filament Colors (Global Color Library)
Admin → **Filament Colors** tab. List the actual filament colors you stock. Any product with **Color Mode = Sync** automatically shows ONLY these colors. Add/remove a color → instantly reflects on storefront.

### Courier Tracking
Admin → **Orders** → Manage. Select courier from list (Delhivery, Blue Dart, DTDC, Shadowfax, Ekart, Xpressbees, India Post, etc.) + paste tracking number. Click 📱 to send WhatsApp message with tracking link to customer.

### Cart Abandonment
When customers reach checkout but don't complete, storefront POSTs to `/api/abandoned`. Admin → **Cart Recovery** → click 📱 to send WhatsApp recovery message with 10% discount code.

### Cashfree Payment
Admin → **Payment** → Enable Cashfree, enter App ID, Secret Key, Mode (sandbox/production), Return URL. (Production requires server-side session token endpoint.)

### Buy Now Behaviour
Admin → **Settings** → Buy Behaviour:
- **Buy Now → WhatsApp**: Buy Now button opens WhatsApp with order details (no checkout)
- **Quick Buy on cards**: shows quick-buy button on product cards
- **3D Viewer**: enables GLB model + animation viewer on product page

## Troubleshooting (தமிழ்)

**"Load failed: Invalid JSON"** → Server PHP error. Browser DevTools (F12) → Network → check `/api/...` response. Usually `config.php` DB credentials wrong.

**Login error** → Username/password mismatch with `config.php` ADMIN_USERNAME/ADMIN_PASSWORD.

**Filament colors not syncing** → Save செய்த பிறகு storefront refresh. Settings table-ல் `globalColors` key check செய்யவும்.

---

Made with ❤️ for MY 3D Gifts — v12 (April 2026)
