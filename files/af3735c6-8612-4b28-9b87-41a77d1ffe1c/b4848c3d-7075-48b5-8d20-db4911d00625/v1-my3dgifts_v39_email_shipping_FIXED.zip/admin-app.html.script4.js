
// New-order badge — polls /orders for new entries since last seen
(function(){
  let _amnSeenIds = null;
  function getBadgeEl(){ return document.getElementById('amnOrdersBadge'); }
  window.clearOrdersBadge = function(){
    const el=getBadgeEl(); if(!el) return;
    el.style.display='none'; el.textContent='0';
    try{ localStorage.setItem('_ordersSeen', JSON.stringify((window.STATE?.orders||[]).map(o=>o.id))); }catch(e){}
    _amnSeenIds = new Set((window.STATE?.orders||[]).map(o=>o.id));
  };
  async function poll(){
    try{
      if(!window.STATE || !window.apiGet) return;
      const orders = await apiGet('/orders').catch(()=>null);
      if(!Array.isArray(orders)) return;
      window.STATE.orders = orders;
      if(_amnSeenIds === null){
        try{ const saved = JSON.parse(localStorage.getItem('_ordersSeen')||'[]'); _amnSeenIds = new Set(saved); }
        catch(e){ _amnSeenIds = new Set(orders.map(o=>o.id)); }
      }
      const fresh = orders.filter(o=>!_amnSeenIds.has(o.id));
      const el = getBadgeEl(); if(!el) return;
      const onOrders = document.getElementById('page-orders')?.classList.contains('active');
      if(fresh.length>0 && !onOrders){
        el.textContent = fresh.length>99?'99+':String(fresh.length);
        el.style.display='inline-block';
      } else if(onOrders){
        clearOrdersBadge();
      }
    }catch(e){}
  }
  const _kick = ()=>{ poll(); setInterval(poll, 30000); };
  if(document.readyState==='complete') setTimeout(_kick,3000);
  else window.addEventListener('load', ()=>setTimeout(_kick,3000));
})();
