<?php
// check.php — Server setup diagnostic tool
// Visit: https://tr.my3dgifts.in/check.php
// DELETE THIS FILE after setup is confirmed!
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$checks = [];

// 1. PHP version
$checks['php_version'] = ['ok' => version_compare(PHP_VERSION, '7.4', '>='), 'value' => PHP_VERSION];

// 2. Config file
$configPath = __DIR__ . '/config.php';
$checks['config_exists'] = ['ok' => file_exists($configPath), 'value' => $configPath];

// 3. Try loading config
if (file_exists($configPath)) {
    try {
        require_once $configPath;
        $checks['config_loaded'] = ['ok' => true, 'value' => 'OK'];
        // 4. DB connection
        try {
            $db = getDB();
            $db->query('SELECT 1');
            $checks['db_connection'] = ['ok' => true, 'value' => 'Connected to ' . DB_NAME];
        } catch (Throwable $e) {
            $checks['db_connection'] = ['ok' => false, 'value' => $e->getMessage()];
        }
    } catch (Throwable $e) {
        $checks['config_loaded'] = ['ok' => false, 'value' => $e->getMessage()];
    }
}

// 5. api/ folder
$checks['api_folder'] = ['ok' => is_dir(__DIR__ . '/api'), 'value' => __DIR__ . '/api'];

// 6. admin-auth.php
$checks['admin_auth'] = ['ok' => file_exists(__DIR__ . '/api/admin-auth.php'), 'value' => __DIR__ . '/api/admin-auth.php'];

// 7. uploads/ writable
$checks['uploads_writable'] = ['ok' => is_writable(__DIR__ . '/uploads'), 'value' => __DIR__ . '/uploads'];

// 8. mod_rewrite
$checks['mod_rewrite'] = ['ok' => function_exists('apache_get_modules') ? in_array('mod_rewrite', apache_get_modules()) : true, 'value' => 'Check .htaccess'];

$allOk = array_reduce($checks, fn($c, $v) => $c && $v['ok'], true);

echo json_encode([
    'ok' => $allOk,
    'server' => $_SERVER['HTTP_HOST'] ?? 'unknown',
    'docroot' => __DIR__,
    'checks' => $checks,
    'instructions' => $allOk ? '✅ All OK! Delete check.php and login.' : '❌ Fix the failed checks above.',
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
