
/* ============================================================
   MY 3D Gifts — Admin Panel JS v12
   PHP API: settings, theme, products, orders, users,
            coupons, flash, popups, pages, abandoned, views
   ============================================================ */

const API = '/api';

/* imgUrl — normalize image URLs for display.
   Strips host from absolute /uploads/ URLs so they work on every device. */
function imgUrl(u) {
  if (!u || typeof u !== 'string') return '';
  const s = u.trim();
  if (!s) return '';
  if (s.startsWith('data:')) return s;
  if (s.startsWith('/uploads/')) return s;
  const m = s.match(/^https?:\/\/[^/]+(\/uploads\/.+)$/i);
  if (m) return m[1];
  return s;
}

const PHP_MAP = {orders:'orders.php',products:'products.php',coupons:'coupons.php',
  settings:'settings.php',views:'views.php',users:'users.php',flash:'flash.php',
  upload:'upload.php',track:'track.php',theme:'theme.php',
  popups:'popups.php',pages:'pages.php',abandoned:'abandoned.php',
  media:'media.php',accounts:'accounts.php'};

function apiUrl(path){
  const p = path.replace(/^\//,'');
  const res = p.split(/[/?]/)[0];
  const php = PHP_MAP[res];
  if(!php) return API+'/'+p;
  return API+'/'+php+p.slice(res.length);
}

function imageValue(v){
  if(!v) return '';
  if(typeof v === 'string') return v;
  if(typeof v === 'object' && v.url) return v.url;
  return '';
}
function imageArrayValues(arr){
  return (Array.isArray(arr) ? arr : []).map(imageValue).filter(Boolean);
}

let ADMIN_KEY = localStorage.getItem('adminApiKey') || '';
let ADMIN_USER = localStorage.getItem('adminUser') || 'Admin';
// ── Admin login guard: redirect to admin-login.html if no key
if (!ADMIN_KEY) {
  try { location.replace('admin-login.html'); } catch(e){}
}

const DEFAULT_FILAMENT = [
  { name:'Red', hex:'#ef4444' },
  { name:'Yellow', hex:'#eab308' },
  { name:'Black', hex:'#1e293b' },
  { name:'White', hex:'#f8fafc' },
  { name:'Purple', hex:'#8b5cf6' },
  { name:'Green', hex:'#22c55e' },
  { name:'Blue', hex:'#3b82f6' },
  { name:'Orange', hex:'#f97316' }
];

const DEFAULT_BNAV = [
  { id:'home', label:'Home', icon:'🏠', view:'shop', enabled:true },
  { id:'wishlist', label:'Wishlist', icon:'❤️', view:'wishlist', enabled:true, badge:'wishCount' },
  { id:'cart', label:'Cart', icon:'🛒', view:'cart', enabled:true, badge:'cartCount' },
  { id:'account', label:'Account', icon:'👤', view:'account', enabled:true }
];
const DEFAULT_SNAV = [
  { id:'about', label:'About Us', icon:'ℹ️', view:'about', enabled:true },
  { id:'track', label:'Track Order', icon:'📦', view:'track', enabled:true },
  { id:'admin', label:'Admin Panel', icon:'⚙️', view:'admin', enabled:true }
];
const DEFAULT_COURIERS = [
  { id:'delhivery', name:'Delhivery', trackUrl:'https://www.delhivery.com/track/package/' },
  { id:'bluedart', name:'Blue Dart', trackUrl:'https://www.bluedart.com/tracking?awb=' },
  { id:'dtdc', name:'DTDC', trackUrl:'https://www.dtdc.in/tracking.asp?awbno=' },
  { id:'indiapost', name:'India Post', trackUrl:'https://www.indiapost.gov.in/_layouts/15/dop.portal.tracking/trackconsignment.aspx?id=' },
  { id:'shadowfax', name:'Shadowfax', trackUrl:'https://tracker.shadowfax.in/?trackingId=' },
  { id:'professional', name:'Professional Couriers', trackUrl:'https://www.tpcindia.com/Tracking2.aspx?id=' },
  { id:'ekart', name:'Ekart', trackUrl:'https://ekartlogistics.com/shipmenttrack/' },
  { id:'xpressbees', name:'Xpressbees', trackUrl:'https://www.xpressbees.com/track?awb=' }
];

let STATE = {
  orders:[], products:[], users:[], coupons:[], popups:[], pages:[],
  settings:{}, theme:{}, flash:{}, abandoned:[], views:{},
  filament: DEFAULT_FILAMENT.slice(),
  couriers: DEFAULT_COURIERS.slice(),
  bnav: DEFAULT_BNAV.slice(),
  snav: DEFAULT_SNAV.slice(),
  cashfree:{},
  about:{},
  buyToggles:{}
};

/* ── HTTP ── */
async function http(method, path, body){
  const headers = {'Content-Type':'application/json'};
  if(ADMIN_KEY) headers['X-Admin-Key'] = ADMIN_KEY;
  const opts = {method, headers};
  if(body !== undefined) opts.body = JSON.stringify(body);
  let r;
  try{
    if(method === 'GET') opts.cache = 'no-store';
    r = await fetch(apiUrl(path), opts);
  }catch(netErr){
    setApiStatus(false);
    throw new Error('Network error: '+netErr.message);
  }
  const raw = await r.text();
  let j;
  try{ j = JSON.parse(raw); }
  catch{
    setApiStatus(false);
    const preview = raw.replace(/<[^>]+>/g,'').trim().slice(0,160);
    throw new Error('HTTP '+r.status+' — Invalid JSON from server. '+(preview?('Detail: '+preview):''));
  }
  setApiStatus(true);
  if(!j.ok) throw new Error(j.error || ('HTTP '+r.status));
  return j.data;
}
const apiGet = (p)=>http('GET',p);
const apiPost = (p,b)=>http('POST',p,b);
const apiPut = (p,b)=>http('PUT',p,b);
const apiDel = (p)=>http('DELETE',p);

function setApiStatus(ok){
  const el = document.getElementById('apiStatus');
  if(!el) return;
  el.className = 'api-status '+(ok?'online':'offline');
  el.textContent = ok ? '● Online' : '● Offline';
}

/* ── Toast ── */
let toastT;
function toast(msg, type='info'){
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = type+' show';
  clearTimeout(toastT);
  toastT = setTimeout(()=>t.className=type, 3000);
}

/* ── Login ── */
async function doLogin(){
  const url = document.getElementById('logUrl').value.trim();
  const user = document.getElementById('logUser').value.trim();
  const pass = document.getElementById('logPass').value;
  let key = document.getElementById('logKey').value.trim();
  const msg = document.getElementById('logMsg');
  msg.style.color=''; msg.textContent='';

  // Mode 1: username + password → call admin-auth, get key
  if(user && pass){
    msg.textContent = '⏳ Logging in...';
    try{
      const base = url ? url.replace(/\/$/,'') : '';
      const res = await fetch((base||'')+'/api/admin-auth.php',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({username:user, password:pass})
      });
      const txt = await res.text();
      let j;
      try{ j = JSON.parse(txt); }
      catch{
        const preview = txt.replace(/<[^>]+>/g,'').trim().slice(0,180);
        throw new Error('Server returned non-JSON. '+preview);
      }
      if(!res.ok || !j.ok) throw new Error(j.error || ('HTTP '+res.status));
      key = j.data?.apiKey;
      if(!key) throw new Error('API key missing in server response');
    }catch(e){
      msg.style.color='#dc2626';
      msg.textContent = '❌ Login failed: '+e.message;
      return;
    }
  }
  // Mode 2: direct API key
  if(!key){
    msg.style.color='#dc2626'; msg.textContent='❌ Username + Password OR API Key is required.';
    return;
  }

  ADMIN_KEY = key;
  try{
    await apiGet('/orders'); // verify
    localStorage.setItem('adminApiKey', key);
    if(user){ localStorage.setItem('adminUser', user); ADMIN_USER = user; }
    document.getElementById('userName').textContent = ADMIN_USER;
    document.getElementById('loginOverlay').style.display='none';
    document.getElementById('app').style.display='flex';
    loadDashboard();
  }catch(e){
    ADMIN_KEY=''; localStorage.removeItem('adminApiKey');
    msg.style.color='#dc2626';
    msg.textContent = '❌ Verify failed: '+e.message;
  }
}
function doLogout(){
  if(!confirm('Logout?')) return;
  localStorage.removeItem('adminApiKey');
  localStorage.removeItem('adminUser');
  location.reload();
}

/* ── Routing ── */
const PAGE_TITLES = {
  dashboard:'Dashboard', orders:'Orders', recovery:'Cart Recovery',
  products:'Products', users:'Customers', analytics:'Analytics',
  coupons:'Coupons', flash:'Flash Sale', popups:'Popup Notifications', coins:'🪙 Loyalty Coins',
  filament:'Filament Color Library', shipping:'Shipping & Couriers',
  payment:'Payment Methods', navigation:'Navigation Builder',
  pages:'Custom Pages', about:'About / Contact', theme:'Theme',
  settings:'Settings', media:'Media Library',
  accounts:'Accounts (Income/Expense)',
  labels:'🖨️ Shipping Label Printer'
};
const PAGE_LOADERS = {
  dashboard:loadDashboard, orders:loadOrders, recovery:loadRecovery,
  products:loadProducts, users:loadUsers, analytics:loadAnalytics,
  coupons:loadCoupons, flash:loadFlash, popups:loadPopups, coins:loadCoinsPage,
  filament:loadFilament, shipping:loadShipping, payment:loadPayment,
  navigation:loadNavigation, pages:loadPages, about:loadAbout,
  theme:loadTheme, settings:async()=>{ await loadSettings(); loadSmtpSettings(); },
  media:loadMedia,
  accounts:loadAccounts,
  labels:(...a)=>loadLabels(...a)
};
function goPage(name){
  document.querySelectorAll('.nav-link').forEach(a=>a.classList.toggle('active', a.dataset.page===name));
  document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active', p.id==='page-'+name));
  document.getElementById('pageTitle').textContent = PAGE_TITLES[name] || name;
  toggleSidebar(false);
  syncAdminMobileNav(name);
  PAGE_LOADERS[name]?.();
}
function syncAdminMobileNav(name){
  document.querySelectorAll('#adminMobileNav .amn-item').forEach(el=>{
    if(el.dataset.amn==='_more') return;
    el.classList.toggle('active', el.dataset.amn===name);
  });
}
document.querySelectorAll('.nav-link').forEach(a=>a.addEventListener('click', ()=>goPage(a.dataset.page)));

function toggleSidebar(open){
  document.getElementById('sidebar').classList.toggle('open', open);
  document.getElementById('scrim').classList.toggle('show', open);
}

/* ── DASHBOARD ── */
async function loadDashboard(){
  try{
    const [orders, products, users] = await Promise.all([
      apiGet('/orders').catch(()=>[]),
      apiGet('/products?all=1').catch(()=>[]),
      apiGet('/users').catch(()=>[]),
    ]);
    STATE.orders = orders||[]; STATE.products = products||[]; STATE.users = users||[];
    document.getElementById('stTotalOrders').textContent = STATE.orders.length;
    const rev = STATE.orders.filter(o=>o.status!=='Cancelled').reduce((s,o)=>s+Number(o.total||0),0);
    document.getElementById('stRevenue').textContent = '₹'+rev.toLocaleString('en-IN');
    document.getElementById('stProducts').textContent = STATE.products.filter(p=>p.active!==false).length;
    document.getElementById('stUsers').textContent = STATE.users.length;
    renderRecent();
  }catch(e){ toast('Failed to load dashboard: '+e.message,'err'); }
}
function renderRecent(){
  const recent = STATE.orders.slice(0,10);
  if(!recent.length){ document.getElementById('recentOrders').innerHTML = emptyHtml('📦','No orders yet'); return; }
  document.getElementById('recentOrders').innerHTML = `
    <table class="tbl"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
    <tbody>${recent.map(o=>`
      <tr><td><b>${esc(o.id)}</b></td><td>${esc(o.customerName||'')}<br><span style="color:var(--muted);font-size:11px">${esc(o.customerPhone||'')}</span></td>
      <td><b>₹${Number(o.total||0).toLocaleString('en-IN')}</b></td>
      <td>${statusChip(o.status)}</td><td>${fmtDate(o.createdAt)}</td></tr>`).join('')}</tbody></table>`;
}

/* ── ORDERS ── */
async function loadOrders(){
  try{ STATE.orders = await apiGet('/orders'); renderOrders(); }
  catch(e){ toast('Load failed: '+e.message,'err'); }
}
/* v15: source tabs (All / Online / Walk-in) */
let _ordSrc = 'all';
function setOrderSrc(src){
  _ordSrc = src;
  document.querySelectorAll('[data-osrc]').forEach(b=>b.classList.toggle('active', b.dataset.osrc===src));
  renderOrders();
}
window.setOrderSrc = setOrderSrc;
function itemThumbs(items){
  const arr = (items||[]).slice(0,4);
  if(!arr.length) return '<span style="color:var(--muted);font-size:11px">—</span>';
  const PROD = STATE.products || [];
  const html = arr.map(it=>{
    let url = it.image || it.coverImage || '';
    if(!url && it.productId){
      const p = PROD.find(x=>x.id===it.productId);
      if(p) url = p.image || p.coverImage || '';
    }
    if(!url && it.options){
      url = it.options.coverImage || it.options.image || '';
    }
    const safe = imgUrl(url);
    if(!safe) return `<span style="display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:6px;background:#f1f5f9;border:1px solid var(--border);font-size:14px" title="${esc(it.name||'')}">🎁</span>`;
    return `<img  loading="lazy" decoding="async"src="${esc(safe)}" title="${esc(it.name||'')}" style="width:34px;height:34px;object-fit:cover;border-radius:6px;border:1px solid var(--border)" onerror="this.outerHTML='&lt;span style=\\'display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:6px;background:#fef3c7;border:1px solid #fde68a;font-size:11px\\' title=\\'broken\\'&gt;⚠️&lt;/span&gt;'"/>`;
  }).join('');
  const more = (items||[]).length>4 ? `<span style="font-size:11px;color:var(--muted);margin-left:4px">+${items.length-4}</span>` : '';
  return `<div style="display:flex;align-items:center;gap:3px;flex-wrap:wrap">${html}${more}</div>`;
}
window.itemThumbs = itemThumbs;

function renderOrders(){
  const q = (document.getElementById('ordSearch')?.value||'').toLowerCase();
  const fStatus = document.getElementById('ordFilter')?.value||'';
  let arr = STATE.orders;
  if(_ordSrc && _ordSrc!=='all') arr = arr.filter(o => (o.source||'online') === _ordSrc);
  if(q) arr = arr.filter(o=>String(o.id||'').toLowerCase().includes(q) || String(o.customerPhone||'').includes(q) || String(o.customerName||'').toLowerCase().includes(q));
  if(fStatus) arr = arr.filter(o=>o.status===fStatus);
  if(!arr.length){ document.getElementById('ordersList').innerHTML = emptyHtml('📦','No orders'); return; }
  document.getElementById('ordersList').innerHTML = `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap">
      <label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer">
        <input type="checkbox" id="ordChkAll" onchange="toggleSelectAll('ord')" style="width:16px;height:16px"> Select All
      </label>
      <div id="ordBulkDel" style="display:none;gap:6px;align-items:center;flex-wrap:wrap">
        <select id="ordBulkStatus" style="padding:6px 8px;border:1px solid var(--border);border-radius:6px;font-size:12.5px">
          <option value="">— Change Status —</option>
          <option value="New">New</option>
          <option value="In Production">In Production</option>
          <option value="Dispatch">Dispatch</option>
          <option value="Shipped">Shipped</option>
          <option value="Delivered">Delivered</option>
          <option value="Cancelled">Cancelled</option>
        </select>
        <label style="display:flex;align-items:center;gap:4px;font-size:12px"><input type="checkbox" id="ordBulkEmail"> Send Email</label>
        <button class="btn btn-success btn-sm" onclick="bulkUpdateOrderStatus()">✅ Update Status</button>
        <button class="btn btn-danger btn-sm" onclick="bulkDeleteOrders()">🗑 Delete</button>
      </div>
    </div>
    <table class="tbl"><thead><tr><th style="width:32px"></th><th>ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Pay</th><th>Status</th><th>Courier</th><th>Date</th><th></th></tr></thead>
    <tbody>${arr.map(o=>`
      <tr><td><input type="checkbox" class="ord-chk row-chk" data-id="${esc(o.id)}" onchange="updateBulkBar('ord')" style="width:16px;height:16px"></td>
      <td><b>${esc(o.id)}</b><br><span style="font-size:11px;color:var(--muted)">${esc(o.tracking||'')}</span></td>
      <td>${esc(o.customerName||'')}<br><span style="font-size:11px;color:var(--muted)">${esc(o.customerPhone||'')}</span></td>
      <td>${itemThumbs(o.items)}<div style="font-size:11px;color:var(--muted);margin-top:2px">${(o.items||[]).length} item(s)</div></td>
      <td><b>₹${Number(o.total||0).toLocaleString('en-IN')}</b></td>
      <td><span class="chip ${o.paymentStatus==='Paid'?'chip-green':'chip-amber'}">${esc(o.paymentStatus||'Pending')}</span></td>
      <td>${statusChip(o.status)}</td>
      <td style="font-size:11px">${o.courier?esc(o.courier)+'<br><code>'+esc(o.courierTracking||'')+'</code>':'<span style="color:var(--muted)">—</span>'}</td>
      <td style="font-size:12px">${fmtDate(o.createdAt)}</td>
      <td style="display:flex;gap:4px;flex-wrap:wrap">
        <button class="btn btn-ghost btn-sm" onclick="viewOrder('${esc(o.id)}')">Manage</button>
        <button class="btn btn-danger btn-sm" onclick="quickDeleteOrder('${esc(o.id)}')" title="Delete Order">🗑</button>
      </td></tr>`).join('')}</tbody></table>`;
}
function viewOrder(id){
  const o = STATE.orders.find(x=>x.id===id); if(!o) return;
  const courierOpts = STATE.couriers.map(c=>`<option value="${esc(c.id)}" ${c.id===o.courier?'selected':''}>${esc(c.name)}</option>`).join('');
  const itemsHtml = (o.items||[]).map(it=>{
    const sel = it.selections || {};
    let selLines = [];
    // Color
    if (sel.color) {
      selLines.push(`<div style="display:flex;align-items:center;gap:6px;margin-top:4px">
        <span style="font-size:11.5px;color:var(--muted);font-weight:600">🎨 Color:</span>
        <span style="display:inline-block;width:16px;height:16px;border-radius:50%;background:${esc(sel.color)};border:1px solid var(--border)"></span>
        <span style="font-size:11.5px;font-family:monospace">${esc(sel.color)}</span>
      </div>`);
    }
    // Color 2 (dual color)
    if (sel.dualColor && sel.color2) {
      selLines.push(`<div style="display:flex;align-items:center;gap:6px;margin-top:2px">
        <span style="font-size:11.5px;color:var(--muted);font-weight:600">🎨 Color 2:</span>
        <span style="display:inline-block;width:16px;height:16px;border-radius:50%;background:${esc(sel.color2)};border:1px solid var(--border)"></span>
        <span style="font-size:11.5px;font-family:monospace">${esc(sel.color2)}</span>
      </div>`);
    }
    // Name inputs (text)
    (sel.names||[]).forEach((n,i)=>{
      if(n) selLines.push(`<div style="font-size:11.5px;margin-top:2px"><span style="color:var(--muted);font-weight:600">✏️ Text ${i+1}:</span> <b>${esc(n)}</b></div>`);
    });
    // Size
    if (sel.size) selLines.push(`<div style="font-size:11.5px;margin-top:2px"><span style="color:var(--muted);font-weight:600">📐 Size:</span> ${esc(sel.size)}</div>`);
    // Material
    if (sel.material) selLines.push(`<div style="font-size:11.5px;margin-top:2px"><span style="color:var(--muted);font-weight:600">🧱 Material:</span> ${esc(sel.material)}</div>`);
    // Uploaded Photo
    if (sel.photo) {
      const photoName = sel.photoName || `order_${o.id}_photo.jpg`;
      selLines.push(`<div style="margin-top:6px"><span style="font-size:11.5px;color:var(--muted);font-weight:600">📷 Uploaded Photo:</span><br>
        <img  loading="lazy" decoding="async"src="${esc(sel.photo)}" style="max-width:120px;max-height:120px;border-radius:8px;margin-top:4px;border:1px solid var(--border);object-fit:cover" 
          onerror="this.outerHTML='<span style=\'font-size:11px;color:#dc2626\'>⚠️ Photo load failed</span>'" />
        <br><a href="${esc(sel.photo)}" download="${esc(photoName)}" 
          style="display:inline-block;margin-top:4px;font-size:11px;color:#2563eb;background:#eff6ff;border:1px solid #bfdbfe;border-radius:5px;padding:2px 8px;text-decoration:none;font-weight:600">
          ⬇️ Download Photo</a></div>`);
    }
    // Dynamic / Custom Options (Unlimited) — show human label from product definition
    if (sel.dyn && Object.keys(sel.dyn).length) {
      // Build a lookup map: opt.id → opt.label from product's dynamicOptions
      const prod = (STATE.products||[]).find(p=>p.id===it.productId);
      const dynOpts = prod?.options?.dynamicOptions || [];
      const labelMap = {};
      dynOpts.forEach(opt=>{ if(opt.id) labelMap[opt.id] = { label: opt.label||opt.id, type: opt.type||'text' }; });

      Object.entries(sel.dyn).forEach(([k,v])=>{
        if (v === null || v === undefined || v === '') return;
        const meta = labelMap[k] || { label: k, type: 'text' };
        const displayLabel = meta.label;
        const isPhoto = typeof v === 'string' && (v.startsWith('data:image') || meta.type === 'file');
        if (isPhoto) {
          const dynPhotoName = `order_${o.id}_${displayLabel.replace(/[^a-zA-Z0-9]/g,'_')}.jpg`;
          selLines.push(`<div style="margin-top:6px"><span style="font-size:11.5px;color:var(--muted);font-weight:600">🧩 ${esc(displayLabel)}:</span><br>
            <img  loading="lazy" decoding="async"src="${esc(v)}" style="max-width:120px;max-height:120px;border-radius:8px;margin-top:4px;border:1px solid var(--border);object-fit:cover"/>
            <br><a href="${esc(v)}" download="${esc(dynPhotoName)}" 
              style="display:inline-block;margin-top:4px;font-size:11px;color:#2563eb;background:#eff6ff;border:1px solid #bfdbfe;border-radius:5px;padding:2px 8px;text-decoration:none;font-weight:600">
              ⬇️ Download Photo</a></div>`);
        } else if (meta.type === 'color' || (typeof v === 'string' && v.match(/^#[0-9a-fA-F]{3,8}$/))) {
          selLines.push(`<div style="display:flex;align-items:center;gap:6px;margin-top:4px">
            <span style="font-size:11.5px;color:var(--muted);font-weight:600">🎨 ${esc(displayLabel)}:</span>
            <span style="display:inline-block;width:16px;height:16px;border-radius:50%;background:${esc(v)};border:1px solid var(--border)"></span>
            <span style="font-size:11.5px;font-family:monospace">${esc(v)}</span>
          </div>`);
        } else {
          selLines.push(`<div style="font-size:11.5px;margin-top:2px"><span style="color:var(--muted);font-weight:600">🧩 ${esc(displayLabel)}:</span> <b>${esc(typeof v==='object'?JSON.stringify(v):String(v))}</b></div>`);
        }
      });
    }
    // Also show it.options (product-level options for reference)
    const prodOpts = Object.entries(it.options||{}).filter(([k])=>!['coverImage','image','gifUrl'].includes(k));
    if (prodOpts.length && !selLines.length) {
      selLines.push(`<span style="font-size:11px;color:var(--muted)">${prodOpts.map(([k,v])=>esc(k)+': '+esc(typeof v==='object'?JSON.stringify(v):v)).join(' • ')}</span>`);
    }
    return `<div style="border:1px solid var(--border);border-radius:8px;padding:10px;margin-bottom:6px">
      <b>${esc(it.name)}</b> × ${it.quantity||1}
      ${selLines.join('')}
      <div style="margin-top:6px"><b>₹${Number(it.price||0).toLocaleString('en-IN')}</b></div>
    </div>`;
  }).join('') || '<p style="color:var(--muted)">No items</p>';

  openModal(`Order ${esc(o.id)}`, `
    <div class="grid grid-2">
      <div><b>Customer</b><br>${esc(o.customerName||'')}<br>${esc(o.customerPhone||'')}<br>${esc(o.customerEmail||'')}</div>
      <div><b>Address</b><br>${esc(o.address||'')}<br>Pincode: ${esc(o.pincode||'')}</div>
    </div>
    <hr style="margin:14px 0;border:none;border-top:1px solid var(--border)">
    <div><b>Items</b>${itemsHtml}</div>
    <div class="grid grid-3" style="margin-top:8px">
      <div><b>Subtotal:</b><br>₹${Number(o.total||0).toLocaleString('en-IN')}</div>
      <div><b>Shipping:</b><br>₹${Number(o.shipping||0)}</div>
      <div><b>Discount:</b><br>-₹${Number(o.discount||0)}</div>
    </div>
    <hr style="margin:14px 0;border:none;border-top:1px solid var(--border)">
    <div class="grid grid-2">
      <div class="field"><label>Order Status</label>
        <select id="ordStatus">
          ${['New','In Production','Dispatch','Shipped','Delivered','Cancelled'].map(s=>`<option ${s===o.status?'selected':''}>${s}</option>`).join('')}
        </select></div>
      <div class="field"><label>Payment Status</label>
        <select id="ordPay">
          ${['Pending','Paid','Refunded','Failed'].map(s=>`<option ${s===(o.paymentStatus||'Pending')?'selected':''}>${s}</option>`).join('')}
        </select></div>
    </div>
    <div class="card" style="margin-top:14px;background:#f8fafc">
      <div class="card-title" style="margin-bottom:10px">🚚 Courier & Tracking</div>
      <div class="grid grid-2">
        <div class="field"><label>Courier Partner</label>
          <select id="ordCourier"><option value="">— Select —</option>${courierOpts}</select></div>
        <div class="field"><label>Tracking Number</label>
          <input id="ordTrack" placeholder="AWB / Tracking ID" value="${esc(o.courierTracking||'')}"/></div>
      </div>
      <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
        <button class="btn btn-wa btn-sm" onclick="sendCourierWA('${esc(o.id)}')">📱 Send Tracking via WhatsApp</button>
        <button class="btn btn-ghost btn-sm" onclick="sendStatusWA('${esc(o.id)}')">💬 Send Status Update</button>
      </div>
      ${o.customerEmail ? `
      <div style="margin-top:10px;padding:10px;background:#eff6ff;border-radius:8px;border:1px solid #bfdbfe">
        <div style="font-size:12px;font-weight:700;color:#1e40af;margin-bottom:6px">📧 Email Notifications → ${esc(o.customerEmail)}</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <button class="btn btn-primary btn-sm" onclick="sendOrderEmail('${esc(o.id)}','order_confirmed')">✅ Order Confirm</button>
          <button class="btn btn-ghost btn-sm" onclick="sendOrderEmail('${esc(o.id)}','tracking_update')">📦 Tracking Update</button>
          <button class="btn btn-success btn-sm" onclick="sendOrderEmail('${esc(o.id)}','delivered')">🎉 Delivered</button>
        </div>
        <div id="emailSendResult_${esc(o.id)}" style="font-size:11px;margin-top:4px"></div>
      </div>` : `<div style="margin-top:8px;font-size:11px;color:#94a3b8">⚠️ No customer email — cannot send email</div>`}
    </div>
    <div class="field" style="margin-top:12px"><label>Internal Notes</label>
      <textarea id="ordNotes" rows="2">${esc(o.notes||'')}</textarea></div>
  `,
  `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
   <button class="btn btn-danger" onclick="deleteOrder('${esc(o.id)}')">🗑 Delete</button>
   <button class="btn btn-success" onclick="saveOrderStatus('${esc(o.id)}')">💾 Save Changes</button>`);
}
async function saveOrderStatus(id){
  try{
    const o = STATE.orders.find(x=>x.id===id); if(!o) return;
    const status = document.getElementById('ordStatus').value;
    const paymentStatus = document.getElementById('ordPay').value;
    const courier = document.getElementById('ordCourier').value;
    const courierTracking = document.getElementById('ordTrack').value.trim();
    const notes = document.getElementById('ordNotes').value;
    await apiPut('/orders/'+id, {...o, status, paymentStatus, courier, courierTracking, notes});
    toast('Order updated','ok'); closeModal(); loadOrders();
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
/* ── QUICK DELETE ORDER (per-row) ── */
async function quickDeleteOrder(id){
  if(!confirm('Permanently delete this order?')) return;
  try{ await apiDel('/orders/'+id); toast('Order deleted','ok'); loadOrders(); }
  catch(e){ toast('Could not delete: '+e.message,'err'); }
}
window.quickDeleteOrder = quickDeleteOrder;

async function sendOrderEmail(orderId, kind){
  const resEl = document.getElementById('emailSendResult_'+orderId);
  if(resEl) resEl.innerHTML = '<span style="color:#6366f1">⏳ Sending email...</span>';
  try{
    const r = await fetch(apiUrl('/email/send'), {
      method:'POST',
      headers:{'Content-Type':'application/json','X-Admin-Key':ADMIN_KEY},
      body: JSON.stringify({kind, orderId})
    });
    const j = await r.json();
    if(j.ok){
      if(resEl) resEl.innerHTML = `<span style="color:#16a34a">✅ Email sent to ${j.to||'customer'}!</span>`;
      toast('Email sent ✓','ok');
    } else {
      if(resEl) resEl.innerHTML = `<span style="color:#dc2626">❌ ${j.error||'Send failed'}</span>`;
      toast(j.error||'Send failed','err');
    }
  }catch(e){
    if(resEl) resEl.innerHTML = `<span style="color:#dc2626">❌ ${e.message}</span>`;
    toast(e.message,'err');
  }
}
window.sendOrderEmail = sendOrderEmail;

/* ── ABANDONED CART EMAIL ── */
async function sendRecoveryEmail(cartId){
  try{
    const r = await fetch(apiUrl('/email/send'), {
      method:'POST',
      headers:{'Content-Type':'application/json','X-Admin-Key':ADMIN_KEY},
      body: JSON.stringify({kind:'cart_recovery', cartId})
    });
    const j = await r.json();
    if(j.ok) toast('Recovery email sent to '+j.to,'ok');
    else toast(j.error||'Send failed','err');
  }catch(e){ toast(e.message,'err'); }
}
window.sendRecoveryEmail = sendRecoveryEmail;
function toggleSelectAll(prefix){
  const allChk = document.getElementById(prefix+'ChkAll');
  const boxes = document.querySelectorAll('.'+prefix+'-chk');
  boxes.forEach(b=>b.checked = allChk.checked);
  updateBulkBar(prefix);
}
function updateBulkBar(prefix){
  const checked = document.querySelectorAll('.'+prefix+'-chk:checked');
  const bar = document.getElementById(prefix+'BulkDel');
  if(bar) bar.style.display = checked.length ? (prefix==='ord'?'flex':'inline-flex') : 'none';
  const wrap = document.getElementById(prefix+'BulkBar');
  if(wrap) wrap.style.display = checked.length ? 'inline-flex' : 'none';
  const cnt = document.getElementById(prefix+'SelCount');
  if(cnt) cnt.textContent = checked.length ? (checked.length+' selected') : '';
  // update "select all" checkbox state
  const allChk = document.getElementById(prefix+'ChkAll');
  if(allChk){
    const all = document.querySelectorAll('.'+prefix+'-chk');
    allChk.indeterminate = checked.length > 0 && checked.length < all.length;
    allChk.checked = all.length > 0 && checked.length === all.length;
  }
}
window.toggleSelectAll = toggleSelectAll;
window.updateBulkBar = updateBulkBar;

async function bulkDeleteProducts(){
  const ids = [...document.querySelectorAll('.prod-chk:checked')].map(b=>b.dataset.id);
  if(!ids.length) return;
  if(!confirm(`${ids.length} product(s)? This cannot be undone!`)) return;
  try{
    const r = await fetch(apiUrl('/products/bulk-delete'), {
      method:'POST', headers:{'Content-Type':'application/json','X-Admin-Key':ADMIN_KEY},
      body: JSON.stringify({ids})
    }).then(r=>r.json());
    if(r.ok){ toast(`${r.data.deleted} deleted`,'ok'); }
    else throw new Error(r.error||'Failed');
  }catch(e){ toast('Could not delete: '+e.message,'err'); }
  loadProducts();
}
window.bulkDeleteProducts = bulkDeleteProducts;

async function bulkApplyProducts(){
  const ids = [...document.querySelectorAll('.prod-chk:checked')].map(b=>b.dataset.id);
  if(!ids.length){ toast('Select at least one product','err'); return; }
  const patch = {};
  const act  = document.getElementById('pbActive').value;
  const typ  = document.getElementById('pbType').value;
  const cat  = document.getElementById('pbCat').value.trim();
  const tagsRaw = document.getElementById('pbTags').value.trim();
  const tagMode = document.getElementById('pbTagMode').value;
  if(act!=='')  patch.active = act === '1';
  if(typ!=='')  patch.productType = typ;
  if(cat!=='')  patch.category = cat;
  if(tagsRaw){
    patch.tags = { mode: tagMode, values: tagsRaw.split(',').map(s=>s.trim()).filter(Boolean) };
  }
  if(!Object.keys(patch).length){ toast('Nothing to apply — set at least one field','err'); return; }
  const summary = Object.keys(patch).join(', ');
  if(!confirm(`Apply [${summary}] to ${ids.length} product(s)?`)) return;
  try{
    const r = await fetch(apiUrl('/products/bulk-update'), {
      method:'POST', headers:{'Content-Type':'application/json','X-Admin-Key':ADMIN_KEY},
      body: JSON.stringify({ ids, patch })
    }).then(r=>r.json());
    if(r.ok){ toast(`${r.data.updated}/${r.data.count} updated`,'ok'); }
    else throw new Error(r.error||'Failed');
  }catch(e){ toast('Bulk update failed: '+e.message,'err'); }
  loadProducts();
}
window.bulkApplyProducts = bulkApplyProducts;

/* ── BULK ORDERS ── */
async function bulkDeleteOrders(){
  const ids = [...document.querySelectorAll('.ord-chk:checked')].map(b=>b.dataset.id);
  if(!ids.length) return;
  if(!confirm(`${ids.length} order(s) permanently? This cannot be undone!`)) return;
  try{
    const r = await fetch(apiUrl('/orders/bulk-delete'), {
      method:'POST', headers:{'Content-Type':'application/json','X-Admin-Key':ADMIN_KEY},
      body: JSON.stringify({ids})
    }).then(r=>r.json());
    if(r.ok){ toast(`${r.data.deleted} order(s) deleted`,'ok'); }
    else throw new Error(r.error||'Failed');
  }catch(e){ toast('Could not delete: '+e.message,'err'); }
  loadOrders();
}
window.bulkDeleteOrders = bulkDeleteOrders;

async function bulkUpdateOrderStatus(){
  const ids = [...document.querySelectorAll('.ord-chk:checked')].map(b=>b.dataset.id);
  if(!ids.length) return toast('No orders selected','err');
  const status = document.getElementById('ordBulkStatus').value;
  if(!status) return toast('Please select a status','err');
  const sendEmail = !!document.getElementById('ordBulkEmail')?.checked;
  if(!confirm(`${ids.length} order(s) status → "${status}"${sendEmail?' + email':''}?`)) return;
  try{
    const r = await fetch(apiUrl('/orders/bulk-status'), {
      method:'POST', headers:{'Content-Type':'application/json','X-Admin-Key':ADMIN_KEY},
      body: JSON.stringify({ids, status, sendEmail, note:'Bulk status update'})
    }).then(r=>r.json());
    if(r.ok){ toast(`${r.data.updated} order(s) updated`,'ok'); }
    else throw new Error(r.error||'Failed');
  }catch(e){ toast('Update fail: '+e.message,'err'); }
  loadOrders();
}
window.bulkUpdateOrderStatus = bulkUpdateOrderStatus;

/* ── AUTO-FIX IMAGES (Media library) ── */
async function autoFixImages(){
  if(!confirm('Convert old http://... absolute image URLs → /uploads/... relative paths?\n\nThis ensures images load correctly across all devices and browsers.')) return;
  toast('🔍 Scanning...','ok');
  try{
    // dry-run preview
    const dry = await fetch(apiUrl('/fix-images.php'), {headers:{'X-Admin-Key':ADMIN_KEY}}).then(r=>r.json());
    const d = dry.data || dry;
    if(!d.will_update && !d.media_will_fix){ toast('✅ Everything looks good — no fix needed','ok'); return; }
    if(!confirm(`Found:\n• Products: ${d.will_update}\n• Media: ${d.media_will_fix}\n\nApply fix?`)) return;
    const res = await fetch(apiUrl('/fix-images.php'), {method:'POST', headers:{'X-Admin-Key':ADMIN_KEY}}).then(r=>r.json());
    const r = res.data || res;
    toast(`✅ ${r.updated} products + ${r.media_will_fix} media fixed`,'ok');
    if(typeof loadMedia==='function') loadMedia();
    if(typeof loadProducts==='function') loadProducts();
  }catch(e){ toast('Auto-fix fail: '+e.message,'err'); }
}
window.autoFixImages = autoFixImages;

async function bulkDeleteAbandoned(){
  const ids = [...document.querySelectorAll('.aban-chk:checked')].map(b=>b.dataset.id);
  if(!ids.length) return;
  if(!confirm(`${ids.length} cart(s)?`)) return;
  let ok=0,fail=0;
  for(const id of ids){
    try{ await apiDel('/abandoned/'+id); ok++; }catch{ fail++; }
  }
  toast(`${ok} deleted`+(fail?`, ${fail} failed`:''), fail?'err':'ok');
  loadRecovery();
}
window.bulkDeleteAbandoned = bulkDeleteAbandoned;

async function bulkDeleteUsers(){
  const ids = [...document.querySelectorAll('.user-chk:checked')].map(b=>b.dataset.id);
  if(!ids.length) return;
  if(!confirm(`${ids.length} user(s)?`)) return;
  let ok=0,fail=0;
  for(const id of ids){
    try{ await apiDel('/users/'+id); ok++; }catch{ fail++; }
  }
  toast(`${ok} deleted`+(fail?`, ${fail} failed`:''), fail?'err':'ok');
  loadUsers();
}
window.bulkDeleteUsers = bulkDeleteUsers;

async function bulkDeleteAccounts(){
  const ids = [...document.querySelectorAll('.ac-chk:checked')].map(b=>Number(b.dataset.id));
  if(!ids.length) return;
  if(!confirm(`${ids.length} entry(ies)?`)) return;
  let ok=0,fail=0;
  for(const id of ids){
    try{ await apiDel('/accounts/'+id); ok++; }catch{ fail++; }
  }
  toast(`${ok} deleted`+(fail?`, ${fail} failed`:''), fail?'err':'ok');
  loadAccounts();
}
window.bulkDeleteAccounts = bulkDeleteAccounts;

async function deleteOrder(id){
  if(!confirm('Delete this order?')) return;
  try{ await apiDel('/orders/'+id); toast('Deleted','ok'); closeModal(); loadOrders(); }
  catch(e){ toast('Delete failed: '+e.message,'err'); }
}
function sendCourierWA(id){
  const o = STATE.orders.find(x=>x.id===id); if(!o) return;
  const courier = STATE.couriers.find(c=>c.id===(document.getElementById('ordCourier').value||o.courier));
  const trackId = (document.getElementById('ordTrack').value || o.courierTracking || '').trim();
  if(!trackId){ toast('Tracking number required','err'); return; }
  const link = courier && courier.trackUrl ? (courier.trackUrl+encodeURIComponent(trackId)) : '';
  const phone = String(o.customerPhone||'').replace(/[^0-9]/g,'').replace(/^0/,'').replace(/^91/,'');
  const msg = `Hi ${o.customerName}, your MY 3D Gifts order *${o.id}* has been dispatched! 🎉\n\n📦 Courier: ${courier?courier.name:''}\n🔗 Tracking: ${trackId}\n${link?'\nTrack here: '+link:''}`;
  window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(msg)}`,'_blank');
}
function sendStatusWA(id){
  const o = STATE.orders.find(x=>x.id===id); if(!o) return;
  const status = document.getElementById('ordStatus').value;
  const phone = String(o.customerPhone||'').replace(/[^0-9]/g,'').replace(/^0/,'').replace(/^91/,'');
  const msg = `Hi ${o.customerName}, your MY 3D Gifts order *${o.id}* status update: *${status}* ✅\n\nThank you for shopping with us!`;
  window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(msg)}`,'_blank');
}

/* ── RECOVERY (abandoned carts) ── */
async function loadRecovery(){
  try{
    const data = await apiGet('/abandoned').catch(()=>[]);
    STATE.abandoned = data || [];
    if(!STATE.abandoned.length){
      document.getElementById('recoveryList').innerHTML = emptyHtml('🛒','No abandoned carts yet. When customers leave checkout incomplete, they appear here.');
      return;
    }
    document.getElementById('recoveryList').innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap">
        <label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer">
          <input type="checkbox" id="abanChkAll" onchange="toggleSelectAll('aban')" style="width:16px;height:16px"> Select All
        </label>
        <button class="btn btn-danger btn-sm" id="abanBulkDel" style="display:none" onclick="bulkDeleteAbandoned()">🗑 Delete Selected</button>
      </div>
      <table class="tbl"><thead><tr><th style="width:32px"></th><th>Customer</th><th>Phone</th><th>Items</th><th>Total</th><th>Last Step</th><th>Date</th><th></th></tr></thead>
      <tbody>${STATE.abandoned.map(a=>`
        <tr><td><input type="checkbox" class="aban-chk row-chk" data-id="${esc(a.id)}" onchange="updateBulkBar('aban')" style="width:16px;height:16px"></td>
        <td>${esc(a.customerName||'(unknown)')}</td>
        <td>${esc(a.customerPhone||'')}</td>
        <td>${(a.items||[]).length} items</td>
        <td>₹${Number(a.total||0).toLocaleString('en-IN')}</td>
        <td>${esc(a.lastStep||'cart')}</td>
        <td style="font-size:11px">${fmtDate(a.createdAt)}</td>
        <td>
          <button class="btn btn-wa btn-sm" onclick="recoverWA('${esc(a.id)}')">📱 Send WA</button>
          ${a.customerEmail ? `<button class="btn btn-ghost btn-sm" onclick="sendRecoveryEmail('${esc(a.id)}')">📧 Send Email</button>` : ''}
          <button class="btn btn-success btn-sm" onclick="approveAbandoned('${esc(a.id)}')">✅ Approve → Order</button>
          <button class="btn btn-danger btn-sm" onclick="deleteAbandoned('${esc(a.id)}')">🗑</button>
        </td></tr>`).join('')}</tbody></table>`;
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
function recoverWA(id){
  const a = STATE.abandoned.find(x=>x.id===id); if(!a) return;
  const phone = String(a.customerPhone||'').replace(/[^0-9]/g,'').replace(/^0/,'').replace(/^91/,'');
  if(!phone){ toast('No phone number','err'); return; }
  const itemList = (a.items||[]).map(i=>'• '+i.name+' × '+(i.quantity||1)).join('\n');
  const msg = `Hi ${a.customerName||'there'} 👋\n\nYou left these items in your cart at MY 3D Gifts:\n\n${itemList}\n\nComplete your order now and get *10% off* with code WELCOME10! 🎁\n\n${location.origin}`;
  window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(msg)}`,'_blank');
}
async function approveAbandoned(id){
  if(!confirm('Approve this cart and convert to a real Order?\nIt will move to Orders page and be removed from Cart Recovery.')) return;
  try{
    const r = await apiPost('/abandoned/approve/'+encodeURIComponent(id), {});
    toast('✅ Order created: '+(r.orderId||''), 'ok');
    loadRecovery();
  }catch(e){ toast('Approve failed: '+e.message,'err'); }
}
window.approveAbandoned = approveAbandoned;
async function deleteAbandoned(id){
  if(!confirm('Delete this abandoned cart entry?')) return;
  try{ await apiDel('/abandoned/'+id); toast('Deleted','ok'); loadRecovery(); }
  catch(e){ toast('Delete failed: '+e.message,'err'); }
}

/* ── PRODUCTS ── */
async function loadProducts(){
  try{ STATE.products = await apiGet('/products?all=1'); renderProducts(); }
  catch(e){ toast('Load failed: '+e.message,'err'); }
}
function renderProducts(){
  if(!STATE.products.length){ document.getElementById('productsList').innerHTML = emptyHtml('🛍️','No products yet'); return; }
  document.getElementById('productsList').innerHTML = `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap">
      <label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer">
        <input type="checkbox" id="prodChkAll" onchange="toggleSelectAll('prod')" style="width:16px;height:16px"> Select All
      </label>
      <span id="prodSelCount" style="font-size:12px;color:var(--muted)"></span>
      <div id="prodBulkBar" style="display:none;align-items:center;gap:6px;flex-wrap:wrap;padding:6px 8px;border:1px solid var(--border);border-radius:8px;background:var(--card,#fafafa)">
        <select id="pbActive" class="btn btn-ghost btn-sm" title="Active / Hidden" style="padding:4px 6px">
          <option value="">Active: —</option>
          <option value="1">✅ Active</option>
          <option value="0">🚫 Hidden</option>
        </select>
        <select id="pbType" class="btn btn-ghost btn-sm" title="Product Type" style="padding:4px 6px">
          <option value="">Type: —</option>
          <option value="readymade">🎁 Readymade</option>
          <option value="custom">✨ Customize</option>
          <option value="others">📦 Others</option>
        </select>
        <input id="pbCat" placeholder="Category: —" list="pCatListBulk" style="padding:4px 6px;width:130px;font-size:12px"/>
        <datalist id="pCatListBulk">${[...new Set(STATE.products.map(x=>x.category||'').filter(Boolean))].map(c=>`<option value="${esc(c)}">`).join('')}</datalist>
        <input id="pbTags" placeholder="Tags (comma)" style="padding:4px 6px;width:150px;font-size:12px"/>
        <select id="pbTagMode" class="btn btn-ghost btn-sm" title="Tag mode" style="padding:4px 6px">
          <option value="add">+ Add</option>
          <option value="remove">− Remove</option>
          <option value="replace">⟳ Replace</option>
        </select>
        <button class="btn btn-primary btn-sm" onclick="bulkApplyProducts()">Apply</button>
        <button class="btn btn-danger btn-sm" id="prodBulkDel" onclick="bulkDeleteProducts()">🗑 Delete</button>
      </div>
    </div>
    <table class="tbl"><thead><tr><th style="width:32px"></th><th style="width:48px">Image</th><th>Name</th><th>Price</th><th>Category</th><th>Active</th><th></th></tr></thead>
    <tbody>${STATE.products.map(p=>{
      const cover = imgUrl(p.image||p.coverImage||'');
      const thumb = cover
        ? `<img  loading="lazy" decoding="async"src="${esc(cover)}" style="width:40px;height:40px;object-fit:cover;border-radius:6px;border:1px solid var(--border)" onerror="this.outerHTML='&lt;span style=\\'display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:6px;background:#fef3c7;border:1px solid #fde68a;font-size:14px\\' title=\\'Broken — file missing\\'&gt;⚠️&lt;/span&gt;'"/>`
        : `<span style="display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:6px;background:#f1f5f9;border:1px solid var(--border);font-size:16px">🎁</span>`;
      return `
      <tr><td><input type="checkbox" class="prod-chk row-chk" data-id="${esc(p.id)}" onchange="updateBulkBar('prod')" style="width:16px;height:16px"></td>
      <td>${thumb}</td>
      <td><b>${esc(p.name)}</b><br><span style="font-size:11px;color:var(--muted)">${esc(p.id)}</span></td>
      <td>₹${Number(p.basePrice||0).toLocaleString('en-IN')}</td>
      <td>${esc(p.category||'')}</td>
      <td>${p.active!==false?'<span class="chip chip-green">Active</span>':'<span class="chip chip-gray">Hidden</span>'}</td>
      <td><button class="btn btn-ghost btn-sm" onclick="openProductModal('${esc(p.id)}')">Edit</button>
      <button class="btn btn-danger btn-sm" onclick="deleteProduct('${esc(p.id)}')">🗑</button></td></tr>`;
    }).join('')}</tbody></table>`;
}
function openProductModal(id){
  const p = id ? STATE.products.find(x=>x.id===id) : {
    id:'p_'+Date.now(), name:'', basePrice:0, description:'', category:'',
    image:'', images:[], active:true,
    productType:'readymade', featured:false,
    options:{ colorMode:'sync', preview3DEnabled:true, gifUrl:'', glbUrl:'', glbAnimation:true,
      colorEnabled:true, photoEnabled:false, productType:'readymade', featured:false }
  };
  const o = p.options || {};
  const ptype = p.productType || o.productType || 'readymade';
  const feat  = p.featured ?? !!o.featured;
  const currentSlug = id ? p.id : '';
  // Featured count guard (max 3) handled at save time
  openModal(id?`Edit Product`:`New Product`,`
    <div class="grid grid-2">
      <div class="field"><label>Name</label><input id="pName" value="${esc(p.name)}" oninput="syncProductSlugFromName()"/></div>
      <div class="field"><label>Base Price (₹)</label><input id="pPrice" type="number" value="${p.basePrice||0}"/></div>
      <div class="field" style="grid-column:1/-1"><label>Product URL Slug</label>
        <input id="pSlug" value="${esc(currentSlug)}" placeholder="auto from product name" ${id?'readonly':''} oninput="this.dataset.touched='1';this.value=productSlugify(this.value);document.getElementById('pSlugPreview').textContent=this.value||'product-name'"/>
        <div class="hint">New products will use this SEO URL: <b>/product/<span id="pSlugPreview">${esc(currentSlug || 'product-name')}</span></b></div>
      </div>
      <div class="field"><label>Category</label>
        <input id="pCat" value="${esc(p.category||'')}" placeholder="keychain, nameplate, etc." list="pCatList" autocomplete="off"/>
        <datalist id="pCatList">${[...new Set(STATE.products.map(x=>x.category||'').filter(Boolean))].map(c=>`<option value="${esc(c)}">`).join('')}</datalist>
      </div>
      <div class="field"><label>Tags (comma separated)</label>
        <input id="pTags" value="${esc((p.tags||[]).join(', '))}" placeholder="birthday, gift, 3d, name…"/>
        <div class="hint">These will help filter products via search.</div>
      </div>
      <div class="field"><label>Active</label><label class="switch"><input type="checkbox" id="pActive" ${p.active!==false?'checked':''}/><span class="slider"></span></label></div>
      <div class="field"><label>📦 Product Type</label>
        <select id="pType">
          <option value="readymade" ${ptype==='readymade'?'selected':''}>🎁 Readymade Product</option>
          <option value="custom" ${ptype==='custom'?'selected':''}>✨ Customize Product</option>
          <option value="others" ${ptype==='others'?'selected':''}>📦 Others</option>
        </select>
        <div class="hint">These will be shown separately on the Storefront Shop page.</div>
      </div>
      <div class="field"><label>⭐ Featured (max 3)</label>
        <label class="switch"><input type="checkbox" id="pFeatured" ${feat?'checked':''}/><span class="slider"></span></label>
        <div class="hint">Featured products will be highlighted first on the Shop page.</div>
      </div>
      <div class="field" style="grid-column:1/-1"><label>Description</label><textarea id="pDesc" rows="2">${esc(p.description||'')}</textarea></div>
      <div class="field" style="grid-column:1/-1">
        <label>Main Image (URL or upload — both show preview)</label>
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
          <input id="pImage" value="${esc(p.image||'')}" placeholder="https://... or /uploads/...jpg" style="flex:1;min-width:200px" oninput="renderPImagePreview()"/>
          <input type="file" id="pImageFile" accept="image/*,image/gif" style="display:none" onchange="adminUploadImageWithCrop(this,'pImage')"/>
          <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('pImageFile').click()">📤 Upload</button>
          <button type="button" class="btn btn-ghost btn-sm" onclick="cropExistingImage('pImage')">✂️ Crop</button>
          <button type="button" class="btn btn-primary btn-sm" onclick="openMediaPickerFor('pImage','single')">🖼️ Select Image</button>
        </div>
        <div id="pImagePrev" style="margin-top:6px"></div>
      </div>
      <div class="field" style="grid-column:1/-1">
        <label>Extra Images (one URL per line — preview below)</label>
        <textarea id="pImages" rows="3" oninput="renderPImagesPreview()">${esc(imageArrayValues(p.images).filter(u=>u && u!==imageValue(p.image)).join('\n'))}</textarea>
        <div style="display:flex;gap:6px;align-items:center;margin-top:6px;">
          <input type="file" id="pImagesFile" accept="image/*,image/gif" multiple style="display:none" onchange="adminUploadMulti(this,'pImages')"/>
          <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('pImagesFile').click()">📤 Upload Multiple</button>
          <button type="button" class="btn btn-primary btn-sm" onclick="openMediaPickerFor('pImages','multi')">🖼️ Select from Library</button>
          <span class="hint">JPG / PNG / GIF / WEBP supported (max 10 MB each)</span>
        </div>
        <div id="pImagesPrev" style="margin-top:8px;display:flex;flex-wrap:wrap;gap:6px"></div>
      </div>
    </div>
    <div class="card" style="margin-top:12px;background:#f8fafc">
      <div class="card-title" style="margin-bottom:8px">🎨 Color Mode</div>
      <div class="field"><label>Mode</label>
        <select id="pColorMode" onchange="adminToggleColorMode(this.value)">
          <option value="sync" ${o.colorMode==='sync'?'selected':''}>Sync (Use global Filament library)</option>
          <option value="custom" ${o.colorMode==='custom'?'selected':''}>Custom (Product-specific palette)</option>
        </select>
        <div class="hint">"Sync" mode → Only colors added under Admin → Filament Colors will be shown.</div>
      </div>
      <!-- Custom palette editor — shown only when mode=custom -->
      <div id="pCustomColorsBox" style="${o.colorMode==='custom'?'':'display:none;'}margin-top:12px;background:#fffbeb;border:1px solid #fcd34d;border-radius:10px;padding:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <b style="font-size:13px">🎨 Custom Colors for this Product</b>
          <button type="button" class="btn btn-success btn-sm" onclick="adminAddCustomColor()">+ Add Color</button>
        </div>
        <div id="pCustomColorsList" style="display:flex;flex-direction:column;gap:6px"></div>
        <div class="hint" style="margin-top:6px">These colors will be shown ONLY for this product, instead of the global filament library.</div>
      </div>
    </div>
    <div class="card" style="margin-top:12px;background:#f8fafc">
      <div class="card-title" style="margin-bottom:8px">📦 Built-in Options & Required Fields</div>
      <div class="hint" style="margin-bottom:8px">Toggle <b>Required</b> below to force the customer to fill these before Add to Cart / Place Order. A warning is shown to the customer. (வாடிக்கையாளருக்கு warning காண்பிக்கப்படும்)</div>
      <div class="grid grid-2">
        <div class="toggle-row"><div><div class="lbl">🎨 Color picker</div><div class="desc">Filament colors only.</div></div><label class="switch"><input type="checkbox" id="pColor" ${o.colorEnabled?'checked':''}/><span class="slider"></span></label></div>
        <div class="toggle-row"><div><div class="lbl">⚠️ Color Required</div><div class="desc">Customer must select a color.</div></div><label class="switch"><input type="checkbox" id="pColorReq" ${o.colorRequired?'checked':''}/><span class="slider"></span></label></div>
        <div class="toggle-row"><div><div class="lbl">📷 Photo upload</div><div class="desc">Show photo upload field.</div></div><label class="switch"><input type="checkbox" id="pPhoto" ${o.photoEnabled?'checked':''}/><span class="slider"></span></label></div>
        <div class="toggle-row"><div><div class="lbl">⚠️ Photo Required</div><div class="desc">Customer must upload a photo.</div></div><label class="switch"><input type="checkbox" id="pPhotoReq" ${o.photoRequired!==false?'checked':''}/><span class="slider"></span></label></div>
      </div>
    </div>
    <div class="card" style="margin-top:12px;background:#f8fafc">
      <div class="card-title" style="margin-bottom:8px">🎬 3D / GIF / Video / YouTube Preview</div>
      <div class="grid grid-2">
        <div class="field"><label>GIF URL</label>
          <div style="display:flex;gap:6px;align-items:center;">
            <input id="pGif" value="${esc(o.gifUrl||'')}" placeholder="https://...gif" style="flex:1;"/>
            <input type="file" id="pGifFile" accept="image/gif" style="display:none" onchange="adminUploadImage(this,'pGif')"/>
            <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('pGifFile').click()">📤</button>
          </div>
        </div>
        <div class="field"><label>3D Model (GLB/GLTF) URL</label><input id="pGlb" value="${esc(o.glbUrl||'')}" placeholder="https://...glb"/></div>
        <div class="field"><label>Video URL (.mp4)</label><input id="pVideo" value="${esc(o.videoUrl||'')}" placeholder="https://.../video.mp4"/></div>
        <div class="toggle-row"><div><div class="lbl">Auto-play Video</div></div><label class="switch"><input type="checkbox" id="pVideoAuto" ${o.videoAutoplay?'checked':''}/><span class="slider"></span></label></div>
        <div class="field"><label>YouTube URL</label><input id="pYT" value="${esc(o.youtubeUrl||'')}" placeholder="https://youtube.com/watch?v=..."/></div>
        <div class="toggle-row"><div><div class="lbl">Auto-play YouTube</div></div><label class="switch"><input type="checkbox" id="pYTAuto" ${o.youtubeAutoplay?'checked':''}/><span class="slider"></span></label></div>
        <div class="toggle-row"><div><div class="lbl">Enable 3D Viewer</div></div><label class="switch"><input type="checkbox" id="p3D" ${o.preview3DEnabled!==false?'checked':''}/><span class="slider"></span></label></div>
        <div class="toggle-row"><div><div class="lbl">Auto-play GLB Animation</div></div><label class="switch"><input type="checkbox" id="pAnim" ${o.glbAnimation!==false?'checked':''}/><span class="slider"></span></label></div>
        <div class="field" style="grid-column:1/-1"><label>Custom 3D Viewer HTML / Embed (advanced)</label>
          <textarea id="p3DHtml" rows="3" placeholder="&lt;model-viewer src='...'&gt;&lt;/model-viewer&gt; OR &lt;iframe ...&gt;">${esc(o.viewer3dHtml||'')}</textarea>
          <div class="hint">Paste HTML/JS code in this field to render it instead of the built-in viewer.</div>
        </div>
      </div>
    </div>
    <!-- v17: Custom Options (Unlimited) — preferred way to add Material / Size / etc. -->
    <div class="card" style="margin-top:12px;background:#f0f9ff;border:1px solid #bae6fd">
      <div class="flex items-center justify-between" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <div>
          <div class="card-title" style="margin-bottom:2px">🧩 Custom Options (Unlimited)</div>
          <div class="hint">Add all options like Material, Size, Finish here: text, dropdown, color, checkbox, file/image uploadpload — flat ₹ extra + per-char/per-color extras.</div>
        </div>
        <button type="button" class="btn btn-success btn-sm" onclick="adminAddDynOpt()">+ Add Option</button>
      </div>
      <div id="adminDynOptsList" class="space-y-2" style="display:flex;flex-direction:column;gap:8px"></div>
    </div>
  `,
  `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
   <button class="btn btn-warn" onclick="saveProductDraft(${id?`'${esc(id)}'`:'null'})">📝 Save Draft</button>
   <button class="btn btn-success" onclick="saveProduct(${id?`'${esc(id)}'`:'null'})">💾 Save Product</button>`);
  // Init dynamic options draft for this modal session
  window.adminDynOptsDraft = JSON.parse(JSON.stringify(o.dynamicOptions || []));
  // Reverse-map storefront fields → admin UI fields
  window.adminDynOptsDraft.forEach(opt=>{
    if (opt.type==='checkbox') {
      opt.triggerShowIds = window.adminDynOptsDraft
        .filter(t=>t.showWhenId===opt.id)
        .map(t=>t.id);
    }
    if (['text','textarea'].includes(opt.type)) {
      opt.syncEnabled = !!opt.syncLengthEnabled;
    }
  });
  window.adminCustomColorsDraft = Array.isArray(o.customColors) && o.customColors.length
    ? JSON.parse(JSON.stringify(o.customColors))
    : (o.colorMode==='custom' ? [] : []);
  setTimeout(()=>{ adminRenderDynOpts(); adminRenderCustomColors(); renderPImagePreview(); renderPImagesPreview(); maybeRestoreProductDraft(id); }, 30);
}

// ── v32: Product Draft Save (localStorage) — v36 also persists Custom Options draft
function _productDraftKey(id){ return 'pDraft_' + (id || 'new'); }
function saveProductDraft(id){
  try{
    const d = {
      name: document.getElementById('pName')?.value||'',
      basePrice: document.getElementById('pPrice')?.value||'',
      slug: document.getElementById('pSlug')?.value||'',
      category: document.getElementById('pCat')?.value||'',
      tags: document.getElementById('pTags')?.value||'',
      description: document.getElementById('pDesc')?.value||'',
      image: document.getElementById('pImage')?.value||'',
      images: document.getElementById('pImages')?.value||'',
      productType: document.getElementById('pType')?.value||'',
      featured: !!document.getElementById('pFeatured')?.checked,
      active: !!document.getElementById('pActive')?.checked,
      dynamicOptions: window.adminDynOptsDraft || [],
      customColors:  window.adminCustomColorsDraft || [],
      savedAt: Date.now()
    };
    localStorage.setItem(_productDraftKey(id), JSON.stringify(d));
    toast('Draft saved locally (வரைவு சேமிக்கப்பட்டது)','ok');
  }catch(e){ toast('Draft save failed','err'); }
}
window.saveProductDraft = saveProductDraft;
function maybeRestoreProductDraft(id){
  try{
    const raw = localStorage.getItem(_productDraftKey(id));
    if(!raw) return;
    const d = JSON.parse(raw);
    if(!d || !d.savedAt) return;
    const age = Math.round((Date.now()-d.savedAt)/60000);
    if(!confirm(`Restore draft saved ${age} min ago? (${age} நிமிடத்திற்கு முன் சேமித்த வரைவை மீட்டெடுக்கவா?)`)){ return; }
    const set = (k,v)=>{ const el=document.getElementById(k); if(el){ if(el.type==='checkbox') el.checked=!!v; else el.value=v||''; } };
    set('pName',d.name); set('pPrice',d.basePrice); set('pCat',d.category);
    set('pSlug',d.slug); set('pTags',d.tags); set('pDesc',d.description); set('pImage',d.image);
    set('pImages',d.images); set('pType',d.productType);
    set('pFeatured',d.featured); set('pActive',d.active);
    if(Array.isArray(d.dynamicOptions)) window.adminDynOptsDraft = d.dynamicOptions;
    if(Array.isArray(d.customColors))   window.adminCustomColorsDraft = d.customColors;
    if(typeof adminRenderDynOpts==='function') adminRenderDynOpts();
    if(typeof adminRenderCustomColors==='function') adminRenderCustomColors();
    renderPImagePreview(); renderPImagesPreview();
  }catch(e){}
}
window.maybeRestoreProductDraft = maybeRestoreProductDraft;
function _clearProductDraft(id){ try{ localStorage.removeItem(_productDraftKey(id)); }catch(e){} }
window._clearProductDraft = _clearProductDraft;
// v36: autosave the Custom Options draft on every change so brief modal
// interruptions (accidental backdrop click, drag-select) don't lose them.
window._autosaveDynOpts = function(id){
  try{
    const key = _productDraftKey(id||'new');
    const cur = JSON.parse(localStorage.getItem(key)||'{}') || {};
    cur.dynamicOptions = window.adminDynOptsDraft || [];
    cur.savedAt = Date.now();
    localStorage.setItem(key, JSON.stringify(cur));
  }catch(e){}
};


/* v17 — live image preview helpers */
function renderPImagePreview(){
  const v = (document.getElementById('pImage')?.value||'').trim();
  const box = document.getElementById('pImagePrev'); if(!box) return;
  if(!v){ box.innerHTML=''; return; }
  box.innerHTML = `<div style="display:flex;align-items:center;gap:8px">
    <img  loading="lazy" decoding="async"src="${esc(imgUrl(v))}" style="max-height:90px;border-radius:6px;border:1px solid #e2e8f0;background:#fff" onerror="this.style.opacity=.3;this.title='Failed to load'"/>
    <button type="button" class="btn btn-ghost btn-sm" onclick="cropExistingImage('pImage')">✂️ Crop</button>
  </div>`;
}
window.renderPImagePreview = renderPImagePreview;
function renderPImagesPreview(){
  const v = document.getElementById('pImages')?.value||'';
  const box = document.getElementById('pImagesPrev'); if(!box) return;
  const arr = v.split('\n').map(s=>s.trim()).filter(Boolean);
  box.innerHTML = arr.map((u,i)=>`
    <div draggable="true" data-idx="${i}"
         ondragstart="event.dataTransfer.setData('text/plain', this.dataset.idx); this.style.opacity='.4'"
         ondragend="this.style.opacity='1'"
         ondragover="event.preventDefault(); this.style.outline='2px dashed var(--primary)'"
         ondragleave="this.style.outline='none'"
         ondrop="event.preventDefault(); this.style.outline='none'; reorderPImage(parseInt(event.dataTransfer.getData('text/plain')), parseInt(this.dataset.idx))"
         title="Drag to reorder"
         style="position:relative;width:80px;height:80px;border:1px solid var(--border);border-radius:6px;overflow:hidden;background:#fff;cursor:grab">
      <img src="${esc(u)}" loading="lazy" decoding="async" style="width:100%;height:100%;object-fit:cover;pointer-events:none" onerror="this.style.opacity=.25"/>
      <span style="position:absolute;top:2px;left:2px;background:rgba(0,0,0,.6);color:#fff;font-size:10px;padding:0 4px;border-radius:6px">${i+1}</span>
      <button type="button" title="Remove" onclick="removePImageRow(${i})" style="position:absolute;top:2px;right:2px;width:20px;height:20px;border-radius:50%;border:0;background:rgba(220,38,38,.9);color:#fff;font-size:12px;cursor:pointer;line-height:1">×</button>
    </div>`).join('');
}
window.renderPImagesPreview = renderPImagesPreview;
window.removePImageRow = function(i){
  const ta = document.getElementById('pImages');
  const arr = ta.value.split('\n').map(s=>s.trim()).filter(Boolean);
  arr.splice(i,1); ta.value = arr.join('\n'); renderPImagesPreview();
};
window.reorderPImage = function(from, to){
  if(from===to || isNaN(from) || isNaN(to)) return;
  const ta = document.getElementById('pImages');
  const arr = ta.value.split('\n').map(s=>s.trim()).filter(Boolean);
  const [m] = arr.splice(from, 1); arr.splice(to, 0, m);
  ta.value = arr.join('\n'); renderPImagesPreview();
};


async function saveProduct(id){
  try{
    const existing = id ? STATE.products.find(x=>x.id===id) : null;
    const p = existing ? JSON.parse(JSON.stringify(existing)) : {id:'p_'+Date.now(), options:{}};
    p.name = document.getElementById('pName').value.trim();
    if(!id){
      const wantedSlug = productSlugify(document.getElementById('pSlug')?.value || p.name);
      p.id = uniqueProductSlug(wantedSlug, null);
    }
    p.basePrice = Number(document.getElementById('pPrice').value)||0;
    p.category = document.getElementById('pCat').value.trim();
    p.tags = document.getElementById('pTags').value.split(',').map(s=>s.trim()).filter(Boolean);
    p.active = document.getElementById('pActive').checked;
    p.description = document.getElementById('pDesc').value;
    p.image = document.getElementById('pImage').value.trim();
    // Extra images from textarea
    const extraImgs = document.getElementById('pImages').value.split('\n').map(s=>s.trim()).filter(Boolean);
    // Always ensure main image is first in images[] so it persists on reload
    if (p.image) {
      p.images = [p.image, ...extraImgs.filter(u => u !== p.image)];
    } else {
      p.images = extraImgs;
      if (p.images.length) p.image = p.images[0]; // auto-set cover from first extra
    }
    p.productType = document.getElementById('pType')?.value || 'readymade';
    p.featured    = !!document.getElementById('pFeatured')?.checked;

    // Enforce max 3 featured
    if (p.featured) {
      const otherFeat = STATE.products.filter(x => x.id !== p.id && (x.featured || x.options?.featured)).length;
      if (otherFeat >= 3) {
        toast('Max 3 featured products. Unfeature one first.', 'err'); return;
      }
    }

    p.options = p.options || {};
    p.options.colorMode = document.getElementById('pColorMode').value;
    p.options.customColors = (p.options.colorMode === 'custom') ? (window.adminCustomColorsDraft || []) : [];
    p.options.colorEnabled = document.getElementById('pColor').checked;
    p.options.colorRequired= !!document.getElementById('pColorReq')?.checked;
    p.options.photoEnabled = document.getElementById('pPhoto').checked;
    p.options.photoRequired= !!document.getElementById('pPhotoReq')?.checked;
    // Force OFF the legacy material/size pickers (v17 removed)
    p.options.sizeEnabled = false;
    p.options.materialEnabled = false;
    p.options.gifUrl = document.getElementById('pGif').value.trim();
    p.options.glbUrl = document.getElementById('pGlb').value.trim();
    p.options.preview3DEnabled = document.getElementById('p3D').checked;
    p.options.glbAnimation = document.getElementById('pAnim').checked;
    p.options.viewer3dHtml = document.getElementById('p3DHtml')?.value||'';
    p.options.videoUrl       = document.getElementById('pVideo')?.value.trim()||'';
    p.options.videoAutoplay  = !!document.getElementById('pVideoAuto')?.checked;
    p.options.youtubeUrl     = document.getElementById('pYT')?.value.trim()||'';
    p.options.youtubeAutoplay= !!document.getElementById('pYTAuto')?.checked;
    // Save dynamicOptions with trigger/sync transformations
    const rawDraft = JSON.parse(JSON.stringify(window.adminDynOptsDraft||[]));
    // 1. Apply triggerShowIds: for each checkbox opt, set showWhenId on target opts
    //    First clear all auto-set showWhenId so re-saves stay clean
    rawDraft.forEach(o=>{ if (o._autoShowWhen) { delete o.showWhenId; delete o.showWhenVal; delete o._autoShowWhen; }});
    rawDraft.forEach(cbOpt=>{
      if (cbOpt.type==='checkbox' && Array.isArray(cbOpt.triggerShowIds)) {
        cbOpt.triggerShowIds.forEach(targetId=>{
          const target = rawDraft.find(x=>x.id===targetId);
          if (target) { target.showWhenId = cbOpt.id; target.showWhenVal = true; target._autoShowWhen = true; }
        });
      }
    });
    // 2. Sync: map syncEnabled → syncLengthEnabled
    rawDraft.forEach(o=>{ if (['text','textarea'].includes(o.type)) { o.syncLengthEnabled = !!o.syncEnabled; }});
    p.options.dynamicOptions = rawDraft;
    p.options.productType    = p.productType;
    p.options.featured       = p.featured;
    if(!p.name){ toast('Name required','err'); return; }
    if(id) await apiPut('/products/'+id, p);
    else await apiPost('/products', p);
    _clearProductDraft(id);
    toast('Saved','ok'); closeAllModals(); loadProducts();
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
async function deleteProduct(id){
  if(!confirm('Delete this product?')) return;
  try{ await apiDel('/products/'+id); toast('Deleted','ok'); loadProducts(); }
  catch(e){ toast('Delete failed: '+e.message,'err'); }
}

/* ── USERS ── */
async function loadUsers(){
  try{
    STATE.users = await apiGet('/users');
    if(!STATE.users.length){ document.getElementById('usersList').innerHTML = emptyHtml('👥','No customers yet'); return; }
    document.getElementById('usersList').innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap">
        <label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer">
          <input type="checkbox" id="userChkAll" onchange="toggleSelectAll('user')" style="width:16px;height:16px"> Select All
        </label>
        <button class="btn btn-danger btn-sm" id="userBulkDel" style="display:none" onclick="bulkDeleteUsers()">🗑 Delete Selected</button>
      </div>
      <table class="tbl"><thead><tr><th style="width:32px"></th><th>Name</th><th>Phone</th><th>Email</th><th>Orders</th><th>Total Spent</th><th>Joined</th></tr></thead>
      <tbody>${STATE.users.map(u=>`
        <tr><td><input type="checkbox" class="user-chk row-chk" data-id="${esc(String(u.id||u.phone||''))}" onchange="updateBulkBar('user')" style="width:16px;height:16px"></td>
        <td><b>${esc(u.name||'')}</b></td><td>${esc(u.phone||'')}</td><td>${esc(u.email||'')}</td>
        <td>${u.orderCount||0}</td><td>₹${Number(u.totalSpent||0).toLocaleString('en-IN')}</td>
        <td style="font-size:11px">${fmtDate(u.createdAt)}</td></tr>`).join('')}</tbody></table>`;
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}

/* ── ANALYTICS ── */
async function loadAnalytics(){
  try{
    const [orders, products, views, viewsDetailed] = await Promise.all([
      apiGet('/orders').catch(()=>[]), apiGet('/products?all=1').catch(()=>[]), apiGet('/views').catch(()=>({})),
      apiGet('/views?detailed=1').catch(()=>null)
    ]);
    STATE.orders = orders||[]; STATE.products = products||[]; STATE.views = views||{};
    const today = new Date().toDateString();
    const todayOrd = STATE.orders.filter(o=>o.createdAt && new Date(String(o.createdAt).replace(' ','T')).toDateString()===today);
    const todayRev = todayOrd.reduce((s,o)=>s+Number(o.total||0),0);
    const validOrders = STATE.orders.filter(o=>o.status!=='Cancelled');
    const aov = validOrders.length ? validOrders.reduce((s,o)=>s+Number(o.total||0),0)/validOrders.length : 0;
    const totalViews = Object.values(STATE.views).reduce((s,v)=>s+Number(v||0),0);
    document.getElementById('anTodayRev').textContent = '₹'+todayRev.toLocaleString('en-IN');
    document.getElementById('anTodayOrd').textContent = todayOrd.length;
    document.getElementById('anAOV').textContent = '₹'+Math.round(aov).toLocaleString('en-IN');
    document.getElementById('anViews').textContent = totalViews.toLocaleString('en-IN');

    // Today vs Yesterday views (from detailed endpoint)
    // NOTE: apiGet()/http() already unwraps {ok,data} and returns data directly
    const vd = viewsDetailed || null;
    document.getElementById('anViewsToday').textContent = (vd ? vd.today : 0).toLocaleString('en-IN');
    document.getElementById('anViewsYesterday').textContent = (vd ? vd.yesterday : 0).toLocaleString('en-IN');

    // Top products by orderCount
    const counts = {};
    STATE.orders.forEach(o=>(o.items||[]).forEach(it=>{ counts[it.productId||it.id||it.name] = (counts[it.productId||it.id||it.name]||0) + (Number(it.quantity)||1); }));
    const top = Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,8);
    document.getElementById('anTopProducts').innerHTML = top.length?`
      <table class="tbl"><thead><tr><th>Product</th><th>Units Sold</th><th>Views</th></tr></thead>
      <tbody>${top.map(([k,v])=>{
        const p = STATE.products.find(x=>x.id===k) || {name:k};
        return `<tr><td><b>${esc(p.name)}</b></td><td>${v}</td><td>${STATE.views[k]||0}</td></tr>`;
      }).join('')}</tbody></table>`:'<p style="color:var(--muted)">No data</p>';

    // Top 5 products by time spent (seconds → human readable)
    const fmtDuration = (sec) => {
      sec = Number(sec)||0;
      if (sec < 60) return sec + 's';
      const m = Math.floor(sec/60), s = sec%60;
      if (m < 60) return m + 'm ' + s + 's';
      const h = Math.floor(m/60), rm = m%60;
      return h + 'h ' + rm + 'm';
    };
    const topTime = (vd && Array.isArray(vd.topByTime)) ? vd.topByTime : [];
    document.getElementById('anTopTimeSpent').innerHTML = topTime.length ? `
      <table class="tbl"><thead><tr><th>#</th><th>Product</th><th>Total Time Spent</th><th>Views</th><th>Avg / View</th></tr></thead>
      <tbody>${topTime.map((t,i)=>{
        const p = STATE.products.find(x=>x.id===t.productId) || {name:t.productId};
        const avg = t.viewCount ? Math.round(t.totalSeconds/t.viewCount) : 0;
        return `<tr><td>${i+1}</td><td><b>${esc(p.name)}</b></td><td>${fmtDuration(t.totalSeconds)}</td><td>${t.viewCount}</td><td>${fmtDuration(avg)}</td></tr>`;
      }).join('')}</tbody></table>` : '<p style="color:var(--muted)">No data yet</p>';

    const statusCount = {};
    STATE.orders.forEach(o=>{ statusCount[o.status||'New'] = (statusCount[o.status||'New']||0)+1; });
    document.getElementById('anStatusBreak').innerHTML = `<div style="display:flex;flex-wrap:wrap;gap:8px">${Object.entries(statusCount).map(([s,c])=>`<div class="stat" style="flex:1;min-width:130px"><div class="lbl">${esc(s)}</div><div class="val">${c}</div></div>`).join('')}</div>`;
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}

/* ── COUPONS ── */
async function loadCoupons(){
  try{
    STATE.coupons = await apiGet('/coupons?all=1');
    if(!STATE.coupons.length){ document.getElementById('couponsList').innerHTML = emptyHtml('🎟️','No coupons yet'); return; }
    document.getElementById('couponsList').innerHTML = `
      <table class="tbl"><thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Min Order</th><th>Active</th><th>Uses</th><th></th></tr></thead>
      <tbody>${STATE.coupons.map(c=>`
        <tr><td><b><code>${esc(c.code)}</code></b></td>
        <td>${esc(c.type)}</td><td>${c.type==='percent'?c.value+'%':'₹'+c.value}</td>
        <td>₹${c.minOrder||0}</td>
        <td>${c.active?'<span class="chip chip-green">Yes</span>':'<span class="chip chip-gray">No</span>'}</td>
        <td>${c.uses||0}</td>
        <td><button class="btn btn-ghost btn-sm" onclick="editCoupon('${esc(c.code)}')">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteCoupon(${c.id})">🗑</button></td></tr>`).join('')}</tbody></table>`;
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
function openCouponModal(){ editCoupon(null); }
function editCoupon(code){
  const c = code ? STATE.coupons.find(x=>x.code===code) : { code:'', type:'percent', value:10, minOrder:0, active:true };
  openModal(code?'Edit Coupon':'New Coupon',`
    <div class="grid grid-2">
      <div class="field"><label>Code</label><input id="cCode" value="${esc(c.code)}" placeholder="WELCOME10"/></div>
      <div class="field"><label>Type</label><select id="cType"><option value="percent" ${c.type==='percent'?'selected':''}>Percent (%)</option><option value="flat" ${c.type==='flat'?'selected':''}>Flat (₹)</option></select></div>
      <div class="field"><label>Value</label><input id="cValue" type="number" value="${c.value||0}"/></div>
      <div class="field"><label>Min Order (₹)</label><input id="cMin" type="number" value="${c.minOrder||0}"/></div>
      <div class="field"><label>Active</label><label class="switch"><input type="checkbox" id="cActive" ${c.active?'checked':''}/><span class="slider"></span></label></div>
    </div>`,
    `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
     <button class="btn btn-success" onclick="saveCoupon()">💾 Save</button>`);
}
async function saveCoupon(){
  try{
    const body = {
      code: document.getElementById('cCode').value.trim().toUpperCase(),
      type: document.getElementById('cType').value,
      value: Number(document.getElementById('cValue').value)||0,
      minOrder: Number(document.getElementById('cMin').value)||0,
      active: document.getElementById('cActive').checked
    };
    if(!body.code){ toast('Code required','err'); return; }
    await apiPost('/coupons', body);
    toast('Saved','ok'); closeModal(); loadCoupons();
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
async function deleteCoupon(id){ if(!confirm('Delete coupon?')) return;
  try{ await apiDel('/coupons/'+id); toast('Deleted','ok'); loadCoupons(); }
  catch(e){ toast('Delete failed: '+e.message,'err'); }
}

/* ── FLASH SALE ── */
async function loadFlash(){
  try{
    const f = await apiGet('/flash').catch(()=>({}));
    STATE.flash = f || {};
    document.getElementById('flActive').checked = !!f?.active;
    document.getElementById('flCode').value = f?.code||'';
    document.getElementById('flDiscount').value = f?.discount||'';
    document.getElementById('flBanner').value = f?.banner||'';
    if(f?.endTime){ const d = new Date(f.endTime); if(!isNaN(d)) document.getElementById('flEndTime').value = d.toISOString().slice(0,16); }
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
async function saveFlash(){
  try{
    await apiPost('/flash',{
      active: document.getElementById('flActive').checked,
      code: document.getElementById('flCode').value.trim().toUpperCase(),
      discount: Number(document.getElementById('flDiscount').value)||0,
      endTime: document.getElementById('flEndTime').value || null,
      banner: document.getElementById('flBanner').value
    });
    toast('Flash sale saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}

/* ── POPUPS ── */
async function loadPopups(){
  try{
    STATE.popups = await apiGet('/popups?all=1');
    if(!STATE.popups.length){ document.getElementById('popupsList').innerHTML = emptyHtml('🔔','No popups yet'); return; }
    document.getElementById('popupsList').innerHTML = `
      <table class="tbl"><thead><tr><th>Title</th><th>Type</th><th>Active</th><th>Delay</th><th></th></tr></thead>
      <tbody>${STATE.popups.map(p=>`
        <tr><td>${p.icon||''} <b>${esc(p.title||'')}</b><br><span style="font-size:11px;color:var(--muted)">${esc((p.body||'').slice(0,80))}</span></td>
        <td>${esc(p.type||'info')}</td>
        <td>${p.active?'<span class="chip chip-green">Yes</span>':'<span class="chip chip-gray">No</span>'}</td>
        <td>${p.showAfterSec||0}s</td>
        <td><button class="btn btn-ghost btn-sm" onclick="editPopup(${p.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deletePopup(${p.id})">🗑</button></td></tr>`).join('')}</tbody></table>`;
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}

/* ── Loyalty Coins ───────────────────────────────────────────────── */
async function loadCoinsPage(){
  await loadCoinsSettings();
  loadCoinsUsers();
  loadCoinsPending();
}
async function loadCoinsPending(){
  const wrap = document.getElementById('coinsPendingList');
  if(!wrap) return;
  wrap.innerHTML = '<div style="padding:20px;text-align:center;color:var(--muted)">Loading…</div>';
  try{
    const r = await fetch(apiUrl('/coins/earn-pending'),{headers:{'X-Admin-Key':ADMIN_KEY||''}}).then(r=>r.json());
    const list = r.data || r || [];
    if(!list.length){ wrap.innerHTML = emptyHtml('✅','No pending coin requests'); return; }
    wrap.innerHTML = `<table class="tbl"><thead><tr><th>Customer</th><th>Phone</th><th>Order</th><th>Amount</th><th>Coins</th><th>Date</th><th>Action</th></tr></thead>
      <tbody>${list.map(rq=>`<tr>
        <td><b>${esc(rq.user_name||'-')}</b></td>
        <td>${esc(rq.phone||'-')}</td>
        <td><b>#${esc(rq.order_id)}</b></td>
        <td>₹${rq.order_total}</td>
        <td><b style="color:#b45309">${rq.coins} 🪙</b></td>
        <td style="font-size:11px;color:var(--muted)">${new Date(rq.created_at).toLocaleString('en-IN')}</td>
        <td>
          <button class="btn btn-success btn-sm" onclick="approveEarnReq(${rq.id},'approved')">✅ Approve</button>
          <button class="btn btn-ghost btn-sm" onclick="approveEarnReq(${rq.id},'rejected')">✕ Reject</button>
        </td></tr>`).join('')}</tbody></table>`;
  }catch(e){
    wrap.innerHTML = '<div style="padding:20px;text-align:center;color:var(--muted)">Could not load: '+esc(e.message)+'</div>';
  }
}
async function approveEarnReq(id, status){
  if(!confirm(status==='approved'?'Approve coins for this customer?':'Reject this coin request?')) return;
  try{
    const r = await fetch(apiUrl('/coins/earn-approve'),{method:'POST',headers:{'Content-Type':'application/json','X-Admin-Key':ADMIN_KEY||''},body:JSON.stringify({id,status})}).then(r=>r.json());
    if(r.error) throw new Error(r.error);
    toast(status==='approved'?'✅ Coins credited!':'✕ Request rejected','ok');
    loadCoinsPending();
    loadCoinsUsers();
  }catch(e){ toast('Failed: '+e.message,'err'); }
}
window.loadCoinsPending = loadCoinsPending;
window.approveEarnReq = approveEarnReq;
async function loadCoinsSettings(){
  try{
    const r = await fetch('/api/coins/settings').then(r=>r.json());
    const c = r.data || r;
    document.getElementById('coinsEnabled').checked       = !!c.enabled;
    document.getElementById('coinsEarnPct').value         = c.earnPct ?? 5;
    document.getElementById('coinsValuePerRupee').value   = c.coinsValuePerRupee ?? 0.25;
    document.getElementById('coinsPerRupee').value        = c.coinsPerRupee ?? 1;
    document.getElementById('coinsMinRedeem').value       = c.minRedeem ?? 50;
    document.getElementById('coinsMaxRedeemAmt').value    = c.maxRedeemAmt ?? 50;
    updateCoinsExample();
  }catch(e){ toast('Coins load failed: '+e.message,'err'); }
}
async function saveCoinsSettings(){
  try{
    const body = {
      enabled:           document.getElementById('coinsEnabled').checked,
      earnPct:           parseFloat(document.getElementById('coinsEarnPct').value)||0,
      coinsValuePerRupee:parseFloat(document.getElementById('coinsValuePerRupee').value)||0.25,
      coinsPerRupee:     parseFloat(document.getElementById('coinsPerRupee').value)||1,
      minRedeem:         parseFloat(document.getElementById('coinsMinRedeem').value)||0,
      maxRedeemAmt:      parseFloat(document.getElementById('coinsMaxRedeemAmt').value)||0,
    };
    // Use http() so X-Admin-Key header is automatically added
    const j = await http('PUT', '/coins/settings', body);
    if(j.error) throw new Error(j.error);
    document.getElementById('coinsMsg').textContent = '✓ Saved at '+new Date().toLocaleTimeString();
    toast('Coins settings saved ✅','ok');
    updateCoinsExample();
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
function updateCoinsExample(){
  const earnPct  = parseFloat(document.getElementById('coinsEarnPct').value)||0;
  const valPerC  = parseFloat(document.getElementById('coinsValuePerRupee').value)||0.25;
  const perRupee = parseFloat(document.getElementById('coinsPerRupee').value)||1;
  const minR     = parseFloat(document.getElementById('coinsMinRedeem').value)||0;
  const maxAmt   = parseFloat(document.getElementById('coinsMaxRedeemAmt').value)||0;
  const sample   = 1000;
  const earnRupees = sample * earnPct / 100;
  const earnCoins  = Math.round(earnRupees * perRupee / valPerC);
  const maxRedeemCoins = maxAmt > 0 ? Math.floor(maxAmt / valPerC) : 0;
  document.getElementById('coinsExampleText').innerHTML =
    `₹${sample} order → customer earns <b>${earnCoins} coins</b> (≈ ₹${earnRupees.toFixed(2)} value). (வாடிக்கையாளருக்கு கிடைக்கும்)<br>` +
    `Up to <b>₹${maxAmt}</b> (${maxRedeemCoins} coins) redeemable per order. Min redeem: <b>${minR} coins</b>. Remaining coins carry to next orders. (மீதி coins அடுத்த ஆர்டரில்)`;
}
async function loadCoinsUsers(){
  const wrap = document.getElementById('coinsUsersList');
  wrap.innerHTML = '<div style="padding:20px;text-align:center;color:var(--muted)">Loading…</div>';
  try{
    const r = await fetch(apiUrl('/coins/users'),{headers:{'X-Admin-Key':ADMIN_KEY||''}}).then(r=>r.json());
    const users = r.data || r || [];
    if(!users.length){ wrap.innerHTML = emptyHtml('🪙','No customer balances yet'); return; }
    wrap.innerHTML = `<table class="tbl"><thead><tr><th>Customer</th><th>Phone</th><th>Balance</th><th>Earned</th><th>Redeemed</th><th>Action</th></tr></thead>
      <tbody>${users.map(u=>`<tr>
        <td><b>${esc(u.name||'-')}</b></td>
        <td>${esc(u.phone||'-')}</td>
        <td><b style="color:#b45309">${u.coins||0} 🪙</b></td>
        <td>${u.totalEarned||u.total_earned||0}</td>
        <td>${u.totalRedeemed||u.total_redeemed||0}</td>
        <td><button class="btn btn-sm" style="background:#ede9fe;color:#6d28d9;font-weight:700" onclick="adjustUserCoins(${u.id},'${esc(u.name||u.phone)}',${u.coins||0})">✏️ Adjust</button></td>
        </tr>`).join('')}</tbody></table>`;
  }catch(e){
    wrap.innerHTML = '<div style="padding:20px;text-align:center;color:var(--muted)">Could not load: '+esc(e.message)+'</div>';
  }
}

function openPopupModal(){ editPopup(null); }
function editPopup(id){
  const existing = id ? STATE.popups.find(x=>x.id===id) : null;
  const p = existing || { title:'', body:'', type:'info', icon:'🎉', ctaLabel:'', ctaUrl:'', active:true, showAfterSec:3, showOnce:true };
  openModal(existing?'Edit Popup':'New Popup',`
    <div class="grid grid-2">
      <div class="field"><label>Title</label><input id="ppTitle" value="${esc(p.title||'')}"/></div>
      <div class="field"><label>Icon</label><input id="ppIcon" value="${esc(p.icon||'🎉')}"/></div>
      <div class="field" style="grid-column:1/-1"><label>Body</label><textarea id="ppBody" rows="3">${esc(p.body||'')}</textarea></div>
      <div class="field"><label>Type</label>
        <select id="ppType">${['info','promo','discount','warning'].map(t=>`<option ${t===(p.type||'info')?'selected':''}>${t}</option>`).join('')}</select></div>
      <div class="field"><label>Show after (sec)</label><input id="ppDelay" type="number" value="${p.showAfterSec||3}"/></div>
      <div class="field"><label>CTA Label</label><input id="ppCta" value="${esc(p.ctaLabel||'')}" placeholder="Shop Now"/></div>
      <div class="field"><label>CTA URL</label><input id="ppCtaUrl" value="${esc(p.ctaUrl||'')}" placeholder="#shop"/></div>
      <div class="field"><label>Active</label><label class="switch"><input type="checkbox" id="ppActive" ${p.active?'checked':''}/><span class="slider"></span></label></div>
      <div class="field"><label>Show only once</label><label class="switch"><input type="checkbox" id="ppOnce" ${p.showOnce?'checked':''}/><span class="slider"></span></label></div>
    </div>`,
    `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
     <button class="btn btn-success" onclick="savePopup(${existing?existing.id:'null'})">💾 Save</button>`);
}
async function savePopup(existingId){
  try{
    const body = {
      title: document.getElementById('ppTitle').value.trim(),
      body: document.getElementById('ppBody').value,
      type: document.getElementById('ppType').value,
      icon: document.getElementById('ppIcon').value,
      ctaLabel: document.getElementById('ppCta').value,
      ctaUrl: document.getElementById('ppCtaUrl').value,
      active: document.getElementById('ppActive').checked,
      showAfterSec: Number(document.getElementById('ppDelay').value)||3,
      showOnce: document.getElementById('ppOnce').checked
    };
    if(existingId) body.id = existingId;
    if(!body.title){ toast('Title required','err'); return; }
    await apiPost('/popups', body);
    toast('Saved','ok'); closeModal(); loadPopups();
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
async function deletePopup(id){ if(!confirm('Delete popup?')) return;
  try{ await apiDel('/popups/'+id); toast('Deleted','ok'); loadPopups(); }
  catch(e){ toast('Delete failed: '+e.message,'err'); }
}

/* ── FILAMENT COLORS ── */
async function loadFilament(){
  try{
    const s = await apiGet('/settings').catch(()=>({}));
    STATE.settings = s || {};
    STATE.filament = Array.isArray(s?.globalColors) && s.globalColors.length ? s.globalColors : DEFAULT_FILAMENT.slice();
    renderFilament();
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
function renderFilament(){
  const html = STATE.filament.map((c,i)=>`
    <div class="color-row">
      <input type="color" value="${esc(c.hex)}" oninput="STATE.filament[${i}].hex=this.value"/>
      <input type="text" value="${esc(c.name)}" placeholder="Color name" oninput="STATE.filament[${i}].name=this.value"/>
      <button class="btn btn-danger btn-sm" onclick="STATE.filament.splice(${i},1);renderFilament()">🗑</button>
    </div>`).join('');
  document.getElementById('filamentList').innerHTML = html || '<p style="color:var(--muted)">No colors. Click + Add Color.</p>';
}
function addFilament(){ STATE.filament.push({name:'New Color', hex:'#888888'}); renderFilament(); }
function resetFilament(){ if(!confirm('Reset to default colors?')) return; STATE.filament = DEFAULT_FILAMENT.slice(); renderFilament(); }
async function saveFilament(){
  try{
    const patch = {globalColors: STATE.filament};
    await apiPost('/settings', patch);
    STATE.settings = {...STATE.settings, ...patch};
    toast('Filament colors saved — storefront will auto-update','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}

/* ── SHIPPING ── */
async function loadShipping(){
  try{
    const s = await apiGet('/settings').catch(()=>({}));
    STATE.settings = s || {};
    STATE.couriers = Array.isArray(s?.couriers) && s.couriers.length ? s.couriers : DEFAULT_COURIERS.slice();
    renderShipZones(s?.shippingZones||[]);
    renderCouriers();
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
function renderShipZones(zones){
  if(!zones.length){ zones=[{pincodes:'',charge:0,label:'',days:''}]; }
  STATE._zones = zones;
  document.getElementById('shipZones').innerHTML = zones.map((z,i)=>`
    <div class="grid grid-4" style="gap:8px;align-items:end;margin-bottom:10px;padding:10px;background:#f8fafc;border-radius:8px">
      <div class="field"><label>Pincodes</label><input value="${esc(z.pincodes||'')}" placeholder="600001-600100 or *" oninput="STATE._zones[${i}].pincodes=this.value"/></div>
      <div class="field"><label>Charge (₹)</label><input type="number" value="${z.charge||0}" oninput="STATE._zones[${i}].charge=Number(this.value)||0"/></div>
      <div class="field"><label>Label</label><input value="${esc(z.label||'')}" placeholder="Free Delivery" oninput="STATE._zones[${i}].label=this.value"/></div>
      <div style="display:flex;gap:6px;align-items:end">
        <div class="field" style="flex:1"><label>Days</label><input value="${esc(z.days||'')}" placeholder="2-3" oninput="STATE._zones[${i}].days=this.value"/></div>
        <button class="btn btn-danger btn-sm" onclick="STATE._zones.splice(${i},1);renderShipZones(STATE._zones)">🗑</button>
      </div>
    </div>`).join('');
}
function addShipZone(){ STATE._zones = STATE._zones||[]; STATE._zones.push({pincodes:'',charge:0,label:'',days:''}); renderShipZones(STATE._zones); }
async function saveShipping(){
  try{
    const patch = {shippingZones: STATE._zones||[]};
    await apiPost('/settings', patch);
    STATE.settings = {...STATE.settings, ...patch};
    toast('Shipping zones saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
function renderCouriers(){
  document.getElementById('courierList').innerHTML = STATE.couriers.map((c,i)=>`
    <div class="grid grid-3" style="gap:8px;align-items:end;margin-bottom:8px;padding:8px;background:#f8fafc;border-radius:8px">
      <div class="field"><label>Name</label><input value="${esc(c.name)}" oninput="STATE.couriers[${i}].name=this.value"/></div>
      <div class="field"><label>ID (slug)</label><input value="${esc(c.id)}" oninput="STATE.couriers[${i}].id=this.value"/></div>
      <div style="display:flex;gap:6px;align-items:end">
        <div class="field" style="flex:1"><label>Track URL prefix</label><input value="${esc(c.trackUrl||'')}" oninput="STATE.couriers[${i}].trackUrl=this.value"/></div>
        <button class="btn btn-danger btn-sm" onclick="STATE.couriers.splice(${i},1);renderCouriers()">🗑</button>
      </div>
    </div>`).join('') + `<button class="btn btn-ghost btn-sm" onclick="STATE.couriers.push({id:'new_'+Date.now(),name:'New Courier',trackUrl:''});renderCouriers()">+ Add Courier</button>`;
}
async function saveCouriers(){
  try{
    const patch = {couriers: STATE.couriers};
    await apiPost('/settings', patch);
    STATE.settings = {...STATE.settings, ...patch};
    toast('Couriers saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}

/* ── PAYMENT ── */
async function loadPayment(){
  try{
    const s = await apiGet('/settings').catch(()=>({}));
    STATE.settings = s || {};
    document.getElementById('payCod').checked = s?.codEnabled !== false;
    document.getElementById('payOnline').checked = s?.onlineEnabled !== false;
    const cf = s?.cashfree || {};
    document.getElementById('cfEnabled').checked = !!cf.enabled;
    document.getElementById('cfMode').value = cf.mode || 'sandbox';
    document.getElementById('cfAppId').value = cf.appId||'';
    document.getElementById('cfSecret').value = cf.secretKey||'';
    document.getElementById('cfReturn').value = cf.returnUrl||'';
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
async function savePaymentToggles(){
  try{
    const patch = {codEnabled: document.getElementById('payCod').checked, onlineEnabled: document.getElementById('payOnline').checked};
    await apiPost('/settings', patch); STATE.settings = {...STATE.settings, ...patch};
    toast('Payment toggles saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
async function saveCashfree(){
  try{
    const cashfree = {
      enabled: document.getElementById('cfEnabled').checked,
      mode: document.getElementById('cfMode').value,
      appId: document.getElementById('cfAppId').value.trim(),
      secretKey: document.getElementById('cfSecret').value.trim(),
      returnUrl: document.getElementById('cfReturn').value.trim()
    };
    const patch = {cashfree};
    await apiPost('/settings', patch); STATE.settings = {...STATE.settings, ...patch};
    toast('Cashfree saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}

/* ── NAVIGATION ── */
async function loadNavigation(){
  try{
    const s = await apiGet('/settings').catch(()=>({}));
    STATE.settings = s || {};
    STATE.bnav = Array.isArray(s?.bottomNavItems) && s.bottomNavItems.length ? s.bottomNavItems : DEFAULT_BNAV.slice();
    STATE.snav = Array.isArray(s?.sideNavItems) && s.sideNavItems.length ? s.sideNavItems : DEFAULT_SNAV.slice();
    renderNavLists();
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
function renderNavLists(){
  function row(items, key, i){
    const it = items[i];
    return `<div class="grid grid-4" style="gap:6px;align-items:end;margin-bottom:8px;padding:8px;background:#f8fafc;border-radius:8px">
      <div class="field"><label>Icon</label><input value="${esc(it.icon||'')}" oninput="STATE.${key}[${i}].icon=this.value"/></div>
      <div class="field"><label>Label</label><input value="${esc(it.label||'')}" oninput="STATE.${key}[${i}].label=this.value"/></div>
      <div class="field"><label>View</label><input value="${esc(it.view||'')}" oninput="STATE.${key}[${i}].view=this.value"/></div>
      <div style="display:flex;gap:6px;align-items:end">
        <label class="switch"><input type="checkbox" ${it.enabled!==false?'checked':''} oninput="STATE.${key}[${i}].enabled=this.checked"/><span class="slider"></span></label>
        <button class="btn btn-danger btn-sm" onclick="STATE.${key}.splice(${i},1);renderNavLists()">🗑</button>
      </div></div>`;
  }
  document.getElementById('bnavList').innerHTML = STATE.bnav.map((_,i)=>row(STATE.bnav,'bnav',i)).join('') +
    `<button class="btn btn-ghost btn-sm" onclick="STATE.bnav.push({id:'new_'+Date.now(),icon:'⭐',label:'New',view:'shop',enabled:true});renderNavLists()">+ Add Bottom Item</button>`;
  document.getElementById('snavList').innerHTML = STATE.snav.map((_,i)=>row(STATE.snav,'snav',i)).join('') +
    `<button class="btn btn-ghost btn-sm" onclick="STATE.snav.push({id:'new_'+Date.now(),icon:'⭐',label:'New',view:'shop',enabled:true});renderNavLists()">+ Add Side Item</button>`;
}
async function saveNavigation(){
  try{
    const patch = {bottomNavItems: STATE.bnav, sideNavItems: STATE.snav};
    await apiPost('/settings', patch); STATE.settings = {...STATE.settings, ...patch};
    toast('Navigation saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}

/* ── PAGES ── */
async function loadPages(){
  try{
    STATE.pages = await apiGet('/pages?all=1');
    if(!STATE.pages.length){ document.getElementById('pagesList').innerHTML = emptyHtml('📄','No pages yet'); return; }
    document.getElementById('pagesList').innerHTML = `
      <table class="tbl"><thead><tr><th>Title</th><th>Slug</th><th>Show in Nav</th><th></th></tr></thead>
      <tbody>${STATE.pages.map(p=>`
        <tr><td><b>${esc(p.title)}</b></td><td><code>${esc(p.slug)}</code></td>
        <td>${p.showInNav?'<span class="chip chip-green">Yes</span>':'<span class="chip chip-gray">No</span>'}</td>
        <td><button class="btn btn-ghost btn-sm" onclick="editPage('${esc(p.slug)}')">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deletePage('${esc(p.slug)}')">🗑</button></td></tr>`).join('')}</tbody></table>`;
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
function openPageModal(){ editPage(null); }
function editPage(slug){
  const p = slug ? STATE.pages.find(x=>x.slug===slug) : { slug:'', title:'', content:'', showInNav:true, sortOrder:0 };
  openModal(slug?'Edit Page':'New Page',`
    <div class="grid grid-2">
      <div class="field"><label>Title</label><input id="pgTitle" value="${esc(p.title||'')}"/></div>
      <div class="field"><label>Slug</label><input id="pgSlug" value="${esc(p.slug||'')}" placeholder="about-us" ${slug?'disabled':''}/></div>
      <div class="field"><label>Show in Nav</label><label class="switch"><input type="checkbox" id="pgNav" ${p.showInNav?'checked':''}/><span class="slider"></span></label></div>
      <div class="field"><label>Sort Order</label><input id="pgOrder" type="number" value="${p.sortOrder||0}"/></div>
      <div class="field" style="grid-column:1/-1"><label>Content (HTML allowed)</label><textarea id="pgContent" rows="8">${esc(p.content||'')}</textarea></div>
    </div>`,
    `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
     <button class="btn btn-success" onclick="savePage()">💾 Save</button>`);
}
async function savePage(){
  try{
    const body = {
      slug: document.getElementById('pgSlug').value.trim().toLowerCase().replace(/[^a-z0-9-]/g,'-'),
      title: document.getElementById('pgTitle').value.trim(),
      content: document.getElementById('pgContent').value,
      showInNav: document.getElementById('pgNav').checked,
      sortOrder: Number(document.getElementById('pgOrder').value)||0
    };
    if(!body.slug || !body.title){ toast('Slug and Title required','err'); return; }
    await apiPost('/pages', body);
    toast('Saved','ok'); closeModal(); loadPages();
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
async function deletePage(slug){ if(!confirm('Delete page?')) return;
  try{ await apiDel('/pages/'+slug); toast('Deleted','ok'); loadPages(); }
  catch(e){ toast('Delete failed: '+e.message,'err'); }
}

/* ── ABOUT ── */
async function loadAbout(){
  try{
    const s = await apiGet('/settings').catch(()=>({}));
    STATE.settings = s || {};
    const c = s?.contact || {};
    document.getElementById('abAbout').value = c.aboutText||'';
    document.getElementById('abPhone').value = c.phone||'';
    document.getElementById('abWa').value = c.whatsapp||'';
    document.getElementById('abEmail').value = c.email||'';
    document.getElementById('abHours').value = c.workingHours||'';
    document.getElementById('abAddr').value = c.address||'';
    document.getElementById('abMap').value = c.mapLink||'';
    document.getElementById('abInsta').value = c.socials?.instagram||'';
    document.getElementById('abFb').value = c.socials?.facebook||'';
    document.getElementById('abYt').value = c.socials?.youtube||'';
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
async function saveAbout(){
  try{
    const contact = {
      aboutText: document.getElementById('abAbout').value,
      phone: document.getElementById('abPhone').value,
      whatsapp: document.getElementById('abWa').value,
      email: document.getElementById('abEmail').value,
      workingHours: document.getElementById('abHours').value,
      address: document.getElementById('abAddr').value,
      mapLink: document.getElementById('abMap').value,
      socials: {
        instagram: document.getElementById('abInsta').value,
        facebook: document.getElementById('abFb').value,
        youtube: document.getElementById('abYt').value
      }
    };
    const patch = {contact};
    await apiPost('/settings', patch); STATE.settings = {...STATE.settings, ...patch};
    toast('About / Contact saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}

/* ── 3D TITLE LIVE PREVIEW ── */
function update3DPreview(){
  const enabled  = document.getElementById('th3dEnabled')?.checked;
  const front    = document.getElementById('th3dFront')?.value  || '#1e1b4b';
  const shadow   = document.getElementById('th3dShadow')?.value || '#c4b5fd';
  const glow     = document.getElementById('th3dGlow')?.value   || '#8b5cf6';
  const font     = document.getElementById('th3dFont')?.value   || 'Bungee';
  const inputEl  = document.getElementById('t3dPreviewInput');
  const storeEl  = document.getElementById('thStoreName');
  const text     = (inputEl?.value || storeEl?.value || STATE.theme?.storeName || 'MY 3D Gifts').trim() || 'MY 3D Gifts';
  const el       = document.getElementById('t3dPreviewText'); if(!el) return;
  // Load Google Font dynamically
  const fontSlug = font.replace(/ /g,'+');
  if(!document.querySelector(`link[data-gf="${fontSlug}"]`)){
    const lk = document.createElement('link');
    lk.rel='stylesheet'; lk.href=`https://fonts.googleapis.com/css2?family=${fontSlug}:wght@400;700;900&display=swap`;
    lk.dataset.gf = fontSlug; document.head.appendChild(lk);
  }
  if(enabled){
    el.style.fontFamily = `'${font}', system-ui`;
    el.style.color = front;
    el.style.textShadow = `3px 3px 0 ${shadow}, 6px 6px 0 ${shadow}88, 0 0 20px ${glow}`;
    el.style.fontWeight = '900';
  } else {
    el.style.fontFamily = 'system-ui';
    el.style.color = '#f1f5f9';
    el.style.textShadow = 'none';
    el.style.fontWeight = '700';
  }
  el.textContent = text;
}
window.update3DPreview = update3DPreview;

/* ── THEME ── */
/* v17 — Gift-themed presets */
const THEME_PRESETS = [
  { id:'royalGold',  label:'👑 Royal Gold',     primary:'#b45309', accent:'#fbbf24', bg:'#fffbeb', surface:'#fffdf5', text:'#1c1917', border:'#fde68a', font:'Bungee',           t3d:{frontColor:'#7c2d12', shadowColor:'#fcd34d', glowColor:'#f59e0b'} },
  { id:'sweetPink',  label:'🎂 Sweet Pink',     primary:'#db2777', accent:'#f9a8d4', bg:'#fdf2f8', surface:'#ffffff', text:'#831843', border:'#fbcfe8', font:'Pacifico',         t3d:{frontColor:'#831843', shadowColor:'#fbcfe8', glowColor:'#ec4899'} },
  { id:'midnightLux',label:'🌙 Midnight Luxe',  primary:'#a855f7', accent:'#facc15', bg:'#0b1020', surface:'#111827', text:'#e2e8f0', border:'#1e293b', font:'Bungee',           t3d:{frontColor:'#fef3c7', shadowColor:'#7c3aed', glowColor:'#facc15'} },
  { id:'mintFresh',  label:'🌿 Mint Fresh',     primary:'#0d9488', accent:'#fb923c', bg:'#f0fdfa', surface:'#ffffff', text:'#134e4a', border:'#99f6e4', font:'Fredoka One',      t3d:{frontColor:'#134e4a', shadowColor:'#5eead4', glowColor:'#14b8a6'} },
  { id:'sunsetPop',  label:'🌅 Sunset Pop',     primary:'#f97316', accent:'#facc15', bg:'#fff7ed', surface:'#ffffff', text:'#7c2d12', border:'#fed7aa', font:'Bangers',          t3d:{frontColor:'#7c2d12', shadowColor:'#fdba74', glowColor:'#fb923c'} },
  { id:'oceanBlue',  label:'🌊 Ocean Blue',     primary:'#0284c7', accent:'#22d3ee', bg:'#f0f9ff', surface:'#ffffff', text:'#0c4a6e', border:'#bae6fd', font:'Fredoka One',      t3d:{frontColor:'#0c4a6e', shadowColor:'#7dd3fc', glowColor:'#0ea5e9'} },
  { id:'classicRed', label:'❤️ Classic Red',    primary:'#dc2626', accent:'#fde047', bg:'#fef2f2', surface:'#ffffff', text:'#7f1d1d', border:'#fecaca', font:'Lobster',          t3d:{frontColor:'#7f1d1d', shadowColor:'#fca5a5', glowColor:'#ef4444'} },
  { id:'kidsParty',  label:'🎈 Kids Party',     primary:'#7c3aed', accent:'#22c55e', bg:'#fdf4ff', surface:'#ffffff', text:'#4c1d95', border:'#e9d5ff', font:'Permanent Marker', t3d:{frontColor:'#4c1d95', shadowColor:'#fde047', glowColor:'#22c55e'} },
  { id:'retroArcade',label:'🕹️ Retro Arcade',  primary:'#10b981', accent:'#f43f5e', bg:'#0f172a', surface:'#1e293b', text:'#f1f5f9', border:'#334155', font:'Press Start 2P',   t3d:{frontColor:'#f1f5f9', shadowColor:'#10b981', glowColor:'#f43f5e'} },
];

function renderThemePresets(){
  const box = document.getElementById('themePresetGallery'); if(!box) return;
  const cur = STATE.theme?.presetId || '';
  box.innerHTML = THEME_PRESETS.map(p => `
    <div class="theme-preset ${cur===p.id?'active':''}" onclick="applyThemePreset('${p.id}')">
      <div class="tp-cover" style="background:linear-gradient(135deg, ${p.primary}, ${p.accent})">
        <div class="tp-title" style="font-family:'${p.font}', system-ui;
            color:${p.t3d.frontColor};
            text-shadow: 3px 3px 0 ${p.t3d.shadowColor}, 0 0 14px ${p.t3d.glowColor};">
          ${esc(STATE.theme?.storeName || 'MY 3D Gifts')}
        </div>
        <div class="tp-tag">${esc(p.label)}</div>
        <div class="tp-swatches">
          <span style="background:${p.primary}"></span>
          <span style="background:${p.accent}"></span>
          <span style="background:${p.bg}"></span>
          <span style="background:${p.text}"></span>
        </div>
      </div>
      <div class="tp-meta"><b>${esc(p.label)}</b><span>${cur===p.id?'✓ Active':'Click to apply'}</span></div>
    </div>`).join('');
}

function applyThemePreset(id){
  const p = THEME_PRESETS.find(x=>x.id===id); if(!p) return;
  document.getElementById('thPrimary').value = p.primary;
  document.getElementById('thBg').value      = p.bg;
  document.getElementById('thAccent').value  = p.accent;
  document.getElementById('thText').value    = p.text;
  document.getElementById('thSurface').value = p.surface;
  document.getElementById('thBorder').value  = p.border;
  document.getElementById('th3dEnabled').checked = true;
  document.getElementById('th3dFront').value  = p.t3d.frontColor;
  document.getElementById('th3dShadow').value = p.t3d.shadowColor;
  document.getElementById('th3dGlow').value   = p.t3d.glowColor;
  document.getElementById('th3dFont').value   = p.font;
  STATE.theme = {...STATE.theme, presetId: id};
  renderThemePresets();
  update3DPreview();
  toast(`Preset "${p.label}" applied. Click 💾 Save Theme to publish.`, 'ok');
}
window.applyThemePreset = applyThemePreset;

async function loadTheme(){
  try{
    const t = await apiGet('/theme').catch(()=>({}));
    STATE.theme = t || {};
    document.getElementById('thPrimary').value = t.primary || '#6366f1';
    document.getElementById('thBg').value = t.bg || '#f8fafc';
    document.getElementById('thAccent').value = t.accent || '#f59e0b';
    document.getElementById('thText').value = t.text || '#0f172a';
    document.getElementById('thSurface').value = t.surface || '#ffffff';
    document.getElementById('thBorder').value = t.border || '#e2e8f0';
    document.getElementById('thStoreName').value = t.storeName || 'MY 3D Gifts';
    document.getElementById('thTagline').value = t.tagline || '';
    const t3 = t.title3d || {};
    document.getElementById('th3dEnabled').checked = t3.enabled !== false;
    document.getElementById('th3dFront').value  = t3.frontColor  || '#1e1b4b';
    document.getElementById('th3dShadow').value = t3.shadowColor || '#c4b5fd';
    document.getElementById('th3dGlow').value   = t3.glowColor   || '#8b5cf6';
    document.getElementById('th3dFont').value   = t3.fontFamily  || 'Bungee';
    renderThemePresets();
    update3DPreview();
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
async function saveTheme(){
  try{
    const t = {
      ...STATE.theme,
      primary: document.getElementById('thPrimary').value,
      bg: document.getElementById('thBg').value,
      accent: document.getElementById('thAccent').value,
      text: document.getElementById('thText').value,
      surface: document.getElementById('thSurface').value,
      border: document.getElementById('thBorder').value,
      storeName: document.getElementById('thStoreName').value,
      tagline: document.getElementById('thTagline').value,
      title3d: {
        enabled:    document.getElementById('th3dEnabled').checked,
        frontColor: document.getElementById('th3dFront').value,
        shadowColor:document.getElementById('th3dShadow').value,
        shadowOpacity: 0.95,
        glowColor:  document.getElementById('th3dGlow').value,
        glowOpacity: 0.45,
        fontFamily: document.getElementById('th3dFont').value
      }
    };
    await apiPost('/theme', t); STATE.theme = t;
    toast('Theme saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
function resetTheme(){
  if(!confirm('Reset theme to default?')) return;
  ['#6366f1','#f8fafc','#f59e0b','#0f172a','#ffffff','#e2e8f0'].forEach((v,i)=>{
    const ids = ['thPrimary','thBg','thAccent','thText','thSurface','thBorder'];
    document.getElementById(ids[i]).value = v;
  });
}

/* ── ACCOUNTS (v17) ── */
async function loadAccounts(){
  try{
    const from = document.getElementById('acFrom')?.value || '';
    const to   = document.getElementById('acTo')?.value   || '';
    const kind = document.getElementById('acKind')?.value || '';
    const q = [];
    if (from) q.push('from='+from);
    if (to)   q.push('to='+to);
    if (kind) q.push('kind='+kind);
    const data = await apiGet('/accounts'+(q.length?'?'+q.join('&'):''));
    const t = data.totals || {income:0,expense:0,net:0};
    const fmt = (n)=>'₹'+Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:2});
    document.getElementById('acTotIn').textContent  = fmt(t.income);
    document.getElementById('acTotEx').textContent  = fmt(t.expense);
    document.getElementById('acTotNet').textContent = fmt(t.net);
    document.getElementById('acTotNet').style.color = (t.net>=0?'#16a34a':'#dc2626');

    const monthly = data.monthly || [];
    document.getElementById('acMonthly').innerHTML = monthly.length ? `
      <table class="tbl"><thead><tr><th>Month</th><th>Income</th><th>Expense</th><th>Net</th></tr></thead>
      <tbody>${monthly.map(m=>`
        <tr><td><b>${esc(m.month)}</b></td>
        <td style="color:#16a34a">${fmt(m.income)}</td>
        <td style="color:#dc2626">${fmt(m.expense)}</td>
        <td style="font-weight:700;color:${m.net>=0?'#16a34a':'#dc2626'}">${fmt(m.net)}</td></tr>`).join('')}</tbody></table>`
      : emptyHtml('📅','No data yet. Click "Sync Orders → Ledger" or "+ New Entry".');

    const entries = data.entries || [];
    document.getElementById('acEntries').innerHTML = entries.length ? `
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap">
        <label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer">
          <input type="checkbox" id="acChkAll" onchange="toggleSelectAll('ac')" style="width:16px;height:16px"> Select All
        </label>
        <button class="btn btn-danger btn-sm" id="acBulkDel" style="display:none" onclick="bulkDeleteAccounts()">🗑 Delete Selected</button>
      </div>
      <table class="tbl"><thead><tr><th style="width:32px"></th><th>Date</th><th>Type</th><th>Category</th><th>Description</th><th>Amount</th><th></th></tr></thead>
      <tbody>${entries.map(e=>`
        <tr><td><input type="checkbox" class="ac-chk row-chk" data-id="${e.id}" onchange="updateBulkBar('ac')" style="width:16px;height:16px"></td>
        <td style="font-size:12px">${esc(e.date)}</td>
        <td>${e.kind==='income'?'<span class="chip chip-green">Income</span>':'<span class="chip chip-gray" style="background:#fee2e2;color:#991b1b">Expense</span>'}</td>
        <td>${esc(e.category||'')}</td>
        <td style="font-size:12px">${esc(e.description||'')}${e.refType?` <span style="color:var(--muted);font-size:10px">[${esc(e.refType)}${e.refId?' '+esc(e.refId):''}]</span>`:''}</td>
        <td style="font-weight:700;color:${e.kind==='income'?'#16a34a':'#dc2626'}">${fmt(e.amount)}</td>
        <td>
          ${e.refType==='manual'?`<button class="btn btn-ghost btn-sm" onclick="editAccountEntry(${e.id})">✏️</button>`:''}
          <button class="btn btn-danger btn-sm" onclick="deleteAccountEntry(${e.id})">🗑</button>
        </td></tr>`).join('')}</tbody></table>`
      : emptyHtml('📜','No entries yet.');

    window._acEntries = entries;
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
async function syncAccounts(){
  try{
    const r = await apiPost('/accounts/sync', {});
    toast(`Synced: +${r.syncedIncome||0} income, +${r.syncedExpense||0} expense`,'ok');
    loadAccounts();
  }catch(e){ toast('Sync failed: '+e.message,'err'); }
}
window.syncAccounts = syncAccounts;
function openAccountEntryModal(entry){
  const e = entry || { kind:'expense', category:'', description:'', amount:0, date:new Date().toISOString().slice(0,10) };
  openModal(entry?'Edit Entry':'+ New Account Entry', `
    <div class="grid grid-2">
      <div class="field"><label>Type</label>
        <select id="aeKind">
          <option value="expense" ${e.kind==='expense'?'selected':''}>Expense</option>
          <option value="income"  ${e.kind==='income' ?'selected':''}>Income</option>
        </select>
      </div>
      <div class="field"><label>Date</label><input type="date" id="aeDate" value="${esc(e.date||'')}"/></div>
      <div class="field"><label>Category</label>
        <input id="aeCat" value="${esc(e.category||'')}" list="aeCats" placeholder="Material / Electricity / Rent / Other Sale"/>
        <datalist id="aeCats">
          <option>Filament / Material</option><option>Electricity</option><option>Internet</option>
          <option>Rent</option><option>Salary</option><option>Packaging</option>
          <option>Marketing / Ads</option><option>Equipment</option><option>Walk-in Sale</option>
          <option>Other Income</option><option>Other Expense</option>
        </datalist></div>
      <div class="field"><label>Amount (₹)</label><input id="aeAmt" type="number" step="0.01" value="${e.amount||0}"/></div>
      <div class="field" style="grid-column:1/-1"><label>Description</label><input id="aeDesc" value="${esc(e.description||'')}" placeholder="What is this for?"/></div>
    </div>`,
    `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
     <button class="btn btn-success" onclick="saveAccountEntry(${entry?entry.id:'null'})">💾 Save</button>`);
}
window.openAccountEntryModal = openAccountEntryModal;
function editAccountEntry(id){
  const e = (window._acEntries||[]).find(x=>x.id===id); if(!e) return;
  openAccountEntryModal(e);
}
window.editAccountEntry = editAccountEntry;
async function saveAccountEntry(id){
  try{
    const body = {
      kind: document.getElementById('aeKind').value,
      date: document.getElementById('aeDate').value,
      category: document.getElementById('aeCat').value.trim(),
      amount: Number(document.getElementById('aeAmt').value)||0,
      description: document.getElementById('aeDesc').value.trim(),
      refType: 'manual'
    };
    if (id) await apiPut('/accounts/'+id, body);
    else    await apiPost('/accounts', body);
    toast('Saved','ok'); closeModal(); loadAccounts();
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
window.saveAccountEntry = saveAccountEntry;
async function deleteAccountEntry(id){
  if(!confirm('Delete this entry?')) return;
  try{ await apiDel('/accounts/'+id); toast('Deleted','ok'); loadAccounts(); }
  catch(e){ toast('Delete failed: '+e.message,'err'); }
}
window.deleteAccountEntry = deleteAccountEntry;

/* ── SETTINGS ── */
async function loadSettings(){
  try{
    const s = await apiGet('/settings').catch(()=>({}));
    STATE.settings = s || {};
    document.getElementById('setMobile').value = s?.whatsapp || s?.mobile || '';
    document.getElementById('setCurrency').value = s?.currency || '₹';
    document.getElementById('setGst').value = s?.gstPercent || 0;
    const mxUp = document.getElementById('setMaxUpload'); if(mxUp) mxUp.value = s?.maxUploadSizeMB || 2;
    document.getElementById('setSort').value = s?.defaultSort || 'admin';
    const nbd = document.getElementById('setNewBadgeDays'); if(nbd) nbd.value = s?.newBadgeDays ?? 14;
    document.getElementById('setBuyWa').checked = s?.buyNowWhatsApp !== false;
    document.getElementById('setQuickBuy').checked = s?.showQuickBuy !== false;
    document.getElementById('setView3D').checked = s?.threeDViewerEnabled !== false;
    // v15 — logo & home page selector
    const lp = document.getElementById('setLogoPreview'); if(lp) lp.src = s?.logoUrl || '';
    if(lp) lp.style.display = s?.logoUrl ? 'inline-block' : 'none';
    const hp = document.getElementById('setHomePage');
    if(hp){
      try{
        const pages = await apiGet('/pages?all=1').catch(()=>[]);
        hp.innerHTML = '<option value="">Default Shop Page</option>' +
          (pages||[]).map(pg=>`<option value="${esc(pg.slug)}" ${s?.homePage===pg.slug?'selected':''}>${esc(pg.title)} (/${esc(pg.slug)})</option>`).join('');
      }catch(e){}
    }
    // v15 — desktop bnav toggle (rendered on Navigation page if open, but stored on settings)
    const dn = document.getElementById('setDesktopBnav'); if(dn) dn.checked = !!s?.bottomNavDesktop;
    // v15 — WhatsApp UPI fields (DB may return object or JSON string)
    let wu = s?.whatsappUpi || {};
    if(typeof wu === 'string'){ try{ wu = JSON.parse(wu); }catch{ wu = {}; } }
    const wuE = document.getElementById('setWaUpiEnabled'); if(wuE) wuE.checked = !!wu.enabled;
    const wuI = document.getElementById('setWaUpiId'); if(wuI) wuI.value = wu.upiId || '';
    const wuN = document.getElementById('setWaUpiName'); if(wuN) wuN.value = wu.payeeName || '';
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
async function saveSettings(){
  try{
    const patch = {
      whatsapp: document.getElementById('setMobile').value.trim(),
      mobile: document.getElementById('setMobile').value.trim(),
      currency: document.getElementById('setCurrency').value,
      gstPercent: Number(document.getElementById('setGst').value)||0,
      maxUploadSizeMB: Number(document.getElementById('setMaxUpload')?.value)||2,
      defaultSort: document.getElementById('setSort').value,
      newBadgeDays: Number(document.getElementById('setNewBadgeDays')?.value ?? 14),
      // v15
      homePage: (document.getElementById('setHomePage')?.value||'').trim(),
      bottomNavDesktop: !!document.getElementById('setDesktopBnav')?.checked
    };
    await apiPost('/settings', patch); STATE.settings = {...STATE.settings, ...patch};
    document.getElementById('setMsg').textContent = '✓ Saved at '+new Date().toLocaleTimeString();
    toast('Settings saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}

/* ── SMTP / EMAIL FUNCTIONS ── */
async function loadSmtpSettings(){
  try{
    const s = STATE.settings || {};
    // Support flat keys (smtp_host etc.) or nested 'smtp' object
    let smtp = s.smtp || {};
    if(typeof smtp === 'string') try{ smtp = JSON.parse(smtp); }catch{}
    // Also check flat keys
    const host = smtp.host || s.smtp_host || '';
    const port = smtp.port || s.smtp_port || '465';
    const secure = smtp.secure || s.smtp_secure || 'ssl';
    const user = smtp.user || s.smtp_user || '';
    const fromEmail = smtp.fromEmail || s.smtp_from_email || user;
    const fromName = smtp.fromName || s.smtp_from_name || 'My3DGifts';
    const adminEmail = smtp.replyTo || s.admin_email || '';
    const enabled = smtp.enabled !== undefined ? smtp.enabled : (s.emailEnabled !== undefined ? s.emailEnabled : true);

    const setVal = (id, val) => { const el=document.getElementById(id); if(el) el.value=val||''; };
    const setChk = (id, val) => { const el=document.getElementById(id); if(el) el.checked=!!val; };
    setChk('smtpEnabled', enabled);
    setVal('smtpHost', host);
    setVal('smtpPort', port);
    const secEl = document.getElementById('smtpSecure');
    if(secEl) secEl.value = secure;
    setVal('smtpUser', user);
    // Don't pre-fill password for security — show placeholder
    const passEl = document.getElementById('smtpPass');
    if(passEl && smtp.pass) passEl.placeholder = '(saved — type to change)';
    setVal('smtpFromEmail', fromEmail);
    setVal('smtpFromName', fromName);
    setVal('smtpAdminEmail', adminEmail);
  }catch(e){}
}
window.loadSmtpSettings = loadSmtpSettings;

async function saveSmtpSettings(){
  try{
    const passEl = document.getElementById('smtpPass');
    let existSmtp = STATE.settings?.smtp || {};
    if(typeof existSmtp === 'string') try{ existSmtp = JSON.parse(existSmtp); }catch{ existSmtp = {}; }
    // Keep existing password if field is empty
    const newPass = passEl?.value || existSmtp?.pass || STATE.settings?.smtp_pass || '';
    const smtp = {
      enabled:   document.getElementById('smtpEnabled')?.checked,
      host:      document.getElementById('smtpHost')?.value.trim() || '',
      port:      Number(document.getElementById('smtpPort')?.value) || 465,
      secure:    document.getElementById('smtpSecure')?.value || 'ssl',
      user:      document.getElementById('smtpUser')?.value.trim() || '',
      pass:      newPass,
      fromEmail: document.getElementById('smtpFromEmail')?.value.trim() || '',
      fromName:  document.getElementById('smtpFromName')?.value.trim() || 'My3DGifts',
      replyTo:   document.getElementById('smtpAdminEmail')?.value.trim() || '',
    };
    const patch = {smtp};
    await apiPost('/settings', patch);
    STATE.settings = {...(STATE.settings||{}), ...patch};
    toast('Email settings saved ✓','ok');
    if(passEl) passEl.value = '';
    if(passEl) passEl.placeholder = '(saved — type to change)';
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
window.saveSmtpSettings = saveSmtpSettings;

async function testSmtpEmail(){
  const to = document.getElementById('smtpTestTo')?.value.trim();
  const res = document.getElementById('smtpTestResult');
  if(!to){ if(res) res.textContent='⚠️ Please provide an email address'; return; }
  if(res) res.textContent = '⏳ Sending...';
  try{
    const r = await fetch(apiUrl('/email/test'), { method:'POST', headers:{'Content-Type':'application/json','X-Admin-Key':ADMIN_KEY}, body:JSON.stringify({to}) });
    const j = await r.json();
    if(res) res.innerHTML = j.ok ? `<span style="color:#16a34a">✅ Test email sent to ${to}! Please check your inbox.</span>` : `<span style="color:#dc2626">❌ ${j.error||'Send failed'}</span>`;
  }catch(e){ if(res) res.innerHTML = `<span style="color:#dc2626">❌ ${e.message}</span>`; }
}
window.testSmtpEmail = testSmtpEmail;

/* v15 — logo upload */
async function uploadLogo(input){
  const file = input.files[0]; if(!file) return;
  const fd = new FormData(); fd.append('file', file);
  try{
    const r = await fetch(apiUrl('/upload'), { method:'POST', headers:{'X-Admin-Key':ADMIN_KEY}, body:fd });
    const j = await r.json();
    if(!j.ok) throw new Error(j.error||'Upload failed');
    const url = j.data.url;
    const patch = {logoUrl: url};
    await apiPost('/settings', patch); STATE.settings = {...STATE.settings, ...patch};
    const lp = document.getElementById('setLogoPreview'); if(lp){ lp.src = url; lp.style.display='inline-block'; }
    toast('Logo uploaded','ok');
  }catch(e){ toast('Upload failed: '+e.message,'err'); }
}
window.uploadLogo = uploadLogo;
/* v15 — Save WhatsApp UPI */
async function saveWaUpi(){
  try{
    // Always re-fetch latest settings before merging to avoid overwriting other keys
    const latest = await apiGet('/settings').catch(()=>({}));
    STATE.settings = {...(latest||{}), ...(STATE.settings||{})};
    const wu = {
      enabled: document.getElementById('setWaUpiEnabled').checked,
      upiId:    document.getElementById('setWaUpiId').value.trim(),
      payeeName:document.getElementById('setWaUpiName').value.trim()
    };
    const patch = {whatsappUpi: wu};
    await apiPost('/settings', patch);
    STATE.settings = {...STATE.settings, ...patch};
    toast('WhatsApp UPI saved ✓ UPI ID: '+(wu.upiId||'(empty)'),'ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
window.saveWaUpi = saveWaUpi;
async function saveBuyToggles(){
  try{
    const patch = {
      buyNowWhatsApp: document.getElementById('setBuyWa').checked,
      showQuickBuy: document.getElementById('setQuickBuy').checked,
      threeDViewerEnabled: document.getElementById('setView3D').checked
    };
    await apiPost('/settings', patch); STATE.settings = {...STATE.settings, ...patch};
    toast('Buy behaviour saved','ok');
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}


/* ─────────────────────────────────────────────────────────────
   v15 — MANUAL ORDER (Walk-in)
   ───────────────────────────────────────────────────────────── */
let _moItems = [];
async function openManualOrderModal(){
  if(!STATE.products.length){
    try{ STATE.products = await apiGet('/products?all=1'); }catch(e){}
  }
  _moItems = [];
  openModal('+ Add Manual Order (Walk-in)', `
    <div class="grid grid-2">
      <div class="field"><label>Customer Name *</label><input id="moName"/></div>
      <div class="field"><label>Phone *</label><input id="moPhone"/></div>
      <div class="field"><label>Email</label><input id="moEmail"/></div>
      <div class="field"><label>Pincode</label><input id="moPin"/></div>
      <div class="field" style="grid-column:1/-1"><label>Address</label><textarea id="moAddr" rows="2"></textarea></div>
    </div>
    <div class="card" style="margin-top:12px;background:#f8fafc">
      <div class="card-h"><div class="card-title">📦 Products</div>
        <button class="btn btn-primary btn-sm" onclick="moAddItem()">+ Add Product</button></div>
      <div id="moItemsList"></div>
    </div>
    <div class="grid grid-3" style="margin-top:12px">
      <div class="field"><label>Shipping (₹)</label><input id="moShip" type="number" value="0"/></div>
      <div class="field"><label>Discount (₹)</label><input id="moDisc" type="number" value="0"/></div>
      <div class="field"><label>Payment Status</label>
        <select id="moPayStatus"><option>Pending</option><option>Paid</option><option>Refunded</option></select></div>
      <div class="field"><label>Pay Method</label>
        <select id="moPayMethod"><option value="cash">Cash</option><option value="upi">UPI</option><option value="card">Card</option><option value="cod">COD</option></select></div>
      <div class="field"><label>Order Status</label>
        <select id="moStatus"><option>New</option><option>In Production</option><option>Dispatch</option><option>Shipped</option><option>Delivered</option></select></div>
      <div class="field" style="grid-column:1/-1"><label>Notes</label><input id="moNotes" placeholder="Internal notes (optional)"/></div>
    </div>
    <div style="margin-top:10px;padding:10px;background:#ecfdf5;border-radius:8px;text-align:right">
      <b>Total: ₹<span id="moTotal">0</span></b>
    </div>
  `, `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-success" onclick="saveManualOrder()">💾 Save Walk-in Order</button>`);
  renderMoItems();
}
window.openManualOrderModal = openManualOrderModal;
function renderMoItems(){
  const el = document.getElementById('moItemsList');
  if(!el) return;
  if(!_moItems.length){ el.innerHTML = '<p style="color:var(--muted);padding:10px">No items added yet.</p>'; updateMoTotal(); return; }
  const opts = STATE.products.map(p=>`<option value="${esc(p.id)}">${esc(p.name)} — ₹${p.basePrice||0}</option>`).join('');
  el.innerHTML = _moItems.map((it,i)=>`
    <div class="grid grid-4" style="gap:6px;align-items:end;margin-bottom:8px;padding:8px;background:#fff;border:1px solid var(--border);border-radius:8px">
      <div class="field" style="grid-column:1/3"><label>Product</label>
        <select onchange="moPick(${i}, this.value)"><option value="">— Select —</option>${opts}</select>
      </div>
      <div class="field"><label>Qty</label><input type="number" min="1" value="${it.quantity||1}" oninput="_moItems[${i}].quantity=Number(this.value)||1;updateMoTotal()"/></div>
      <div class="field"><label>Price (₹)</label><input type="number" value="${it.price||0}" oninput="_moItems[${i}].price=Number(this.value)||0;updateMoTotal()"/></div>
      <div style="grid-column:1/-1;display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--muted)">
        <span>${esc(it.name||'(no product)')} × ${it.quantity||1} = ₹${(Number(it.price)||0)*(Number(it.quantity)||1)}</span>
        <button class="btn btn-danger btn-sm" onclick="_moItems.splice(${i},1);renderMoItems()">🗑</button>
      </div>
    </div>`).join('');
  updateMoTotal();
}
function moAddItem(){ _moItems.push({productId:'', name:'', quantity:1, price:0}); renderMoItems(); }
function moPick(i, pid){
  const p = STATE.products.find(x=>x.id===pid);
  if(!p){ _moItems[i] = {productId:'', name:'', quantity:1, price:0}; }
  else { _moItems[i] = {productId:p.id, name:p.name, quantity:_moItems[i].quantity||1, price:p.basePrice||0, image:p.image||''}; }
  renderMoItems();
}
window.moAddItem = moAddItem; window.moPick = moPick;
function updateMoTotal(){
  const sub = _moItems.reduce((s,i)=>s+(Number(i.price)||0)*(Number(i.quantity)||1),0);
  const ship = Number(document.getElementById('moShip')?.value||0);
  const disc = Number(document.getElementById('moDisc')?.value||0);
  const total = Math.max(0, sub + ship - disc);
  const el = document.getElementById('moTotal'); if(el) el.textContent = total.toLocaleString('en-IN');
}
['moShip','moDisc'].forEach(id=>{
  document.addEventListener('input', e=>{ if(e.target?.id===id) updateMoTotal(); });
});
async function saveManualOrder(){
  const name = document.getElementById('moName').value.trim();
  const phone = document.getElementById('moPhone').value.trim();
  if(!name || !phone){ toast('Name + phone required','err'); return; }
  if(!_moItems.length){ toast('Add at least one product','err'); return; }
  const sub = _moItems.reduce((s,i)=>s+(Number(i.price)||0)*(Number(i.quantity)||1),0);
  const ship = Number(document.getElementById('moShip').value||0);
  const disc = Number(document.getElementById('moDisc').value||0);
  const payload = {
    name, phone,
    email: document.getElementById('moEmail').value.trim(),
    addr:  document.getElementById('moAddr').value.trim(),
    pin:   document.getElementById('moPin').value.trim(),
    items: _moItems.filter(i=>i.productId),
    total: Math.max(0, sub + ship - disc),
    shipping: ship, discount: disc,
    payMethod: document.getElementById('moPayMethod').value,
    paymentStatus: document.getElementById('moPayStatus').value,
    status: document.getElementById('moStatus').value,
    notes: document.getElementById('moNotes').value,
    source: 'walkin'
  };
  try{
    await apiPost('/orders', payload);
    toast('Walk-in order saved','ok'); closeModal(); loadOrders();
  }catch(e){ toast('Save failed: '+e.message,'err'); }
}
window.saveManualOrder = saveManualOrder;

/* ─────────────────────────────────────────────────────────────
   v15 — MEDIA LIBRARY
   ───────────────────────────────────────────────────────────── */
/* ── MEDIA PICKER (for product image selection) ── */
async function openMediaPickerFor(targetId, mode) {
  window._mediaPickerState = { targetId, mode, selected: [] };
  // Ensure media is loaded
  if (!STATE.media || !STATE.media.length) {
    try { STATE.media = await apiGet('/media').catch(()=>[]); } catch(e){ STATE.media = []; }
  }
  const items = STATE.media || [];
  const gridHtml = items.length
    ? items.map(m => `
        <div class="media-pick-item"
          style="border:2px solid transparent;border-radius:10px;overflow:hidden;cursor:pointer;background:#f8fafc;transition:all .15s;position:relative"
          onclick="pickMediaItem('${esc(m.url)}','${targetId}','${mode}',this)"
          onmouseover="this.style.borderColor='var(--primary)'" onmouseout="if(!this.classList.contains('picked'))this.style.borderColor='transparent'">
          <img  loading="lazy" decoding="async"src="${esc(imgUrl(m.url))}" style="width:100%;height:80px;object-fit:cover;display:block"/>
          <div style="font-size:10px;padding:3px 5px;color:#64748b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc((m.filename||m.url.split('/').pop()).substring(0,22))}</div>
        </div>`)
      .join('')
    : `<div style="grid-column:1/-1;text-align:center;color:#94a3b8;padding:30px">
        Library is empty.<br>
        <button class="btn btn-primary btn-sm" style="margin-top:10px" onclick="document.getElementById('mediaUpload')?.click()">📤 Upload Images</button>
      </div>`;

  openModal('🖼️ Media Library — Select Image',
    `<div style="margin-bottom:8px;font-size:12px;color:#64748b">${mode==='multi'?'You can select multiple images — click Done':'Select one image'}</div>
     <div id="mediaPickGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(90px,1fr));gap:8px;max-height:380px;overflow-y:auto;padding:4px">${gridHtml}</div>
     <div id="mediaPickStatus" style="font-size:12px;color:#6366f1;margin-top:8px;min-height:18px"></div>`,
    mode==='multi'
      ? `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="applyPickedMediaMulti()">✅ Done</button>`
      : `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>`
  );
}
window.openMediaPickerFor = openMediaPickerFor;

function pickMediaItem(url, targetId, mode, el) {
  // Keep relative /uploads/... URLs as-is so they work on all devices.
  // Only keep absolute URL if it's genuinely external (different domain).
  function normalizePickedUrl(u) {
    if (!u) return u;
    // Always normalize to relative /uploads/... so it works on every device & domain.
    try { return (typeof imgUrl === 'function') ? imgUrl(u) : u; } catch(e){ return u; }
  }
  const useUrl = normalizePickedUrl(url);
  if (mode === 'single') {
    // Target input is in the STACKED product edit modal (not current media picker).
    // So: show status → closeModal (restores product edit) → then set input value.
    document.getElementById('mediaPickStatus').textContent = '✅ Image selected!';
    setTimeout(() => {
      closeModal(); // restores product edit modal from stack
      // Product edit modal now visible — set the input value
      const inp = document.getElementById(targetId);
      if (inp) {
        inp.value = useUrl;
        inp.dispatchEvent(new Event('input'));
      }
      if (typeof renderPImagePreview === 'function') try { renderPImagePreview(); } catch(e) {}
      if (typeof renderPImagesPreview === 'function') try { renderPImagesPreview(); } catch(e) {}
    }, 250);
  } else {
    const state = window._mediaPickerState || { selected: [] };
    state.selected = Array.isArray(state.selected) ? state.selected : [];
    if (!state.selected.includes(useUrl)) {
      state.selected.push(useUrl);
    } else {
      state.selected = state.selected.filter(x => x !== useUrl);
    }
    window._mediaPickerState = state;
    const isPicked = state.selected.includes(useUrl);
    el.classList.toggle('picked', isPicked); el.style.borderColor = isPicked ? '#22c55e' : 'transparent';
    document.getElementById('mediaPickStatus').textContent = `✅ ${state.selected.length} image(s) selected`;
  }
}
window.pickMediaItem = pickMediaItem;

function applyPickedMediaMulti(){
  const state = window._mediaPickerState || {};
  const picked = Array.isArray(state.selected) ? state.selected : [];
  closeModal();
  setTimeout(()=>{
    const ta = document.getElementById(state.targetId || 'pImages');
    if(!ta) return;
    const lines = ta.value.trim() ? ta.value.split('\n').map(s=>s.trim()).filter(Boolean) : [];
    picked.forEach(u=>{ if(!lines.includes(u)) lines.push(u); });
    ta.value = lines.join('\n');
    ta.dispatchEvent(new Event('input'));
    if(typeof renderPImagesPreview === 'function') renderPImagesPreview();
  }, 30);
}
window.applyPickedMediaMulti = applyPickedMediaMulti;

// ── v32: Media library with folders + bulk + broken detector + thumb-aware
window._mediaSel = new Set();
async function loadMedia(){
  try{
    const items = await apiGet('/media').catch(()=>[]);
    STATE.media = items || [];
    // Rebuild folder filter
    const folders = [...new Set(STATE.media.map(m=>m.folder||'general'))].sort();
    const sel = document.getElementById('mediaFolderFilter');
    if (sel) {
      const cur = sel.value;
      sel.innerHTML = `<option value="">All folders (${STATE.media.length})</option>` +
        folders.map(f=>{ const c = STATE.media.filter(m=>(m.folder||'general')===f).length; return `<option value="${esc(f)}" ${cur===f?'selected':''}>📁 ${esc(f)} (${c})</option>`; }).join('');
    }
    window._mediaSel.clear();
    renderMediaGrid();
  }catch(e){ toast('Load failed: '+e.message,'err'); }
}
window.loadMedia = loadMedia;

function renderMediaGrid(){
  const grid = document.getElementById('mediaGrid'); if(!grid) return;
  const folder = (document.getElementById('mediaFolderFilter')?.value)||'';
  const q = ((document.getElementById('mediaSearch')?.value)||'').toLowerCase().trim();
  let list = STATE.media || [];
  if (folder) list = list.filter(m => (m.folder||'general')===folder);
  if (q) list = list.filter(m => ((m.name||'')+(m.url||'')).toLowerCase().includes(q));
  if(!list.length){
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:var(--muted);padding:30px">No images match. Upload some or change filter.</div>`;
    updateMediaSelInfo(); return;
  }
  grid.innerHTML = list.map(m=>{
    const sel = window._mediaSel.has(m.id);
    const display = m.thumb ? imgUrl(m.thumb) : imgUrl(m.url);
    return `<div data-id="${m.id}" style="border:2px solid ${sel?'#22c55e':'var(--border)'};border-radius:8px;overflow:hidden;background:#fff;position:relative">
      <label style="position:absolute;top:4px;left:4px;background:#fff;border-radius:4px;padding:2px 4px;z-index:2;cursor:pointer">
        <input type="checkbox" ${sel?'checked':''} onchange="toggleMediaSel(${m.id})"/>
      </label>
      <span style="position:absolute;top:4px;right:4px;background:rgba(0,0,0,.55);color:#fff;font-size:10px;padding:1px 5px;border-radius:8px;z-index:2">📁 ${esc(m.folder||'general')}</span>
      <img src="${esc(display)}" loading="lazy" decoding="async" style="width:100%;height:120px;object-fit:cover;cursor:pointer" onclick="copyMediaUrl('${esc(m.url)}')" title="Click to copy URL" onerror="this.style.opacity=.25;this.title='Broken'"/>
      <div style="padding:6px;font-size:11px;display:flex;justify-content:space-between;align-items:center;gap:4px">
        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1" title="${esc(m.name||'')}">${esc(m.name||m.url.split('/').pop())}</span>
        <button class="btn btn-danger btn-sm" style="padding:2px 6px" onclick="deleteMedia(${m.id})">🗑</button>
      </div>
    </div>`;
  }).join('');
  updateMediaSelInfo();
}
window.renderMediaGrid = renderMediaGrid;

function toggleMediaSel(id){
  if(window._mediaSel.has(id)) window._mediaSel.delete(id); else window._mediaSel.add(id);
  renderMediaGrid();
}
window.toggleMediaSel = toggleMediaSel;

function toggleSelectAllMedia(){
  const folder = (document.getElementById('mediaFolderFilter')?.value)||'';
  const q = ((document.getElementById('mediaSearch')?.value)||'').toLowerCase().trim();
  let list = STATE.media || [];
  if (folder) list = list.filter(m => (m.folder||'general')===folder);
  if (q) list = list.filter(m => ((m.name||'')+(m.url||'')).toLowerCase().includes(q));
  const allSel = list.every(m => window._mediaSel.has(m.id));
  if (allSel) list.forEach(m=>window._mediaSel.delete(m.id));
  else list.forEach(m=>window._mediaSel.add(m.id));
  renderMediaGrid();
}
window.toggleSelectAllMedia = toggleSelectAllMedia;

function updateMediaSelInfo(){
  const n = window._mediaSel.size;
  const info = document.getElementById('mediaSelInfo'); if (info) info.textContent = n ? `${n} selected` : '';
  ['mediaBulkDel','mediaBulkMove','mediaBulkDownload'].forEach(id=>{ const el=document.getElementById(id); if(el) el.style.display = n?'inline-flex':'none'; });
}

function filteredMediaList(){
  const folder = (document.getElementById('mediaFolderFilter')?.value)||'';
  const q = ((document.getElementById('mediaSearch')?.value)||'').toLowerCase().trim();
  let list = STATE.media || [];
  if (folder) list = list.filter(m => (m.folder||'general')===folder);
  if (q) list = list.filter(m => ((m.name||'')+(m.url||'')).toLowerCase().includes(q));
  return list;
}

function safeMediaFilename(item, index){
  const base = (item.name || (item.url||'').split('/').pop() || `media-${index+1}`).replace(/[\\/:*?"<>|]+/g,'-').trim();
  return base || `media-${index+1}`;
}

async function bulkDownloadMedia(scope){
  const list = scope === 'selected'
    ? (STATE.media||[]).filter(m => window._mediaSel.has(m.id))
    : filteredMediaList();
  if(!list.length){ toast('No media selected to download','err'); return; }
  if(!window.JSZip){
    toast('ZIP tool not loaded; downloading files one by one','err');
    list.forEach((m,i)=>setTimeout(()=>{
      const a=document.createElement('a');
      a.href = imgUrl(m.url); a.download = safeMediaFilename(m,i);
      document.body.appendChild(a); a.click(); a.remove();
    }, i*250));
    return;
  }
  const zip = new JSZip();
  let ok = 0, fail = 0;
  const lbl = document.getElementById('mediaProgressLabel');
  const cnt = document.getElementById('mediaProgressCount');
  const bar = document.getElementById('mediaProgressBar');
  const prog = document.getElementById('mediaProgress');
  if(prog){ prog.style.display='block'; if(bar) bar.style.width='0%'; if(lbl) lbl.textContent='Preparing ZIP…'; if(cnt) cnt.textContent=`0 / ${list.length}`; }
  for(let i=0;i<list.length;i++){
    const m = list[i];
    try{
      const res = await fetch(imgUrl(m.url), {cache:'no-store'});
      if(!res.ok) throw new Error('HTTP '+res.status);
      zip.file(safeMediaFilename(m, i), await res.blob());
      ok++;
    }catch(e){ fail++; }
    if(prog){ if(bar) bar.style.width = Math.round((i+1)*100/list.length)+'%'; if(cnt) cnt.textContent = `${i+1} / ${list.length}`; }
  }
  if(!ok){ toast('Download failed — no files could be read','err'); if(prog) setTimeout(()=>prog.style.display='none', 1200); return; }
  if(lbl) lbl.textContent = 'Creating ZIP…';
  const blob = await zip.generateAsync({type:'blob'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `my3dgifts_media_${scope}_${new Date().toISOString().slice(0,10)}.zip`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 5000);
  if(prog) setTimeout(()=>prog.style.display='none', 1500);
  toast(`Downloaded ${ok} file(s)` + (fail ? `, ${fail} skipped` : ''), fail?'err':'ok');
}
window.bulkDownloadMedia = bulkDownloadMedia;

async function bulkDeleteMedia(){
  const ids = [...window._mediaSel]; if(!ids.length) return;
  if(!confirm(`Delete ${ids.length} image(s)? This removes files from disk too.`)) return;
  try{ await apiPost('/media/bulk-delete', {ids}); toast(`Deleted ${ids.length}`,'ok'); loadMedia(); }
  catch(e){ toast('Bulk delete failed: '+e.message,'err'); }
}
window.bulkDeleteMedia = bulkDeleteMedia;

async function bulkMoveMedia(){
  const ids = [...window._mediaSel]; if(!ids.length) return;
  const folder = prompt('Move selected images to folder (letters, numbers, _ -, max 40 chars):', 'products');
  if(!folder) return;
  if(!/^[a-zA-Z0-9_-]{1,40}$/.test(folder)){ toast('Bad folder name','err'); return; }
  try{ await apiPost('/media/bulk-move', {ids, folder}); toast(`Moved ${ids.length} → 📁 ${folder}`,'ok'); loadMedia(); }
  catch(e){ toast('Bulk move failed: '+e.message,'err'); }
}
window.bulkMoveMedia = bulkMoveMedia;

async function detectBrokenImages(){
  toast('Scanning images…','ok');
  const urls = new Set();
  (STATE.media||[]).forEach(m=>{ if(m.url) urls.add(m.url); });
  (STATE.products||[]).forEach(p=>{
    if(p.image) urls.add(p.image);
    (p.images||[]).forEach(u=>u && urls.add(u));
  });
  const broken = [];
  const arr = [...urls];
  let idx = 0; const CONC = 6;
  async function worker(){
    while(idx < arr.length){
      const u = arr[idx++];
      const abs = u.startsWith('http') ? u : (location.origin + (u.startsWith('/')?'':'/') + u);
      try{
        const r = await fetch(abs, {method:'HEAD'});
        if(!r.ok) broken.push({url:u, status:r.status});
      }catch(e){ broken.push({url:u, status:'err'}); }
    }
  }
  await Promise.all(Array.from({length:CONC}, worker));
  if(!broken.length){ toast(`✅ All ${arr.length} images load OK`,'ok'); return; }
  openModal('🔍 Broken Images Detector',
    `<div style="font-size:13px;margin-bottom:8px"><b>${broken.length}</b> broken of <b>${arr.length}</b> total images.</div>
     <div style="max-height:60vh;overflow:auto;border:1px solid #e2e8f0;border-radius:8px">
       <table class="tbl" style="width:100%;font-size:12px">
         <thead><tr><th>URL</th><th>Status</th></tr></thead>
         <tbody>${broken.map(b=>`<tr><td style="word-break:break-all">${esc(b.url)}</td><td>${b.status}</td></tr>`).join('')}</tbody>
       </table></div>`,
    `<button class="btn btn-ghost" onclick="closeModal()">Close</button>`);
}
window.detectBrokenImages = detectBrokenImages;

async function downloadBackup(){
  const m = document.getElementById('backupMsg'); if(m) m.textContent = 'Preparing backup… (may take a moment)';
  try{
    const r = await fetch(apiUrl('/backup'), {headers:{'X-Admin-Key':ADMIN_KEY}});
    if(!r.ok) throw new Error('HTTP '+r.status);
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = `my3dgifts_backup_${new Date().toISOString().slice(0,10)}.zip`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 5000);
    if(m) m.textContent = '✅ Downloaded';
    toast('Backup downloaded','ok');
  }catch(e){ if(m) m.textContent = '❌ Failed: '+e.message; toast('Backup failed: '+e.message,'err'); }
}
window.downloadBackup = downloadBackup;

async function uploadMedia(files){
  files = files ? Array.from(files).filter(f => f && f.type && f.type.startsWith('image/')) : [];
  if(!files.length){ toast('No image files selected','err'); return; }
  const total = files.length;
  let done = 0, ok = 0, fail = 0;
  const prog = document.getElementById('mediaProgress');
  const bar  = document.getElementById('mediaProgressBar');
  const cnt  = document.getElementById('mediaProgressCount');
  const lbl  = document.getElementById('mediaProgressLabel');
  if(prog){ prog.style.display='block'; bar.style.width='0%'; cnt.textContent=`0 / ${total}`; lbl.textContent='Uploading…'; }
  // Upload 3 in parallel to keep server happy
  const CONC = 3;
  let idx = 0;
  async function worker(){
    while(idx < files.length){
      const f = files[idx++];
      const fd = new FormData(); fd.append('file', f);
      try{
        const r = await fetch(apiUrl('/upload'), { method:'POST', headers:{'X-Admin-Key':ADMIN_KEY}, body:fd });
        const j = await r.json();
        if(j && j.ok) ok++; else fail++;
      }catch{ fail++; }
      done++;
      if(prog){ bar.style.width = Math.round(done*100/total)+'%'; cnt.textContent = `${done} / ${total}`; }
    }
  }
  await Promise.all(Array.from({length: Math.min(CONC, files.length)}, worker));
  if(prog){ lbl.textContent = fail ? `Done — ${ok} uploaded, ${fail} failed` : `✅ All ${ok} uploaded`; setTimeout(()=>{ prog.style.display='none'; }, 1800); }
  toast(`Uploaded ${ok} file(s)`+(fail?`, ${fail} failed`:''), fail?'err':'ok');
  const input = document.getElementById('mediaUpload'); if(input) input.value='';
  loadMedia();
}
window.uploadMedia = uploadMedia;
async function deleteMedia(id){
  if(!confirm('Delete this image from library?')) return;
  try{ await apiDel('/media/'+id); toast('Deleted','ok'); loadMedia(); }
  catch(e){ toast('Delete failed: '+e.message,'err'); }
}
window.deleteMedia = deleteMedia;
function copyMediaUrl(url){
  // Resolve to absolute URL
  const abs = url.startsWith('http') ? url : (location.origin + (url.startsWith('/')?'':'/') + url);
  navigator.clipboard?.writeText(abs).then(
    ()=> toast('Image URL copied: '+abs.slice(0,60),'ok'),
    ()=> { prompt('Copy URL:', abs); }
  );
}

window.imageValue = imageValue;
window.imageArrayValues = imageArrayValues;
window.copyMediaUrl = copyMediaUrl;

/* ── Modal (Stack support — nested modals work without closing parent) ── */
const _modalStack = [];

function snapshotModalHtml(el){
  const clone = el.cloneNode(true);
  clone.querySelectorAll('input, textarea, select').forEach((node, i)=>{
    const live = el.querySelectorAll('input, textarea, select')[i];
    if(!live) return;
    if(live.tagName === 'TEXTAREA') node.textContent = live.value;
    else if(live.tagName === 'SELECT') {
      Array.from(node.options).forEach((opt, idx)=>{ opt.selected = live.options[idx]?.selected || false; });
    } else if(live.type === 'checkbox' || live.type === 'radio') {
      if(live.checked) node.setAttribute('checked','checked'); else node.removeAttribute('checked');
    } else {
      node.setAttribute('value', live.value);
    }
  });
  return clone.innerHTML;
}

function openModal(title, body, footer){
  const mc = document.getElementById('modalContent');
  // Save current modal if one is already open (push to stack)
  if(document.getElementById('modalBg').classList.contains('show') && mc.innerHTML.trim()){
    _modalStack.push(snapshotModalHtml(mc));
  }
  mc.innerHTML = `
    <div class="modal-h"><h3>${title}</h3><button class="icon-x" onclick="closeModal()">×</button></div>
    <div class="modal-b">${body}</div>
    <div class="modal-f">${footer}</div>`;
  document.getElementById('modalBg').classList.add('show');
}

function closeModal(){
  if(_modalStack.length){
    // Pop and restore previous modal (e.g. product edit after media picker)
    document.getElementById('modalContent').innerHTML = _modalStack.pop();
    document.getElementById('modalBg').classList.add('show');
    // Re-fire input events so previews refresh
    document.querySelectorAll('#modalContent input,#modalContent textarea').forEach(el=>{
      try{ el.dispatchEvent(new Event('input')); } catch(e){}
    });
    // Explicitly re-render product image previews if product edit modal was restored
    if(typeof renderPImagePreview === 'function') try{ renderPImagePreview(); }catch(e){}
    if(typeof renderPImagesPreview === 'function') try{ renderPImagesPreview(); }catch(e){}
  } else {
    document.getElementById('modalBg').classList.remove('show');
  }
}

function closeAllModals(){
  _modalStack.length = 0;
  document.getElementById('modalBg').classList.remove('show');
}

// v36: only close on true backdrop click. If user drags text inside an input
// and releases outside, the click's target may bubble as modalBg — that
// previously wiped an unsaved New Product form. Require mousedown AND mouseup
// to both start on the backdrop.
(function(){
  const bg = document.getElementById('modalBg');
  let downOnBg = false;
  bg.addEventListener('mousedown', e=>{ downOnBg = (e.target.id==='modalBg'); });
  bg.addEventListener('mouseup',   e=>{
    if(downOnBg && e.target.id==='modalBg') closeModal();
    downOnBg = false;
  });
  // Also guard: any drag that started inside content must not close on release
  bg.addEventListener('click', e=>{ /* no-op — handled by mousedown/mouseup */ });
})();

/* ── Utilities ── */
function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function productSlugify(s){
  return String(s||'').toLowerCase().trim()
    .replace(/&/g,' and ')
    .replace(/[^a-z0-9]+/g,'-')
    .replace(/^-+|-+$/g,'')
    .slice(0,40) || 'product';
}
function uniqueProductSlug(slug, currentId){
  const base = productSlugify(slug);
  let out = base, i = 2;
  const exists = x => String(x.id||'') !== String(currentId||'') && String(x.id||'') === out;
  while((STATE.products||[]).some(exists)) out = `${base.slice(0,36)}-${i++}`;
  return out;
}
function syncProductSlugFromName(){
  const slug = document.getElementById('pSlug');
  if(!slug || slug.readOnly || slug.dataset.touched === '1') return;
  slug.value = productSlugify(document.getElementById('pName')?.value || '');
  const prev = document.getElementById('pSlugPreview'); if(prev) prev.textContent = slug.value || 'product-name';
}
window.productSlugify = productSlugify;
window.syncProductSlugFromName = syncProductSlugFromName;
function fmtDate(d){ if(!d) return ''; const dt = new Date(String(d).replace(' ','T')); if(isNaN(dt)) return esc(d); return dt.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})+' '+dt.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}); }
function statusChip(s){ const m={'New':'chip-green','In Production':'chip-blue','Dispatch':'chip-amber','Shipped':'chip-blue','Delivered':'chip-green','Cancelled':'chip-red'}; return `<span class="chip ${m[s]||'chip-gray'}">${esc(s||'New')}</span>`; }
function emptyHtml(icon,msg){ return `<div class="empty"><div class="em-icon">${icon}</div>${msg}</div>`; }

/* ── Boot ── */
document.getElementById('logUrl').value = location.origin;
if(ADMIN_KEY){
  document.getElementById('userName').textContent = ADMIN_USER;
  apiGet('/orders').then(()=>{
    document.getElementById('loginOverlay').style.display='none';
    document.getElementById('app').style.display='flex';
    loadDashboard();
  }).catch(()=>{
    localStorage.removeItem('adminApiKey');
  });
}

/* ============================================================
   v16 — IMAGE UPLOAD + CUSTOM OPTIONS (UNLIMITED)
   ============================================================ */

async function adminUploadImage(input, targetId){
  const f = input.files && input.files[0];
  if (!f) return;
  toast('Uploading...');
  try{
    const fd = new FormData();
    fd.append('file', f);
    const r = await fetch(apiUrl('/upload'), { method:'POST', headers:{ 'X-Admin-Key': ADMIN_KEY }, body: fd });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error||'Upload failed');
    const t = document.getElementById(targetId);
    if (t) t.value = j.data.url;
    const prev = document.getElementById(targetId+'Prev');
    if (prev) prev.innerHTML = `<img  loading="lazy" decoding="async"src="${j.data.url}" style="max-height:80px;border-radius:6px;border:1px solid #e2e8f0"/>`;
    toast('✅ Uploaded','ok');
  }catch(e){ toast('Upload failed: '+e.message,'err'); }
  finally { input.value=''; }
}
window.adminUploadImage = adminUploadImage;

async function adminUploadMulti(input, targetId){
  const files = Array.from(input.files||[]);
  if (!files.length) return;
  toast(`Uploading ${files.length} file(s)...`);
  const ta = document.getElementById(targetId);
  let added = 0, failed = 0;
  for (const f of files){
    try{
      const fd = new FormData();
      fd.append('file', f);
      const r = await fetch(apiUrl('/upload'), { method:'POST', headers:{ 'X-Admin-Key': ADMIN_KEY }, body: fd });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error||'fail');
      const cur = ta.value.trim();
      ta.value = (cur ? cur + '\n' : '') + j.data.url;
      added++;
    }catch(e){ failed++; console.warn(e); }
  }
  input.value = '';
  toast(`✅ ${added} uploaded${failed?` · ${failed} failed`:''}`, failed?'err':'ok');
}
window.adminUploadMulti = adminUploadMulti;

/* ============================================================
   v17 — Image Crop (Cropper.js) + Upload-with-Crop helpers
   ============================================================ */
let _cropper = null;
let _cropTargetInputId = null;
function openCropModal(src, targetInputId){
  _cropTargetInputId = targetInputId;
  const bg = document.getElementById('cropModalBg');
  const img = document.getElementById('cropImg');
  img.src = src;
  bg.classList.add('show');
  setTimeout(()=>{
    if (_cropper) { try{_cropper.destroy();}catch(e){} _cropper=null; }
    if (typeof Cropper === 'undefined') { toast('Cropper still loading…','err'); return; }
    _cropper = new Cropper(img, { aspectRatio: 1, viewMode:1, autoCropArea:0.9, background:false, movable:true, zoomable:true });
  }, 60);
}
window.openCropModal = openCropModal;
function closeCropModal(){
  if (_cropper) { try{_cropper.destroy();}catch(e){} _cropper=null; }
  document.getElementById('cropModalBg').classList.remove('show');
}
window.closeCropModal = closeCropModal;
function setCropRatio(r){
  if (!_cropper) return;
  document.querySelectorAll('.crop-modal .ratios button').forEach(b=>b.classList.remove('active'));
  if (event && event.target) event.target.classList.add('active');
  _cropper.setAspectRatio(r);
}
window.setCropRatio = setCropRatio;
async function confirmCrop(){
  if (!_cropper || !_cropTargetInputId) { closeCropModal(); return; }
  try{
    const canvas = _cropper.getCroppedCanvas({ maxWidth: 1600, maxHeight: 1600, fillColor:'#ffffff' });
    const blob = await new Promise(res => canvas.toBlob(res, 'image/jpeg', 0.92));
    if (!blob) throw new Error('Crop failed');
    const fd = new FormData();
    fd.append('file', new File([blob], 'crop_'+Date.now()+'.jpg', {type:'image/jpeg'}));
    toast('Uploading cropped image…');
    const r = await fetch(apiUrl('/upload'), { method:'POST', headers:{'X-Admin-Key':ADMIN_KEY}, body: fd });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error||'Upload failed');
    const t = document.getElementById(_cropTargetInputId);
    if (t) { t.value = j.data.url; t.dispatchEvent(new Event('input')); }
    toast('✅ Cropped & uploaded','ok');
    closeCropModal();
  }catch(e){ toast('Crop failed: '+e.message,'err'); }
}
window.confirmCrop = confirmCrop;

// Upload that opens crop modal first (used by Main Image upload button)
async function adminUploadImageWithCrop(input, targetId){
  const f = input.files && input.files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = (ev)=> openCropModal(ev.target.result, targetId);
  reader.readAsDataURL(f);
  input.value = '';
}
window.adminUploadImageWithCrop = adminUploadImageWithCrop;

// Crop an image already pasted as URL (downloads, then opens cropper)
async function cropExistingImage(targetId){
  const url = (document.getElementById(targetId)?.value||'').trim();
  if (!url) { toast('No image URL','err'); return; }
  openCropModal(url, targetId);
}
window.cropExistingImage = cropExistingImage;

/* ── Custom Options (Unlimited) editor ── */
window.adminDynOptsDraft = window.adminDynOptsDraft || [];
const ADM_DYN_TYPES = ['text','textarea','number','dropdown','radio','color','checkbox','file'];

function adminAddDynOpt(){
  window.adminDynOptsDraft.push({
    id: 'opt'+Date.now()+Math.floor(Math.random()*1000),
    type: 'text', label: 'New Option', required: false,
    extra: 0, perChar: 0, perUnit: 0, maxChars: 50, placeholder: '',
    accept: 'image/*', values: [],
    // checkbox trigger: when checked, show these option IDs
    triggerShowIds: [],
    // text sync: pair this text input with another option ID for equal-length validation
    syncWithId: '', syncEnabled: false
  });
  adminRenderDynOpts();
}
window.adminAddDynOpt = adminAddDynOpt;

function adminRemoveDynOpt(i){
  if (!confirm('Remove this option?')) return;
  window.adminDynOptsDraft.splice(i,1);
  adminRenderDynOpts();
}
window.adminRemoveDynOpt = adminRemoveDynOpt;

function adminMoveDynOpt(i, dir){
  const a = window.adminDynOptsDraft;
  const j = i+dir;
  if (j<0||j>=a.length) return;
  [a[i],a[j]] = [a[j],a[i]];
  adminRenderDynOpts();
}
window.adminMoveDynOpt = adminMoveDynOpt;

function adminUpdateDynOpt(i, key, val){
  if (!window.adminDynOptsDraft[i]) return;
  if (['extra','perChar','perUnit','maxChars'].includes(key)) val = Number(val)||0;
  if (key==='required') val = !!val;
  if (key==='syncEnabled') val = !!val;
  window.adminDynOptsDraft[i][key] = val;
  if (key==='type') adminRenderDynOpts();
}
window.adminUpdateDynOpt = adminUpdateDynOpt;

function adminUpdateDynValues(i, txt){
  if (!window.adminDynOptsDraft[i]) return;
  // preserve existing imageUrl per value
  const existing = window.adminDynOptsDraft[i].values || [];
  window.adminDynOptsDraft[i].values = (txt||'').split('\n').map(l=>l.trim()).filter(Boolean).map((l,vi)=>{
    const [label, extra] = l.split(',').map(x=>x.trim());
    const prev = existing[vi] || {};
    return { label: label||'Option', extra: Number(extra)||0, imageUrl: prev.imageUrl||'' };
  });
}
window.adminUpdateDynValues = adminUpdateDynValues;

// Upload image for a specific option value in admin-app
window.adminUploadDynValImg = (i, vi, inp) => {
  const f = inp.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = e => {
    if (!window.adminDynOptsDraft[i] || !window.adminDynOptsDraft[i].values[vi]) return;
    window.adminDynOptsDraft[i].values[vi].imageUrl = e.target.result;
    const img = document.getElementById('adminValImg_'+i+'_'+vi);
    if (img) { img.src = e.target.result; img.style.display='block'; }
    const rmBtn = document.getElementById('adminValImgRm_'+i+'_'+vi);
    if (rmBtn) rmBtn.style.display='inline-block';
  };
  r.readAsDataURL(f);
};
window.adminRemoveDynValImg = (i, vi) => {
  if (!window.adminDynOptsDraft[i] || !window.adminDynOptsDraft[i].values[vi]) return;
  window.adminDynOptsDraft[i].values[vi].imageUrl = '';
  const img = document.getElementById('adminValImg_'+i+'_'+vi);
  if (img) { img.src=''; img.style.display='none'; }
  const rmBtn = document.getElementById('adminValImgRm_'+i+'_'+vi);
  if (rmBtn) rmBtn.style.display='none';
};
window.adminAddDynValue = (i) => {
  if (!window.adminDynOptsDraft[i]) return;
  window.adminDynOptsDraft[i].values = window.adminDynOptsDraft[i].values || [];
  window.adminDynOptsDraft[i].values.push({label:'New Value', extra:0, imageUrl:''});
  adminRenderDynOpts();
};
window.adminRemoveDynValue = (i, vi) => {
  if (!window.adminDynOptsDraft[i]) return;
  window.adminDynOptsDraft[i].values.splice(vi,1);
  adminRenderDynOpts();
};
window.adminUpdateDynValueField = (i, vi, field, val) => {
  if (!window.adminDynOptsDraft[i] || !window.adminDynOptsDraft[i].values[vi]) return;
  if (field==='extra') val = Number(val)||0;
  window.adminDynOptsDraft[i].values[vi][field] = val;
};

function adminRenderDynOpts(){
  const wrap = document.getElementById('adminDynOptsList');
  if (!wrap) return;
  // v36 autosave draft on every render (every mutation triggers a render)
  try{ if(window._autosaveDynOpts){ const pid = document.getElementById('pSlug')?.value || 'new'; window._autosaveDynOpts(pid); } }catch(e){}
  const list = window.adminDynOptsDraft || [];
  if (!list.length){
    wrap.innerHTML = '<p class="hint" style="padding:12px;text-align:center;background:#fff;border-radius:6px;">No custom options yet. Click "+ Add Option" to start.</p>';
    return;
  }

  wrap.innerHTML = list.map((o,i)=>{
    const needsValues = ['dropdown','radio'].includes(o.type);
    const isCharType  = ['text','textarea'].includes(o.type);
    const isNumber    = o.type==='number';
    const isFile      = o.type==='file';
    const isCheckbox  = o.type==='checkbox';
    const otherOpts   = list.filter((_,j)=>j!==i);
    const triggerIds  = o.triggerShowIds||[];

    // --- CHECKBOX TRIGGER SECTION ---
    const triggerSection = isCheckbox && otherOpts.length ? `
      <div style="margin-top:8px;background:#fef3c7;border:1px solid #f59e0b;border-radius:8px;padding:10px;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
          <span style="font-size:13px;">&#x26A1;</span>
          <b style="font-size:12px;color:#92400e;">Show these options when ticked (இதை டிக் செய்தால் காட்டு):</b>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;max-height:160px;overflow-y:auto;">
          ${otherOpts.map(opt=>`
            <label style="display:flex;align-items:center;gap:6px;font-size:12px;padding:3px 6px;border-radius:5px;background:#fffbeb;cursor:pointer;">
              <input type="checkbox" ${triggerIds.includes(opt.id)?'checked':''}
                onchange="adminToggleTriggerOpt(${i},'${opt.id}',this.checked)"
                style="width:14px;height:14px;accent-color:#f59e0b;"/>
              <span style="background:#fff;border:1px solid #86efac;border-radius:4px;padding:2px 7px;">${(opt.label||opt.id).replace(/</g,'&lt;')}</span>
              <span style="color:#94a3b8;font-size:10px;">[${opt.type}]</span>
            </label>`).join('')}
        </div>
        ${triggerIds.length?`<div style="margin-top:6px;font-size:11px;background:#f0fdf4;border-radius:4px;padding:5px 8px;color:#166534;border:1px solid #86efac;">
          &#x2705; ${triggerIds.length} option(s) will show when this checkbox is ticked; hidden otherwise.
        </div>`:'<div style="margin-top:4px;font-size:11px;color:#a16207;">No options linked yet — check above to show them conditionally.</div>'}
      </div>` : (isCheckbox ? `
      <div style="margin-top:6px;font-size:11px;color:#94a3b8;background:#f8fafc;border-radius:6px;padding:6px 8px;">
        &#x26A1; Add more options to configure show/hide triggers from this checkbox.
      </div>` : '');

    // --- TEXT SYNC SECTION ---
    const textSyncOpts = isCharType ? list.filter((_,j)=>j!==i && ['text','textarea'].includes(_.type)) : [];
    const syncSection = isCharType ? (textSyncOpts.length ? `
      <div style="margin-top:8px;background:#fefce8;border:1px solid #fde68a;border-radius:8px;padding:10px;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap;">
          <span style="font-size:13px;">&#x1F517;</span>
          <b style="font-size:12px;color:#92400e;">Text Length Match / Sync (சரிசம எழுத்துக்கள்)</b>
          <label style="display:flex;align-items:center;gap:5px;margin-left:auto;cursor:pointer;">
            <span style="font-size:11px;color:#64748b;">Enable:</span>
            <label class="switch" style="transform:scale(0.8);display:inline-flex;">
              <input type="checkbox" ${o.syncEnabled?'checked':''}
                onchange="adminUpdateDynOpt(${i},'syncEnabled',this.checked);adminRenderDynOpts();"
              /><span class="slider"></span>
            </label>
          </label>
        </div>
        ${o.syncEnabled ? `
          <select onchange="adminUpdateDynOpt(${i},'syncWithId',this.value)" style="width:100%;padding:5px;border:1px solid #fbbf24;border-radius:6px;margin-bottom:6px;">
            <option value="">-- Select paired text option --</option>
            ${textSyncOpts.map(opt=>`<option value="${opt.id}" ${o.syncWithId===opt.id?'selected':''}>${(opt.label||opt.id).replace(/</g,'&lt;')}</option>`).join('')}
          </select>
          <div style="background:#fff;border:1px solid #fbbf24;border-radius:6px;padding:8px;font-size:11px;color:#78350f;line-height:1.7;">
            <b>Rule:</b> Both inputs must have equal character count.<br>
            If unequal &#x2192; <b>&#x2665;</b> fills the shorter one automatically.<br>
            <b>Customer warning:</b> "Both text fields must have the same character count, otherwise &#x2665; will be used to pad." (இரண்டு டெக்ஸ்ட்டிலும் சரிசம எழுத்துக்கள்; இல்லையேல் &#x2665; பயன்படும்)<br>
            <i>If they ignore: &#x2665; symbol will be auto-filled to match length.</i>
          </div>` : `<p style="font-size:11px;color:#a16207;margin:4px 0 0 0;">Enable sync to pair with another text field for equal-length validation.</p>`}
      </div>` : `
      <div style="margin-top:6px;font-size:11px;color:#94a3b8;background:#f8fafc;border-radius:6px;padding:6px 8px;">
        &#x1F517; Add at least one more text/textarea option to enable sync pairing.
      </div>`) : '';

    const borderColor = isCheckbox ? '#f59e0b' : (isCharType && o.syncEnabled ? '#10b981' : '#6366f1');

    return `
    <div style="background:#fff;border:1px solid #bae6fd;border-left:4px solid ${borderColor};border-radius:8px;padding:10px;">
      <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;">
        <span style="background:#eef2ff;color:#4338ca;font-weight:700;font-size:12px;padding:4px 8px;border-radius:6px;">#${i+1}</span>
        ${isCheckbox?'<span title="Triggers show/hide" style="font-size:14px;">&#x2611;&#xFE0F;</span>':''}
        ${isCharType&&o.syncEnabled?'<span title="Text sync ON" style="font-size:14px;">&#x1F517;</span>':''}
        <input type="text" value="${(o.label||'').replace(/"/g,'&quot;')}" placeholder="Option label (e.g. Engraving Name)"
          oninput="adminUpdateDynOpt(${i},'label',this.value)" style="flex:1;padding:6px 8px;border:1px solid #e2e8f0;border-radius:6px;"/>
        <button class="btn btn-ghost btn-sm" onclick="adminMoveDynOpt(${i},-1)" title="Up">&#x2191;</button>
        <button class="btn btn-ghost btn-sm" onclick="adminMoveDynOpt(${i},1)" title="Down">&#x2193;</button>
        <button class="btn btn-danger btn-sm" onclick="adminRemoveDynOpt(${i})" title="Remove">&#x2715;</button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;">
        <div><label style="font-size:11px;color:#64748b;">Type</label>
          <select onchange="adminUpdateDynOpt(${i},'type',this.value)" style="width:100%;padding:5px;border:1px solid #e2e8f0;border-radius:6px;">
            ${ADM_DYN_TYPES.map(t=>`<option value="${t}" ${o.type===t?'selected':''}>${t}</option>`).join('')}
          </select>
        </div>
        <div><label style="font-size:11px;color:#64748b;">Required</label>
          <select onchange="adminUpdateDynOpt(${i},'required',this.value==='yes')" style="width:100%;padding:5px;border:1px solid #e2e8f0;border-radius:6px;">
            <option value="no" ${!o.required?'selected':''}>No</option>
            <option value="yes" ${o.required?'selected':''}>Yes</option>
          </select>
        </div>
        <div><label style="font-size:11px;color:#64748b;">Flat extra (&#x20B9;)</label>
          <input type="number" value="${Number(o.extra)||0}" oninput="adminUpdateDynOpt(${i},'extra',this.value)" style="width:100%;padding:5px;border:1px solid #e2e8f0;border-radius:6px;"/>
        </div>
        <div><label style="font-size:11px;color:#64748b;">${isCharType?'Per char (&#x20B9;)':isNumber?'Per unit (&#x20B9;)':'(unused)'}</label>
          <input type="number" value="${Number(isNumber?o.perUnit:o.perChar)||0}"
            oninput="adminUpdateDynOpt(${i},'${isNumber?'perUnit':'perChar'}',this.value)"
            ${(!isCharType && !isNumber)?'disabled':''}
            style="width:100%;padding:5px;border:1px solid #e2e8f0;border-radius:6px;"/>
        </div>
      </div>
      ${isCharType?`<div style="margin-top:6px"><label style="font-size:11px;color:#64748b;">Placeholder</label>
         <input type="text" value="${(o.placeholder||'').replace(/"/g,'&quot;')}" oninput="adminUpdateDynOpt(${i},'placeholder',this.value)" style="width:100%;padding:5px;border:1px solid #e2e8f0;border-radius:6px;"/>
        </div>`:''}
      ${isCharType?`<div style="margin-top:6px"><label style="font-size:11px;color:#64748b;">Max chars</label>
         <input type="number" value="${Number(o.maxChars)||50}" oninput="adminUpdateDynOpt(${i},'maxChars',this.value)" style="width:100%;padding:5px;border:1px solid #e2e8f0;border-radius:6px;"/>
        </div>`:''}
      ${isFile?`<div style="margin-top:6px"><label style="font-size:11px;color:#64748b;">Accept (file types)</label>
         <input type="text" value="${(o.accept||'image/*').replace(/"/g,'&quot;')}" oninput="adminUpdateDynOpt(${i},'accept',this.value)" placeholder="image/*  or  .pdf,.png" style="width:100%;padding:5px;border:1px solid #e2e8f0;border-radius:6px;"/>
        </div>`:''}
      ${needsValues?`<div style="margin-top:8px;border-top:1px solid #e2e8f0;padding-top:8px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
          <label style="font-size:11px;font-weight:700;color:#4c1d95;">🧩 Values (${(o.values||[]).length})</label>
          <button type="button" onclick="adminAddDynValue(${i})" style="background:#7c3aed;color:#fff;border:none;border-radius:5px;padding:3px 10px;font-size:11px;cursor:pointer;">+ Add</button>
        </div>
        ${(o.values||[]).length===0?'<p style="font-size:11px;color:#94a3b8;text-align:center;padding:6px;">No values yet. Click + Add</p>':''}
        ${(o.values||[]).map((v,vi)=>`
          <div style="background:#f8f7ff;border:1px solid #ddd6fe;border-radius:8px;padding:7px 8px;margin-bottom:6px;">
            <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
              <input value="${(v.label||'').replace(/"/g,'&quot;')}" oninput="adminUpdateDynValueField(${i},${vi},'label',this.value)" placeholder="Label" style="flex:2;min-width:80px;padding:4px 6px;border:1px solid #e2e8f0;border-radius:5px;font-size:12px;"/>
              <input type="number" value="${Number(v.extra)||0}" oninput="adminUpdateDynValueField(${i},${vi},'extra',this.value)" placeholder="Extra ₹" style="width:70px;padding:4px 6px;border:1px solid #e2e8f0;border-radius:5px;font-size:12px;"/>
              <button type="button" onclick="adminRemoveDynValue(${i},${vi})" style="background:#fee2e2;color:#b91c1c;border:none;border-radius:5px;padding:4px 8px;font-size:11px;cursor:pointer;">✕</button>
            </div>
            <div style="margin-top:6px;display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
              <span style="font-size:11px;color:#7c3aed;font-weight:600;white-space:nowrap;">🖼️ Image:</span>
              ${v.imageUrl?`<img  loading="lazy" decoding="async"id="adminValImg_${i}_${vi}" src="${v.imageUrl}" style="height:44px;width:44px;object-fit:cover;border-radius:6px;border:2px solid #7c3aed;"/>`:
                           `<img  loading="lazy" decoding="async"id="adminValImg_${i}_${vi}" src="" style="display:none;height:44px;width:44px;object-fit:cover;border-radius:6px;border:2px solid #7c3aed;"/>`}
              <label style="background:#ede9fe;color:#5b21b6;border:none;border-radius:5px;padding:4px 8px;font-size:11px;cursor:pointer;white-space:nowrap;">📤 Upload<input type="file" accept="image/*" onchange="adminUploadDynValImg(${i},${vi},this)" style="display:none;"/></label>
              <input value="${(v.imageUrl||'').replace(/"/g,'&quot;')}" oninput="adminUpdateDynValueField(${i},${vi},'imageUrl',this.value);(function(el,ii,vii){const img=document.getElementById('adminValImg_'+ii+'_'+vii);const rmb=document.getElementById('adminValImgRm_'+ii+'_'+vii);if(img){img.src=el.value;img.style.display=el.value?'block':'none';}if(rmb)rmb.style.display=el.value?'inline-block':'none';})(this,${i},${vi})" placeholder="or paste URL (URL ஒட்டவும்)" style="flex:2;min-width:90px;padding:4px 6px;border:1px solid #e2e8f0;border-radius:5px;font-size:11px;"/>
              <button id="adminValImgRm_${i}_${vi}" type="button" onclick="adminRemoveDynValImg(${i},${vi})" style="display:${v.imageUrl?'inline-block':'none'};background:#fee2e2;color:#b91c1c;border:none;border-radius:5px;padding:3px 7px;font-size:11px;cursor:pointer;">🗑️</button>
            </div>
          </div>
        `).join('')}
       </div>`:''}
      ${o.type==='color'?`<div style="margin-top:6px;font-size:11px;color:#64748b;">Color values come from <b>Filament Colors</b> library. The "Flat extra" above is added per color choice.</div>`:''}
      ${triggerSection}
      ${syncSection}
    </div>`;
  }).join('');
}
window.adminRenderDynOpts = adminRenderDynOpts;

function adminToggleTriggerOpt(i, optId, checked){
  const o = window.adminDynOptsDraft[i];
  if (!o) return;
  if (!o.triggerShowIds) o.triggerShowIds = [];
  if (checked){
    if (!o.triggerShowIds.includes(optId)) o.triggerShowIds.push(optId);
  } else {
    o.triggerShowIds = o.triggerShowIds.filter(id=>id!==optId);
  }
  adminRenderDynOpts();
}
window.adminToggleTriggerOpt = adminToggleTriggerOpt;

// ══════════════════════════════════════════════

