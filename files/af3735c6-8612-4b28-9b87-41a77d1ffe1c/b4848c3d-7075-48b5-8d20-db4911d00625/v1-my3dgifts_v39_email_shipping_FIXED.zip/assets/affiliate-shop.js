/* assets/affiliate-shop.js
 * Adds an "🔗 Affiliate" tab to the shop product-type carousel.
 * Affiliate products are kept OUT of All/Customize/Readymade/Others tabs
 * (the existing shop reads from window.products, which we never touch).
 * Selecting the Affiliate tab loads /api/affiliate and renders cards into
 * the shop grid; clicking a card hits /api/affiliate/click/{id} for
 * tracking and then opens the affiliate URL in a new tab.
 *
 * Also exposes window.renderAffiliateHome(targetEl) so the home page can
 * optionally show featured affiliate products (only those with showOnHome).
 */
(function(){
  'use strict';
  const SRC_LABEL = {amazon:'Amazon', flipkart:'Flipkart', meesho:'Meesho', other:'Shop'};
  const SRC_BADGE = {amazon:'#ff9900', flipkart:'#2874f0', meesho:'#f43397', other:'#64748b'};
  const esc = (s)=> String(s??'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  let cache = null;
  let cacheAt = 0;
  async function getAffiliate(force){
    const now = Date.now();
    if (!force && cache && now - cacheAt < 60_000) return cache;
    try {
      const r = await fetch('/api/affiliate');
      const j = await r.json();
      cache = (j && j.ok) ? (j.data||[]) : [];
    } catch(e){ cache = []; }
    cacheAt = now;
    return cache;
  }

  async function trackAndOpen(id){
    // Open synchronously to avoid popup blockers, then update href after track
    const w = window.open('about:blank', '_blank');
    try {
      const r = await fetch('/api/affiliate/click/'+encodeURIComponent(id), {method:'POST'});
      const j = await r.json();
      const url = (j && j.ok && j.data && j.data.url) ? j.data.url : null;
      if (w && url) w.location.href = url;
      else if (w) w.close();
    } catch(e){ if (w) w.close(); }
  }
  window.affiliateClick = trackAndOpen;

  function cardHTML(p){
    return `
      <div class="aff-shop-card" data-aff="${esc(p.id)}" style="background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:10px;cursor:pointer;display:flex;flex-direction:column;gap:8px;transition:transform .15s, box-shadow .15s;position:relative" onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,.08)'" onmouseout="this.style.transform='';this.style.boxShadow=''">
        <span style="position:absolute;top:8px;left:8px;background:${SRC_BADGE[p.source]||'#64748b'};color:#fff;font-size:10px;font-weight:700;padding:3px 8px;border-radius:99px;text-transform:uppercase;letter-spacing:.4px;z-index:2">${esc(SRC_LABEL[p.source]||p.source)}</span>
        <span style="position:absolute;top:8px;right:8px;background:#0f172a;color:#fff;font-size:10px;font-weight:600;padding:3px 8px;border-radius:99px;z-index:2">↗ Affiliate</span>
        <img src="${esc(p.image||'https://placehold.co/400x300?text=Product')}" alt="${esc(p.title)}" style="width:100%;aspect-ratio:1/1;object-fit:cover;border-radius:10px;background:#f1f5f9" onerror="this.src='https://placehold.co/400x300?text=Product'"/>
        <div style="font-size:13px;font-weight:600;line-height:1.3;min-height:34px;color:#0f172a">${esc(p.title)}</div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          ${p.price>0 ? `<div style="font-weight:800;color:#0f172a">₹ ${Number(p.price).toFixed(0)}</div>` : '<div></div>'}
          <button style="background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border:0;padding:6px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer">Buy Now ↗</button>
        </div>
      </div>`;
  }

  function wireGrid(root){
    root.querySelectorAll('.aff-shop-card').forEach(c=>{
      c.addEventListener('click', ()=> trackAndOpen(c.dataset.aff));
    });
  }

  // ---------- Inject the "Affiliate" tab into the shop carousel ----------
  function injectTab(){
    const carousel = document.getElementById('ptypeCarousel');
    if (!carousel || carousel.querySelector('[data-ptype="affiliate"]')) return false;
    const btn = document.createElement('button');
    btn.className = 'ptype-tab';
    btn.dataset.ptype = 'affiliate';
    btn.type = 'button';
    btn.innerHTML = '🔗 Affiliate';
    btn.addEventListener('click', ()=> selectAffiliate());
    carousel.appendChild(btn);
    return true;
  }

  async function selectAffiliate(){
    document.querySelectorAll('.ptype-tab').forEach(b=>b.classList.toggle('active', b.dataset.ptype==='affiliate'));
    window.currentProductType = 'affiliate'; // sentinel so getSortedProducts gives 0 in case
    const list = await getAffiliate(true);
    renderAffiliateGrid(list);
  }

  function findShopGrid(){
    return document.getElementById('productGrid')
        || document.getElementById('shopGrid')
        || document.querySelector('[data-shop-grid]')
        || document.querySelector('#shop .grid, #shop-grid');
  }

  function renderAffiliateGrid(list){
    const grid = findShopGrid();
    if (!grid) return;
    // Clear and inject affiliate-only layout
    grid.innerHTML = '';
    grid.style.display = 'grid';
    grid.style.gridTemplateColumns = 'repeat(auto-fill,minmax(160px,1fr))';
    grid.style.gap = '12px';
    if (!list.length){
      grid.innerHTML = '<div style="grid-column:1/-1;padding:40px;text-align:center;color:#64748b">No affiliate products yet.</div>';
      return;
    }
    grid.innerHTML = list.map(cardHTML).join('');
    wireGrid(grid);
  }

  // Patch setProductType so switching AWAY from affiliate re-runs the normal renderShop
  function patchSetProductType(){
    const orig = window.setProductType;
    if (!orig || orig.__affPatched) return;
    window.setProductType = function(t){
      if (t === 'affiliate') return selectAffiliate();
      try { orig.call(this, t); } catch(e){ console.error(e); }
    };
    window.setProductType.__affPatched = true;
  }

  // Optional: home page injection
  window.renderAffiliateHome = async function(targetEl){
    if (!targetEl) return;
    const list = (await getAffiliate(false)).filter(p=>p.showOnHome);
    if (!list.length){ targetEl.innerHTML=''; return; }
    targetEl.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin:18px 0 10px">
        <h2 style="font-size:18px;font-weight:800;margin:0;color:#0f172a">🔗 Featured Picks</h2>
        <button onclick="setProductType('affiliate');document.getElementById('shop')?.scrollIntoView({behavior:'smooth'})" style="background:none;border:0;color:#6366f1;font-weight:600;font-size:13px;cursor:pointer">View all →</button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px">${list.slice(0,6).map(cardHTML).join('')}</div>`;
    wireGrid(targetEl);
  };

  function boot(){
    const ok = injectTab();
    if (!ok) { setTimeout(boot, 500); return; }
    patchSetProductType();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
