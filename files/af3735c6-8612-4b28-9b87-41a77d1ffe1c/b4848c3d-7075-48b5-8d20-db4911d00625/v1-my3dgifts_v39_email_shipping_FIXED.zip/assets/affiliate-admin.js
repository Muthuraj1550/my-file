/* assets/affiliate-admin.js
 * Adds an "🔗 Affiliate" section to the admin app — sidebar link, list/CRUD
 * page, and an analytics panel. Uses the existing admin auth (X-Admin-Key
 * header) provided by window.apiGet/apiPost/apiPut/apiDel helpers, but
 * falls back to fetch() if those aren't exposed.
 */
(function(){
  'use strict';
  const ADMIN_KEY_LS = 'admin_secret'; // best-effort; many admin apps keep it here

  function getAdminKey(){
    return window.ADMIN_KEY
        || window.ADMIN_SECRET
        || localStorage.getItem('adminApiKey')
        || localStorage.getItem('admin_key')
        || localStorage.getItem(ADMIN_KEY_LS)
        || sessionStorage.getItem('adminApiKey')
        || sessionStorage.getItem('admin_key')
        || '';
  }
  async function api(path, opts={}){
    const headers = Object.assign({'Content-Type':'application/json','X-Admin-Key':getAdminKey()}, opts.headers||{});
    const r = await fetch('/api'+path, Object.assign({}, opts, {headers}));
    const j = await r.json().catch(()=>({ok:false,error:'bad json'}));
    if (!j.ok) throw new Error(j.error||('HTTP '+r.status));
    return j.data;
  }
  const $ = (s, root=document) => root.querySelector(s);
  const esc = (s)=> String(s??'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const SRC_LABEL = {amazon:'Amazon', flipkart:'Flipkart', meesho:'Meesho', other:'Other'};
  const SRC_BADGE = {amazon:'#ff9900', flipkart:'#2874f0', meesho:'#f43397', other:'#64748b'};

  // ---------- Inject sidebar link + page section ----------
  function inject(){
    const sidebar = document.querySelector('aside.sidebar') || document.getElementById('sidebar');
    if (!sidebar) return false;
    if (document.querySelector('[data-page="affiliate"]')) return true; // already injected

    // Add sidebar link right after Analytics
    const analyticsLink = sidebar.querySelector('[data-page="analytics"]');
    const link = document.createElement('a');
    link.className = 'nav-link';
    link.dataset.page = 'affiliate';
    link.innerHTML = '<span class="ico">🔗</span> Affiliate';
    (analyticsLink ? analyticsLink.parentNode.insertBefore(link, analyticsLink.nextSibling) : sidebar.appendChild(link));

    // Add page section
    const main = document.querySelector('.content, main, #mainContent') || document.body;
    const sec = document.createElement('section');
    sec.className = 'page';
    sec.id = 'page-affiliate';
    sec.innerHTML = `
      <style>
        #page-affiliate .aff-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;margin-top:14px}
        #page-affiliate .aff-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:12px;display:flex;flex-direction:column;gap:8px;position:relative}
        #page-affiliate .aff-card img{width:100%;height:140px;object-fit:cover;border-radius:8px;background:#f1f5f9}
        #page-affiliate .aff-card .badge{position:absolute;top:8px;left:8px;color:#fff;font-size:10px;font-weight:700;padding:3px 8px;border-radius:99px;text-transform:uppercase;letter-spacing:.4px}
        #page-affiliate .aff-stat{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#475569}
        #page-affiliate .aff-row{display:flex;gap:6px}
        #page-affiliate .aff-row button{flex:1;padding:6px 8px;font-size:12px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;cursor:pointer}
        #page-affiliate .aff-row button.danger{background:#fee2e2;border-color:#fca5a5;color:#b91c1c}
        #page-affiliate .aff-toolbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:8px}
        #page-affiliate .aff-toolbar input,#page-affiliate .aff-toolbar select{padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px}
        #page-affiliate .aff-toolbar button.primary{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border:0;padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer}
        #affModal{position:fixed;inset:0;background:rgba(15,23,42,.55);display:none;align-items:center;justify-content:center;z-index:9999;padding:16px}
        #affModal.open{display:flex}
        #affModal .box{background:#fff;border-radius:14px;width:100%;max-width:520px;padding:20px;max-height:90vh;overflow:auto}
        #affModal h3{margin:0 0 12px;font-size:18px;font-weight:700}
        #affModal label{display:block;margin:10px 0 4px;font-size:12px;font-weight:600;color:#334155}
        #affModal input,#affModal select{width:100%;padding:9px 11px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px}
        #affModal .actions{display:flex;gap:8px;justify-content:flex-end;margin-top:16px}
        #affModal .actions button{padding:9px 16px;border-radius:8px;font-weight:600;cursor:pointer;border:1px solid #cbd5e1;background:#fff}
        #affModal .actions button.primary{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border:0}
        #page-affiliate .aff-analytics{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:14px 0}
        #page-affiliate .aff-stat-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:14px}
        #page-affiliate .aff-stat-card .n{font-size:26px;font-weight:800;color:#0f172a}
        #page-affiliate .aff-stat-card .l{font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;margin-top:4px}
        #page-affiliate .aff-bar{display:flex;align-items:center;gap:8px;margin:6px 0;font-size:12px}
        #page-affiliate .aff-bar .track{flex:1;background:#f1f5f9;border-radius:4px;height:10px;overflow:hidden}
        #page-affiliate .aff-bar .fill{height:100%}
        #page-affiliate h3.aff-h{font-size:14px;font-weight:700;color:#0f172a;margin:18px 0 8px}
      </style>
      <div class="aff-toolbar">
        <input id="affSearch" placeholder="Search affiliate products…" />
        <select id="affFilterSource">
          <option value="">All sources</option>
          <option value="amazon">Amazon</option>
          <option value="flipkart">Flipkart</option>
          <option value="meesho">Meesho</option>
          <option value="other">Other</option>
        </select>
        <button class="primary" id="affAddBtn">+ Add Affiliate Product</button>
        <button id="affReloadBtn">Reload</button>
      </div>

      <div class="aff-analytics" id="affAnalyticsTop"></div>
      <h3 class="aff-h">📈 Clicks by Source</h3>
      <div id="affBySource"></div>
      <h3 class="aff-h">🏆 Top Performing</h3>
      <div id="affTopList"></div>
      <h3 class="aff-h">🛍️ All Affiliate Products</h3>
      <div id="affGrid" class="aff-grid"></div>

      <div id="affModal"><div class="box">
        <h3 id="affModalTitle">Add Affiliate Product</h3>
        <input type="hidden" id="affId" />
        <label>Title *</label><input id="affTitle" required />
        <label>Source *</label>
        <select id="affSource">
          <option value="amazon">Amazon</option>
          <option value="flipkart">Flipkart</option>
          <option value="meesho">Meesho</option>
          <option value="other">Other</option>
        </select>
        <label>Affiliate URL *</label><input id="affUrl" placeholder="https://www.amazon.in/dp/..." />
        <label>Image URL</label><input id="affImage" placeholder="https://… (optional)" />
        <label>Price (₹)</label><input id="affPrice" type="number" step="0.01" min="0" value="0" />
        <label>Sort Order</label><input id="affSort" type="number" value="999" />
        <label style="display:flex;align-items:center;gap:8px;margin-top:14px"><input type="checkbox" id="affActive" checked style="width:auto" /> Active (visible on shop)</label>
        <label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="affHome" style="width:auto" /> Show on Home page</label>
        <div class="actions">
          <button id="affCancel">Cancel</button>
          <button class="primary" id="affSave">Save</button>
        </div>
      </div></div>
    `;
    main.appendChild(sec);

    // PAGE_TITLES + PAGE_LOADERS hookup (best effort)
    try { if (window.PAGE_TITLES) window.PAGE_TITLES.affiliate = '🔗 Affiliate Products'; } catch(e){}
    try { if (window.PAGE_LOADERS) window.PAGE_LOADERS.affiliate = loadAffiliate; } catch(e){}

    // Click handler — emulate goPage behavior if it doesn't auto-pick up
    link.addEventListener('click', (e)=>{
      e.preventDefault();
      if (typeof window.goPage === 'function') window.goPage('affiliate');
      else {
        document.querySelectorAll('.nav-link').forEach(a=>a.classList.toggle('active', a===link));
        document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active', p.id==='page-affiliate'));
        const t = document.getElementById('pageTitle'); if (t) t.textContent = '🔗 Affiliate Products';
        loadAffiliate();
      }
    });

    wireForm();
    return true;
  }

  // ---------- Data + Render ----------
  let _all = [];
  async function loadAffiliate(){
    try {
      const [list, stats] = await Promise.all([
        api('/affiliate?all=1'),
        api('/affiliate/analytics'),
      ]);
      _all = list || [];
      renderList();
      renderAnalytics(stats);
    } catch (e) {
      console.error('affiliate load failed', e);
      const g = document.getElementById('affGrid');
      if (g) g.innerHTML = `<div style="grid-column:1/-1;padding:20px;color:#b91c1c">Failed to load: ${esc(e.message)}</div>`;
    }
  }

  function renderList(){
    const grid = document.getElementById('affGrid');
    if (!grid) return;
    const q = ($('#affSearch')?.value||'').toLowerCase().trim();
    const src = $('#affFilterSource')?.value||'';
    const filtered = _all.filter(p =>
      (!src || p.source===src) &&
      (!q || (p.title||'').toLowerCase().includes(q))
    );
    if (!filtered.length){
      grid.innerHTML = `<div style="grid-column:1/-1;padding:30px;text-align:center;color:#64748b;background:#fff;border:1px dashed #cbd5e1;border-radius:12px">No affiliate products. Click "+ Add Affiliate Product" to create one.</div>`;
      return;
    }
    grid.innerHTML = filtered.map(p => `
      <div class="aff-card">
        <span class="badge" style="background:${SRC_BADGE[p.source]||'#64748b'}">${SRC_LABEL[p.source]||p.source}</span>
        <img src="${esc(p.image||'https://placehold.co/400x300?text=No+Image')}" alt="${esc(p.title)}" onerror="this.src='https://placehold.co/400x300?text=No+Image'"/>
        <div style="font-weight:600;font-size:13px;line-height:1.3;min-height:34px">${esc(p.title)}</div>
        <div class="aff-stat"><span>₹ ${Number(p.price||0).toFixed(2)}</span><span>👆 ${p.clickCount||0} clicks</span></div>
        <div class="aff-stat"><span>${p.active?'🟢 Active':'⚪ Hidden'}</span><span>${p.showOnHome?'🏠 Home':''}</span></div>
        <div class="aff-row">
          <button data-edit="${esc(p.id)}">Edit</button>
          <button data-toggle="${esc(p.id)}">${p.active?'Hide':'Show'}</button>
          <button class="danger" data-del="${esc(p.id)}">Delete</button>
        </div>
      </div>
    `).join('');

    grid.querySelectorAll('[data-edit]').forEach(b=>b.onclick = ()=>openModal(_all.find(x=>x.id===b.dataset.edit)));
    grid.querySelectorAll('[data-del]').forEach(b=>b.onclick = async ()=>{
      if (!confirm('Delete this affiliate product?')) return;
      try { await api('/affiliate/'+b.dataset.del, {method:'DELETE'}); loadAffiliate(); }
      catch(e){ alert('Delete failed: '+e.message); }
    });
    grid.querySelectorAll('[data-toggle]').forEach(b=>b.onclick = async ()=>{
      const p = _all.find(x=>x.id===b.dataset.toggle);
      try { await api('/affiliate/'+p.id, {method:'PUT', body: JSON.stringify({active: !p.active})}); loadAffiliate(); }
      catch(e){ alert('Update failed: '+e.message); }
    });
  }

  function renderAnalytics(s){
    const top = document.getElementById('affAnalyticsTop');
    if (!top || !s) return;
    top.innerHTML = `
      <div class="aff-stat-card"><div class="n">${s.totalClicks||0}</div><div class="l">Total Clicks</div></div>
      <div class="aff-stat-card"><div class="n">${s.productCount||0}</div><div class="l">Affiliate Products</div></div>
      <div class="aff-stat-card"><div class="n">${Object.keys(s.bySource||{}).length}</div><div class="l">Active Sources</div></div>
      <div class="aff-stat-card"><div class="n">${Object.values(s.last7Days||{}).reduce((a,b)=>a+b,0)}</div><div class="l">Last 7 days</div></div>
    `;
    const bs = document.getElementById('affBySource');
    const entries = Object.entries(s.bySource||{});
    const max = Math.max(1, ...entries.map(([,v])=>v));
    bs.innerHTML = entries.length
      ? entries.map(([src,c])=>`
        <div class="aff-bar">
          <div style="width:90px;font-weight:600">${esc(SRC_LABEL[src]||src)}</div>
          <div class="track"><div class="fill" style="width:${(c/max*100)|0}%;background:${SRC_BADGE[src]||'#64748b'}"></div></div>
          <div style="width:50px;text-align:right;font-weight:600">${c}</div>
        </div>`).join('')
      : '<div style="color:#64748b;padding:8px">No clicks yet.</div>';

    const tl = document.getElementById('affTopList');
    const top10 = (s.topProducts||[]).slice(0,10).filter(p=>p.clickCount>0);
    tl.innerHTML = top10.length
      ? `<table style="width:100%;border-collapse:collapse;background:#fff;border:1px solid #e5e7eb;border-radius:10px;overflow:hidden">
          <thead><tr style="background:#f8fafc"><th style="text-align:left;padding:8px 12px;font-size:11px;text-transform:uppercase;color:#475569">Product</th><th style="text-align:left;padding:8px;font-size:11px;text-transform:uppercase;color:#475569">Source</th><th style="text-align:right;padding:8px 12px;font-size:11px;text-transform:uppercase;color:#475569">Clicks</th></tr></thead>
          <tbody>${top10.map(p=>`
            <tr style="border-top:1px solid #f1f5f9"><td style="padding:8px 12px">${esc(p.title)}</td><td style="padding:8px"><span style="background:${SRC_BADGE[p.source]||'#64748b'};color:#fff;font-size:10px;padding:2px 8px;border-radius:99px;font-weight:600">${esc(SRC_LABEL[p.source]||p.source)}</span></td><td style="padding:8px 12px;text-align:right;font-weight:700">${p.clickCount}</td></tr>
          `).join('')}</tbody></table>`
      : '<div style="color:#64748b;padding:8px">No clicks yet.</div>';
  }

  // ---------- Modal form ----------
  function openModal(p){
    const m = document.getElementById('affModal');
    $('#affModalTitle').textContent = p ? 'Edit Affiliate Product' : 'Add Affiliate Product';
    $('#affId').value     = p?.id || '';
    $('#affTitle').value  = p?.title || '';
    $('#affSource').value = p?.source || 'amazon';
    $('#affUrl').value    = p?.affiliateUrl || '';
    $('#affImage').value  = p?.image || '';
    $('#affPrice').value  = p?.price ?? 0;
    $('#affSort').value   = p?.sortOrder ?? 999;
    $('#affActive').checked = p ? !!p.active : true;
    $('#affHome').checked   = !!p?.showOnHome;
    m.classList.add('open');
  }
  function closeModal(){ document.getElementById('affModal').classList.remove('open'); }
  function wireForm(){
    $('#affAddBtn').onclick    = ()=>openModal(null);
    $('#affReloadBtn').onclick = loadAffiliate;
    $('#affCancel').onclick    = closeModal;
    $('#affSearch').oninput    = renderList;
    $('#affFilterSource').onchange = renderList;
    $('#affSave').onclick = async ()=>{
      const id = $('#affId').value;
      const body = {
        title: $('#affTitle').value.trim(),
        source: $('#affSource').value,
        affiliateUrl: $('#affUrl').value.trim(),
        image: $('#affImage').value.trim(),
        price: parseFloat($('#affPrice').value)||0,
        sortOrder: parseInt($('#affSort').value)||999,
        active: $('#affActive').checked,
        showOnHome: $('#affHome').checked,
      };
      if (!body.title || !body.affiliateUrl) { alert('Title & Affiliate URL required'); return; }
      try {
        if (id) await api('/affiliate/'+id, {method:'PUT', body: JSON.stringify(body)});
        else    await api('/affiliate',     {method:'POST', body: JSON.stringify(body)});
        closeModal(); loadAffiliate();
      } catch(e){ alert('Save failed: '+e.message); }
    };
  }

  // ---------- Boot ----------
  function boot(){
    if (!inject()) { setTimeout(boot, 400); return; }
    // expose for manual reload from console & analytics page link
    window.loadAffiliate = loadAffiliate;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
