// =============================================================
//  MY 3D Gifts — api-bridge.js
//  localStorage → PHP MySQL API sync bridge
//  Include this AFTER the main script in index.html
//  It patches the LS object + persistAll() to also sync to API
// =============================================================

(function () {
  'use strict';

  // ── Config ──────────────────────────────────────────────────
  const API   = '/api';           // base URL (same origin)
  const ADMIN_KEY_LS = 'adminApiKey'; // key stored in localStorage

  // LiteSpeed bypass: direct PHP file URLs (no .htaccess routing needed)
  const _PHP_MAP = {orders:'orders.php',products:'products.php',coupons:'coupons.php',
    settings:'settings.php',views:'views.php',users:'users.php',flash:'flash.php',
    wishlist:'wishlist.php',upload:'upload.php',track:'track.php',theme:'theme.php',
    popups:'popups.php',pages:'pages.php',coins:'coins.php'};
  function resolveApiUrl(path) {
    const clean = path.replace(/^\//, '');
    const resource = clean.split(/[/?]/)[0];
    const php = _PHP_MAP[resource];
    if (!php) return API + '/' + path;
    const rest = clean.slice(resource.length);
    return API + '/' + php + rest;
  }

  // Session ID for wishlist (anonymous)
  let sessionId = localStorage.getItem('_session');
  if (!sessionId) {
    sessionId = 'sess_' + Math.random().toString(36).slice(2) + Date.now();
    localStorage.setItem('_session', sessionId);
  }

  // ── HTTP helpers ─────────────────────────────────────────────
  function apiGet(path) {
    return fetch(resolveApiUrl(path), {
      cache: 'no-store',
      headers: { 'Cache-Control': 'no-cache', 'Pragma': 'no-cache' }
    }).then(r => r.json());
  }
  // v16: helpers throw on !ok so callers can detect real failures
  async function _request(method, path, body, adminKey) {
    const headers = {};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (adminKey) headers['X-Admin-Key'] = adminKey;
    const opts = { method, headers };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const r = await fetch(resolveApiUrl(path), opts);
    let j;
    try { j = await r.json(); } catch { throw new Error('HTTP ' + r.status + ' (non-JSON)'); }
    if (!r.ok || !j.ok) {
      const err = new Error(j && j.error ? j.error : 'HTTP ' + r.status);
      err.status = r.status; err.body = j;
      throw err;
    }
    return j;
  }
  function apiGet2(path, adminKey)            { return _request('GET',    path, undefined, adminKey); }
  function apiPost(path, body, adminKey)      { return _request('POST',   path, body, adminKey); }
  function apiPut(path, body, adminKey)       { return _request('PUT',    path, body, adminKey); }
  function apiDel(path, adminKey)             { return _request('DELETE', path, undefined, adminKey); }

  // ── Fetch customer orders by phone from API ─────────────────
  async function fetchOrdersByPhone(phone) {
    try {
      const r = await fetch(resolveApiUrl('/orders?phone=' + encodeURIComponent(phone)));
      const j = await r.json();
      if (j.ok && Array.isArray(j.data)) {
        const apiOrders = j.data;
        const localOnly = (window.orders || []).filter(o => o && o.phone !== phone && o.customerPhone !== phone);
        window.orders = [...apiOrders, ...localOnly];
        if (window.__setOrders) window.__setOrders(window.orders);
        if (window.LS) window.LS.set('orders', window.orders);
      }
    } catch(e) { /* non-fatal */ }
  }

  // ── Patch userLogin to fetch orders from server ──────────────
  const _origUserLogin = window.userLogin;
  window.userLogin = async function() {
    if (typeof _origUserLogin === 'function') _origUserLogin();
    // After login, fetch this user's orders from the server
    const user = window.currentUser;
    if (user && user.phone) {
      await fetchOrdersByPhone(user.phone);
      // Re-render account page if open
      if (typeof window.renderAccount === 'function') {
        const accSection = document.getElementById('view-account');
        if (accSection && !accSection.classList.contains('hidden')) {
          window.renderAccount();
        }
      }
    }
  };

  // Also fetch on page load if user already logged in
  (async function autoFetchUserOrders() {
    const user = window.currentUser;
    if (user && user.phone) {
      await fetchOrdersByPhone(user.phone);
    }
  })();

  // ── Admin key helper ────────────────────────────────────────
  function getAdminKey() {
    const raw = localStorage.getItem(ADMIN_KEY_LS) || '';
    try {
      const parsed = JSON.parse(raw);
      return typeof parsed === 'string' ? parsed : raw;
    } catch {
      return raw;
    }
  }

  let _settingsLoadedFromAPI = false;
  let _productsLoadedFromAPI = false;
  let _themeLoadedFromAPI = false;
  let _lastSettingsRefreshAt = 0;

  function refreshSettingsDependents() {
    if (typeof window.applyTheme === 'function') window.applyTheme();
    if (typeof window.renderBottomNav === 'function') window.renderBottomNav();
    if (typeof window.renderCustomPagesNav === 'function') window.renderCustomPagesNav();
    if (typeof window.renderShop === 'function') window.renderShop();
    const pin = document.getElementById('custPinCart')?.value || '';
    if (pin && typeof window.calcCartShipping === 'function') window.calcCartShipping(pin);
  }

  async function refreshSettingsFromAPI(options) {
    const force = !!(options && options.force);
    const now = Date.now();
    if (!force && now - _lastSettingsRefreshAt < 3000) return window.settings;
    _lastSettingsRefreshAt = now;
    const sep = '/settings'.includes('?') ? '&' : '?';
    const settingsRes = await apiGet('/settings' + sep + '_=' + now);
    if (settingsRes.ok && settingsRes.data) {
      const s = settingsRes.data;
      if (typeof window.__setSettings === 'function') window.__setSettings(s);
      else Object.assign(window.settings, s);
      _settingsLoadedFromAPI = true;
      if (window.LS) window.LS.set('settings', window.settings);
      _lastSyncedSettingsStr = JSON.stringify(window.settings);
      refreshSettingsDependents();
      return window.settings;
    }
    throw new Error(settingsRes.error || 'Settings load failed');
  }
  window.refreshSettingsFromAPI = refreshSettingsFromAPI;

  // ── Load all data from API on startup ────────────────────────
  async function loadFromAPI() {
    try {
      // 1. Settings
      await refreshSettingsFromAPI({ force: true });

      // 2. Theme
      const themeRes = await apiGet('/theme');
      if (themeRes.ok && themeRes.data) {
        if (typeof window.__setTheme === 'function') window.__setTheme(themeRes.data);
        else Object.assign(window.theme, themeRes.data);
        if (window.LS) window.LS.set('theme', window.theme);
        _themeLoadedFromAPI = true;
        _lastSyncedThemeStr = JSON.stringify(window.theme);
        if (typeof window.applyTheme === 'function') window.applyTheme();
      }

      // 3. Products
      const prodRes = await apiGet('/products?all=1');
      if (prodRes.ok && Array.isArray(prodRes.data)) {
        // v24: Fix image URLs — handles both string and {url:'...'} object format
        const origin = window.location.origin;
        const fixUrl = u => {
          if (!u) return u;
          // Handle {url:'...'} object images (returned by API)
          if (typeof u === 'object' && u.url) {
            const fixed = u.url.startsWith('http') ? u.url : origin + (u.url.startsWith('/') ? '' : '/') + u.url;
            return { ...u, url: fixed };
          }
          if (typeof u !== 'string') return u;
          return u.startsWith('http') ? u : origin + (u.startsWith('/') ? '' : '/') + u;
        };
        const urlOf = u => (u && typeof u === 'object' && u.url) ? u.url : (typeof u === 'string' ? u : '');
        const fixedData = prodRes.data.map(p => {
          const fixedImages = Array.isArray(p.images) ? p.images.map(fixUrl) : (p.image ? [fixUrl(p.image)] : []);
          const coverUrl = fixedImages.length ? urlOf(fixedImages[0]) : (p.image ? (typeof p.image === 'string' ? fixUrl(p.image) : urlOf(fixUrl(p.image))) : '');
          return {
            ...p,
            image: coverUrl || (typeof p.image === 'string' ? fixUrl(p.image) : ''),
            images: fixedImages,
            coverImage: coverUrl,
          };
        });
        if (typeof window.__setProducts === 'function') window.__setProducts(fixedData);
        else window.products = fixedData;
        if (window.LS) window.LS.set('products', window.products);
        // v16: seed sync baseline so first persistAll won't delete everything
        window._lastSyncedProductIds = prodRes.data.map(p => p && p.id).filter(Boolean);
        _productsLoadedFromAPI = true;
        _lastSyncedProductsStr = JSON.stringify(window.products);
      }

      // 4. Coupons
      const cpRes = await apiGet('/coupons');
      if (cpRes.ok && Array.isArray(cpRes.data)) {
        const mapped = cpRes.data.map(c => ({
          code: c.code, type: c.type, value: c.value,
          minOrder: c.minOrder, active: c.active, uses: c.uses
        }));
        if (typeof window.__setCoupons === 'function') window.__setCoupons(mapped);
        else window.coupons = mapped;
        if (window.LS) window.LS.set('coupons', window.coupons);
      }

      // 5. Flash sale
      const flashRes = await apiGet('/flash');
      if (flashRes.ok && flashRes.data) {
        const fs = {
          active: flashRes.data.active,
          code: flashRes.data.code,
          discount: flashRes.data.discount,
          endTime: flashRes.data.endTime,
          banner: flashRes.data.banner
        };
        if (typeof window.__setFlashSale === 'function') window.__setFlashSale(fs);
        else window.flashSale = fs;
        if (window.LS) window.LS.set('flashSale', window.flashSale);
      }

      // 6. Wishlist (server-side by session)
      const wishRes = await apiGet(`/wishlist?session=${sessionId}`);
      if (wishRes.ok && Array.isArray(wishRes.data)) {
        if (typeof window.__setWishlist === 'function') window.__setWishlist(wishRes.data);
        else window.wishlist = wishRes.data;
        if (window.LS) window.LS.set('wishlist', window.wishlist);
      }

      // 7. Product views
      const viewsRes = await apiGet('/views');
      if (viewsRes.ok && viewsRes.data) {
        if (typeof window.__setProductViews === 'function') window.__setProductViews(viewsRes.data);
        else window.productViews = viewsRes.data;
      }

      // 8. Custom Pages (About / Contact / etc.)
      try {
        const pagesRes = await apiGet('/pages');
        if (pagesRes.ok && Array.isArray(pagesRes.data)) {
          const mapped = pagesRes.data.map(p => ({
            slug:      p.slug,
            title:     p.title,
            content:   p.content,
            showInNav: !!p.showInNav,
            sortOrder: p.sortOrder || 0
          }));
          if (typeof window.__setSettings === 'function') {
            window.__setSettings({ customPages: mapped });
          } else {
            window.settings.customPages = mapped;
          }
          if (window.LS) window.LS.set('settings', window.settings);
        }
      } catch (e) { console.warn('[api-bridge] pages load failed', e); }

      // 9. Popup banner — admin manages an array; show the first active one
      try {
        const popRes = await apiGet('/popups?_=' + Date.now());
        if (popRes.ok && Array.isArray(popRes.data) && popRes.data.length) {
          const p = popRes.data[0];
          const popup = {
            ...(window.settings.popup||{}),
            id:      p.id,
            updatedAt: p.updatedAt || '',
            enabled: !!p.active,
            type:    p.type || 'info',
            icon:    p.icon || '🎉',
            title:   p.title || '',
            message: p.body  || '',
            ctaText: p.ctaLabel || '',
            ctaLink: p.ctaUrl   || 'close',
            delayMs: (p.showAfterSec || 1) * 1000,
            maxPerDay: p.showOnce ? 1 : 999
          };
          if (typeof window.__setSettings === 'function') {
            window.__setSettings({ popup });
          } else {
            window.settings.popup = popup;
          }
          if (window.LS) window.LS.set('settings', window.settings);
          if (typeof window.__onPopupSettingsUpdated === 'function') window.__onPopupSettingsUpdated(popup);
        } else if (popRes.ok && Array.isArray(popRes.data) && !popRes.data.length) {
          const popup = { ...(window.settings.popup||{}), enabled: false, id: null, updatedAt: String(Date.now()) };
          if (typeof window.__setSettings === 'function') {
            window.__setSettings({ popup });
          } else {
            window.settings.popup = popup;
          }
          if (window.LS) window.LS.set('settings', window.settings);
          if (typeof window.__onPopupSettingsUpdated === 'function') window.__onPopupSettingsUpdated(popup);
          if (typeof window.closePopup === 'function') window.closePopup();
        }
      } catch (e) {}

      // 10. Orders (admin only)
      if (getAdminKey()) {
        try {
          const ordRes = await fetch(resolveApiUrl('/orders'), {
            headers: { 'X-Admin-Key': getAdminKey() }
          }).then(r => r.json());
          if (ordRes.ok && Array.isArray(ordRes.data)) {
            if (typeof window.__setOrders === 'function') window.__setOrders(ordRes.data);
            else window.orders = ordRes.data;
            if (window.LS) window.LS.set('orders', window.orders);
          }
        } catch (e) {}
      }

      // Re-render after data load
      if (typeof window.applyTheme         === 'function') window.applyTheme();
      if (typeof window.renderBottomNav    === 'function') window.renderBottomNav();
      if (typeof window.renderCustomPagesNav === 'function') window.renderCustomPagesNav();
      if (typeof window.renderShop         === 'function') window.renderShop();
      if (typeof window.syncBnavBadges     === 'function') window.syncBnavBadges();
      if (typeof window.initFlashBanner    === 'function') window.initFlashBanner();
      if (typeof window.routeFromLocation  === 'function') window.routeFromLocation();
      if (typeof window.renderAboutPage    === 'function'
          && document.getElementById('view-about')
          && !document.getElementById('view-about').classList.contains('hidden')) {
        window.renderAboutPage();
      }
      // If admin panel currently open, refresh its tabs too
      if (typeof window.renderAdmin === 'function' && window.isAdmin
          && document.getElementById('view-admin')
          && !document.getElementById('view-admin').classList.contains('hidden')) {
        window.renderAdmin();
      }

    } catch (err) {
      console.warn('[api-bridge] Load failed, using localStorage fallback:', err);
    }
  }

  // ── Patch persistAll ─────────────────────────────────────────
  // After the original persistAll saves to localStorage,
  // we also push changed data to the API.
  const _origPersistAll = window.persistAll;
  window.persistAll = function () {
    // Always call original first (localStorage)
    if (_origPersistAll) _origPersistAll();
    // Then async-sync to API (fire and forget)
    syncToAPI();
  };

  let _lastSyncedProductsStr = '';
  let _lastSyncedSettingsStr = '';
  let _lastSyncedThemeStr    = '';

  // v16: Convert any data: URL images on a product to real /uploads/ URLs.
  // Mutates the product in-place. Silent on failure (kept as data URL).
  async function uploadDataUrlImages(p, adminKey) {
    if (!p) return;
    async function up(dataUrl) {
      try {
        const blob = await (await fetch(dataUrl)).blob();
        const ext = (blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
        const file = new File([blob], 'img_' + Date.now() + '.' + ext, { type: blob.type });
        const fd = new FormData();
        fd.append('file', file);
        const r = await fetch(resolveApiUrl('/upload'), {
          method: 'POST',
          headers: { 'X-Admin-Key': adminKey },
          body: fd
        });
        const j = await r.json();
        if (j.ok && j.data && j.data.url) return j.data.url;
      } catch (e) { console.warn('[api-bridge] upload data-url failed', e.message); }
      return null;
    }
    if (typeof p.image === 'string' && p.image.startsWith('data:')) {
      const u = await up(p.image); if (u) p.image = u;
    }
    if (Array.isArray(p.images)) {
      for (let i = 0; i < p.images.length; i++) {
        if (typeof p.images[i] === 'string' && p.images[i].startsWith('data:')) {
          const u = await up(p.images[i]); if (u) p.images[i] = u;
        }
      }
    }
    if (p.options) {
      for (const k of ['gifUrl','videoUrl']) {
        if (typeof p.options[k] === 'string' && p.options[k].startsWith('data:')) {
          const u = await up(p.options[k]); if (u) p.options[k] = u;
        }
      }
    }
  }
  window.uploadDataUrlImages = uploadDataUrlImages;

  async function syncToAPI() {
    const adminKey = getAdminKey();
    if (!adminKey) return; // Only sync when admin is logged in

    try {
      // ── Settings ──
      const settingsStr = JSON.stringify(window.settings);
      if (_settingsLoadedFromAPI && settingsStr !== _lastSyncedSettingsStr) {
        _lastSyncedSettingsStr = settingsStr;
        apiPost('/settings', window.settings, adminKey).catch(() => {});
      }

      // ── Theme ──
      const themeStr = JSON.stringify(window.theme);
      if (_themeLoadedFromAPI && themeStr !== _lastSyncedThemeStr) {
        _lastSyncedThemeStr = themeStr;
        apiPost('/theme', window.theme, adminKey).catch(() => {});
      }

      // ── Products (v16: robust create-or-update + delete tracking) ──
      const productsStr = JSON.stringify(window.products);
      if (_productsLoadedFromAPI && productsStr !== _lastSyncedProductsStr) {
        const prevIds  = (window._lastSyncedProductIds || []);
        const currIds  = (window.products || []).map(p => p && p.id).filter(Boolean);
        const removed  = prevIds.filter(id => !currIds.includes(id));
        // Delete removed first
        for (const rid of removed) {
          try { await apiDel('/products/' + encodeURIComponent(rid), adminKey); }
          catch (e) { console.warn('[api-bridge] delete failed', rid, e.message); }
        }
        // Upsert each (await so we know if it really persisted)
        for (const p of (window.products || [])) {
          try {
            // Upload any embedded data: URL images to server before sync
            await uploadDataUrlImages(p, adminKey);
            await apiPut('/products/' + encodeURIComponent(p.id), p, adminKey);
          } catch (eUpd) {
            try { await apiPost('/products', p, adminKey); }
            catch (eIns) {
              console.error('[api-bridge] product save failed', p.id, eIns.message);
              if (window.toast) window.toast('⚠️ Save failed: '+(p.name||p.id)+' — '+eIns.message);
            }
          }
        }
        _lastSyncedProductsStr = JSON.stringify(window.products);
        window._lastSyncedProductIds = (window.products || []).map(p => p && p.id).filter(Boolean);
      }

      // ── Coupons ──
      if (window.coupons) {
        for (const c of window.coupons) {
          apiPost('/coupons', c, adminKey).catch(() => {});
        }
      }

      // ── Flash sale ──
      if (window.flashSale) {
        apiPost('/flash', {
          active:   window.flashSale.active,
          code:     window.flashSale.code,
          discount: window.flashSale.discount,
          endTime:  window.flashSale.endTime,
          banner:   window.flashSale.banner || ''
        }, adminKey).catch(() => {});
      }

      // ── Custom Pages (About / Contact / etc.) ──
      if (Array.isArray(window.settings?.customPages)) {
        for (const pg of window.settings.customPages) {
          if (!pg || !pg.slug) continue;
          apiPost('/pages', {
            slug:      pg.slug,
            title:     pg.title || '',
            content:   pg.content || '',
            showInNav: !!pg.showInNav,
            sortOrder: pg.sortOrder || 0
          }, adminKey).catch(() => {});
        }
      }

    } catch (e) {
      console.warn('[api-bridge] Sync error:', e);
    }
  }

  // ── Patch wishlist toggle ────────────────────────────────────
  const _origToggleWishlist = window.toggleWishlist;
  window.toggleWishlist = function (pid) {
    // Call original (localStorage update)
    if (_origToggleWishlist) _origToggleWishlist(pid);
    // Also sync to server
    apiPost('/wishlist', { session: sessionId, productId: pid }).catch(() => {});
  };

  // ── Patch placeOrder ─────────────────────────────────────────
  // Intercept order placement to save to DB (admin panel-ல் தெரிய வேண்டும்)
  // _abId declared here so placeOrder patch can clear it without ReferenceError
  let _abId = localStorage.getItem('_abandonedId') || '';

  const _origPlaceOrder = window.placeOrder;
  window.placeOrder = async function () {
    // Collect form data before original runs
    const nameEl  = document.getElementById('custName');
    const phoneEl = document.getElementById('custPhone');
    const addrSel = document.getElementById('custAddr');
    const addrNew = document.getElementById('custAddrNew');
    const pinEl   = document.getElementById('custPinCart');
    const emailEl = document.getElementById('custEmail');
    const couponEl = document.getElementById('cartCouponInput');

    const name   = nameEl?.value.trim()  || '';
    const phone  = phoneEl?.value.trim() || '';
    let   addr   = addrSel?.value || '';
    if (addr === '' && addrNew) addr = addrNew.value.trim();
    const pin    = pinEl?.value || '';
    const email  = emailEl?.value.trim() || '';
    const coupon = couponEl?.value.trim().toUpperCase() || '';

    if (!name || !phone || !addr) {
      // Let original handle validation error
      if (_origPlaceOrder) _origPlaceOrder();
      return;
    }

    // Calculate totals (mirror logic from original)
    const N       = (v, d = 0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
    const rawTotal = (window.cart || []).reduce((s, i) => s + N(i.price), 0);
    let disc = 0, shipCh = 0;
    const cp = (window.coupons || []).find(x => x.code === coupon && x.active);
    if (cp) {
      disc = cp.type === 'percent'
        ? Math.round(rawTotal * N(cp.value) / 100)
        : Math.min(N(cp.value), rawTotal);
    }
    if (pin.length === 6) {
      const zones = (window.settings?.shippingZones) || [];
      let found = null;
      for (const z of zones) {
        if (z.pincodes === '*') { found = z; break; }
        const pts = z.pincodes.split('-');
        if (pts.length === 2) {
          const [f, t] = pts.map(Number);
          if (Number(pin) >= f && Number(pin) <= t) { found = z; break; }
        }
      }
      shipCh = found ? N(found.charge) : 100;
    }
    const payMethod  = document.querySelector('input[name="payMethod"]:checked')?.value || 'cod';
    const finalTotal = rawTotal - disc + shipCh;

    const payload = {
      name, phone, email, addr, pin,
      items:      window.cart || [],
      total:      finalTotal,
      discount:   disc,
      shipping:   shipCh,
      coupon:     coupon,
      payMethod,
      notes:      '',
      source:     'online',
      userId:     window.currentUser?.id || null
    };

    // ★ AWAIT API save BEFORE running original (admin panel-ல் order உடனே தெரிய)
    let saved = false;
    try {
      const res = await apiPost('/orders', payload);
      if (res && res.ok) {
        saved = true;
        console.log('[api-bridge] ✓ Order saved to DB:', res.data);
        // Store DB tracking on cart for original handler
        window._lastApiOrder = res.data;
      } else {
        console.error('[api-bridge] ✗ Order API error:', res);
        console.warn('[api-bridge] Order not saved to DB:', res?.error);
        // Don't alert user - order still goes via WhatsApp
      }
    } catch (e) {
      console.error('[api-bridge] ✗ Order API failed:', e);
      console.warn('[api-bridge] Server not reachable, order via WhatsApp only:', e.message);
      // Don't block user with alert
    }

    // Also upsert customer record (so admin sees user list)
    if (saved) {
      apiPost('/users', { name, phone, email }).catch(() => {});
    }

    // Run original (handles WhatsApp / Cashfree / local storage)
    if (_origPlaceOrder) await _origPlaceOrder();

    // Clear abandoned cart tracking
    localStorage.removeItem('_abandonedId');
    _abId = '';

    // If the API order was created, replace any temporary local copy and refresh account coins instantly.
    if (saved && phone) {
      try {
        await fetchOrdersByPhone(phone);
        if (typeof window.renderAccount === 'function') {
          const accSection = document.getElementById('view-account');
          if (accSection && !accSection.classList.contains('hidden')) {
            await window.renderAccount();
          }
        }
      } catch (e) {}
    }
  };

  // ── Patch openProduct (view counter + time-spent tracking) ───
  let _activeViewId = null;
  let _activeViewStart = 0;
  let _activeViewProductId = null;

  function _flushTimeSpent() {
    if (!_activeViewId) return;
    const seconds = Math.round((Date.now() - _activeViewStart) / 1000);
    const viewId = _activeViewId;
    _activeViewId = null;
    _activeViewProductId = null;
    if (seconds <= 0) return;
    // Use sendBeacon when available so it survives page unload/navigation
    try {
      const url = resolveApiUrl('/views');
      const payload = JSON.stringify({ viewId, seconds });
      if (navigator.sendBeacon) {
        const blob = new Blob([payload], { type: 'application/json' });
        navigator.sendBeacon(url, blob);
        return;
      }
    } catch (e) { /* fall through to fetch */ }
    apiPost('/views', { viewId, seconds }).catch(() => {});
  }

  const _origOpenProduct = window.openProduct;
  window.openProduct = function (id) {
    // Flush time spent on whatever product was open before switching
    _flushTimeSpent();
    if (_origOpenProduct) _origOpenProduct(id);
    apiPost('/views', { productId: id }).then(res => {
      if (res && res.ok && res.data && res.data.viewId) {
        _activeViewId = res.data.viewId;
        _activeViewStart = Date.now();
        _activeViewProductId = id;
      }
    }).catch(() => {});
  };

  // Flush when leaving the product view for any other view (cart, shop, etc.)
  const _origShowView = window.showView;
  window.showView = function (v, opts) {
    if (_activeViewId && v !== 'product') _flushTimeSpent();
    if (_origShowView) return _origShowView(v, opts);
  };

  // Flush on tab close / refresh / navigating away from the site
  window.addEventListener('pagehide', _flushTimeSpent);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') _flushTimeSpent();
  });

  // ── Admin login: store API key ───────────────────────────────
  // The original adminLogin() checks a password locally.
  // We extend it to also store the ADMIN_SECRET as the API key.
  // Set the key via: localStorage.setItem('adminApiKey', 'YOUR_SECRET')
  // OR hook into the admin login flow:
  const _origAdminLogin = window.adminLogin;
  window.adminLogin = function () {
    if (_origAdminLogin) _origAdminLogin();
    // After original login, prompt for API key if not set
    setTimeout(() => {
      if (window.isAdmin && !localStorage.getItem(ADMIN_KEY_LS)) {
        const key = prompt(
          'Enter Admin API Key (config.php-ல் ADMIN_SECRET value):\n' +
          '(ஒரு முறை மட்டும் கேட்கும்)'
        );
        if (key) {
          localStorage.setItem(ADMIN_KEY_LS, key);
          syncToAPI(); // Immediate sync
        }
      }
    }, 500);
  };

  // ── Image upload helper (admin) ──────────────────────────────
  window.uploadImageToServer = async function (file, onSuccess, onError) {
    const adminKey = getAdminKey();
    if (!adminKey) {
      onError && onError('Admin key not set');
      return;
    }
    const fd = new FormData();
    fd.append('file', file);
    try {
      const res = await fetch(resolveApiUrl('/upload'), {
        method: 'POST',
        headers: { 'X-Admin-Key': adminKey },
        body: fd
      });
      const json = await res.json();
      if (json.ok) {
        onSuccess && onSuccess(json.data.url);
      } else {
        onError && onError(json.error || 'Upload failed');
      }
    } catch (e) {
      onError && onError(e.message);
    }
  };

  // ── Kick off initial load ─────────────────────────────────────
  // Wait for DOM + Three.js to be ready before loading from API
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadFromAPI);
  } else {
    // Small delay so the original script runs first
    setTimeout(loadFromAPI, 100);
  }

  // ── Abandoned-cart capture ──────────────────────────────────
  // _abId is declared above (near placeOrder patch) so it's in scope here too.
  let _abTimer = null;
  function captureAbandoned() {
    try {
      if (!Array.isArray(window.cart) || !window.cart.length) return;
      const name  = (document.getElementById('custName')?.value  || '').trim();
      const phone = (document.getElementById('custPhone')?.value || '').trim();
      const email = (document.getElementById('custEmail')?.value || '').trim();
      const addrSel = document.getElementById('custAddr');
      const addrNew = document.getElementById('custAddrNew');
      let addr = addrSel?.value || '';
      if (!addr && addrNew) addr = addrNew.value.trim();
      if (!phone && !addr) return; // need at least phone or address
      if (!_abId) {
        _abId = 'ab_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
        localStorage.setItem('_abandonedId', _abId);
      }
      const total = (window.cart || []).reduce((s, i) => s + (Number(i.price) || 0), 0);
      const items = (window.cart || []).map(i => ({
        productId: i.productId || i.id || '',
        name:      i.name || '',
        quantity:  i.quantity || 1,
        price:     i.price || 0,
        options:   i.options || {}
      }));
      apiPost('/abandoned', {
        id: _abId,
        customerName:  name,
        customerPhone: phone,
        customerEmail: email,
        items, total,
        lastStep: addr ? 'address' : 'contact'
      }).catch(() => {});
    } catch (e) {}
  }
  // Debounced listener — fires 800ms after user stops typing in cart fields
  document.addEventListener('input', e => {
    if (!e.target || !e.target.id) return;
    if (!['custName','custPhone','custEmail','custAddrNew','custAddr','custPinCart'].includes(e.target.id)) return;
    clearTimeout(_abTimer);
    _abTimer = setTimeout(captureAbandoned, 800);
  });
  // Clear abandoned id once order is placed (merged into main placeOrder patch above)
  // NOTE: do NOT re-override window.placeOrder here — it would replace the API-save patch above.
  // Abandoned cart clear is now handled inside the main placeOrder patch.

  console.log('[api-bridge] MY 3D Gifts API bridge loaded');
})();
