/* =============================================================
   MY 3D Gifts — v15 storefront feature wiring
   Loaded AFTER index.html main script + api-bridge.js
   Adds (additively):
     1. Bottom nav hidden on desktop unless settings.bottomNavDesktop
     2. Mobile sticky Add-to-Cart bar always shown on product page < 768px
     3. Custom 3D viewer HTML injection (product.options.viewer3dHtml)
     4. Dynamic option labels (product.options.sizeLabel, etc.)
     5. WhatsApp UPI checkout button
     6. settings.homePage → opens custom page as landing screen
     7. Render uploaded logo (settings.logoUrl)
   ============================================================= */
(function(){
  'use strict';

  // ---------- 1. Desktop bottom-nav toggle ----------
  function applyDesktopBnav(){
    let css = document.getElementById('v15-bnav-css');
    if(!css){
      css = document.createElement('style');
      css.id = 'v15-bnav-css';
      document.head.appendChild(css);
    }
    const showOnDesktop = !!(window.settings && window.settings.bottomNavDesktop);
    css.textContent = showOnDesktop ? '' : `
      @media (min-width: 1024px) {
        #bottomNav { display: none !important; }
        body { padding-bottom: 0 !important; }
      }
    `;
  }

  // ---------- 2. Mobile sticky Add-to-Cart visibility ----------
  function applyStickyCartMobile(){
    let css = document.getElementById('v15-sticky-css');
    if(!css){
      css = document.createElement('style');
      css.id = 'v15-sticky-css';
      css.textContent = `
        /* keep sticky bar visible above the bottom nav on mobile */
        @media (max-width: 767px) {
          #stickyCart { display: block !important; bottom: 62px !important; z-index: 55; }
        }
        @media (min-width: 768px) {
          #stickyCart { display: none !important; }
        }
        body.v15-on-product #stickyCart { display: block !important; }
        body:not(.v15-on-product) #stickyCart { display: none !important; }
      `;
      document.head.appendChild(css);
    }
  }
  // Patch showView so we can toggle a body class & home page redirect
  function patchShowView(){
    const orig = window.showView;
    if(!orig || orig.__v15) return;
    const wrapped = function(v){
      // v15: home page redirect — first call only
      if(!wrapped.__homeApplied && v === 'shop'){
        wrapped.__homeApplied = true;
        const hp = window.settings && window.settings.homePage;
        if(hp && (window.settings.customPages||[]).some(p=>p.slug===hp)){
          return orig.call(this, 'page:'+hp);
        }
      }
      const ret = orig.apply(this, arguments);
      // body class for sticky-cart visibility
      const onProduct = (v === 'product');
      document.body.classList.toggle('v15-on-product', onProduct);
      // Re-render UPI button when on cart
      if(v === 'cart') setTimeout(injectWaUpiButton, 30);
      // Inject custom 3D HTML when on product
      if(v === 'product') setTimeout(injectCustom3D, 80);
      // Re-render dynamic labels
      if(v === 'product') setTimeout(renameOptionLabels, 80);
      return ret;
    };
    wrapped.__v15 = true;
    window.showView = wrapped;
  }

  // ---------- 3. Custom 3D viewer HTML ----------
  function injectCustom3D(){
    const cur = window.currentProduct;
    if(!cur) return;
    const html = cur.options && cur.options.viewer3dHtml;
    if(!html) return;
    const host = document.getElementById('preview3D');
    if(!host) return;
    if(host.dataset.v15For === cur.id) return;
    host.dataset.v15For = cur.id;
    host.classList.remove('hidden');
    // Replace content with custom HTML
    host.innerHTML = `<div class="v15-custom-3d" style="width:100%;height:320px;border-radius:14px;overflow:hidden;background:#0f172a">${html}</div>`;
    // Execute any <script> tags inside the inserted HTML
    host.querySelectorAll('script').forEach(s=>{
      const ns = document.createElement('script');
      [...s.attributes].forEach(a=>ns.setAttribute(a.name, a.value));
      ns.textContent = s.textContent;
      s.parentNode.replaceChild(ns, s);
    });
  }

  // ---------- 4. Dynamic option labels ----------
  function renameOptionLabels(){
    const cur = window.currentProduct;
    if(!cur || !cur.options) return;
    const map = {
      sizeLabel:     ['Size','அளவு','Choose Size'],
      materialLabel: ['Material','மெட்டீரியல்','Choose Material'],
      colorLabel:    ['Color','நிறம்','Choose Color']
    };
    document.querySelectorAll('#productDetail label, #productDetail .opt-label, #productDetail h3, #productDetail h4').forEach(el=>{
      const t = (el.textContent||'').trim();
      Object.entries(map).forEach(([k, alts])=>{
        const v = cur.options[k];
        if(!v) return;
        if(alts.some(a => t === a || t.startsWith(a))) {
          el.textContent = v;
        }
      });
    });
  }

  // ---------- 5. WhatsApp UPI button in cart ----------
  function injectWaUpiButton(){
    const cartView = document.getElementById('view-cart');
    if(!cartView || cartView.classList.contains('hidden')) return;
    const upi = window.settings && window.settings.whatsappUpi;
    let host = document.getElementById('v15WaUpi');
    if(!upi || !upi.enabled || !upi.upiId){
      if(host) host.remove();
      return;
    }
    // Find a place to inject (before pay method radios or near place order)
    const placeBtn = cartView.querySelector('button[onclick*="placeOrder"]');
    if(!placeBtn) return;
    if(host){ host.remove(); }
    host = document.createElement('div');
    host.id = 'v15WaUpi';
    host.style.cssText = 'margin:10px 0;padding:12px;border:1px dashed #25D366;border-radius:12px;background:#f0fdf4;text-align:center';
    host.innerHTML = `
      <div style="font-size:13px;font-weight:600;color:#065f46;margin-bottom:6px">
        💚 Pay via WhatsApp UPI
      </div>
      <div style="font-size:11.5px;color:#047857;margin-bottom:8px">
        UPI ID: <b>${escapeHtml(upi.upiId)}</b>${upi.payeeName?' · '+escapeHtml(upi.payeeName):''}
      </div>
      <button id="v15WaUpiBtn" type="button"
        style="background:#25D366;color:#fff;border:none;border-radius:10px;padding:10px 16px;font-weight:700;font-size:13px;cursor:pointer">
        📱 Send Payment Details on WhatsApp
      </button>
    `;
    placeBtn.parentNode.insertBefore(host, placeBtn);
    document.getElementById('v15WaUpiBtn').onclick = sendWaUpi;
  }
  function sendWaUpi(){
    const upi = window.settings.whatsappUpi || {};
    const adminPhone = String((window.settings.whatsapp || window.settings.mobile || '')).replace(/\D/g,'');
    if(!adminPhone){ alert('Shop WhatsApp number not configured.'); return; }
    const cart = window.cart || [];
    if(!cart.length){ alert('Cart is empty.'); return; }
    const N = (v,d=0)=>{const n=Number(v);return Number.isFinite(n)?n:d;};
    const total = cart.reduce((s,i)=>s+N(i.price)*(N(i.quantity)||1),0);
    const name  = (document.getElementById('custName')?.value||'').trim();
    const phone = (document.getElementById('custPhone')?.value||'').trim();
    const items = cart.map(i=>`• ${i.name} × ${i.quantity||1} — ₹${i.price}`).join('\n');
    const upiLink = `upi://pay?pa=${encodeURIComponent(upi.upiId)}&pn=${encodeURIComponent(upi.payeeName||'Shop')}&am=${total}&cu=INR&tn=${encodeURIComponent('Order from '+(name||'Customer'))}`;
    const msg = `Hi! I'd like to place this order:\n\n${items}\n\n*Total: ₹${total}*\n\nName: ${name}\nPhone: ${phone}\n\nPaying via UPI to:\nUPI ID: ${upi.upiId}\n${upi.payeeName?'Payee: '+upi.payeeName+'\n':''}\nUPI link:\n${upiLink}\n\nWill share screenshot after payment.`;
    window.open(`https://wa.me/${adminPhone.startsWith('91')?adminPhone:('91'+adminPhone)}?text=${encodeURIComponent(msg)}`, '_blank');
  }

  // ---------- 7. Logo render ----------
  function applyLogo(){
    const url = window.settings && window.settings.logoUrl;
    if(!url) return;
    // Find the brand element — heuristic: first <h1> inside header, or element with id storeName
    const targets = document.querySelectorAll('#storeName, header h1, header .brand, [data-brand]');
    targets.forEach(t=>{
      if(t.dataset.v15Logo === url) return;
      t.dataset.v15Logo = url;
      t.innerHTML = `<img src="${escapeAttr(url)}" alt="${escapeAttr(t.textContent.trim()||'Logo')}" style="height:36px;width:auto;display:inline-block;vertical-align:middle"/>`;
    });
  }

  // ---------- helpers ----------
  function escapeHtml(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function escapeAttr(s){return escapeHtml(s);}

  // ---------- boot ----------
  function boot(){
    applyStickyCartMobile();
    applyDesktopBnav();
    patchShowView();
    applyLogo();
    // Re-apply when api-bridge updates settings
    const origSet = window.__setSettings;
    window.__setSettings = function(s){
      const r = origSet ? origSet(s) : Object.assign(window.settings||{}, s);
      applyDesktopBnav();
      applyLogo();
      // refresh UPI button if cart open
      injectWaUpiButton();
      return r;
    };
    // Listen for currentProduct change
    setInterval(()=>{
      if(document.body.classList.contains('v15-on-product')){
        injectCustom3D();
        renameOptionLabels();
      }
    }, 1500);
    console.log('[v15] storefront features loaded');
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    setTimeout(boot, 200);
  }
})();
