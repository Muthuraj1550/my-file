// ============================================================
//  MY 3D Gifts — cart-media-patch.js
//  1. Abandoned Cart — proper save when phone entered
//  2. placeOrder fix — addr select vs new input bug fix
//  3. Admin Media Library tab
//  Include AFTER main script in index.html
// ============================================================
(function () {
  'use strict';

  /* ── Wait for main app to initialize ── */
  function onReady(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else setTimeout(fn, 200);
  }

  onReady(function () {

    /* ════════════════════════════════════════════════════════
       1. ABANDONED CART — Save when phone field is filled
       ════════════════════════════════════════════════════════ */

    // Patch renderCart to add oninput listeners after it renders
    const _origRenderCart = window.renderCart;
    window.renderCart = function () {
      if (_origRenderCart) _origRenderCart();
      // Small delay so DOM is updated
      setTimeout(attachCartListeners, 100);
    };

    function attachCartListeners() {
      const phoneEl = document.getElementById('custPhone');
      const nameEl  = document.getElementById('custName');
      const addrEl  = document.getElementById('custAddr');
      const addrNew = document.getElementById('custAddrNew');

      if (phoneEl && !phoneEl._abandonedPatched) {
        phoneEl._abandonedPatched = true;
        phoneEl.addEventListener('blur', saveAbandonedCart);
        phoneEl.addEventListener('input', debouncedSaveAbandoned);
      }
      if (nameEl && !nameEl._abandonedPatched) {
        nameEl._abandonedPatched = true;
        nameEl.addEventListener('blur', saveAbandonedCart);
      }
      if (addrEl && !addrEl._abandonedPatched) {
        addrEl._abandonedPatched = true;
        addrEl.addEventListener('blur', saveAbandonedCart);
        addrEl.addEventListener('change', saveAbandonedCart);
      }
      if (addrNew && !addrNew._abandonedPatched) {
        addrNew._abandonedPatched = true;
        addrNew.addEventListener('blur', saveAbandonedCart);
      }
    }

    let _abandonedDebounce = null;
    function debouncedSaveAbandoned() {
      clearTimeout(_abandonedDebounce);
      _abandonedDebounce = setTimeout(saveAbandonedCart, 1500);
    }

    function saveAbandonedCart() {
      // Don't save if cart is empty
      if (!window.cart || !window.cart.length) return;

      const nameEl  = document.getElementById('custName');
      const phoneEl = document.getElementById('custPhone');
      const addrSel = document.getElementById('custAddr');
      const addrNew = document.getElementById('custAddrNew');

      const name  = nameEl?.value.trim() || '';
      const phone = phoneEl?.value.trim() || '';
      let   addr  = addrSel?.value || '';
      if (addr === '' && addrNew) addr = addrNew.value.trim();

      // Only save if at least phone is filled (minimum useful data)
      if (!phone) return;

      const N = (v, d=0) => { const n=Number(v); return Number.isFinite(n)?n:d; };
      const rawTotal = (window.cart||[]).reduce((s,i)=>s+N(i.price),0);
      const itemNames = (window.cart||[]).map(i=>i.name).join(', ');

      // Check if this session already has an abandoned cart entry
      const existing = (window.abandonedCarts||[]).findIndex(a => a.phone === phone);
      const entry = {
        phone, name, addr,
        items: itemNames,
        cart: JSON.parse(JSON.stringify(window.cart)),
        total: rawTotal,
        at: new Date().toISOString()
      };

      if (existing >= 0) {
        window.abandonedCarts[existing] = entry; // Update
      } else {
        if (!window.abandonedCarts) window.abandonedCarts = [];
        window.abandonedCarts.push(entry);
      }

      // Save to localStorage (don't call full persistAll to avoid recursion)
      try { localStorage.setItem('abandonedCarts', JSON.stringify(window.abandonedCarts)); } catch(e) {}
    }

    /* ════════════════════════════════════════════════════════
       2. placeOrder FIX — addr select "new address" bug
       ════════════════════════════════════════════════════════
       Bug: when user has saved addresses and selects "+ New Address",
       addrSel.value = '' but addrNew is hidden. Fix: force show addrNew
       when value is empty, and read from addrNew.
    ════════════════════════════════════════════════════════ */
    const _origPlaceOrder = window.placeOrder;
    window.placeOrder = function () {
      // Fix: if custAddr select value is '' and custAddrNew exists, use custAddrNew value
      const addrSel = document.getElementById('custAddr');
      const addrNew = document.getElementById('custAddrNew');
      if (addrSel && addrNew && addrSel.value === '' && addrNew.classList.contains('hidden')) {
        // addrNew is hidden but empty — this means "no saved addresses" single input case
        // nothing to fix here
      }
      if (addrSel && addrNew && addrSel.value === '' && !addrNew.classList.contains('hidden')) {
        // User selected "+New Address" and typed in addrNew — good
      }
      // Handle edge case: addrSel is a text input (no saved addresses)
      // In this case value should be direct
      if (_origPlaceOrder) _origPlaceOrder();

      // After successful order placement, remove from abandoned carts
      const phoneEl = document.getElementById('custPhone');
      const phone = phoneEl?.value.trim() || '';
      if (phone && window.abandonedCarts) {
        window.abandonedCarts = window.abandonedCarts.filter(a => a.phone !== phone);
        try { localStorage.setItem('abandonedCarts', JSON.stringify(window.abandonedCarts)); } catch(e) {}
      }
    };

    /* ════════════════════════════════════════════════════════
       3. ADMIN — Add "Media" tab + render function
       ════════════════════════════════════════════════════════ */

    // Inject Media tab button into admin panel
    function injectMediaTab() {
      const adminPanel = document.getElementById('adminPanel');
      if (!adminPanel) return;

      // Find the tab row (first flex div inside adminPanel)
      const tabRow = adminPanel.querySelector('.flex.flex-wrap');
      if (!tabRow) return;

      // Check if already injected
      if (tabRow.querySelector('[data-media-tab]')) return;

      // Find "📄 Pages" button to insert before it
      const pagesBtn = [...tabRow.querySelectorAll('button')].find(b => b.textContent.includes('Pages'));
      const mediaBtn = document.createElement('button');
      mediaBtn.setAttribute('data-media-tab', '1');
      mediaBtn.className = 'adm-tab px-3 py-1.5 rounded-lg surface text-sm whitespace-nowrap';
      mediaBtn.textContent = '🖼️ Media';
      mediaBtn.onclick = () => adminTab('media');

      if (pagesBtn) {
        tabRow.insertBefore(mediaBtn, pagesBtn);
      } else {
        // Add before logout button
        const logoutBtn = [...tabRow.querySelectorAll('button')].find(b=>b.textContent.includes('Logout'));
        if (logoutBtn) tabRow.insertBefore(mediaBtn, logoutBtn);
        else tabRow.appendChild(mediaBtn);
      }
    }

    // Patch adminTab to handle 'media'
    const _origAdminTab = window.adminTab;
    window.adminTab = function (t) {
      if (t === 'media') {
        // Highlight tab
        document.querySelectorAll('.adm-tab').forEach(b => b.classList.remove('tab-active'));
        document.querySelectorAll('.adm-tab').forEach(b => {
          if (b.getAttribute('data-media-tab') || b.onclick?.toString().includes("'media'")) {
            b.classList.add('tab-active');
          }
        });
        renderAdmMedia();
        return;
      }
      if (_origAdminTab) _origAdminTab(t);
    };

    // Watch for admin panel to open, then inject tab
    const observer = new MutationObserver(() => {
      const ap = document.getElementById('adminPanel');
      if (ap && !ap.classList.contains('hidden')) {
        injectMediaTab();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });

    // Also try immediately
    injectMediaTab();

    /* ── Media Library Render ── */
    async function renderAdmMedia() {
      const cont = document.getElementById('admContent');
      if (!cont) return;

      // Collect all images from products
      const allImages = new Map(); // url → { url, productName, productId }
      (window.products || []).forEach(p => {
        const imgs = Array.isArray(p.images) ? p.images : (p.image ? [p.image] : []);
        imgs.filter(Boolean).forEach(url => {
          if (!allImages.has(url)) {
            allImages.set(url, { url, productName: p.name, productId: p.id });
          }
        });
      });
      const imageList = Array.from(allImages.values());

      cont.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:8px;">
          <div>
            <h3 style="font-weight:800;font-size:17px;">🖼️ Media Library</h3>
            <p style="font-size:12px;color:var(--c-muted);">${imageList.length} images · Products-ல் உள்ள அனைத்து images</p>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <label for="mediaUploadBtn" class="btn-primary px-4 py-2 rounded-lg text-sm font-bold cursor-pointer" style="display:inline-flex;align-items:center;gap:6px;">
              📤 Upload Image
            </label>
            <input type="file" id="mediaUploadBtn" accept="image/*" multiple style="display:none" onchange="handleAdmMediaUpload(this)"/>
          </div>
        </div>

        <div id="uploadProgress" style="display:none;" class="surface p-3 mb-3" style="background:#f0fdf4;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="width:20px;height:20px;border:2px solid var(--c-border);border-top-color:var(--c-primary);border-radius:50%;animation:spin .7s linear infinite;"></div>
            <span id="uploadProgressText" style="font-size:13px;">Uploading...</span>
          </div>
        </div>

        ${!imageList.length ? `
          <div style="text-align:center;padding:60px 20px;color:var(--c-muted);">
            <div style="font-size:56px;margin-bottom:12px;">🖼️</div>
            <p style="font-size:15px;font-weight:600;">No media yet</p>
            <p style="font-size:13px;margin-top:6px;">Products-ல் images add செய்தால் இங்கே காட்டும்</p>
          </div>
        ` : `
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px;" id="mediaGridAdm">
            ${imageList.map((img, i) => `
              <div style="border-radius:12px;overflow:hidden;background:var(--c-bg);border:1px solid var(--c-border);position:relative;">
                <div style="aspect-ratio:1;overflow:hidden;cursor:pointer;" onclick="admPreviewImage('${img.url.replace(/'/g,"\\'")}')">
                  <img src="${img.url}" style="width:100%;height:100%;object-fit:cover;" loading="lazy"
                    onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"/>
                  <div style="display:none;align-items:center;justify-content:center;height:100%;font-size:32px;">🖼️</div>
                </div>
                <div style="padding:6px 8px;">
                  <p style="font-size:10px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${img.productName}</p>
                </div>
                <div style="position:absolute;top:6px;right:6px;display:flex;gap:4px;">
                  <button onclick="admCopyUrl('${img.url.replace(/'/g,"\\'")}',this)"
                    style="background:rgba(255,255,255,.9);border:none;border-radius:6px;padding:4px 6px;font-size:11px;cursor:pointer;font-weight:700;" title="Copy URL">📋</button>
                </div>
              </div>`).join('')}
          </div>
        `}

        <div style="margin-top:24px;" class="surface p-4">
          <h4 style="font-weight:700;margin-bottom:10px;font-size:14px;">📤 URL பயன்படுத்தி Add செய்யவும்</h4>
          <p style="font-size:12px;color:var(--c-muted);margin-bottom:10px;">
            Paste any image URL to use it directly in a product.
            Products → Edit → Images-ல் paste செய்யவும்.
          </p>
          <div style="display:flex;gap:8px;">
            <input id="mediaUrlInput" class="input-c" style="flex:1;" placeholder="https://example.com/image.jpg" type="url"/>
            <button onclick="admTestImageUrl()" class="btn-primary px-3 py-2 rounded-lg text-sm">Test URL</button>
          </div>
          <div id="urlTestResult" style="margin-top:10px;"></div>
        </div>`;

      // Add CSS if not present
      if (!document.getElementById('media-spin-css')) {
        const s = document.createElement('style');
        s.id = 'media-spin-css';
        s.textContent = '@keyframes spin{to{transform:rotate(360deg)}}';
        document.head.appendChild(s);
      }
    }

    window.admPreviewImage = function (url) {
      // Show image in a modal overlay
      const existing = document.getElementById('mediaPreviewModal');
      if (existing) existing.remove();
      const modal = document.createElement('div');
      modal.id = 'mediaPreviewModal';
      modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:500;display:flex;align-items:center;justify-content:center;padding:16px;';
      modal.innerHTML = `
        <div style="max-width:600px;width:100%;position:relative;">
          <button onclick="document.getElementById('mediaPreviewModal').remove()"
            style="position:absolute;top:-40px;right:0;background:rgba(255,255,255,.2);border:none;color:#fff;width:32px;height:32px;border-radius:50%;font-size:18px;cursor:pointer;">×</button>
          <img src="${url}" style="width:100%;border-radius:12px;max-height:80vh;object-fit:contain;" loading="lazy"/>
          <div style="background:rgba(255,255,255,.1);padding:10px;border-radius:8px;margin-top:10px;display:flex;gap:8px;align-items:center;">
            <input value="${url}" readonly style="flex:1;background:rgba(255,255,255,.15);border:none;color:#fff;padding:6px 10px;border-radius:6px;font-size:12px;font-family:monospace;"/>
            <button onclick="admCopyUrl('${url.replace(/'/g,"\\'")}',this)" style="background:#fff;color:var(--c-primary,#6366f1);border:none;padding:6px 12px;border-radius:6px;font-weight:700;font-size:12px;cursor:pointer;">📋 Copy</button>
          </div>
        </div>`;
      modal.onclick = e => { if (e.target===modal) modal.remove(); };
      document.body.appendChild(modal);
    };

    window.admCopyUrl = function (url, btn) {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(() => {
          const orig = btn.textContent;
          btn.textContent = '✅';
          setTimeout(() => btn.textContent = orig, 1500);
          if (typeof window.toast === 'function') window.toast('📋 URL copied!');
        });
      } else {
        // Fallback
        const ta = document.createElement('textarea');
        ta.value = url; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); document.body.removeChild(ta);
        if (typeof window.toast === 'function') window.toast('📋 Copied!');
      }
    };

    window.admTestImageUrl = function () {
      const url = document.getElementById('mediaUrlInput')?.value.trim();
      const res = document.getElementById('urlTestResult');
      if (!url || !url.startsWith('http')) { res.innerHTML='<p style="font-size:12px;color:#ef4444;">⚠️ Valid URL enter செய்யவும்</p>'; return; }
      res.innerHTML = `<div style="text-align:center;padding:12px;">
        <img src="${url}" style="max-height:200px;border-radius:10px;" loading="lazy"
          onload="this.nextElementSibling.style.display='none'"
          onerror="this.style.display='none';this.nextElementSibling.textContent='❌ Image load failed'"/>
        <p style="font-size:12px;color:var(--c-muted);">Loading...</p>
        <div style="margin-top:8px;display:flex;gap:6px;justify-content:center;">
          <button onclick="admCopyUrl('${url}',this)" class="btn-primary px-3 py-1.5 rounded-lg text-xs">📋 Copy URL</button>
        </div>
      </div>`;
    };

    window.handleAdmMediaUpload = async function (input) {
      const files = Array.from(input.files);
      if (!files.length) return;
      const prog = document.getElementById('uploadProgress');
      const progText = document.getElementById('uploadProgressText');
      if (prog) prog.style.display='block';
      let uploaded = 0;
      const uploadedUrls = [];
      for (const file of files) {
        if (progText) progText.textContent = `Uploading ${file.name}... (${uploaded+1}/${files.length})`;
        // Use the uploadImageToServer helper from api-bridge.js if available
        if (typeof window.uploadImageToServer === 'function') {
          await new Promise((resolve) => {
            window.uploadImageToServer(file,
              url => { uploadedUrls.push(url); uploaded++; resolve(); },
              err => { if (typeof window.toast==='function') window.toast('❌ '+err); resolve(); }
            );
          });
        } else {
          // Fallback: convert to data URL and show
          await new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = e => {
              uploadedUrls.push(e.target.result);
              uploaded++;
              resolve();
            };
            reader.readAsDataURL(file);
          });
        }
      }
      if (prog) prog.style.display='none';
      input.value='';
      if (typeof window.toast==='function') window.toast(`✅ ${uploaded}/${files.length} uploaded!`);
      // Refresh media view
      if (typeof window.renderAdmMedia === 'function') window.renderAdmMedia();
      else window.adminTab('media');
    };

    // expose renderAdmMedia globally
    window.renderAdmMedia = renderAdmMedia;

    console.log('[cart-media-patch] Loaded: abandoned cart fix + media library');
  });
})();
