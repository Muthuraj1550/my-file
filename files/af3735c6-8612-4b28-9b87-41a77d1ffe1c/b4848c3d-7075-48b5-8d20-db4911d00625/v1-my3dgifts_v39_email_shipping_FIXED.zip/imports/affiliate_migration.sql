-- ============================================================
--  V34 Affiliate Migration — run once in phpMyAdmin
--  (SQL is also idempotent and re-runs safely inside api/affiliate.php)
-- ============================================================

CREATE TABLE IF NOT EXISTS `affiliate_products` (
  `id`            VARCHAR(40) PRIMARY KEY,
  `title`         VARCHAR(255) NOT NULL,
  `image`         TEXT,
  `price`         DECIMAL(10,2) DEFAULT 0,
  `source`        VARCHAR(40) NOT NULL DEFAULT 'amazon',
  `affiliate_url` TEXT NOT NULL,
  `show_on_home`  TINYINT(1) DEFAULT 0,
  `active`        TINYINT(1) DEFAULT 1,
  `sort_order`    INT DEFAULT 999,
  `click_count`   INT DEFAULT 0,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `affiliate_clicks` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `affiliate_id` VARCHAR(40) NOT NULL,
  `source`       VARCHAR(40),
  `click_date`   DATE NOT NULL,
  `ip`           VARCHAR(64),
  `ua`           VARCHAR(255),
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_aff_id` (`affiliate_id`),
  KEY `idx_aff_date` (`click_date`),
  KEY `idx_aff_source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
