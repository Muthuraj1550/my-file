# Product Import (from old WordPress site)

This folder contains **21 products** extracted from your old WooCommerce
database (`mydgift1_wp20.sql`) ready to import into the new site
(`my.my3dgifts.in` — the duplicate / temporary site).

## Files

| File | Purpose |
|---|---|
| `products_import.sql` | INSERT IGNORE statements for the `products` table |
| `run-import.php`      | One-click web importer (admin protected) |
| `IMAGES_NEEDED.txt`   | Full list of image filenames each product expects in `/uploads/` |

## How to import (choose ONE method)

### Method A — One-click (easiest)
1. Upload the whole folder `imports/` to your site root.
2. Open in browser while logged in as admin:
   `https://my.my3dgifts.in/imports/run-import.php`

### Method B — phpMyAdmin
1. Open phpMyAdmin → select the database (`mydgift1_new55`).
2. Import tab → choose `products_import.sql` → Go.

### Method C — MySQL CLI
```bash
mysql -u USER -p mydgift1_new55 < imports/products_import.sql
```

The SQL uses `INSERT IGNORE`, so re-running it is safe and will not
overwrite or duplicate existing products.

## Images

Each product has the original WordPress image filenames already wired in
(stored as `/uploads/<filename>`). You just need to upload the actual
image files to the `/uploads/` folder on your hosting. The full list is
in `IMAGES_NEEDED.txt` (53 unique files).

Easiest way to grab them: log into your old WordPress hosting via FTP /
cPanel File Manager and download everything under
`wp-content/uploads/2024/` and `wp-content/uploads/2023/`, then upload
those same files into `/uploads/` on the new site.

You can also re-upload them through **Admin Panel → Media** — keep the
same filenames and the products will auto-link.

## SEO / AI ranking

- Product **names are kept verbatim** from the old site (they are
  already keyword-stuffed for Google + AI search: e.g.
  *"Big Size 3D Flip name - Couple 3D Name Gifts - My 3d gifts
  Personalized 3d print Gifts in Tamil Nadu"*).
- Each product has an `options.seo` block with `title`, `metaDescription`,
  `keywords`, `ogTitle`, `ogDescription`, and the original WP `slug`.
- The same slug from your old WordPress URLs is preserved, so once you
  add 301 redirects you keep your SEO juice from Google.

## After import — customize

Open **Admin Panel → Products → Edit** for each one to:
- Tweak the price (many products had `0` in the WP dump — you may need
  to fill these in).
- Add size / material / color / photo options.
- Mark featured products.
- Reorder display.
