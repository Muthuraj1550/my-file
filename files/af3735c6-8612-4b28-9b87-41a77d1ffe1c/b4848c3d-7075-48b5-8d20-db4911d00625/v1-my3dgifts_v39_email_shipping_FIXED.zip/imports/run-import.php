<?php
// imports/run-import.php — one-click product importer
// Run: open in browser while logged in as admin, or visit:
//   https://my.my3dgifts.in/imports/run-import.php?key=YOUR_ADMIN_KEY
// Safe: uses INSERT IGNORE, will not duplicate or overwrite existing products.

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../api/admin-auth.php';

// Allow either logged-in admin session OR ?key= matching ADMIN_KEY in config.php
$ok = false;
if (function_exists('isAdmin') && isAdmin()) $ok = true;
if (!$ok && defined('ADMIN_KEY') && isset($_GET['key']) && hash_equals(ADMIN_KEY, $_GET['key'])) $ok = true;

if (!$ok) {
    http_response_code(403);
    echo "Forbidden. Login as admin or pass ?key=ADMIN_KEY";
    exit;
}

$sqlFile = __DIR__ . '/products_import.sql';
if (!is_file($sqlFile)) {
    http_response_code(500);
    echo "products_import.sql not found.";
    exit;
}

$db = getDB();
$sql = file_get_contents($sqlFile);

echo "<pre>";
echo "Running products_import.sql ...\n";
try {
    $db->exec($sql);
    $count = (int)$db->query("SELECT COUNT(*) FROM products WHERE id LIKE 'p_wp_%'")->fetchColumn();
    echo "✅ Done. Imported product rows currently in DB: $count\n\n";
    echo "Next steps:\n";
    echo "1. Upload product images to /uploads/ (see IMAGES_NEEDED.txt).\n";
    echo "2. Go to Admin Panel → Products to review / customize.\n";
} catch (Throwable $e) {
    http_response_code(500);
    echo "❌ Import failed: " . htmlspecialchars($e->getMessage()) . "\n";
}
echo "</pre>";
