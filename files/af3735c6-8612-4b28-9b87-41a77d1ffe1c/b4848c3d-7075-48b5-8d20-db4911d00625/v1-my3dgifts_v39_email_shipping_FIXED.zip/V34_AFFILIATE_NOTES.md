# V34 — Affiliate Products Feature

## என்ன புதிது?

`Amazon / Flipkart / Meesho` (+ Other) ஆகியவற்றிலிருந்து உங்கள் affiliate
links-ஐ admin-ல் சேர்த்து, shop-ல் **🔗 Affiliate** என்ற தனி tab-ல் மட்டும்
காண்பிக்கலாம். மற்ற tabs (All / Customize / Readymade / Others)-ல் இவை
எப்போதும் வராது.

## எப்படி இயக்க வேண்டும்?

1. **Files upload** — இந்த zip-ஐ extract செய்து server-க்கு upload செய்யுங்கள்.
   - புதிய files:
     - `api/affiliate.php`
     - `assets/affiliate-admin.js`
     - `assets/affiliate-shop.js`
     - `imports/affiliate_migration.sql`
   - மாற்றப்பட்ட files:
     - `api/index.php` (`affiliate` route சேர்க்கப்பட்டது)
     - `admin-app.html` (admin script tag)
     - `index.html` (shop script tag)

2. **SQL** — phpMyAdmin → SQL tab-ல் `imports/affiliate_migration.sql`-ஐ
   paste செய்து Go. (API தானாகவே `CREATE TABLE IF NOT EXISTS` run செய்யும்,
   ஆனால் முதலில் ஒரு manual run பாதுகாப்பானது.)

3. **Admin** — Admin panel திறக்கவும். Sidebar-ல் `🔗 Affiliate` link
   தோன்றும். Click செய்து:
   - **+ Add Affiliate Product** — Title, Source, Affiliate URL, Image,
     Price சேர்க்கவும்.
   - **Show on Home** check செய்தால் home page-ல் (optional) காட்டலாம்.
   - **Active** uncheck செய்தால் shop-ல் hide ஆகும்.

4. **Shop** — Customer-facing site `index.html`-ல் product type carousel-ல்
   `🔗 Affiliate` tab தானாக வரும். Click செய்தால் affiliate cards காட்டப்படும்.
   Card click → click DB-ல் log ஆகி, புதிய tab-ல் affiliate URL திறக்கும்.

## Analytics

Affiliate page மேல் பகுதியிலேயே:
- Total clicks
- Clicks per source (Amazon / Flipkart / Meesho / Other) — bar chart
- Top performing products — table
- Per-product click count card-ல் காட்டப்படும்

## API (reference)

| Method | Path                                | Auth   | Description |
|--------|-------------------------------------|--------|-------------|
| GET    | `/api/affiliate`                    | public | Active products |
| GET    | `/api/affiliate?all=1`              | admin  | All products |
| GET    | `/api/affiliate/{id}`               | public | One product |
| POST   | `/api/affiliate`                    | admin  | Create |
| PUT    | `/api/affiliate/{id}`               | admin  | Update |
| DELETE | `/api/affiliate/{id}`               | admin  | Delete (+clicks) |
| POST   | `/api/affiliate/click/{id}`         | public | Track click → returns URL |
| GET    | `/api/affiliate/analytics`          | admin  | Aggregated stats |

## Home page-ல் காட்ட (optional)

`index.html`-ல் எங்காவது:

```html
<div id="affiliateHomeBlock"></div>
<script>
  window.addEventListener('load', ()=> {
    window.renderAffiliateHome?.(document.getElementById('affiliateHomeBlock'));
  });
</script>
```

`Show on Home` checked products மட்டுமே 6 cards வரை வரும்.

## பாதுகாப்பு

- Admin CRUD endpoints `X-Admin-Key` header header-ஐ verify செய்கின்றன
  (existing `requireAdmin()` mechanism).
- Click endpoint public — ஆனால் URL validation (`http(s)://`) + safe
  redirect மட்டுமே செய்யப்படும்.
- Affiliate products `products` table-ஐ touch செய்வதில்லை — existing
  shop logic untouched.
