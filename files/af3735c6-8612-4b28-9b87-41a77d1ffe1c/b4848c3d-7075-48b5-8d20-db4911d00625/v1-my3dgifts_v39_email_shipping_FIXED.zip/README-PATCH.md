# MY 3D Gifts — v18.2 PATCH (Part 1 of 2)

## 🎯 இந்த ZIP-ல் என்ன இருக்கிறது

### ✅ புதிய Files (உங்கள் hosting-ல் /api/ folder-ல் upload செய்யவும்)
- `api/_mailer.php` — SMTP email sender (PHPMailer தேவையில்லை)
- `api/_email_templates.php` — அழகான HTML email templates (Tamil/English)
- `api/email.php` — Email API endpoint

### 🔄 Replace செய்ய வேண்டிய files (existing-ஐ overwrite)
- `api/index.php` — `email` route சேர்க்கப்பட்டது
- `api/products.php` — **DELETE BUG FIX** (உண்மையில் delete ஆகும், hide ஆக மாட்டாது) + bulk-delete endpoint
- `api/orders.php` — Bulk delete + bulk status update + auto-email triggers
- `admin-app.html` — Orders multi-select UI + bulk status update + email send checkbox

---

## 📤 Upload Steps (Hostinger / cPanel File Manager)

1. **Backup** முதலில்: `api/` folder மற்றும் `admin-app.html` files-ஐ download செய்து வைத்துக்கொள்ளவும்.
2. இந்த ZIP-ஐ extract செய்து, files-ஐ உங்கள் site root-க்கு upload செய்யவும் (existing-ஐ overwrite செய்யவும்).
3. **SMTP Setup** (கீழே 'SMTP Setup' பகுதி பார்க்கவும்).

---

## 📧 SMTP Setup (உங்கள் domain mail இயங்க)

உங்கள் hosting-ல் ஏற்கனவே email account இருக்கும் (உதா: `orders@my3dgifts.com`). அதன் SMTP credentials-ஐ settings-ல் save செய்ய வேண்டும்.

### Option A: phpMyAdmin மூலம் (இப்போதைக்கு)
phpMyAdmin → SQL tab → கீழே உள்ளதை paste செய்யவும் (உங்கள் values-ஐ replace செய்யவும்):

```sql
INSERT INTO settings (skey, svalue) VALUES (
  'smtp',
  '{"host":"smtp.hostinger.com","port":465,"secure":"ssl","user":"orders@yourdomain.com","pass":"YOUR_EMAIL_PASSWORD","fromName":"MY 3D Gifts","fromEmail":"orders@yourdomain.com","replyTo":"orders@yourdomain.com"}'
)
ON DUPLICATE KEY UPDATE svalue = VALUES(svalue);
```

**Hostinger:** `smtp.hostinger.com`, port `465`, secure `ssl`
**Gmail:** `smtp.gmail.com`, port `465`, secure `ssl` (App Password use செய்யவும்)
**cPanel mail:** `mail.yourdomain.com`, port `465`, secure `ssl`

### SMTP Test
Browser console-ல் (admin login செய்த பிறகு):
```js
fetch('/api/email/test', {
  method:'POST',
  headers:{'Content-Type':'application/json','X-Admin-Key':localStorage.getItem('ADMIN_KEY')},
  body: JSON.stringify({to:'your-test-email@gmail.com'})
}).then(r=>r.json()).then(console.log)
```
`{ok:true, data:{sent:true}}` வந்தால் SMTP work ஆகிறது!

---

## 📬 Auto-Email எப்போது அனுப்பப்படும்

| Trigger | Email type |
|---|---|
| புதிய ஆர்டர் place ஆகும்போது (online) | ✅ **Order Confirmed** |
| Admin Tracking Number / Courier add செய்யும்போது | 📦 **Tracking Update** |
| Admin Status = "Shipped" / "Dispatch" மாற்றும்போது | 📦 **Tracking Update** |
| Admin Status = "Delivered" மாற்றும்போது | 🎉 **Delivered** |
| Bulk status update (admin checkbox enabled) | ✅ அனைத்தும் |
| Cart Recovery (manual trigger) | 🛒 **Cart Recovery** |

**குறிப்பு:** Email அனுப்பப்படுவதற்கு order-ல் valid `customer_email` இருக்க வேண்டும்.

---

## 🐛 Fixed Bugs

### 1. Product Delete Bug ✅
**முன்பு:** Delete button click → `active=0` மட்டுமே (hide). மீண்டும் delete செய்தால் "already deleted" ஆகாமல் same hidden product மீண்டும் காட்டப்படும்.
**இப்போது:** Delete button → DB-ல் இருந்து **உண்மையில் remove** ஆகிறது.

### 2. Orders Multi-Select ✅
- "எல்லாவற்றையும் தேர்ந்தெடு" checkbox
- Bulk delete (multiple orders ஒரே நேரத்தில்)
- Bulk status update + auto-email checkbox
- Selected count display

---

## 🔜 அடுத்த Patch-ல் வரும் (Part 2)

- Product Image fix (cover image robust loading)
- Product modal-ல் "Media library-லிருந்து தேர்வு" button
- Order modal-ல் "📧 Send Email Now" buttons (manual trigger)
- Cart Recovery page-ல் "📧 Email send" button
- Admin Settings → Email Setup tab (SMTP UI)

இவை இப்போதைய urgent fixes-ஐ test செய்த பிறகு, "Part 2 patch அனுப்பு" என்று கூறினால் உருவாக்குகிறேன்.

---

## ⚠️ Important Notes

1. **DB schema change இல்லை** — install.sql-ஐ மீண்டும் run செய்ய வேண்டாம்.
2. `email_log` table auto-create ஆகும் (first email send-ல்).
3. SMTP errors ஏதேனும் இருந்தால் `email_log.err` column-ல் store ஆகும். phpMyAdmin-ல் check செய்யலாம்.
4. Hostinger free plan-ல் outgoing SMTP block இருக்கலாம் — premium plan / Gmail SMTP use செய்யவும்.
