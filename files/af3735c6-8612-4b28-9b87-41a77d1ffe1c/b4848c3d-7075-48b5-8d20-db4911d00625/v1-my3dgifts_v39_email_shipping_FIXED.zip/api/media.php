<?php
// api/media.php — v32: list/delete + bulk + folders
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
$db = getDB();

$db->exec("CREATE TABLE IF NOT EXISTS media (
    id INT AUTO_INCREMENT PRIMARY KEY, url VARCHAR(500) NOT NULL,
    name VARCHAR(255), mime VARCHAR(60), size INT DEFAULT 0,
    thumb VARCHAR(500) NULL, folder VARCHAR(60) DEFAULT 'general',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Auto-heal columns
$cols = $db->query("SHOW COLUMNS FROM media")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array('thumb', $cols, true))  $db->exec("ALTER TABLE media ADD COLUMN thumb VARCHAR(500) NULL");
if (!in_array('folder', $cols, true)) $db->exec("ALTER TABLE media ADD COLUMN folder VARCHAR(60) DEFAULT 'general'");

function mediaRow(array $r): array {
    return [
        'id'        => (int)$r['id'],
        'url'       => $r['url'],
        'name'      => $r['name'],
        'mime'      => $r['mime'],
        'size'      => (int)$r['size'],
        'thumb'     => $r['thumb'] ?? '',
        'folder'    => $r['folder'] ?? 'general',
        'createdAt' => $r['created_at'],
    ];
}

function deleteOneMedia(PDO $db, int $id): void {
    $row = $db->prepare("SELECT url, thumb FROM media WHERE id=?");
    $row->execute([$id]);
    $r = $row->fetch();
    if ($r) {
        foreach (['url','thumb'] as $k) {
            if (!empty($r[$k])) {
                $file = __DIR__ . '/..' . $r[$k];
                if (is_file($file)) @unlink($file);
            }
        }
    }
    $db->prepare("DELETE FROM media WHERE id=?")->execute([$id]);
}

if ($method === 'GET') {
    requireAdmin();
    // Sub-routes
    if ($id === 'folders') {
        $rows = $db->query("SELECT folder, COUNT(*) c FROM media GROUP BY folder ORDER BY folder")->fetchAll();
        jsonOk($rows);
    }
    $rows = $db->query("SELECT * FROM media ORDER BY id DESC LIMIT 1000")->fetchAll();
    jsonOk(array_map('mediaRow', $rows));
}

if ($method === 'POST') {
    requireAdmin();
    $body = jsonBody();
    // Bulk delete
    if ($id === 'bulk-delete') {
        $ids = array_map('intval', $body['ids'] ?? []);
        foreach ($ids as $iid) deleteOneMedia($db, $iid);
        jsonOk(['deleted' => count($ids)]);
    }
    // Bulk move (assign folder)
    if ($id === 'bulk-move') {
        $ids = array_map('intval', $body['ids'] ?? []);
        $folder = trim($body['folder'] ?? 'general');
        if (!preg_match('/^[a-zA-Z0-9_-]{1,40}$/', $folder)) jsonError('Bad folder name');
        if (!$ids) jsonError('No ids');
        $in = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $db->prepare("UPDATE media SET folder=? WHERE id IN ($in)");
        $stmt->execute(array_merge([$folder], $ids));
        jsonOk(['moved' => count($ids), 'folder' => $folder]);
    }
    jsonError('Unknown action', 400);
}

if ($method === 'DELETE') {
    requireAdmin();
    if (!$id) jsonError('Missing id', 400);
    deleteOneMedia($db, (int)$id);
    jsonOk(['deleted' => (int)$id]);
}

jsonError('Method not allowed', 405);
