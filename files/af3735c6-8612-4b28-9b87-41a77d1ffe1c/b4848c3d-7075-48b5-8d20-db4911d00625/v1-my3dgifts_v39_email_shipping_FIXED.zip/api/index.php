<?php
// ============================================================
//  MY 3D Gifts — api/index.php  (API Router) — v18.2 patch
//  Routes: GET/POST /api/{resource}[/{id}]
// ============================================================
require_once __DIR__ . '/../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$uri    = $_SERVER['REQUEST_URI'];

// Strip query string and leading /api/
$path = parse_url($uri, PHP_URL_PATH);
$path = preg_replace('#^.*/api/?#', '', $path);
$path = trim($path, '/');

$segments = explode('/', $path);
$resource = $segments[0] ?? '';
$id       = $segments[1] ?? null;

switch ($resource) {
    case 'settings':    require_once __DIR__ . '/settings.php'; break;
    case 'theme':       require_once __DIR__ . '/theme.php'; break;
    case 'products':    require_once __DIR__ . '/products.php'; break;
    case 'orders':      require_once __DIR__ . '/orders.php'; break;
    case 'users':       require_once __DIR__ . '/users.php'; break;
    case 'coupons':     require_once __DIR__ . '/coupons.php'; break;
    case 'flash':       require_once __DIR__ . '/flash.php'; break;
    case 'wishlist':    require_once __DIR__ . '/wishlist.php'; break;
    case 'upload':      require_once __DIR__ . '/upload.php'; break;
    case 'admin-auth':  require_once __DIR__ . '/admin-auth.php'; break;
    case 'track':       require_once __DIR__ . '/track.php'; break;
    case 'views':       require_once __DIR__ . '/views.php'; break;
    case 'popups':      require_once __DIR__ . '/popups.php'; break;
    case 'abandoned':   require_once __DIR__ . '/abandoned.php'; break;
    case 'pages':       require_once __DIR__ . '/pages.php'; break;
    case 'media':       require_once __DIR__ . '/media.php'; break;
    case 'backup':      require_once __DIR__ . '/backup.php'; break;
    case 'accounts':    require_once __DIR__ . '/accounts.php'; break;
    case 'email':       require_once __DIR__ . '/email.php'; break;   // ← NEW
    case 'fix-images':  require_once __DIR__ . '/fix-images.php'; break; // v21
    case 'coins':       require_once __DIR__ . '/coins.php'; break;      // v22 loyalty
    case 'affiliate':   require_once __DIR__ . '/affiliate.php'; break;
    case 'cashfree':    require_once __DIR__ . '/cashfree.php'; break;   // v26 real payment
    default:            jsonError('Unknown endpoint', 404);
}
