<?php
// api/_email_templates.php — Beautiful HTML email templates

function emailLayout(string $title, string $body, array $brand = []): string {
    $store = htmlspecialchars($brand['storeName'] ?? 'MY 3D Gifts');
    $primary = htmlspecialchars($brand['primary'] ?? '#6366f1');
    $logoUrl = htmlspecialchars($brand['logoUrl'] ?? '');
    $logo = $logoUrl ? "<img src=\"$logoUrl\" alt=\"$store\" style=\"max-height:48px;\">" : "<div style=\"font-size:22px;font-weight:800;color:#fff;\">$store</div>";
    return <<<HTML
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>$title</title></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a;">
<div style="max-width:600px;margin:0 auto;background:#ffffff;">
  <div style="background:$primary;padding:24px;text-align:center;">$logo</div>
  <div style="padding:28px 24px;">$body</div>
  <div style="padding:18px 24px;background:#f8fafc;border-top:1px solid #e2e8f0;text-align:center;color:#64748b;font-size:12px;">
    &copy; $store &middot; For any queries related to this order, you can reply to this email.
  </div>
</div>
</body></html>
HTML;
}

function emailButton(string $label, string $url, string $color = '#6366f1'): string {
    $label = htmlspecialchars($label);
    $url = htmlspecialchars($url);
    return "<div style=\"text-align:center;margin:24px 0;\"><a href=\"$url\" style=\"background:$color;color:#fff;padding:13px 28px;border-radius:10px;text-decoration:none;font-weight:700;display:inline-block;\">$label</a></div>";
}

function tplCartRecovery(array $cart, array $brand): array {
    $name = htmlspecialchars($cart['customerName'] ?? 'Valued Customer');
    $itemsHtml = '';
    $total = number_format((float)($cart['total'] ?? 0), 2);
    foreach (($cart['items'] ?? []) as $it) {
        $n = htmlspecialchars($it['name'] ?? '');
        $q = (int)($it['quantity'] ?? 1);
        $p = number_format((float)($it['price'] ?? 0), 2);
        $itemsHtml .= "<tr><td style=\"padding:8px;border-bottom:1px solid #e2e8f0;\">$n</td><td style=\"padding:8px;border-bottom:1px solid #e2e8f0;text-align:center;\">&times;$q</td><td style=\"padding:8px;border-bottom:1px solid #e2e8f0;text-align:right;\">&curren;$p</td></tr>";
    }
    $store = $brand['storeName'] ?? 'MY 3D Gifts';
    $url = $brand['siteUrl'] ?? '#';
    $body = "<h2 style=\"margin:0 0 12px;color:#0f172a;\">Hello $name 👋</h2>
<p style=\"line-height:1.6;color:#475569;\">You left some beautiful gifts in your cart! The items below are still waiting for you — complete your checkout in just one click.</p>
<table style=\"width:100%;border-collapse:collapse;margin:18px 0;font-size:14px;\">
<thead><tr style=\"background:#f8fafc;\"><th style=\"padding:8px;text-align:left;\">Product</th><th style=\"padding:8px;\">Qty</th><th style=\"padding:8px;text-align:right;\">Price</th></tr></thead>
<tbody>$itemsHtml</tbody>
<tfoot><tr><td colspan=\"2\" style=\"padding:10px;font-weight:700;\">Total</td><td style=\"padding:10px;text-align:right;font-weight:700;color:#16a34a;\">&curren;$total</td></tr></tfoot>
</table>"
. emailButton('🛒 Complete Your Cart', $url, $brand['primary'] ?? '#6366f1') .
"<p style=\"font-size:12px;color:#94a3b8;text-align:center;\">This offer is limited — complete your order soon!</p>";
    return [
        'subject' => "🎁 Did you forget to complete your cart? · $store",
        'html'    => emailLayout('Cart Recovery', $body, $brand),
    ];
}

function tplOrderConfirmed(array $order, array $brand): array {
    $name = htmlspecialchars($order['customerName'] ?? '');
    $oid  = htmlspecialchars($order['id'] ?? '');
    $trk  = htmlspecialchars($order['tracking'] ?? '');
    $totalNum = (float)($order['total'] ?? 0);
    $shipNum  = (float)($order['shipping'] ?? 0);
    $discNum  = (float)($order['discount'] ?? 0);
    $subtotal = 0;
    $itemsHtml = '';
    foreach (($order['items'] ?? []) as $it) {
        $n = htmlspecialchars($it['name'] ?? '');
        $q = (int)($it['quantity'] ?? 1);
        $pr= (float)($it['price'] ?? 0);
        $subtotal += $pr * $q;
        $p = number_format($pr, 2);
        $itemsHtml .= "<tr><td style=\"padding:8px;border-bottom:1px solid #e2e8f0;\">$n</td><td style=\"padding:8px;border-bottom:1px solid #e2e8f0;text-align:center;\">&times;$q</td><td style=\"padding:8px;border-bottom:1px solid #e2e8f0;text-align:right;\">&#8377;$p</td></tr>";
    }
    // Fallback: infer shipping if not passed but total > subtotal - discount
    if ($shipNum <= 0) {
        $inferred = $totalNum - ($subtotal - $discNum);
        if ($inferred > 0.5) $shipNum = $inferred;
    }
    $subF  = number_format($subtotal, 2);
    $shipF = number_format($shipNum, 2);
    $discF = number_format($discNum, 2);
    $total = number_format($totalNum, 2);
    $addr = htmlspecialchars($order['address'] ?? '');
    $store = $brand['storeName'] ?? 'MY 3D Gifts';
    $summaryRows  = "<tr><td colspan=\"2\" style=\"padding:6px 10px;color:#475569;\">Subtotal (பொருட்கள்)</td><td style=\"padding:6px 10px;text-align:right;color:#475569;\">&#8377;$subF</td></tr>";
    if ($discNum > 0) $summaryRows .= "<tr><td colspan=\"2\" style=\"padding:6px 10px;color:#475569;\">Discount (தள்ளுபடி)</td><td style=\"padding:6px 10px;text-align:right;color:#dc2626;\">- &#8377;$discF</td></tr>";
    $shipLabel = $shipNum > 0 ? "&#8377;$shipF" : "FREE";
    $shipColor = $shipNum > 0 ? "#475569" : "#16a34a";
    $summaryRows .= "<tr><td colspan=\"2\" style=\"padding:6px 10px;color:#475569;\">Shipping / Courier Charges (சேவை கட்டணம்)</td><td style=\"padding:6px 10px;text-align:right;color:$shipColor;font-weight:600;\">$shipLabel</td></tr>";
    $summaryRows .= "<tr><td colspan=\"2\" style=\"padding:10px;font-weight:700;border-top:2px solid #e2e8f0;\">Total (மொத்தம்)</td><td style=\"padding:10px;text-align:right;font-weight:700;color:#16a34a;border-top:2px solid #e2e8f0;\">&#8377;$total</td></tr>";
    $body = "<h2 style=\"margin:0 0 12px;\">✅ Order Confirmed!</h2>
<p style=\"line-height:1.6;color:#475569;\">Hello <b>$name</b>, we have received your order. Production will begin shortly.</p>
<div style=\"background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;margin:14px 0;\">
  <div style=\"font-size:12px;color:#15803d;font-weight:700;\">ORDER ID</div>
  <div style=\"font-size:18px;font-weight:800;color:#0f172a;\">$oid</div>
  <div style=\"font-size:12px;color:#15803d;margin-top:8px;font-weight:700;\">TRACKING ID</div>
  <div style=\"font-size:16px;font-weight:700;color:#0f172a;font-family:monospace;\">$trk</div>
</div>
<table style=\"width:100%;border-collapse:collapse;margin:14px 0;font-size:14px;\">
<thead><tr style=\"background:#f8fafc;\"><th style=\"padding:8px;text-align:left;\">Product</th><th style=\"padding:8px;\">Qty</th><th style=\"padding:8px;text-align:right;\">Price</th></tr></thead>
<tbody>$itemsHtml</tbody>
<tfoot>$summaryRows</tfoot>
</table>
<p style=\"font-size:12px;color:#64748b;margin:-4px 0 12px;\">Note: Total includes courier / shipping charges. (மொத்த தொகையில் கூரியர் கட்டணம் சேர்க்கப்பட்டுள்ளது.)</p>
<p style=\"font-size:13px;color:#475569;\"><b>Delivery Address:</b><br>$addr</p>
<p style=\"font-size:13px;color:#64748b;\">You can always check your order status on our site using your Tracking ID.</p>";
    return [
        'subject' => "✅ Order $oid confirmed · $store",
        'html'    => emailLayout('Order Confirmed', $body, $brand),
    ];
}

function tplTrackingUpdate(array $order, array $brand): array {
    $name = htmlspecialchars($order['customerName'] ?? '');
    $oid  = htmlspecialchars($order['id'] ?? '');
    $courier = htmlspecialchars($order['courier'] ?? 'Courier');
    $awb = htmlspecialchars($order['courierTracking'] ?? '');
    $store = $brand['storeName'] ?? 'MY 3D Gifts';
    $body = "<h2 style=\"margin:0 0 12px;\">📦 Your Order Has Been Dispatched!</h2>
<p style=\"line-height:1.6;color:#475569;\">Hello <b>$name</b>, your parcel has been handed over to our courier partner. Use the tracking ID below to track your shipment in real time.</p>
<div style=\"background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:16px;margin:14px 0;text-align:center;\">
  <div style=\"font-size:12px;color:#1e40af;font-weight:700;\">COURIER PARTNER</div>
  <div style=\"font-size:16px;font-weight:700;\">$courier</div>
  <div style=\"font-size:12px;color:#1e40af;font-weight:700;margin-top:10px;\">TRACKING NUMBER</div>
  <div style=\"font-size:20px;font-weight:800;color:#0f172a;font-family:monospace;letter-spacing:1px;\">$awb</div>
</div>
<p style=\"font-size:13px;color:#64748b;text-align:center;\">Order ID: <code>$oid</code></p>";
    return [
        'subject' => "📦 Your parcel has been dispatched (#$oid) · $store",
        'html'    => emailLayout('Tracking Update', $body, $brand),
    ];
}

function tplDelivered(array $order, array $brand): array {
    $name = htmlspecialchars($order['customerName'] ?? '');
    $oid  = htmlspecialchars($order['id'] ?? '');
    $store = $brand['storeName'] ?? 'MY 3D Gifts';
    $body = "<h2 style=\"margin:0 0 12px;\">🎉 Delivered!</h2>
<p style=\"line-height:1.6;color:#475569;\">Hello <b>$name</b>, your order <b>$oid</b> has been successfully delivered! We hope the gift brings you joy. ❤️</p>
<div style=\"background:#fef3c7;border:1px solid #fde68a;border-radius:10px;padding:16px;text-align:center;margin:14px 0;\">
  <div style=\"font-size:14px;color:#92400e;\">⭐ Your feedback means a lot to us</div>
  <div style=\"margin-top:6px;font-size:13px;color:#78350f;\">Leaving a review helps us serve you even better next time.</div>
</div>
<p style=\"line-height:1.6;color:#475569;\">Come back for your next gift — we always have fresh customizations ready for you.</p>";
    return [
        'subject' => "🎉 Order #$oid delivered · Thank you! · $store",
        'html'    => emailLayout('Delivered', $body, $brand),
    ];
}
