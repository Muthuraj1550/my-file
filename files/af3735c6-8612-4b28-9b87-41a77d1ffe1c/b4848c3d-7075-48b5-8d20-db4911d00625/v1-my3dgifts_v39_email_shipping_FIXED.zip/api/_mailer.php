<?php
// api/_mailer.php — Lightweight SMTP mailer (no external libraries)
// Used by email.php to send transactional emails via your domain SMTP

if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';

/**
 * Send email via SMTP using settings stored in `settings` table:
 *   smtp = {"host":"smtp.hostinger.com","port":465,"secure":"ssl","user":"orders@yourdomain.com","pass":"...","fromName":"MY 3D Gifts","fromEmail":"orders@yourdomain.com","replyTo":"info@yourdomain.com"}
 */
function getSmtpConfig(): array {
    $db = getDB();
    // Try single JSON key 'smtp' first (admin-panel saved format)
    $row = $db->prepare("SELECT svalue FROM settings WHERE skey='smtp'");
    $row->execute();
    $r = $row->fetch();
    if ($r && $r['svalue']) {
        $v = json_decode($r['svalue'], true);
        if (is_string($v)) $v = json_decode($v, true);
        if (is_array($v) && !empty($v['host'])) return $v;
    }
    // Fallback: flat keys (smtp_host, smtp_port, smtp_user, smtp_pass etc.) from manual SQL INSERT
    $rows = $db->query("SELECT skey, svalue FROM settings WHERE skey IN ('smtp_host','smtp_port','smtp_secure','smtp_user','smtp_pass','smtp_from_email','smtp_from_name','admin_email')")->fetchAll();
    if (!$rows) return [];
    $flat = [];
    foreach ($rows as $r2) {
        $v = json_decode($r2['svalue'], true);
        $flat[$r2['skey']] = is_string($v) ? $v : $r2['svalue'];
    }
    if (empty($flat['smtp_host'])) return [];
    // Map flat keys → unified config array
    return [
        'host'      => $flat['smtp_host']       ?? '',
        'port'      => (int)($flat['smtp_port'] ?? 465),
        'secure'    => $flat['smtp_secure']      ?? 'ssl',
        'user'      => $flat['smtp_user']        ?? '',
        'pass'      => $flat['smtp_pass']        ?? '',
        'fromEmail' => $flat['smtp_from_email']  ?? ($flat['smtp_user'] ?? ''),
        'fromName'  => $flat['smtp_from_name']   ?? 'MY 3D Gifts',
        'replyTo'   => $flat['admin_email']      ?? ($flat['smtp_from_email'] ?? ''),
    ];
}

function sendMailSmtp(string $to, string $subject, string $htmlBody, string $textBody = ''): array {
    $cfg = getSmtpConfig();
    if (empty($cfg['host']) || empty($cfg['user']) || empty($cfg['pass'])) {
        return ['ok'=>false, 'error'=>'SMTP not configured. Go to Admin → Settings → Email Setup.'];
    }
    $host     = $cfg['host'];
    $port     = (int)($cfg['port'] ?? 465);
    $secure   = strtolower($cfg['secure'] ?? 'ssl'); // ssl | tls | none
    $user     = $cfg['user'];
    $pass     = $cfg['pass'];
    $fromEmail= $cfg['fromEmail'] ?? $user;
    $fromName = $cfg['fromName']  ?? 'MY 3D Gifts';
    $replyTo  = $cfg['replyTo']   ?? $fromEmail;

    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return ['ok'=>false,'error'=>'Invalid recipient email: '.$to];
    if (!$textBody) $textBody = trim(strip_tags(preg_replace('#<br\s*/?>#i', "\n", $htmlBody)));

    // DNS pre-check — catches "Name or service not known" early with a friendly message
    if ($host !== 'localhost' && $host !== '127.0.0.1') {
        $resolvedIp = @gethostbyname($host);
        if ($resolvedIp === $host) {
            return ['ok'=>false,'error'=>"SMTP host '$host' DNS resolve ஆகவில்லை. Admin → Settings → Email Setup-ல் SMTP Host சரியாக இருக்கிறதா என்று பாருங்கள். Hosting panel-ல் SMTP IP address பயன்படுத்தவும்."];
        }
    }
    $remote = ($secure === 'ssl') ? "ssl://$host:$port" : "$host:$port";
    $errno = 0; $errstr = '';
    $sock = @stream_socket_client($remote, $errno, $errstr, 20, STREAM_CLIENT_CONNECT, stream_context_create([
        'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]
    ]));
    if (!$sock) return ['ok'=>false,'error'=>"SMTP Connect failed: $errstr ($errno). Port $port தரம் பாருங்கள். SSL=465, TLS=587."];
    stream_set_timeout($sock, 20);

    $read = function() use ($sock) {
        $data = '';
        while (($line = fgets($sock, 1024)) !== false) {
            $data .= $line;
            if (isset($line[3]) && $line[3] === ' ') break;
        }
        return $data;
    };
    $cmd = function($c) use ($sock, $read) {
        fwrite($sock, $c . "\r\n");
        return $read();
    };

    $resp = $read();
    if (substr($resp,0,3) !== '220') { fclose($sock); return ['ok'=>false,'error'=>"SMTP greet: $resp"]; }

    $r = $cmd("EHLO localhost");
    if (substr($r,0,3) !== '250') { fclose($sock); return ['ok'=>false,'error'=>"EHLO: $r"]; }

    if ($secure === 'tls') {
        $r = $cmd("STARTTLS");
        if (substr($r,0,3) !== '220') { fclose($sock); return ['ok'=>false,'error'=>"STARTTLS: $r"]; }
        if (!stream_socket_enable_crypto($sock, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($sock); return ['ok'=>false,'error'=>'TLS enable failed'];
        }
        $cmd("EHLO localhost");
    }

    $r = $cmd("AUTH LOGIN");
    if (substr($r,0,3) !== '334') { fclose($sock); return ['ok'=>false,'error'=>"AUTH LOGIN: $r"]; }
    $r = $cmd(base64_encode($user));
    if (substr($r,0,3) !== '334') { fclose($sock); return ['ok'=>false,'error'=>"AUTH user: $r"]; }
    $r = $cmd(base64_encode($pass));
    if (substr($r,0,3) !== '235') { fclose($sock); return ['ok'=>false,'error'=>"AUTH pass: $r (check username/password)"]; }

    $r = $cmd("MAIL FROM:<$fromEmail>");
    if (substr($r,0,3) !== '250') { fclose($sock); return ['ok'=>false,'error'=>"MAIL FROM: $r"]; }
    $r = $cmd("RCPT TO:<$to>");
    if (substr($r,0,3) !== '250') { fclose($sock); return ['ok'=>false,'error'=>"RCPT TO: $r"]; }

    $r = $cmd("DATA");
    if (substr($r,0,3) !== '354') { fclose($sock); return ['ok'=>false,'error'=>"DATA: $r"]; }

    $boundary = 'b_'.bin2hex(random_bytes(8));
    $headers  = "From: =?UTF-8?B?".base64_encode($fromName)."?= <$fromEmail>\r\n";
    $headers .= "To: <$to>\r\n";
    $headers .= "Reply-To: <$replyTo>\r\n";
    $headers .= "Subject: =?UTF-8?B?".base64_encode($subject)."?=\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Date: ".date('r')."\r\n";
    $headers .= "Message-ID: <".bin2hex(random_bytes(8))."@".parse_url($host,PHP_URL_HOST?:$host).">\r\n";
    $headers .= "Content-Type: multipart/alternative; boundary=\"$boundary\"\r\n";

    $body  = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
    $body .= chunk_split(base64_encode($textBody))."\r\n";
    $body .= "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
    $body .= chunk_split(base64_encode($htmlBody))."\r\n";
    $body .= "--$boundary--\r\n";

    fwrite($sock, $headers . "\r\n" . $body . "\r\n.\r\n");
    $r = $read();
    if (substr($r,0,3) !== '250') { fclose($sock); return ['ok'=>false,'error'=>"Send: $r"]; }

    $cmd("QUIT");
    fclose($sock);
    return ['ok'=>true];
}

/**
 * Log email send attempt
 */
function logEmail(string $to, string $kind, string $subject, bool $ok, string $err = '', string $orderId = ''): void {
    try {
        $db = getDB();
        $db->exec("CREATE TABLE IF NOT EXISTS email_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            recipient VARCHAR(255), kind VARCHAR(40), subject VARCHAR(255),
            ok TINYINT(1), err TEXT, order_id VARCHAR(40),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $st = $db->prepare("INSERT INTO email_log (recipient, kind, subject, ok, err, order_id) VALUES (?,?,?,?,?,?)");
        $st->execute([$to, $kind, $subject, $ok?1:0, $err, $orderId]);
    } catch (Throwable $e) {}
}
