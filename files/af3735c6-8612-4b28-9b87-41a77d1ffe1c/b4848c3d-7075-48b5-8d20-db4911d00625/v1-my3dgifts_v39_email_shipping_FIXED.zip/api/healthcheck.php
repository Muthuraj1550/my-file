<?php
// ============================================================
//  healthcheck.php — DB + Tables verify செய்ய
//  Browser-ல் open: https://yourdomain.com/healthcheck.php
//  Use ஆனப்பின் DELETE பண்ணவும் (security)
// ============================================================
require_once __DIR__ . '/../config.php';

header('Content-Type: text/html; charset=utf-8');
echo "<h2>MY 3D Gifts — Health Check</h2><pre>";

try {
    $db = getDB();
    echo "✓ DB CONNECTED to '" . DB_NAME . "' as '" . DB_USER . "'\n\n";

    $tables = ['settings','theme','products','orders','users','coupons','flash_sale','wishlist','product_views','abandoned_carts'];
    foreach ($tables as $t) {
        try {
            $r = $db->query("SELECT COUNT(*) AS c FROM `$t`")->fetch();
            echo str_pad($t, 20) . " → " . $r['c'] . " rows\n";
        } catch (Exception $e) {
            echo str_pad($t, 20) . " → ✗ MISSING (" . $e->getMessage() . ")\n";
        }
    }

    echo "\n--- Latest 5 orders ---\n";
    $rows = $db->query("SELECT id, tracking, customer_name, customer_phone, total, status, created_at FROM orders ORDER BY created_at DESC LIMIT 5")->fetchAll();
    if (!$rows) echo "(no orders yet)\n";
    foreach ($rows as $r) {
        echo "{$r['created_at']}  {$r['id']}  {$r['customer_name']} ({$r['customer_phone']})  ₹{$r['total']}  [{$r['status']}]\n";
    }

    echo "\n--- ADMIN_SECRET configured: " . (ADMIN_SECRET === 'CHANGE_THIS_SECRET_KEY' ? '✗ DEFAULT! மாற்றவும்!' : '✓ custom') . "\n";

} catch (Exception $e) {
    echo "✗ ERROR: " . $e->getMessage() . "\n";
}
echo "</pre>";
echo "<p style='color:red'><b>⚠ verify ஆனப்பின் இந்த file-ஐ DELETE செய்யவும்.</b></p>";
