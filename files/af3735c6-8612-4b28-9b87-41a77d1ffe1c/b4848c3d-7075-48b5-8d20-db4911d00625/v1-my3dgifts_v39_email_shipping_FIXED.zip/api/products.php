<?php
// api/products.php — v18.2 (HARD DELETE + BULK DELETE)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
$db = getDB();

/**
 * Normalize an image URL so it works on every device.
 * - Strips host/scheme from old absolute URLs that point to OUR /uploads/ folder
 *   (e.g. "http://localhost/uploads/x.jpg" → "/uploads/x.jpg").
 * - Leaves external URLs (other domains, data:, https://cdn...) untouched.
 * - Leaves relative paths untouched.
 */
function normalizeImageUrl($url) {
    if (!is_string($url) || $url === '') return $url;
    if (strpos($url, 'data:') === 0) return $url;
    if (strpos($url, '/uploads/') === 0) return $url; // already relative
    // If absolute URL containing /uploads/ → strip host
    if (preg_match('#^https?://[^/]+(/uploads/.+)$#i', $url, $m)) {
        return $m[1];
    }
    return $url;
}

function normalizeImagesArray($images) {
    if (!is_array($images)) return [];
    $out = [];
    foreach ($images as $img) {
        if (is_array($img)) {
            if (isset($img['url'])) $img['url'] = normalizeImageUrl($img['url']);
            $out[] = $img;
        } else {
            $out[] = normalizeImageUrl((string)$img);
        }
    }
    return $out;
}

function productRow(array $row): array {
    $images  = json_decode($row['images']  ?? '[]', true) ?: [];
    $options = json_decode($row['options'] ?? '{}', true) ?: [];
    $images  = normalizeImagesArray($images);
    if (isset($options['coverImage'])) $options['coverImage'] = normalizeImageUrl($options['coverImage']);
    if (isset($options['image']))      $options['image']      = normalizeImageUrl($options['image']);
    if (isset($options['gifUrl']))     $options['gifUrl']     = normalizeImageUrl($options['gifUrl']);
    // Robust cover image: first entry from `images`, then options.coverImage, then options.image
    $cover   = '';
    if (!empty($images) && is_array($images)) {
        $first = $images[0];
        $cover = is_array($first) ? ($first['url'] ?? '') : (string)$first;
    }
    if (!$cover) $cover = $options['coverImage'] ?? ($options['image'] ?? '');
    return [
        'id'          => $row['id'],
        'name'        => $row['name'],
        'basePrice'   => (float)$row['base_price'],
        'description' => $row['description'] ?? '',
        'category'    => $row['category'] ?? '',
        'tags'        => json_decode($row['tags'] ?? '[]', true) ?: [],
        'images'      => $images,
        'image'       => $cover,
        'coverImage'  => $cover,
        'options'     => $options,
        'productType' => $options['productType'] ?? 'readymade',
        'featured'    => !empty($options['featured']),
        'adminOrder'  => (int)$row['admin_order'],
        'viewCount'   => (int)$row['view_count'],
        'orderCount'  => (int)$row['order_count'],
        'active'      => (bool)$row['active'],
        'createdAt'   => $row['created_at'] ?? null,
    ];
}

if ($method === 'GET') {
    if ($id) {
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) jsonError('Product not found', 404);
        $db->prepare("UPDATE products SET view_count = view_count + 1 WHERE id = ?")->execute([$id]);
        $db->prepare("INSERT INTO product_views (product_id, count) VALUES (?,1)
                      ON DUPLICATE KEY UPDATE count = count + 1")->execute([$id]);
        jsonOk(productRow($row));
    } else {
        $activeOnly = isset($_GET['all']) ? '' : 'WHERE active = 1';
        $rows = $db->query("SELECT * FROM products $activeOnly ORDER BY admin_order ASC, created_at ASC")->fetchAll();
        jsonOk(array_map('productRow', $rows));
    }
}

if ($method === 'POST') {
    requireAdmin();
    $b = jsonBody();

    // ---- BULK DELETE: POST /api/products/bulk-delete  body: { ids: [...] } ----
    if ($id === 'bulk-delete') {
        $ids = $b['ids'] ?? [];
        if (!is_array($ids) || !count($ids)) jsonError('ids required');
        $place = implode(',', array_fill(0, count($ids), '?'));
        $st = $db->prepare("DELETE FROM products WHERE id IN ($place)");
        $st->execute($ids);
        jsonOk(['deleted' => $st->rowCount()]);
    }

    // ---- BULK UPDATE: POST /api/products/bulk-update
    // body: { ids:[...], patch:{ active?:bool, category?:string, productType?:string,
    //   tags?:{ mode:'add'|'remove'|'replace', values:[...] } } }
    if ($id === 'bulk-update') {
        $ids   = $b['ids']   ?? [];
        $patch = $b['patch'] ?? [];
        if (!is_array($ids) || !count($ids)) jsonError('ids required');
        if (!is_array($patch) || !count($patch)) jsonError('patch required');

        $updated = 0;
        foreach ($ids as $pid) {
            // load current row for options/tags merge
            $cur = $db->prepare("SELECT options, tags FROM products WHERE id = ?");
            $cur->execute([$pid]);
            $row = $cur->fetch();
            if (!$row) continue;

            $opts = json_decode($row['options'] ?? '{}', true) ?: [];
            $tags = json_decode($row['tags']    ?? '[]', true) ?: [];

            $setActive = array_key_exists('active', $patch) ? ($patch['active'] ? 1 : 0) : null;
            $setCat    = array_key_exists('category', $patch) ? (string)$patch['category'] : null;

            if (array_key_exists('productType', $patch)) {
                $opts['productType'] = (string)$patch['productType'];
            }

            $newTagsJson = null;
            if (isset($patch['tags']) && is_array($patch['tags'])) {
                $mode = $patch['tags']['mode'] ?? 'add';
                $vals = array_values(array_filter(array_map('trim', (array)($patch['tags']['values'] ?? [])), 'strlen'));
                if ($mode === 'replace') {
                    $tags = $vals;
                } elseif ($mode === 'remove') {
                    $tags = array_values(array_diff($tags, $vals));
                } else { // add
                    $tags = array_values(array_unique(array_merge($tags, $vals)));
                }
                $newTagsJson = json_encode($tags, JSON_UNESCAPED_UNICODE);
            }

            $st = $db->prepare("UPDATE products SET
                category = COALESCE(:cat, category),
                tags     = COALESCE(:tags, tags),
                options  = COALESCE(:opts, options),
                active   = COALESCE(:act, active)
                WHERE id = :id");
            $st->execute([
                ':cat'  => $setCat,
                ':tags' => $newTagsJson,
                ':opts' => array_key_exists('productType', $patch) ? json_encode($opts, JSON_UNESCAPED_UNICODE) : null,
                ':act'  => $setActive,
                ':id'   => $pid,
            ]);
            $updated += $st->rowCount() > 0 ? 1 : 0;
        }
        jsonOk(['updated' => $updated, 'count' => count($ids)]);
    }

    $pid = $b['id'] ?? ('p' . uniqid());
    $opts = $b['options'] ?? [];
    if (isset($b['productType'])) $opts['productType'] = $b['productType'];
    if (isset($b['featured']))    $opts['featured']    = (bool)$b['featured'];

    $stmt = $db->prepare("INSERT INTO products
        (id, name, base_price, description, category, tags, images, options, admin_order)
        VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $pid,
        $b['name'] ?? 'New Product',
        $b['basePrice'] ?? 0,
        $b['description'] ?? '',
        $b['category'] ?? '',
        json_encode($b['tags'] ?? [], JSON_UNESCAPED_UNICODE),
        json_encode(normalizeImagesArray($b['images'] ?? []), JSON_UNESCAPED_UNICODE),
        json_encode($opts, JSON_UNESCAPED_UNICODE),
        $b['adminOrder'] ?? 999,
    ]);
    jsonOk(['id' => $pid]);
}

if ($method === 'PUT') {
    requireAdmin();
    if (!$id) jsonError('Product ID required');
    $b = jsonBody();
    $opts = null;
    if (array_key_exists('options', $b) || array_key_exists('productType', $b) || array_key_exists('featured', $b)) {
        $cur = $db->prepare("SELECT options FROM products WHERE id = ?");
        $cur->execute([$id]);
        $exist = json_decode(($cur->fetch()['options'] ?? '{}'), true) ?: [];
        $opts = array_merge($exist, $b['options'] ?? []);
        if (isset($b['productType'])) $opts['productType'] = $b['productType'];
        if (isset($b['featured']))    $opts['featured']    = (bool)$b['featured'];
    }

    $stmt = $db->prepare("UPDATE products SET
        name        = COALESCE(:name, name),
        base_price  = COALESCE(:bp, base_price),
        description = COALESCE(:desc, description),
        category    = COALESCE(:cat, category),
        tags        = COALESCE(:tags, tags),
        images      = COALESCE(:imgs, images),
        options     = COALESCE(:opts, options),
        admin_order = COALESCE(:aord, admin_order),
        active      = COALESCE(:act, active)
        WHERE id = :id");
    $stmt->execute([
        ':name' => $b['name'] ?? null,
        ':bp'   => isset($b['basePrice']) ? (float)$b['basePrice'] : null,
        ':desc' => $b['description'] ?? null,
        ':cat'  => $b['category'] ?? null,
        ':tags' => isset($b['tags']) ? json_encode($b['tags'], JSON_UNESCAPED_UNICODE) : null,
        ':imgs' => isset($b['images']) ? json_encode(normalizeImagesArray($b['images']), JSON_UNESCAPED_UNICODE) : null,
        ':opts' => $opts !== null ? json_encode($opts, JSON_UNESCAPED_UNICODE) : null,
        ':aord' => isset($b['adminOrder']) ? (int)$b['adminOrder'] : null,
        ':act'  => isset($b['active']) ? ($b['active'] ? 1 : 0) : null,
        ':id'   => $id,
    ]);
    jsonOk(['updated' => $id]);
}

// ── HARD DELETE (was soft-delete in v18; that's the bug) ──
if ($method === 'DELETE') {
    requireAdmin();
    if (!$id) jsonError('Product ID required');
    $st = $db->prepare("DELETE FROM products WHERE id = ?");
    $st->execute([$id]);
    if ($st->rowCount() === 0) jsonError('Product not found or already deleted', 404);
    jsonOk(['deleted' => $id]);
}

jsonError('Method not allowed', 405);
