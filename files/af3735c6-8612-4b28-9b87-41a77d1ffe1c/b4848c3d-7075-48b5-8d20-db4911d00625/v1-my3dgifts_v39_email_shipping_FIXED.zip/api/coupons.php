<?php
// Standalone direct-access header (works both via index.php router and direct .php URL)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    // id is the segment after the php filename or resource name
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
// api/coupons.php
$db = getDB();

function couponRow(array $r): array {
    return [
        'id'       => (int)$r['id'],
        'code'     => $r['code'],
        'type'     => $r['type'],
        'value'    => (float)$r['value'],
        'minOrder' => (float)$r['min_order'],
        'active'   => (bool)$r['active'],
        'uses'     => (int)$r['uses'],
        'maxUses'  => (int)$r['max_uses'],
        'expiresAt'=> $r['expires_at'],
    ];
}

// GET — public validate or admin list
if ($method === 'GET') {
    if ($id) {
        // validate coupon code
        $stmt = $db->prepare("SELECT * FROM coupons WHERE code = ? AND active = 1");
        $stmt->execute([strtoupper($id)]);
        $row = $stmt->fetch();
        if (!$row) jsonError('Invalid or expired coupon', 404);
        if ($row['max_uses'] > 0 && $row['uses'] >= $row['max_uses']) jsonError('Coupon usage limit reached', 410);
        if ($row['expires_at'] && strtotime($row['expires_at']) < time()) jsonError('Coupon expired', 410);
        jsonOk(couponRow($row));
    } else {
        requireAdmin();
        $rows = $db->query("SELECT * FROM coupons ORDER BY id DESC")->fetchAll();
        jsonOk(array_map('couponRow', $rows));
    }
}

// POST — create coupon (admin)
if ($method === 'POST') {
    requireAdmin();
    $b = jsonBody();
    $stmt = $db->prepare("INSERT INTO coupons (code,type,value,min_order,active,max_uses,expires_at)
                          VALUES (?,?,?,?,?,?,?)
                          ON DUPLICATE KEY UPDATE
                            type=VALUES(type),value=VALUES(value),min_order=VALUES(min_order),
                            active=VALUES(active),max_uses=VALUES(max_uses),expires_at=VALUES(expires_at)");
    $stmt->execute([
        strtoupper($b['code'] ?? ''),
        $b['type'] ?? 'percent',
        $b['value'] ?? 0,
        $b['minOrder'] ?? 0,
        isset($b['active']) ? ($b['active']?1:0) : 1,
        $b['maxUses'] ?? 0,
        $b['expiresAt'] ?? null,
    ]);
    jsonOk(['saved' => true]);
}

// DELETE — deactivate coupon (admin)
if ($method === 'DELETE') {
    requireAdmin();
    $db->prepare("UPDATE coupons SET active = 0 WHERE id = ?")->execute([$id]);
    jsonOk(['deleted' => $id]);
}

jsonError('Method not allowed', 405);
