<?php
// api/admin-auth.php
// Admin username/password login → returns ADMIN_SECRET key
require_once __DIR__ . '/../config.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'POST') {
    $b = jsonBody();
    $username = trim($b['username'] ?? '');
    $password = trim($b['password'] ?? '');

    if (empty($username) || empty($password)) {
        jsonError('Username and Password are required', 400);
    }

    // Constant-time comparison to prevent timing attacks
    $userOk = hash_equals(ADMIN_USERNAME, $username);
    $passOk = hash_equals(ADMIN_PASSWORD, $password);

    if ($userOk && $passOk) {
        jsonOk([
            'apiKey'   => ADMIN_SECRET,
            'username' => ADMIN_USERNAME,
            'message'  => 'Login successful',
        ]);
    } else {
        jsonError('Invalid Username or Password', 401);
    }
}

jsonError('Method not allowed', 405);
