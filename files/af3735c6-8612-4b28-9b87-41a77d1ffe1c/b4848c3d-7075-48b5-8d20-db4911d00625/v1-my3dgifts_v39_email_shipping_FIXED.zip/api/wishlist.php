<?php
// Standalone direct-access header (works both via index.php router and direct .php URL)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    // id is the segment after the php filename or resource name
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
// api/wishlist.php
$db = getDB();
$sid = $_GET['session'] ?? ($_POST['session'] ?? '');

if ($method === 'GET') {
    if (!$sid) jsonOk([]);
    $stmt = $db->prepare("SELECT product_id FROM wishlist WHERE session_id = ?");
    $stmt->execute([$sid]);
    jsonOk(array_column($stmt->fetchAll(), 'product_id'));
}

if ($method === 'POST') {
    $b = jsonBody();
    $sid = $b['session'] ?? $sid;
    $pid = $b['productId'] ?? '';
    if (!$sid || !$pid) jsonError('session and productId required');

    // Toggle
    $check = $db->prepare("SELECT id FROM wishlist WHERE session_id = ? AND product_id = ?");
    $check->execute([$sid, $pid]);
    if ($check->fetch()) {
        $db->prepare("DELETE FROM wishlist WHERE session_id = ? AND product_id = ?")->execute([$sid,$pid]);
        jsonOk(['action'=>'removed']);
    } else {
        $db->prepare("INSERT INTO wishlist (session_id, product_id) VALUES (?,?)")->execute([$sid,$pid]);
        jsonOk(['action'=>'added']);
    }
}

if ($method === 'DELETE') {
    $b = jsonBody();
    $sid = $b['session'] ?? $sid;
    $pid = $b['productId'] ?? '';
    if ($pid) {
        $db->prepare("DELETE FROM wishlist WHERE session_id = ? AND product_id = ?")->execute([$sid,$pid]);
    } else {
        $db->prepare("DELETE FROM wishlist WHERE session_id = ?")->execute([$sid]);
    }
    jsonOk(['deleted'=>true]);
}

jsonError('Method not allowed', 405);
