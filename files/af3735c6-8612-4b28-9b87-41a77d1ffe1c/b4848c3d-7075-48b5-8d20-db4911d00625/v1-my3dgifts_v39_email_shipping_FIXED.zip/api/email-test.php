<?php
// email-test.php — SMTP connection debug tool
// Browser-ல் திறந்தால் உங்கள் SMTP problem என்னென்று தெரியும்
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';

$key = $_GET['key'] ?? '';
if ($key !== ADMIN_SECRET) { http_response_code(401); echo "Unauthorized"; exit; }

$cfg_row = getDB()->prepare("SELECT svalue FROM settings WHERE skey='smtp'");
$cfg_row->execute();
$r = $cfg_row->fetch();
$cfg = $r ? json_decode($r['svalue'], true) : [];
if (is_string($cfg)) $cfg = json_decode($cfg, true);

$host = $cfg['host'] ?? '(not set)';
$port = $cfg['port'] ?? 465;
$user = $cfg['user'] ?? '(not set)';

echo "<h2>SMTP Debug Report</h2>";
echo "<b>Host:</b> $host<br>";
echo "<b>Port:</b> $port<br>";
echo "<b>User:</b> $user<br><br>";

// Test 1: DNS lookup
echo "<b>Test 1: DNS Lookup</b><br>";
$ip = @gethostbyname($host);
if ($ip === $host) {
    echo "❌ DNS FAILED — '$host' could not be resolved. This is your main problem!<br>";
    echo "→ Hosting server cannot reach external DNS.<br>";
} else {
    echo "✅ DNS OK — $host → $ip<br>";
}
echo "<br>";

// Test 2: TCP connect
echo "<b>Test 2: TCP Connect (ssl://$host:$port)</b><br>";
$ctx = stream_context_create(['ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
$sock = @stream_socket_client("ssl://$host:$port", $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $ctx);
if (!$sock) {
    echo "❌ CONNECT FAILED: $errstr ($errno)<br>";
} else {
    echo "✅ TCP Connected!<br>";
    fclose($sock);
}
echo "<br>";

// Test 3: PHP mail() fallback check
echo "<b>Test 3: sendmail_path</b><br>";
echo ini_get('sendmail_path') ?: '(empty)';
echo "<br><br>";

// Recommendation
echo "<h3>💡 Recommendations</h3>";
if ($ip === $host) {
    echo "உங்கள் hosting-ல் outbound DNS blocked ஆகியிருக்கலாம்.<br>";
    echo "1️⃣ Hosting panel → Email → SMTP credentials மீண்டும் check செய்யுங்கள்<br>";
    echo "2️⃣ <b>smtp.hostinger.com</b> பதிலாக <b>127.0.0.1</b> (localhost mail server) try செய்யுங்கள்<br>";
    echo "3️⃣ Hostinger-ல் உள்ள Email Accounts → SMTP host IP address நேரடியாக பயன்படுத்துங்கள்<br>";
}
