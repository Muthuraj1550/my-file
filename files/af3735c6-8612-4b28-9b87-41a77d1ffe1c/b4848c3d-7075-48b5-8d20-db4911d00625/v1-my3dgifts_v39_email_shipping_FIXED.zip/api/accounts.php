<?php
// api/accounts.php — v17 income / expense ledger
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
$db = getDB();

// Auto-create table
$db->exec("CREATE TABLE IF NOT EXISTS accounts_ledger (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    kind        VARCHAR(10) NOT NULL,            -- 'income' | 'expense'
    category    VARCHAR(80) DEFAULT '',
    description VARCHAR(255) DEFAULT '',
    amount      DECIMAL(12,2) NOT NULL DEFAULT 0,
    ref_type    VARCHAR(30) DEFAULT '',          -- e.g. 'order', 'shipping', 'manual'
    ref_id      VARCHAR(40) DEFAULT '',          -- e.g. order id
    entry_date  DATE NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_ref (ref_type, ref_id, kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

requireAdmin();

function rowOut(array $r): array {
    return [
        'id' => (int)$r['id'],
        'kind' => $r['kind'],
        'category' => $r['category'],
        'description' => $r['description'],
        'amount' => (float)$r['amount'],
        'refType' => $r['ref_type'],
        'refId' => $r['ref_id'],
        'date' => $r['entry_date'],
        'createdAt' => $r['created_at'],
    ];
}

// Sub-routes:  /api/accounts        list (with ?from=&to=&kind=)
//              /api/accounts/sync   (POST) idempotently sync orders → income+shipping expense
//              /api/accounts/{id}   PUT update / DELETE
$action = $id;

if ($method === 'POST' && $action === 'sync') {
    // Pull all orders not yet in ledger; insert income (total) + expense (shipping)
    $orders = $db->query("SELECT id, total, shipping, COALESCE(created_at, NOW()) AS created_at, status
                          FROM orders
                          WHERE COALESCE(status,'') NOT IN ('Cancelled','Refunded')")->fetchAll();
    $insIncome = $db->prepare("INSERT IGNORE INTO accounts_ledger
        (kind, category, description, amount, ref_type, ref_id, entry_date)
        VALUES ('income','Order Sale', :desc, :amt, 'order', :rid, :dt)");
    $insExpense = $db->prepare("INSERT IGNORE INTO accounts_ledger
        (kind, category, description, amount, ref_type, ref_id, entry_date)
        VALUES ('expense','Shipping Cost', :desc, :amt, 'shipping', :rid, :dt)");
    $cIn = 0; $cEx = 0;
    foreach ($orders as $o) {
        $dt = substr($o['created_at'], 0, 10);
        $insIncome->execute([':desc'=>'Order #'.$o['id'], ':amt'=>(float)$o['total'], ':rid'=>$o['id'], ':dt'=>$dt]);
        $cIn += $insIncome->rowCount();
        if ((float)$o['shipping'] > 0) {
            $insExpense->execute([':desc'=>'Shipping for #'.$o['id'], ':amt'=>(float)$o['shipping'], ':rid'=>$o['id'], ':dt'=>$dt]);
            $cEx += $insExpense->rowCount();
        }
    }
    jsonOk(['syncedIncome' => $cIn, 'syncedExpense' => $cEx]);
}

if ($method === 'GET') {
    $from = $_GET['from'] ?? null;
    $to   = $_GET['to']   ?? null;
    $kind = $_GET['kind'] ?? null;
    $sql = "SELECT * FROM accounts_ledger WHERE 1=1";
    $args = [];
    if ($from) { $sql .= " AND entry_date >= ?"; $args[] = $from; }
    if ($to)   { $sql .= " AND entry_date <= ?"; $args[] = $to; }
    if ($kind) { $sql .= " AND kind = ?";        $args[] = $kind; }
    $sql .= " ORDER BY entry_date DESC, id DESC LIMIT 2000";
    $stmt = $db->prepare($sql);
    $stmt->execute($args);
    $rows = array_map('rowOut', $stmt->fetchAll());

    // Totals
    $tot = ['income'=>0, 'expense'=>0, 'net'=>0];
    foreach ($rows as $r) {
        if ($r['kind']==='income') $tot['income'] += $r['amount'];
        else                       $tot['expense'] += $r['amount'];
    }
    $tot['net'] = $tot['income'] - $tot['expense'];

    // Monthly breakdown
    $monthly = [];
    foreach ($rows as $r) {
        $m = substr($r['date'],0,7);
        if (!isset($monthly[$m])) $monthly[$m] = ['month'=>$m,'income'=>0,'expense'=>0,'net'=>0];
        if ($r['kind']==='income') $monthly[$m]['income'] += $r['amount'];
        else                       $monthly[$m]['expense'] += $r['amount'];
        $monthly[$m]['net'] = $monthly[$m]['income'] - $monthly[$m]['expense'];
    }
    krsort($monthly);

    jsonOk(['entries'=>$rows,'totals'=>$tot,'monthly'=>array_values($monthly)]);
}

if ($method === 'POST') {
    $b = jsonBody();
    $kind = ($b['kind'] ?? 'expense') === 'income' ? 'income' : 'expense';
    $stmt = $db->prepare("INSERT INTO accounts_ledger
        (kind, category, description, amount, ref_type, ref_id, entry_date)
        VALUES (?,?,?,?,?,?,?)");
    $stmt->execute([
        $kind,
        substr((string)($b['category'] ?? ''), 0, 80),
        substr((string)($b['description'] ?? ''), 0, 255),
        (float)($b['amount'] ?? 0),
        $b['refType'] ?? 'manual',
        $b['refId'] ?? '',
        $b['date'] ?? date('Y-m-d'),
    ]);
    jsonOk(['id' => $db->lastInsertId()]);
}

if ($method === 'PUT' && $id) {
    $b = jsonBody();
    $stmt = $db->prepare("UPDATE accounts_ledger SET
        kind        = COALESCE(:kind, kind),
        category    = COALESCE(:cat,  category),
        description = COALESCE(:desc, description),
        amount      = COALESCE(:amt,  amount),
        entry_date  = COALESCE(:dt,   entry_date)
        WHERE id = :id");
    $stmt->execute([
        ':kind' => isset($b['kind']) ? ($b['kind']==='income'?'income':'expense') : null,
        ':cat'  => $b['category'] ?? null,
        ':desc' => $b['description'] ?? null,
        ':amt'  => isset($b['amount']) ? (float)$b['amount'] : null,
        ':dt'   => $b['date'] ?? null,
        ':id'   => (int)$id,
    ]);
    jsonOk(['updated' => $id]);
}

if ($method === 'DELETE' && $id) {
    $db->prepare("DELETE FROM accounts_ledger WHERE id = ?")->execute([(int)$id]);
    jsonOk(['deleted' => $id]);
}

jsonError('Method not allowed', 405);
