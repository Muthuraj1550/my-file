<?php
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
$db = getDB();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// Auto-heal: create popups table if missing (prevents 500 on fresh installs)
$db->exec("CREATE TABLE IF NOT EXISTS popups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255), body TEXT, type VARCHAR(20) DEFAULT 'info',
    icon VARCHAR(20) DEFAULT '🎉', cta_label VARCHAR(100), cta_url VARCHAR(500),
    active TINYINT(1) DEFAULT 1, show_after_sec INT DEFAULT 3, show_once TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

function popupRow(array $r): array {
    return [
        'id'           => (int)$r['id'],
        'title'        => $r['title'],
        'body'         => $r['body'],
        'type'         => $r['type'],
        'icon'         => $r['icon'],
        'ctaLabel'     => $r['cta_label'],
        'ctaUrl'       => $r['cta_url'],
        'active'       => (bool)$r['active'],
        'showAfterSec' => (int)$r['show_after_sec'],
        'showOnce'     => (bool)$r['show_once'],
        'updatedAt'    => $r['updated_at'] ?? '',
    ];
}

if ($method === 'GET') {
    $where = isset($_GET['all']) ? '' : 'WHERE active = 1';
    $rows = $db->query("SELECT * FROM popups $where ORDER BY id DESC")->fetchAll();
    jsonOk(array_map('popupRow', $rows));
}

if ($method === 'POST' || $method === 'PUT') {
    requireAdmin();
    $b = jsonBody();
    if (!empty($b['id'])) {
        $stmt = $db->prepare("UPDATE popups SET title=?,body=?,type=?,icon=?,cta_label=?,cta_url=?,active=?,show_after_sec=?,show_once=? WHERE id=?");
        $stmt->execute([
            $b['title'] ?? '', $b['body'] ?? '', $b['type'] ?? 'info', $b['icon'] ?? '🎉',
            $b['ctaLabel'] ?? '', $b['ctaUrl'] ?? '',
            !empty($b['active']) ? 1 : 0,
            (int)($b['showAfterSec'] ?? 3),
            !empty($b['showOnce']) ? 1 : 0,
            (int)$b['id'],
        ]);
        jsonOk(['updated' => (int)$b['id']]);
    } else {
        $stmt = $db->prepare("INSERT INTO popups (title,body,type,icon,cta_label,cta_url,active,show_after_sec,show_once) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $b['title'] ?? '', $b['body'] ?? '', $b['type'] ?? 'info', $b['icon'] ?? '🎉',
            $b['ctaLabel'] ?? '', $b['ctaUrl'] ?? '',
            !empty($b['active']) ? 1 : 0,
            (int)($b['showAfterSec'] ?? 3),
            !empty($b['showOnce']) ? 1 : 0,
        ]);
        jsonOk(['created' => (int)$db->lastInsertId()]);
    }
}

if ($method === 'DELETE') {
    requireAdmin();
    if (!$id) jsonError('Missing id', 400);
    $db->prepare("DELETE FROM popups WHERE id=?")->execute([$id]);
    jsonOk(['deleted' => $id]);
}

jsonError('Method not allowed', 405);
