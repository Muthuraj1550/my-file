<?php
// api/backup.php — Backup DB + uploads as ZIP
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
requireAdmin();

$root = dirname(__DIR__);
$tmp = sys_get_temp_dir() . '/backup_' . date('Ymd_His') . '_' . uniqid() . '.zip';

// Dump DB
$sqlFile = sys_get_temp_dir() . '/db_' . uniqid() . '.sql';
try {
    $db = getDB();
    $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $fh = fopen($sqlFile, 'w');
    fwrite($fh, "-- Backup " . date('Y-m-d H:i:s') . "\nSET FOREIGN_KEY_CHECKS=0;\n\n");
    foreach ($tables as $t) {
        $create = $db->query("SHOW CREATE TABLE `$t`")->fetch();
        fwrite($fh, "DROP TABLE IF EXISTS `$t`;\n" . $create['Create Table'] . ";\n\n");
        $rows = $db->query("SELECT * FROM `$t`")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $cols = '`' . implode('`,`', array_keys($r)) . '`';
            $vals = implode(',', array_map(fn($v) => $v === null ? 'NULL' : $db->quote($v), array_values($r)));
            fwrite($fh, "INSERT INTO `$t` ($cols) VALUES ($vals);\n");
        }
        fwrite($fh, "\n");
    }
    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
} catch (Throwable $e) { jsonError('DB dump failed: ' . $e->getMessage(), 500); }

// ZIP
$zip = new ZipArchive();
if ($zip->open($tmp, ZipArchive::CREATE) !== true) jsonError('Cannot create zip', 500);
$zip->addFile($sqlFile, 'database.sql');
if (is_dir(UPLOAD_DIR)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(UPLOAD_DIR, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile()) {
            $rel = 'uploads/' . substr($f->getPathname(), strlen(UPLOAD_DIR));
            $zip->addFile($f->getPathname(), $rel);
        }
    }
}
$zip->close();
@unlink($sqlFile);

if (!is_file($tmp)) jsonError('Zip not created', 500);

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="my3dgifts_backup_' . date('Ymd_His') . '.zip"');
header('Content-Length: ' . filesize($tmp));
readfile($tmp);
@unlink($tmp);
exit;
