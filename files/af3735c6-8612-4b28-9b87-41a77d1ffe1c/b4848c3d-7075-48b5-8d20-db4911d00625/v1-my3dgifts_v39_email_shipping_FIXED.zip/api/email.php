<?php
// api/email.php — Send transactional emails (cart recovery / order confirm / tracking / delivered)
// POST /api/email/send  body: { kind: 'cart_recovery'|'order_confirmed'|'tracking_update'|'delivered', orderId?: ..., cartId?: ..., to?: ... }
// POST /api/email/test  body: { to: 'a@b.com' }
// GET  /api/email/log   → recent send log

if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/_mailer.php';
require_once __DIR__ . '/_email_templates.php';

if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

$uri = $_SERVER['REQUEST_URI'] ?? '';
$path = trim(parse_url($uri, PHP_URL_PATH), '/');
$segs = explode('/', $path);
// figure out the action (segment immediately after 'email' or 'email.php')
$action = '';
for ($i=0;$i<count($segs);$i++) {
    if ($segs[$i] === 'email' || $segs[$i] === 'email.php') {
        $action = $segs[$i+1] ?? '';
        break;
    }
}
$action = strtolower($action);
$db = getDB();

// helper: load brand context from theme + settings
function brandCtx(): array {
    $db = getDB();
    $brand = ['storeName'=>'MY 3D Gifts','primary'=>'#6366f1','logoUrl'=>'','siteUrl'=>''];
    foreach ($db->query("SELECT tkey, tvalue FROM theme")->fetchAll() as $r) {
        $v = json_decode($r['tvalue'], true);
        if (in_array($r['tkey'], ['storeName','primary','logoUrl'])) $brand[$r['tkey']] = $v;
    }
    $row = $db->prepare("SELECT svalue FROM settings WHERE skey='siteUrl'");
    $row->execute();
    $r = $row->fetch();
    if ($r) {
        $u = json_decode($r['svalue'], true);
        if (is_string($u)) $brand['siteUrl'] = $u;
    }
    if (empty($brand['siteUrl'])) {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http';
        $brand['siteUrl'] = $scheme.'://'.($_SERVER['HTTP_HOST'] ?? 'localhost');
    }
    return $brand;
}

if ($method === 'GET' && $action === 'log') {
    requireAdmin();
    try {
        $rows = $db->query("SELECT * FROM email_log ORDER BY id DESC LIMIT 100")->fetchAll();
        jsonOk($rows);
    } catch (Throwable $e) { jsonOk([]); }
}

if ($method === 'POST' && $action === 'test') {
    requireAdmin();
    $b = jsonBody();
    $to = $b['to'] ?? '';
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) jsonError('Valid email required');
    $brand = brandCtx();
    $body = "<h2>SMTP Test ✅</h2><p>உங்கள் email setup வேலை செய்கிறது!</p><p style=\"color:#64748b;font-size:12px;\">Sent at ".date('Y-m-d H:i:s')."</p>";
    $html = emailLayout('SMTP Test', $body, $brand);
    $res = sendMailSmtp($to, 'SMTP Test · '.($brand['storeName']??'Store'), $html);
    logEmail($to, 'test', 'SMTP Test', $res['ok'], $res['error'] ?? '');
    if (!$res['ok']) jsonError($res['error'] ?? 'Send failed', 500);
    jsonOk(['sent'=>true, 'to'=>$to]);
}

if ($method === 'POST' && $action === 'send') {
    requireAdmin();
    $b = jsonBody();
    $kind = $b['kind'] ?? '';
    $brand = brandCtx();

    if ($kind === 'cart_recovery') {
        $cartId = $b['cartId'] ?? '';
        if (!$cartId) jsonError('cartId required');
        $st = $db->prepare("SELECT * FROM abandoned_carts WHERE id=?");
        $st->execute([$cartId]);
        $r = $st->fetch();
        if (!$r) jsonError('Cart not found', 404);
        $cart = [
            'customerName' => $r['customer_name'],
            'customerEmail'=> $r['customer_email'],
            'items'        => json_decode($r['items'] ?? '[]', true) ?: [],
            'total'        => $r['total'],
        ];
        $to = $b['to'] ?: $cart['customerEmail'];
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) jsonError('No valid customer email on this cart');
        $tpl = tplCartRecovery($cart, $brand);
        $res = sendMailSmtp($to, $tpl['subject'], $tpl['html']);
        logEmail($to, 'cart_recovery', $tpl['subject'], $res['ok'], $res['error'] ?? '', $cartId);
        if (!$res['ok']) jsonError($res['error'] ?? 'Send failed', 500);
        jsonOk(['sent'=>true,'to'=>$to]);
    }

    if (in_array($kind, ['order_confirmed','tracking_update','delivered'], true)) {
        $orderId = $b['orderId'] ?? '';
        if (!$orderId) jsonError('orderId required');
        $st = $db->prepare("SELECT * FROM orders WHERE id=? OR tracking=?");
        $st->execute([$orderId, $orderId]);
        $r = $st->fetch();
        if (!$r) jsonError('Order not found', 404);
        $order = [
            'id'              => $r['id'],
            'tracking'        => $r['tracking'],
            'customerName'    => $r['customer_name'],
            'customerEmail'   => $r['customer_email'],
            'address'         => $r['address'],
            'pincode'         => $r['pincode'],
            'items'           => json_decode($r['items'] ?? '[]', true) ?: [],
            'total'           => $r['total'],
            'shipping'        => $r['shipping'] ?? 0,
            'discount'        => $r['discount'] ?? 0,
            'courier'         => $r['courier'],
            'courierTracking' => $r['courier_tracking'],
        ];
        $to = $b['to'] ?: $order['customerEmail'];
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) jsonError('No valid customer email on this order');
        $tpl = match($kind){
            'order_confirmed' => tplOrderConfirmed($order, $brand),
            'tracking_update' => tplTrackingUpdate($order, $brand),
            'delivered'       => tplDelivered($order, $brand),
        };
        $res = sendMailSmtp($to, $tpl['subject'], $tpl['html']);
        logEmail($to, $kind, $tpl['subject'], $res['ok'], $res['error'] ?? '', $order['id']);
        if (!$res['ok']) jsonError($res['error'] ?? 'Send failed', 500);
        jsonOk(['sent'=>true,'to'=>$to,'kind'=>$kind]);
    }

    jsonError('Unknown kind: '.$kind);
}

jsonError('Method not allowed', 405);
