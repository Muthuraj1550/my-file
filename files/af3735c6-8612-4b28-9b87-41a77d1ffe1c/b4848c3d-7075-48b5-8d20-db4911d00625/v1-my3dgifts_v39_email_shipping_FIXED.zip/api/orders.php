<?php
// api/orders.php — v18.2 (BULK ops + auto-email triggers)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
define('ORDERS_PHP_RUNNING', true); // Signal to coins.php: skip routing when included
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
$db = getDB();

try {
    $has = $db->query("SHOW COLUMNS FROM orders LIKE 'source'")->fetch();
    if (!$has) $db->exec("ALTER TABLE orders ADD COLUMN source VARCHAR(20) DEFAULT 'online'");
} catch (Throwable $e) {}

function orderRow(array $row): array {
    return [
        'id'             => $row['id'],
        'tracking'       => $row['tracking'],
        'customerName'   => $row['customer_name'],
        'customerPhone'  => $row['customer_phone'],
        'customerEmail'  => $row['customer_email'],
        'address'        => $row['address'],
        'pincode'        => $row['pincode'],
        'name'           => $row['customer_name'],
        'phone'          => $row['customer_phone'],
        'email'          => $row['customer_email'],
        'addr'           => $row['address'],
        'pin'            => $row['pincode'],
        'items'          => json_decode($row['items'] ?? '[]', true),
        'total'          => (float)$row['total'],
        'discount'       => (float)$row['discount'],
        'shipping'       => (float)$row['shipping'],
        'coupon'         => $row['coupon'],
        'payMethod'      => $row['pay_method'],
        'paymentStatus'  => $row['payment_status'],
        'status'         => $row['status'],
        'courier'        => $row['courier'],
        'courierTracking'=> $row['courier_tracking'],
        'history'        => json_decode($row['history'] ?? '[]', true),
        'notes'          => $row['notes'],
        'source'         => $row['source'] ?? 'online',
        'createdAt'      => $row['created_at'],
    ];
}

// fire-and-forget email trigger (best-effort, never blocks API response)
function triggerOrderEmail(string $kind, string $orderId): void {
    try {
        require_once __DIR__ . '/_mailer.php';
        require_once __DIR__ . '/_email_templates.php';
        $db = getDB();
        $st = $db->prepare("SELECT * FROM orders WHERE id=?");
        $st->execute([$orderId]);
        $r = $st->fetch();
        if (!$r) return;
        $email = $r['customer_email'] ?? '';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return;

        // brand context
        $brand = ['storeName'=>'MY 3D Gifts','primary'=>'#6366f1','logoUrl'=>''];
        foreach ($db->query("SELECT tkey,tvalue FROM theme")->fetchAll() as $tr) {
            $v = json_decode($tr['tvalue'], true);
            if (in_array($tr['tkey'], ['storeName','primary','logoUrl'])) $brand[$tr['tkey']] = $v;
        }

        $order = [
            'id'=>$r['id'],'tracking'=>$r['tracking'],
            'customerName'=>$r['customer_name'],'customerEmail'=>$email,
            'address'=>$r['address'],'pincode'=>$r['pincode'],
            'items'=>json_decode($r['items']??'[]',true)?:[],
            'total'=>$r['total'],
            'courier'=>$r['courier'],'courierTracking'=>$r['courier_tracking'],
        ];
        $tpl = match($kind){
            'order_confirmed' => tplOrderConfirmed($order, $brand),
            'tracking_update' => tplTrackingUpdate($order, $brand),
            'delivered'       => tplDelivered($order, $brand),
            default => null,
        };
        if (!$tpl) return;
        $res = sendMailSmtp($email, $tpl['subject'], $tpl['html']);
        logEmail($email, $kind, $tpl['subject'], $res['ok'], $res['error'] ?? '', $orderId);
    } catch (Throwable $e) {}
}

// GET
if ($method === 'GET') {
    if ($id) {
        $stmt = $db->prepare("SELECT * FROM orders WHERE id = ? OR tracking = ?");
        $stmt->execute([$id, $id]);
        $row = $stmt->fetch();
        if (!$row) jsonError('Order not found', 404);
        jsonOk(orderRow($row));
    } elseif (isset($_GET['phone'])) {
        $stmt = $db->prepare("SELECT * FROM orders WHERE customer_phone = ? ORDER BY created_at DESC");
        $stmt->execute([$_GET['phone']]);
        jsonOk(array_map('orderRow', $stmt->fetchAll()));
    } else {
        requireAdmin();
        $rows = $db->query("SELECT * FROM orders ORDER BY created_at DESC")->fetchAll();
        jsonOk(array_map('orderRow', $rows));
    }
}

if ($method === 'POST') {
    $b = jsonBody();

    // ---- BULK DELETE: POST /api/orders/bulk-delete  body: { ids: [...] } ----
    if ($id === 'bulk-delete') {
        requireAdmin();
        $ids = $b['ids'] ?? [];
        if (!is_array($ids) || !count($ids)) jsonError('ids required');
        $place = implode(',', array_fill(0, count($ids), '?'));
        $st = $db->prepare("DELETE FROM orders WHERE id IN ($place)");
        $st->execute($ids);
        jsonOk(['deleted' => $st->rowCount()]);
    }

    // ---- BULK STATUS UPDATE: POST /api/orders/bulk-status  body: { ids:[], status:'Shipped', sendEmail:true } ----
    if ($id === 'bulk-status') {
        requireAdmin();
        $ids = $b['ids'] ?? [];
        $status = $b['status'] ?? '';
        if (!is_array($ids) || !count($ids)) jsonError('ids required');
        if (!$status) jsonError('status required');
        $sendEmail = !empty($b['sendEmail']);
        $note = $b['note'] ?? 'Bulk status update';

        $updated = 0;
        foreach ($ids as $oid) {
            $cur = $db->prepare("SELECT history, status FROM orders WHERE id = ?");
            $cur->execute([$oid]);
            $exist = $cur->fetch();
            if (!$exist) continue;
            $hist = json_decode($exist['history'] ?? '[]', true) ?: [];
            if ($status !== $exist['status']) {
                $hist[] = ['status'=>$status,'at'=>date('c'),'note'=>$note];
            }
            $up = $db->prepare("UPDATE orders SET status = ?, history = ? WHERE id = ?");
            $up->execute([$status, json_encode($hist, JSON_UNESCAPED_UNICODE), $oid]);
            $updated++;

            if ($sendEmail) {
                $kind = match($status){
                    'New' => 'order_confirmed',
                    'Shipped','Dispatch' => 'tracking_update',
                    'Delivered' => 'delivered',
                    default => '',
                };
                if ($kind) triggerOrderEmail($kind, $oid);
            }
            // Loyalty: revoke coins on Cancel/Refund
            if (in_array($status, ['Cancelled','Refunded'], true)) {
                try { require_once __DIR__ . '/coins.php'; revokeCoinsForOrder($db, $oid, $status); } catch (\Throwable $e) {}
            }
        }
        jsonOk(['updated'=>$updated, 'status'=>$status, 'emailsSent'=>$sendEmail]);
    }

    // ---- regular new order ----
    $name  = $b['name']    ?? $b['customerName']  ?? '';
    $phone = $b['phone']   ?? $b['customerPhone'] ?? '';
    $email = $b['email']   ?? $b['customerEmail'] ?? '';
    $addr  = $b['addr']    ?? $b['address']       ?? '';
    $pin   = $b['pin']     ?? $b['pincode']       ?? '';
    $items = $b['items']   ?? [];
    if (!$name || !$phone || !$addr || empty($items)) {
        jsonError('Missing required field (name, phone, address, items)');
    }

    $oid      = 'ORD-' . strtoupper(substr(md5(uniqid()),0,8));
    $tracking = 'TRK-' . strtoupper(substr(md5(uniqid()),0,6));
    $now      = date('c');
    $source   = $b['source'] ?? 'online';
    $history  = [['status'=>'New','at'=>$now,'note'=>$source==='walkin'?'Manual order added':'Order placed']];

    $stmt = $db->prepare("INSERT INTO orders
        (id, tracking, customer_name, customer_phone, customer_email,
         address, pincode, items, total, discount, shipping, coupon,
         pay_method, payment_status, status, history, notes, user_id, source)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

    $payMethod = $b['payMethod'] ?? 'cod';
    $payStatusDefault = $payMethod === 'cod' ? 'Pending' : 'Awaiting';
    $payStatus = $b['paymentStatus'] ?? $payStatusDefault;
    $statusInit = $b['status'] ?? 'New';
    $stmt->execute([
        $oid, $tracking, $name, $phone, $email, $addr, $pin,
        json_encode($items, JSON_UNESCAPED_UNICODE),
        $b['total'] ?? 0, $b['discount'] ?? 0, $b['shipping'] ?? 0,
        $b['coupon'] ?? '', $payMethod, $payStatus, $statusInit,
        json_encode($history, JSON_UNESCAPED_UNICODE),
        $b['notes'] ?? '', $b['userId'] ?? null, $source,
    ]);

    if (!empty($items)) {
        $upd = $db->prepare("UPDATE products SET order_count = order_count + 1 WHERE id = ?");
        foreach ($items as $item) {
            if (!empty($item['productId'])) $upd->execute([$item['productId']]);
        }
    }
    if (!empty($b['coupon'])) {
        $db->prepare("UPDATE coupons SET uses = uses + 1 WHERE code = ?")->execute([$b['coupon']]);
    }

    // ── AUTO-EMAIL: order confirmation ──
    if ($source !== 'walkin' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        triggerOrderEmail('order_confirmed', $oid);
    }

    // ── LOYALTY COINS: queue earn-request (admin must approve before crediting) ──
    // NOTE: earnCoinsForOrder() was removed to prevent double-crediting.
    // The frontend (index.html) also calls /api/coins/earn-request after order placement.
    // coins.php earn-approve handles the actual credit — only once, checked by coin_transactions.

    jsonOk(['id' => $oid, 'tracking' => $tracking, 'source' => $source]);
}

if ($method === 'PUT') {
    requireAdmin();
    if (!$id) jsonError('Order ID required');
    $b = jsonBody();

    $row = $db->prepare("SELECT history, status, courier_tracking FROM orders WHERE id = ?");
    $row->execute([$id]);
    $existing = $row->fetch();
    if (!$existing) jsonError('Order not found', 404);

    $history = json_decode($existing['history'] ?? '[]', true);
    $newStatus = $b['status'] ?? null;
    $statusChanged = $newStatus && $newStatus !== $existing['status'];
    if ($statusChanged) {
        $history[] = ['status'=>$newStatus,'at'=>date('c'),'note'=>($b['note']??'Status updated')];
    }
    $newAwb = $b['courierTracking'] ?? null;
    $awbChanged = $newAwb !== null && $newAwb !== ($existing['courier_tracking'] ?? '');

    $stmt = $db->prepare("UPDATE orders SET
        status           = COALESCE(:st, status),
        payment_status   = COALESCE(:ps, payment_status),
        courier          = COALESCE(:cr, courier),
        courier_tracking = COALESCE(:ct, courier_tracking),
        notes            = COALESCE(:no, notes),
        history          = :hy
        WHERE id = :id");
    $stmt->execute([
        ':st' => $b['status'] ?? null,
        ':ps' => $b['paymentStatus'] ?? null,
        ':cr' => $b['courier'] ?? null,
        ':ct' => $newAwb,
        ':no' => $b['notes'] ?? null,
        ':hy' => json_encode($history, JSON_UNESCAPED_UNICODE),
        ':id' => $id,
    ]);

    // ── AUTO-EMAIL on status / tracking change ──
    $sendEmail = !isset($b['sendEmail']) ? true : !empty($b['sendEmail']);
    if ($sendEmail) {
        if ($statusChanged && $newStatus === 'Delivered') {
            triggerOrderEmail('delivered', $id);
        } elseif ($awbChanged && !empty($newAwb)) {
            triggerOrderEmail('tracking_update', $id);
        } elseif ($statusChanged && in_array($newStatus, ['Shipped','Dispatch'], true)) {
            triggerOrderEmail('tracking_update', $id);
        }
    }

    // Loyalty: revoke coins when admin cancels or refunds the order
    if ($statusChanged && in_array($newStatus, ['Cancelled','Refunded'], true)) {
        try { require_once __DIR__ . '/coins.php'; revokeCoinsForOrder($db, $id, $newStatus); } catch (\Throwable $e) {}
    }

    jsonOk(['updated' => $id]);
}

if ($method === 'DELETE') {
    requireAdmin();
    if (!$id) jsonError('Order ID required');
    $db->prepare("DELETE FROM orders WHERE id=?")->execute([$id]);
    jsonOk(['deleted' => $id]);
}

jsonError('Method not allowed', 405);
