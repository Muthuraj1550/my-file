<?php
// api/upload.php — v32: hardened upload + auto-optimize + thumbnails
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method !== 'POST') jsonError('Method not allowed', 405);
requireAdmin();

if (empty($_FILES['file'])) jsonError('No file uploaded');

$file = $_FILES['file'];
if (!empty($file['error']) && $file['error'] !== UPLOAD_ERR_OK) {
    jsonError('Upload error code: ' . $file['error']);
}

$maxSize = 15 * 1024 * 1024; // 15 MB raw
if ($file['size'] > $maxSize) jsonError('File too large (max 15 MB)');

$detectedMime = '';
if (function_exists('finfo_open')) {
    $f = finfo_open(FILEINFO_MIME_TYPE);
    if ($f) { $detectedMime = finfo_file($f, $file['tmp_name']) ?: ''; finfo_close($f); }
}
if (!$detectedMime) $detectedMime = $file['type'] ?? '';

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$extMap = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','gif'=>'image/gif','webp'=>'image/webp'];
if (!$detectedMime && isset($extMap[$ext])) $detectedMime = $extMap[$ext];

$allowed = ['image/jpeg','image/png','image/gif','image/webp'];
if (!in_array($detectedMime, $allowed, true)) {
    jsonError('Only JPG, PNG, GIF, WEBP allowed (got: ' . $detectedMime . ')');
}
if (!isset($extMap[$ext])) {
    $rev = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
    $ext = $rev[$detectedMime] ?? 'jpg';
}

if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
$thumbDir = UPLOAD_DIR . 'thumbs/';
if (!is_dir($thumbDir)) mkdir($thumbDir, 0755, true);

$name = uniqid('img_', true) . '.' . $ext;
$dest = UPLOAD_DIR . $name;

if (!move_uploaded_file($file['tmp_name'], $dest)) jsonError('Failed to save file', 500);
@chmod($dest, 0644);

$folder = trim($_POST['folder'] ?? 'general');
if (!preg_match('/^[a-zA-Z0-9_-]{1,40}$/', $folder)) $folder = 'general';

// ── Auto-optimize: resize large images (>1920px) and recompress JPG/PNG/WEBP
// GIFs are skipped (animation preservation). 
$thumbUrl = '';
if ($detectedMime !== 'image/gif' && function_exists('imagecreatefromstring')) {
    try {
        $raw = @file_get_contents($dest);
        $src = @imagecreatefromstring($raw);
        if ($src) {
            $w = imagesx($src); $h = imagesy($src);
            $maxDim = 1920;
            if ($w > $maxDim || $h > $maxDim) {
                $ratio = min($maxDim/$w, $maxDim/$h);
                $nw = (int)($w*$ratio); $nh = (int)($h*$ratio);
                $resized = imagecreatetruecolor($nw, $nh);
                if ($detectedMime === 'image/png' || $detectedMime === 'image/webp') {
                    imagealphablending($resized, false); imagesavealpha($resized, true);
                    imagefill($resized, 0, 0, imagecolorallocatealpha($resized,0,0,0,127));
                }
                imagecopyresampled($resized, $src, 0,0,0,0, $nw, $nh, $w, $h);
                switch ($detectedMime) {
                    case 'image/jpeg': imagejpeg($resized, $dest, 85); break;
                    case 'image/png':  imagepng($resized, $dest, 6); break;
                    case 'image/webp': imagewebp($resized, $dest, 85); break;
                }
                imagedestroy($resized);
                $w = $nw; $h = $nh;
            }
            // Thumbnail 400x400 (contain)
            $tw = 400; $th = 400;
            $ratio = min($tw/$w, $th/$h, 1);
            $thw = max(1,(int)($w*$ratio)); $thh = max(1,(int)($h*$ratio));
            $thumb = imagecreatetruecolor($thw, $thh);
            if ($detectedMime === 'image/png' || $detectedMime === 'image/webp') {
                imagealphablending($thumb, false); imagesavealpha($thumb, true);
                imagefill($thumb, 0, 0, imagecolorallocatealpha($thumb,0,0,0,127));
            }
            imagecopyresampled($thumb, $src, 0,0,0,0, $thw, $thh, $w, $h);
            $thumbName = 'th_' . $name;
            $thumbPath = $thumbDir . $thumbName;
            switch ($detectedMime) {
                case 'image/jpeg': imagejpeg($thumb, $thumbPath, 78); break;
                case 'image/png':  imagepng($thumb, $thumbPath, 6); break;
                case 'image/webp': imagewebp($thumb, $thumbPath, 78); break;
            }
            imagedestroy($thumb); imagedestroy($src);
            @chmod($thumbPath, 0644);
            $thumbUrl = UPLOAD_URL . 'thumbs/' . $thumbName;
        }
    } catch (Throwable $e) { /* optimization is best-effort */ }
}

$url = UPLOAD_URL . $name;

try {
    $db = getDB();
    // Ensure columns exist
    $cols = $db->query("SHOW COLUMNS FROM media")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('thumb', $cols, true))  $db->exec("ALTER TABLE media ADD COLUMN thumb VARCHAR(500) NULL");
    if (!in_array('folder', $cols, true)) $db->exec("ALTER TABLE media ADD COLUMN folder VARCHAR(60) DEFAULT 'general'");
    $stmt = $db->prepare("INSERT INTO media (url, name, mime, size, thumb, folder) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$url, $file['name'], $detectedMime, (int)filesize($dest), $thumbUrl, $folder]);
} catch (Throwable $e) { /* ok */ }

jsonOk(['url' => $url, 'name' => $name, 'size' => (int)filesize($dest), 'mime' => $detectedMime, 'thumb' => $thumbUrl, 'folder' => $folder]);
