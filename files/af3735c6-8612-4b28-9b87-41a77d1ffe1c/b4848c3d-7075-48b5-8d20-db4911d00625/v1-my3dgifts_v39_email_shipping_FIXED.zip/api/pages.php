<?php
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
$db = getDB();

// Auto-heal: create pages table if missing
$db->exec("CREATE TABLE IF NOT EXISTS pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(120) UNIQUE NOT NULL, title VARCHAR(255) NOT NULL,
    content LONGTEXT, show_in_nav TINYINT(1) DEFAULT 1, sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

function pageRow(array $r): array {
    return [
        'id'         => (int)$r['id'],
        'slug'       => $r['slug'],
        'title'      => $r['title'],
        'content'    => $r['content'],
        'showInNav'  => (bool)$r['show_in_nav'],
        'sortOrder'  => (int)$r['sort_order'],
    ];
}

if ($method === 'GET') {
    if ($id) {
        $stmt = $db->prepare("SELECT * FROM pages WHERE slug=? OR id=? LIMIT 1");
        $stmt->execute([$id, (int)$id]);
        $row = $stmt->fetch();
        if (!$row) jsonError('Page not found', 404);
        jsonOk(pageRow($row));
    } else {
        $rows = $db->query("SELECT * FROM pages ORDER BY sort_order ASC, id ASC")->fetchAll();
        jsonOk(array_map('pageRow', $rows));
    }
}

if ($method === 'POST' || $method === 'PUT') {
    requireAdmin();
    $b = jsonBody();
    $slug = strtolower(preg_replace('/[^a-z0-9-]+/i', '-', $b['slug'] ?? ''));
    if (!$slug) jsonError('Slug required', 400);
    $stmt = $db->prepare("INSERT INTO pages (slug,title,content,show_in_nav,sort_order) VALUES (?,?,?,?,?)
        ON DUPLICATE KEY UPDATE title=VALUES(title),content=VALUES(content),show_in_nav=VALUES(show_in_nav),sort_order=VALUES(sort_order)");
    $stmt->execute([
        $slug, $b['title'] ?? '', $b['content'] ?? '',
        !empty($b['showInNav']) ? 1 : 0,
        (int)($b['sortOrder'] ?? 0),
    ]);
    jsonOk(['saved' => $slug]);
}

if ($method === 'DELETE') {
    requireAdmin();
    if (!$id) jsonError('Missing id/slug', 400);
    $db->prepare("DELETE FROM pages WHERE slug=? OR id=?")->execute([$id, (int)$id]);
    jsonOk(['deleted' => $id]);
}

jsonError('Method not allowed', 405);
