<?php
// setup.php — Run once to install DB tables
// After setup, DELETE this file from server!
// Access: https://yourdomain.com/setup.php?key=SETUP_KEY

define('SETUP_KEY', 'MY3D_SETUP_2024'); // Change this!

if (($_GET['key'] ?? '') !== SETUP_KEY) {
    http_response_code(403);
    die('<h2>403 Forbidden — wrong setup key</h2>');
}

require_once __DIR__ . '/../config.php';

$sql = file_get_contents(__DIR__ . '/install.sql');

// Split into individual statements
$statements = array_filter(array_map('trim', explode(';', $sql)));

$db     = getDB();
$errors = [];
$done   = 0;

foreach ($statements as $stmt) {
    if (empty($stmt)) continue;
    try {
        $db->exec($stmt);
        $done++;
    } catch (PDOException $e) {
        // Ignore "already exists" errors
        if (strpos($e->getMessage(), 'already exists') === false &&
            strpos($e->getMessage(), 'Duplicate entry') === false) {
            $errors[] = htmlspecialchars($e->getMessage());
        } else {
            $done++;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ta">
<head>
<meta charset="UTF-8"/>
<title>MY 3D Gifts — Setup</title>
<style>
body{font-family:sans-serif;max-width:600px;margin:60px auto;padding:20px;}
.ok{color:#16a34a;background:#f0fdf4;border:1px solid #bbf7d0;padding:16px;border-radius:8px;}
.err{color:#dc2626;background:#fef2f2;border:1px solid #fecaca;padding:16px;border-radius:8px;margin-top:8px;}
pre{background:#f1f5f9;padding:12px;border-radius:6px;font-size:12px;overflow:auto;}
</style>
</head>
<body>
<h2>🎁 MY 3D Gifts — Database Setup</h2>

<?php if (empty($errors)): ?>
<div class="ok">
    <strong>✅ Setup complete!</strong><br/>
    <?= $done ?> statements executed successfully.<br/><br/>
    <strong>⚠️ Important:</strong> இந்த <code>setup.php</code> file-ஐ server-இல் இருந்து <strong>delete</strong> செய்யுங்கள்!
</div>
<?php else: ?>
<div class="ok">✅ <?= $done ?> statements OK.</div>
<?php foreach ($errors as $e): ?>
<div class="err">❌ <?= $e ?></div>
<?php endforeach; ?>
<?php endif; ?>

<h3>Next Steps:</h3>
<ol>
    <li><code>config.php</code> file-ல் DB credentials சரி பாருங்கள்</li>
    <li>Admin panel: <a href="/">வலைதளம் திறந்து</a> → Admin → Password: <code>admin123</code></li>
    <li><strong>setup.php delete செய்யுங்கள்!</strong></li>
</ol>
</body>
</html>
