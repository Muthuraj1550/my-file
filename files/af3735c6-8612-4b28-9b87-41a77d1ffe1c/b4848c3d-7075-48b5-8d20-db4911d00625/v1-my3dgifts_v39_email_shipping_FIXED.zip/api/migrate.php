<?php
/* ============================================================
 * MY 3D Gifts — migrate.php (v14)
 * Visit ONCE in browser after upgrading: https://yoursite.com/migrate.php
 * Safe to re-run: idempotent ALTER TABLE / CREATE IF NOT EXISTS.
 * ============================================================ */
require_once __DIR__ . '/../config.php';
header('Content-Type: text/html; charset=utf-8');
$db = getDB();
$logs = [];

function step($db, $sql, $label, &$logs) {
    try { $db->exec($sql); $logs[] = "<span style='color:green'>✓</span> $label"; }
    catch (Throwable $e) { $logs[] = "<span style='color:#b91c1c'>✗</span> $label — " . htmlspecialchars($e->getMessage()); }
}

/* ---- popups (v12) ---- */
step($db, "CREATE TABLE IF NOT EXISTS `popups` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255), `body` TEXT, `type` VARCHAR(20) DEFAULT 'info',
  `icon` VARCHAR(20) DEFAULT '🎉', `cta_label` VARCHAR(100), `cta_url` VARCHAR(500),
  `active` TINYINT(1) DEFAULT 1, `show_after_sec` INT DEFAULT 3, `show_once` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create popups table", $logs);

/* ---- pages (v12) ---- */
step($db, "CREATE TABLE IF NOT EXISTS `pages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `slug` VARCHAR(120) UNIQUE NOT NULL, `title` VARCHAR(255) NOT NULL,
  `content` LONGTEXT, `show_in_nav` TINYINT(1) DEFAULT 1, `sort_order` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create pages table", $logs);

/* ---- abandoned_carts: drop OLD wrong schema, create v14 schema ---- */
$stmt = $db->query("SHOW COLUMNS FROM abandoned_carts LIKE 'customer_name'");
if (!$stmt || !$stmt->fetch()) {
    step($db, "DROP TABLE IF EXISTS abandoned_carts", "Drop legacy abandoned_carts (wrong schema)", $logs);
}
step($db, "CREATE TABLE IF NOT EXISTS `abandoned_carts` (
  `id` VARCHAR(40) PRIMARY KEY, `customer_name` VARCHAR(255),
  `customer_phone` VARCHAR(30), `customer_email` VARCHAR(255),
  `items` LONGTEXT, `total` DECIMAL(10,2) DEFAULT 0,
  `last_step` VARCHAR(50) DEFAULT 'cart',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create abandoned_carts (v14 schema)", $logs);

/* ---- media library (v14) ---- */
step($db, "CREATE TABLE IF NOT EXISTS `media` (
  `id` INT AUTO_INCREMENT PRIMARY KEY, `url` VARCHAR(500) NOT NULL,
  `name` VARCHAR(255), `mime` VARCHAR(60), `size` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create media table", $logs);

/* ---- orders.source column (v14) ---- */
$has = $db->query("SHOW COLUMNS FROM orders LIKE 'source'")->fetch();
if (!$has) step($db, "ALTER TABLE orders ADD COLUMN `source` VARCHAR(20) DEFAULT 'online'", "Add orders.source", $logs);
else $logs[] = "<span style='color:#888'>=</span> orders.source already exists";

/* ---- new default settings keys (v14) ---- */
$defaults = [
    'whatsappUpiEnabled' => 'false',
    'upiId'              => '""',
    'desktopBnavEnabled' => 'false',
    'homePageSlug'       => '""',
    'optionDefs'         => '{}',  // per-product custom labels stored on product itself; this is global fallback
];
$ins = $db->prepare("INSERT IGNORE INTO settings (skey, svalue) VALUES (?, ?)");
foreach ($defaults as $k => $v) { $ins->execute([$k, $v]); }
$logs[] = "<span style='color:green'>✓</span> Seeded v14 default settings keys";

/* ---- v17: accounts ledger ---- */
step($db, "CREATE TABLE IF NOT EXISTS accounts_ledger (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kind VARCHAR(10) NOT NULL,
  category VARCHAR(80) DEFAULT '',
  description VARCHAR(255) DEFAULT '',
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  ref_type VARCHAR(30) DEFAULT '',
  ref_id VARCHAR(40) DEFAULT '',
  entry_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_ref (ref_type, ref_id, kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create accounts_ledger (v17)", $logs);

echo "<h2 style='font-family:sans-serif'>Migration result</h2><ul style='font-family:monospace;font-size:13px'>";
foreach ($logs as $l) echo "<li>$l</li>";
echo "</ul><p>✅ Done. <b>Delete this file (migrate.php) from server after success.</b></p>";
