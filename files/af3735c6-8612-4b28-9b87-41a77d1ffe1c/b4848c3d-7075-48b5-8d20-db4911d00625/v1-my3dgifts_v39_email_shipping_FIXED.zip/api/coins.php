<?php
// api/coins.php — Loyalty Coins System v1.0
// Endpoints:
//   GET    /api/coins?phone=...        → user coin balance + history
//   POST   /api/coins/earn             → add coins after order (called internally)
//   POST   /api/coins/redeem           → redeem coins at checkout
//   GET    /api/coins/settings         → public: get coins config
//   PUT    /api/coins/settings         → admin: update coins config
//   GET    /api/coins/users            → admin: all users with coin balances

if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';

// ── Guard: when included from orders.php, only define functions — skip routing ─
define('COINS_PHP_LOADED', true);
$_COINS_AS_INCLUDE = defined('ORDERS_PHP_RUNNING');

if (!$_COINS_AS_INCLUDE) {
    if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (!isset($id)) {
        $uri  = $_SERVER['REQUEST_URI'] ?? '';
        $path = trim(parse_url($uri, PHP_URL_PATH), '/');
        $segs = explode('/', $path);
        // Remove the resource name ('coins') from segments to get the sub-id
        // e.g. api/coins/earn-approve → ['api','coins','earn-approve'] → id = 'earn-approve'
        // e.g. api/coins → ['api','coins'] → id = null
        $last = end($segs);
        $id   = ($last && $last !== 'coins' && !str_ends_with($last, '.php')) ? $last : null;
    }
}
$db = getDB();

// ── Ensure coins tables exist ────────────────────────────────────────────────
$db->exec("CREATE TABLE IF NOT EXISTS `user_coins` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT NOT NULL,
  `balance`    DECIMAL(10,2) NOT NULL DEFAULT 0,
  `total_earned` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `total_redeemed` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS `coin_transactions` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT NOT NULL,
  `order_id`   VARCHAR(40),
  `type`       ENUM('earn','redeem','expire','adjust') NOT NULL,
  `coins`      DECIMAL(10,2) NOT NULL,
  `note`       VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Default coin settings
$db->exec("INSERT IGNORE INTO `settings` (`skey`, `svalue`) VALUES
  ('coinsEnabled',         'false'),
  ('coinsPerRupee',        '1'),
  ('coinsValuePerRupee',   '0.25'),
  ('coinsMinRedeem',       '50'),
  ('coinsMaxRedeemPct',    '20'),
  ('coinsMaxRedeemAmt',    '50'),
  ('coinsEarnPct',         '5')
");

// ── Helper: get coins settings ────────────────────────────────────────────────
function getCoinsSettings($db): array {
    $rows = $db->query("SELECT skey, svalue FROM settings WHERE skey IN (
        'coinsEnabled','coinsPerRupee','coinsValuePerRupee',
        'coinsMinRedeem','coinsMaxRedeemPct','coinsMaxRedeemAmt','coinsEarnPct'
    )")->fetchAll();
    $s = [];
    foreach ($rows as $r) $s[$r['skey']] = json_decode($r['svalue'], true);
    return [
        'enabled'          => (bool)($s['coinsEnabled']         ?? false),
        'coinsPerRupee'    => (float)($s['coinsPerRupee']        ?? 1),
        'coinsValuePerRupee'=> (float)($s['coinsValuePerRupee'] ?? 0.25),
        'minRedeem'        => (float)($s['coinsMinRedeem']       ?? 50),
        'maxRedeemPct'     => (float)($s['coinsMaxRedeemPct']    ?? 20),
        'maxRedeemAmt'     => (float)($s['coinsMaxRedeemAmt']    ?? 50),
        'earnPct'          => (float)($s['coinsEarnPct']         ?? 5),
    ];
}

// ── Helper: coins value in rupees ─────────────────────────────────────────────
function coinsToRupees(float $coins, array $cfg): float {
    if ($cfg['coinsPerRupee'] <= 0) return 0;
    return round($coins / $cfg['coinsPerRupee'] * $cfg['coinsValuePerRupee'], 2);
}

// ── All API routing (skipped when included from orders.php) ──────────────────
if (!$_COINS_AS_INCLUDE) {

// ── GET /api/coins?phone=... ──────────────────────────────────────────────────
if ($method === 'GET' && !$id) {
    $phone = $_GET['phone'] ?? '';
    if (!$phone) jsonError('phone required');
    $userRow = $db->prepare("SELECT id FROM users WHERE phone = ?");
    $userRow->execute([$phone]);
    $user = $userRow->fetch();
    if (!$user) jsonOk(['balance'=>0,'rupees'=>0,'history'=>[]]);
    $uid = $user['id'];
    $cfg = getCoinsSettings($db);
    $bal = $db->prepare("SELECT * FROM user_coins WHERE user_id = ?");
    $bal->execute([$uid]);
    $row = $bal->fetch();
    $balance = $row ? (float)$row['balance'] : 0;
    $hist = $db->prepare("SELECT * FROM coin_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 30");
    $hist->execute([$uid]);
    jsonOk([
        'balance'       => $balance,
        'rupees'        => coinsToRupees($balance, $cfg),
        'totalEarned'   => $row ? (float)$row['total_earned'] : 0,
        'totalRedeemed' => $row ? (float)$row['total_redeemed'] : 0,
        'minRedeem'     => $cfg['minRedeem'],
        'maxRedeemPct'  => $cfg['maxRedeemPct'],
        'history'       => $hist->fetchAll(),
    ]);
}

// ── GET /api/coins/settings ───────────────────────────────────────────────────
if ($method === 'GET' && $id === 'settings') {
    jsonOk(getCoinsSettings($db));
}

// ── PUT /api/coins/settings  (admin) ─────────────────────────────────────────
if ($method === 'PUT' && $id === 'settings') {
    requireAdmin();
    $b = jsonBody();
    $map = [
        'enabled'           => 'coinsEnabled',
        'coinsPerRupee'     => 'coinsPerRupee',
        'coinsValuePerRupee'=> 'coinsValuePerRupee',
        'minRedeem'         => 'coinsMinRedeem',
        'maxRedeemPct'      => 'coinsMaxRedeemPct',
        'maxRedeemAmt'      => 'coinsMaxRedeemAmt',
        'earnPct'           => 'coinsEarnPct',
    ];
    $stmt = $db->prepare("INSERT INTO settings (skey,svalue) VALUES (?,?) ON DUPLICATE KEY UPDATE svalue=VALUES(svalue)");
    foreach ($map as $jsKey => $dbKey) {
        if (array_key_exists($jsKey, $b)) {
            $stmt->execute([$dbKey, json_encode($b[$jsKey])]);
        }
    }
    jsonOk(['saved' => true]);
}

// ── POST /api/coins/earn  (called after order placed) ─────────────────────────
// Body: { phone, orderId, orderTotal }
if ($method === 'POST' && $id === 'earn') {
    $b   = jsonBody();
    $cfg = getCoinsSettings($db);
    if (!$cfg['enabled']) jsonOk(['coins'=>0,'message'=>'Coins disabled']);
    $phone = $b['phone'] ?? '';
    $orderId = $b['orderId'] ?? '';
    $total   = (float)($b['orderTotal'] ?? 0);
    if (!$phone || !$orderId || $total <= 0) jsonError('phone, orderId, orderTotal required');
    // Get/create user
    $uStmt = $db->prepare("SELECT id FROM users WHERE phone = ?");
    $uStmt->execute([$phone]);
    $user = $uStmt->fetch();
    if (!$user) {
        // Auto-create user record so coins can be tracked (guest checkout support)
        $db->prepare("INSERT INTO users (name, phone) VALUES (?,?) ON DUPLICATE KEY UPDATE name=VALUES(name)")
           ->execute([$b['name'] ?? 'Guest', $phone]);
        $uid = $db->lastInsertId();
        if (!$uid) {
            $uStmt->execute([$phone]);
            $uid = $uStmt->fetch()['id'] ?? null;
        }
        if (!$uid) jsonError('User not found and could not create');
    } else {
        $uid = $user['id'];
    }
    // Check if already earned for this order
    $dup = $db->prepare("SELECT id FROM coin_transactions WHERE order_id = ? AND type = 'earn'");
    $dup->execute([$orderId]);
    if ($dup->fetch()) jsonOk(['coins'=>0,'message'=>'Already earned for this order']);
    // Calculate coins: earnPct % of orderTotal → converted to coins
    $earnRupees = round($total * $cfg['earnPct'] / 100, 2);
    $earnCoins  = round($earnRupees * $cfg['coinsPerRupee'] / $cfg['coinsValuePerRupee']);
    if ($earnCoins <= 0) jsonOk(['coins'=>0]);
    // Upsert balance
    $db->prepare("INSERT INTO user_coins (user_id, balance, total_earned)
                  VALUES (?,?,?)
                  ON DUPLICATE KEY UPDATE
                    balance      = balance + VALUES(balance),
                    total_earned = total_earned + VALUES(total_earned),
                    updated_at   = NOW()")
       ->execute([$uid, $earnCoins, $earnCoins]);
    $db->prepare("INSERT INTO coin_transactions (user_id, order_id, type, coins, note)
                  VALUES (?,?,?,?,?)")
       ->execute([$uid, $orderId, 'earn', $earnCoins, "Earned for order #$orderId"]);
    jsonOk(['coins' => $earnCoins, 'rupeeValue' => $earnRupees]);
}

// ── POST /api/coins/redeem ─────────────────────────────────────────────────────
// Body: { phone, coinsToRedeem, orderId }
// Returns: { discount } (rupee amount to deduct)
if ($method === 'POST' && $id === 'redeem') {
    $b   = jsonBody();
    $cfg = getCoinsSettings($db);
    if (!$cfg['enabled']) jsonError('Coins feature disabled');
    $phone  = $b['phone'] ?? '';
    $coins  = (float)($b['coinsToRedeem'] ?? 0);
    $orderId = $b['orderId'] ?? '';
    $orderTotal = (float)($b['orderTotal'] ?? 0);
    if (!$phone || $coins <= 0) jsonError('phone and coinsToRedeem required');
    if ($coins < $cfg['minRedeem']) jsonError("Minimum {$cfg['minRedeem']} coins needed to redeem");
    // Get user
    $uStmt = $db->prepare("SELECT id FROM users WHERE phone = ?");
    $uStmt->execute([$phone]);
    $user = $uStmt->fetch();
    if (!$user) jsonError('User not found');
    $uid = $user['id'];
    // Get balance
    $balStmt = $db->prepare("SELECT balance FROM user_coins WHERE user_id = ?");
    $balStmt->execute([$uid]);
    $balRow = $balStmt->fetch();
    $balance = $balRow ? (float)$balRow['balance'] : 0;
    if ($coins > $balance) jsonError('Insufficient coins');
    // Enforce maxRedeemAmt (rupee cap per order)
    $maxAmt = (float)($cfg['maxRedeemAmt'] ?? 0);
    if ($maxAmt > 0) {
        $requestedDiscount = coinsToRupees($coins, $cfg);
        if ($requestedDiscount > $maxAmt) {
            $coins = floor($maxAmt / $cfg['coinsValuePerRupee'] * $cfg['coinsPerRupee']);
        }
    }
    $discount = coinsToRupees($coins, $cfg);
    // Deduct
    $db->prepare("UPDATE user_coins SET balance = balance - ?, total_redeemed = total_redeemed + ? WHERE user_id = ?")
       ->execute([$coins, $coins, $uid]);
    $db->prepare("INSERT INTO coin_transactions (user_id, order_id, type, coins, note) VALUES (?,?,?,?,?)")
       ->execute([$uid, $orderId ?: null, 'redeem', $coins, "Redeemed: ₹$discount discount"]);
    jsonOk(['coinsUsed' => $coins, 'discount' => $discount]);
}

// ── GET /api/coins/users  (admin) ─────────────────────────────────────────────
if ($method === 'GET' && $id === 'users') {
    requireAdmin();
    $cfg = getCoinsSettings($db);
    $rows = $db->query("SELECT u.id, u.name, u.phone, u.email,
        COALESCE(uc.balance,0) AS balance,
        COALESCE(uc.total_earned,0) AS total_earned,
        COALESCE(uc.total_redeemed,0) AS total_redeemed
      FROM users u
      LEFT JOIN user_coins uc ON uc.user_id = u.id
      ORDER BY balance DESC")->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'id'           => (int)$r['id'],
            'name'         => $r['name'],
            'phone'        => $r['phone'],
            'email'        => $r['email'],
            'coins'        => (float)$r['balance'],
            'rupees'       => coinsToRupees((float)$r['balance'], $cfg),
            'totalEarned'  => (float)$r['total_earned'],
            'totalRedeemed'=> (float)$r['total_redeemed'],
        ];
    }
    jsonOk($out);
}

// ── POST /api/coins/adjust  (admin manual adjust) ─────────────────────────────
if ($method === 'POST' && $id === 'adjust') {
    requireAdmin();
    $b = jsonBody();
    $uid   = (int)($b['userId'] ?? 0);
    $coins = (float)($b['coins'] ?? 0);
    $note  = $b['note'] ?? 'Admin adjustment';
    if (!$uid || $coins == 0) jsonError('userId and coins required');
    $db->prepare("INSERT INTO user_coins (user_id, balance, total_earned)
                  VALUES (?,GREATEST(0,?),GREATEST(0,?))
                  ON DUPLICATE KEY UPDATE
                    balance      = GREATEST(0, balance + VALUES(balance)),
                    total_earned = IF(VALUES(total_earned)>0, total_earned + VALUES(total_earned), total_earned),
                    updated_at   = NOW()")
       ->execute([$uid, $coins, max(0,$coins)]);
    $db->prepare("INSERT INTO coin_transactions (user_id, type, coins, note) VALUES (?,?,?,?)")
       ->execute([$uid, 'adjust', $coins, $note]);
    jsonOk(['adjusted' => $coins]);
}

// ── POST /api/coins/cashredeem ─────────────────────────────────────────────────
// Body: { phone, coins }
// Records a "cash redeem request" — admin will manually transfer via UPI/Bank.
// Coins are deducted immediately and marked as pending cash payout.
if ($method === 'POST' && $id === 'cashredeem') {
    $b   = jsonBody();
    $cfg = getCoinsSettings($db);
    if (!$cfg['enabled']) jsonError('Coins feature disabled');
    $phone = trim($b['phone'] ?? '');
    $coins = (float)($b['coins'] ?? 0);
    if (!$phone || $coins <= 0) jsonError('phone மற்றும் coins required');
    if ($coins < $cfg['minRedeem']) jsonError("குறைந்தபட்சம் {$cfg['minRedeem']} coins தேவை");

    // Get user
    $uStmt = $db->prepare("SELECT id, name, phone, email FROM users WHERE phone = ?");
    $uStmt->execute([$phone]);
    $user = $uStmt->fetch();
    if (!$user) jsonError('User not found');
    $uid = $user['id'];

    // Get current balance
    $balStmt = $db->prepare("SELECT balance FROM user_coins WHERE user_id = ?");
    $balStmt->execute([$uid]);
    $balRow  = $balStmt->fetch();
    $balance = $balRow ? (float)$balRow['balance'] : 0;
    if ($coins > $balance) jsonError("Insufficient coins. Balance: $balance");

    // Calculate rupee value
    $rupees = coinsToRupees($coins, $cfg);

    // Deduct coins immediately (pending payout)
    $db->prepare("UPDATE user_coins SET balance = balance - ?, total_redeemed = total_redeemed + ? WHERE user_id = ?")
       ->execute([$coins, $coins, $uid]);

    // Record transaction
    $txNote = "Cash redeem request: ₹{$rupees} (pending admin payout)";
    $db->prepare("INSERT INTO coin_transactions (user_id, order_id, type, coins, note) VALUES (?,?,?,?,?)")
       ->execute([$uid, null, 'redeem', $coins, $txNote]);

    // Record in a cash_redeem_requests table (auto-create)
    $db->exec("CREATE TABLE IF NOT EXISTS `cash_redeem_requests` (
        `id`         INT AUTO_INCREMENT PRIMARY KEY,
        `user_id`    INT NOT NULL,
        `user_name`  VARCHAR(100),
        `phone`      VARCHAR(20),
        `coins`      DECIMAL(10,2) NOT NULL,
        `rupees`     DECIMAL(10,2) NOT NULL,
        `status`     ENUM('pending','paid','rejected') DEFAULT 'pending',
        `admin_note` VARCHAR(255) DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $db->prepare("INSERT INTO cash_redeem_requests (user_id, user_name, phone, coins, rupees) VALUES (?,?,?,?,?)")
       ->execute([$uid, $user['name'], $phone, $coins, $rupees]);

    jsonOk([
        'coinsRedeemed' => $coins,
        'rupees'        => $rupees,
        'message'       => "Request submitted. Admin approve செய்த பிறகு ₹{$rupees} transfer ஆகும்.",
    ]);
}

// ── GET /api/coins/cashredeem-list  (admin) ────────────────────────────────────
if ($method === 'GET' && $id === 'cashredeem-list') {
    requireAdmin();
    $db->exec("CREATE TABLE IF NOT EXISTS `cash_redeem_requests` (
        `id`         INT AUTO_INCREMENT PRIMARY KEY,
        `user_id`    INT NOT NULL,
        `user_name`  VARCHAR(100),
        `phone`      VARCHAR(20),
        `coins`      DECIMAL(10,2) NOT NULL,
        `rupees`     DECIMAL(10,2) NOT NULL,
        `status`     ENUM('pending','paid','rejected') DEFAULT 'pending',
        `admin_note` VARCHAR(255) DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $rows = $db->query("SELECT * FROM cash_redeem_requests ORDER BY created_at DESC LIMIT 200")->fetchAll();
    jsonOk($rows);
}

// ── POST /api/coins/cashredeem-status  (admin) ─────────────────────────────────
// Body: { id, status: 'paid'|'rejected' }
// If rejected → refund coins back to user
if ($method === 'POST' && $id === 'cashredeem-status') {
    requireAdmin();
    $b      = jsonBody();
    $reqId  = (int)($b['id'] ?? 0);
    $status = $b['status'] ?? '';
    if (!$reqId || !in_array($status, ['paid','rejected'])) jsonError('id and valid status required');

    $stmt = $db->prepare("SELECT * FROM cash_redeem_requests WHERE id = ?");
    $stmt->execute([$reqId]);
    $req = $stmt->fetch();
    if (!$req) jsonError('Request not found');
    if ($req['status'] !== 'pending') jsonError('Already processed');

    // Update status
    $db->prepare("UPDATE cash_redeem_requests SET status = ?, updated_at = NOW() WHERE id = ?")
       ->execute([$status, $reqId]);

    // If rejected → refund coins
    if ($status === 'rejected') {
        $uid   = (int)$req['user_id'];
        $coins = (float)$req['coins'];
        $db->prepare("UPDATE user_coins SET balance = balance + ?, total_redeemed = total_redeemed - ? WHERE user_id = ?")
           ->execute([$coins, $coins, $uid]);
        $db->prepare("INSERT INTO coin_transactions (user_id, type, coins, note) VALUES (?,?,?,?)")
           ->execute([$uid, 'adjust', $coins, "Refund: cash redeem request #{$reqId} rejected"]);
    }

    jsonOk(['updated' => $reqId, 'status' => $status]);
}

// ── Ensure pending earn requests table exists ─────────────────────────────────
$db->exec("CREATE TABLE IF NOT EXISTS `coin_earn_requests` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT,
  `user_name`  VARCHAR(100),
  `phone`      VARCHAR(20),
  `order_id`   VARCHAR(40),
  `order_total` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `coins`      DECIMAL(10,2) NOT NULL,
  `status`     ENUM('pending','approved','rejected') DEFAULT 'pending',
  `admin_note` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── POST /api/coins/earn-request  (user — creates pending earn request) ──────
if ($method === 'POST' && $id === 'earn-request') {
    $b   = jsonBody();
    $cfg = getCoinsSettings($db);
    if (!$cfg['enabled']) jsonOk(['queued'=>0,'message'=>'Coins disabled']);
    $phone   = trim($b['phone'] ?? '');
    $name    = trim($b['name']  ?? 'Customer');
    $orderId = trim($b['orderId'] ?? '');
    $total   = (float)($b['orderTotal'] ?? 0);
    $coins   = (float)($b['coins'] ?? 0);
    if (!$phone || !$orderId || $total <= 0) jsonError('phone, orderId, orderTotal required');
    if ($coins <= 0) {
        $earnRupees = round($total * $cfg['earnPct'] / 100, 2);
        $coins = round($earnRupees * $cfg['coinsPerRupee'] / $cfg['coinsValuePerRupee']);
    }
    if ($coins <= 0) jsonOk(['queued'=>0]);
    // Get/create user
    $uStmt = $db->prepare("SELECT id FROM users WHERE phone = ?");
    $uStmt->execute([$phone]);
    $user = $uStmt->fetch();
    $uid = $user['id'] ?? null;
    if (!$uid) {
        $db->prepare("INSERT INTO users (name, phone) VALUES (?,?) ON DUPLICATE KEY UPDATE name=VALUES(name)")
           ->execute([$name, $phone]);
        $uStmt->execute([$phone]);
        $uid = $uStmt->fetch()['id'] ?? null;
    }
    // Insert (ignore duplicate order)
    $db->prepare("INSERT IGNORE INTO coin_earn_requests
                  (user_id, user_name, phone, order_id, order_total, coins, status)
                  VALUES (?,?,?,?,?,?, 'pending')")
       ->execute([$uid, $name, $phone, $orderId, $total, $coins]);
    jsonOk(['queued' => 1, 'coins' => $coins]);
}

// ── GET /api/coins/earn-status?phone=...  (user — list their earn requests) ──
if ($method === 'GET' && $id === 'earn-status') {
    $phone = trim($_GET['phone'] ?? '');
    if (!$phone) jsonError('phone required');
    $stmt = $db->prepare("SELECT order_id, coins, status, admin_note, updated_at
                          FROM coin_earn_requests WHERE phone = ?
                          ORDER BY created_at DESC LIMIT 200");
    $stmt->execute([$phone]);
    $out = [];
    foreach ($stmt->fetchAll() as $r) {
        $out[$r['order_id']] = [
            'coins'  => (float)$r['coins'],
            'status' => $r['status'],
            'note'   => $r['admin_note'],
        ];
    }
    jsonOk($out);
}

// ── GET /api/coins/earn-pending  (admin — list pending earn requests) ────────
if ($method === 'GET' && $id === 'earn-pending') {
    requireAdmin();
    $st = $_GET['status'] ?? 'pending';
    $stmt = $db->prepare("SELECT * FROM coin_earn_requests WHERE status = ? ORDER BY created_at DESC LIMIT 500");
    $stmt->execute([$st]);
    jsonOk($stmt->fetchAll());
}

// ── POST /api/coins/earn-approve  (admin) ────────────────────────────────────
// Body: { id, status: 'approved'|'rejected', note? }
if ($method === 'POST' && $id === 'earn-approve') {
    requireAdmin();
    $b   = jsonBody();
    $rid = (int)($b['id'] ?? 0);
    $st  = $b['status'] ?? '';
    $note= $b['note'] ?? '';
    if (!$rid || !in_array($st, ['approved','rejected'])) jsonError('id and valid status required');
    $stmt = $db->prepare("SELECT * FROM coin_earn_requests WHERE id = ?");
    $stmt->execute([$rid]);
    $req = $stmt->fetch();
    if (!$req) jsonError('Request not found');
    if ($req['status'] !== 'pending') jsonError('Already processed');
    $db->prepare("UPDATE coin_earn_requests SET status=?, admin_note=?, updated_at=NOW() WHERE id=?")
       ->execute([$st, $note, $rid]);
    if ($st === 'approved') {
        $uid   = (int)$req['user_id'];
        $coins = (float)$req['coins'];
        $oid   = $req['order_id'];
        $phone = $req['phone'] ?? '';

        // If user_id is missing (NULL/0), try to find user by phone
        if (!$uid && $phone) {
            $uRow = $db->prepare("SELECT id FROM users WHERE phone = ?");
            $uRow->execute([$phone]);
            $found = $uRow->fetch();
            if ($found) {
                $uid = (int)$found['id'];
                // Also fix the earn request record for future reference
                $db->prepare("UPDATE coin_earn_requests SET user_id=? WHERE id=?")
                   ->execute([$uid, $rid]);
            }
        }

        // Skip if already credited for this order
        $dup = $db->prepare("SELECT id FROM coin_transactions WHERE order_id=? AND type='earn'");
        $dup->execute([$oid]);
        if (!$dup->fetch() && $uid && $coins > 0) {
            $db->prepare("INSERT INTO user_coins (user_id, balance, total_earned)
                          VALUES (?,?,?)
                          ON DUPLICATE KEY UPDATE
                            balance      = balance + VALUES(balance),
                            total_earned = total_earned + VALUES(total_earned),
                            updated_at   = NOW()")
               ->execute([$uid, $coins, $coins]);
            $db->prepare("INSERT INTO coin_transactions (user_id, order_id, type, coins, note) VALUES (?,?,?,?,?)")
               ->execute([$uid, $oid, 'earn', $coins, "Approved for order #$oid"]);
        }
    }
    jsonOk(['updated' => $rid, 'status' => $st]);
}

jsonError('Method or endpoint not allowed', 405);

// ── Reusable: called from orders.php ─────────────────────────────────────────

} // end routing guard

function earnCoinsForOrder($db, string $phone, string $orderId, float $total): void {
    $cfg = getCoinsSettings($db);
    if (!$cfg['enabled'] || $total <= 0) return;
    $uRow = $db->prepare("SELECT id FROM users WHERE phone = ?");
    $uRow->execute([$phone]);
    $user = $uRow->fetch();
    if (!$user) return;
    $uid = $user['id'];
    $dup = $db->prepare("SELECT id FROM coin_transactions WHERE order_id = ? AND type = 'earn'");
    $dup->execute([$orderId]);
    if ($dup->fetch()) return;
    $earnRupees = round($total * $cfg['earnPct'] / 100, 2);
    $earnCoins  = round($earnRupees * $cfg['coinsPerRupee'] / $cfg['coinsValuePerRupee']);
    if ($earnCoins <= 0) return;
    $db->prepare("INSERT INTO user_coins (user_id, balance, total_earned)
                  VALUES (?,?,?)
                  ON DUPLICATE KEY UPDATE
                    balance      = balance + VALUES(balance),
                    total_earned = total_earned + VALUES(total_earned),
                    updated_at   = NOW()")
       ->execute([$uid, $earnCoins, $earnCoins]);
    $db->prepare("INSERT INTO coin_transactions (user_id, order_id, type, coins, note)
                  VALUES (?,?,?,?,?)")
       ->execute([$uid, $orderId, 'earn', $earnCoins, "Earned for order #$orderId"]);
}

// Revoke previously earned coins for an order (called when admin cancels/refunds).
// Idempotent — won't revoke twice.
function revokeCoinsForOrder($db, string $orderId, string $reason = 'Order cancelled'): void {
    $stmt = $db->prepare("SELECT id, user_id, coins FROM coin_transactions WHERE order_id = ? AND type = 'earn'");
    $stmt->execute([$orderId]);
    $earn = $stmt->fetch();
    if (!$earn) return;
    $rev = $db->prepare("SELECT id FROM coin_transactions WHERE order_id = ? AND type = 'adjust' AND note LIKE 'Revoked:%'");
    $rev->execute([$orderId]);
    if ($rev->fetch()) return;
    $uid   = (int)$earn['user_id'];
    $coins = (float)$earn['coins'];
    if ($coins <= 0) return;
    $db->prepare("UPDATE user_coins
                  SET balance = GREATEST(0, balance - ?),
                      total_earned = GREATEST(0, total_earned - ?),
                      updated_at = NOW()
                  WHERE user_id = ?")
       ->execute([$coins, $coins, $uid]);
    $db->prepare("INSERT INTO coin_transactions (user_id, order_id, type, coins, note) VALUES (?,?,?,?,?)")
       ->execute([$uid, $orderId, 'adjust', -$coins, "Revoked: $reason (order #$orderId)"]);
}

