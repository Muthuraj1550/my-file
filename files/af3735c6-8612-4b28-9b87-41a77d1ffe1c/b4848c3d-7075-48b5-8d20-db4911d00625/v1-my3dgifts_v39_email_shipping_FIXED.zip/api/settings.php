<?php
// Standalone direct-access header (works both via index.php router and direct .php URL)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    // id is the segment after the php filename or resource name
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
// api/settings.php
$db = getDB();

if ($method === 'GET') {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    // Return all settings as a flat key→value object
    $rows = $db->query("SELECT skey, svalue FROM settings")->fetchAll();
    $out  = [];
    foreach ($rows as $r) {
        $decoded = json_decode($r['svalue'], true);
        // If the decoded value is still a JSON string (double-encoded), decode again
        if (is_string($decoded)) {
            $second = json_decode($decoded, true);
            if (json_last_error() === JSON_ERROR_NONE && $second !== null) {
                $decoded = $second;
            }
        }
        $out[$r['skey']] = $decoded;
    }
    jsonOk($out);
}

if ($method === 'POST' || $method === 'PUT') {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    requireAdmin();
    $body = jsonBody();
    $stmt = $db->prepare("INSERT INTO settings (skey, svalue) VALUES (:k, :v)
                          ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)");
    foreach ($body as $k => $v) {
        $stmt->execute([':k' => $k, ':v' => json_encode($v, JSON_UNESCAPED_UNICODE)]);
    }
    jsonOk(['saved' => count($body)]);
}

jsonError('Method not allowed', 405);
