<?php
// Standalone direct-access header (works both via index.php router and direct .php URL)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    // id is the segment after the php filename or resource name
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
// api/track.php
$db = getDB();

if ($method === 'GET') {
    $q = $_GET['q'] ?? $id ?? '';
    if (!$q) jsonError('Tracking ID or Order ID required');
    $stmt = $db->prepare("SELECT * FROM orders WHERE id = ? OR tracking = ?");
    $stmt->execute([$q, $q]);
    $row = $stmt->fetch();
    if (!$row) jsonError('Order not found', 404);
    // Return only safe fields for customer
    jsonOk([
        'id'             => $row['id'],
        'tracking'       => $row['tracking'],
        'status'         => $row['status'],
        'paymentStatus'  => $row['payment_status'],
        'courier'        => $row['courier'],
        'courierTracking'=> $row['courier_tracking'],
        'history'        => json_decode($row['history']??'[]',true),
        'createdAt'      => $row['created_at'],
        'items'          => json_decode($row['items']??'[]',true),
        'total'          => (float)$row['total'],
    ]);
}

jsonError('Method not allowed', 405);
