<?php
// Standalone direct-access header (works both via index.php router and direct .php URL)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    // id is the segment after the php filename or resource name
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
// api/users.php
$db = getDB();

function userRow(array $r): array {
    return [
        'id'        => (int)$r['id'],
        'name'      => $r['name'],
        'phone'     => $r['phone'],
        'email'     => $r['email'],
        'addresses' => json_decode($r['addresses'] ?? '[]', true),
        'createdAt' => $r['created_at'],
    ];
}

if ($method === 'GET') {
    if ($id) {
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ? OR phone = ?");
        $stmt->execute([$id, $id]);
        $row = $stmt->fetch();
        if (!$row) jsonError('User not found', 404);
        jsonOk(userRow($row));
    } else {
        requireAdmin();
        jsonOk(array_map('userRow', $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll()));
    }
}

if ($method === 'POST') {
    $b = jsonBody();
    if (empty($b['phone'])) jsonError('Phone required');
    // Upsert user
    $stmt = $db->prepare("INSERT INTO users (name, phone, email, addresses) VALUES (?,?,?,?)
                          ON DUPLICATE KEY UPDATE
                            name      = COALESCE(VALUES(name), name),
                            email     = COALESCE(VALUES(email), email)");
    $stmt->execute([
        $b['name'] ?? '',
        $b['phone'],
        $b['email'] ?? '',
        json_encode($b['addresses'] ?? [], JSON_UNESCAPED_UNICODE),
    ]);
    $uid = $db->lastInsertId() ?: null;
    // Fetch back
    $s = $db->prepare("SELECT * FROM users WHERE phone = ?");
    $s->execute([$b['phone']]);
    jsonOk(userRow($s->fetch()));
}

if ($method === 'PUT') {
    if (!$id) jsonError('User ID required');
    $b = jsonBody();
    // Add address
    if (isset($b['addAddress'])) {
        $s = $db->prepare("SELECT addresses FROM users WHERE id = ?");
        $s->execute([$id]);
        $row = $s->fetch();
        $addrs = json_decode($row['addresses'] ?? '[]', true);
        if (!in_array($b['addAddress'], $addrs)) {
            $addrs[] = $b['addAddress'];
            $db->prepare("UPDATE users SET addresses = ? WHERE id = ?")->execute([
                json_encode($addrs, JSON_UNESCAPED_UNICODE), $id
            ]);
        }
    }
    $s = $db->prepare("SELECT * FROM users WHERE id = ?");
    $s->execute([$id]);
    jsonOk(userRow($s->fetch()));
}

if ($method === 'DELETE') {
    requireAdmin();
    if (!$id) jsonError('Missing id', 400);
    $db->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
    jsonOk(['deleted' => $id]);
}

jsonError('Method not allowed', 405);
