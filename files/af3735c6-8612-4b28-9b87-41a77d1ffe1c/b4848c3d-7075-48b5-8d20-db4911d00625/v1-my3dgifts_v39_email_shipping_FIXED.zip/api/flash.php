<?php
// Standalone direct-access header (works both via index.php router and direct .php URL)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    // id is the segment after the php filename or resource name
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
// api/flash.php
$db = getDB();

function flashRow(array $r): array {
    return [
        'active'   => (bool)$r['active'],
        'code'     => $r['code'],
        'discount' => (float)$r['discount'],
        'endTime'  => $r['end_time'],
        'banner'   => $r['banner'],
    ];
}

if ($method === 'GET') {
    $row = $db->query("SELECT * FROM flash_sale ORDER BY id DESC LIMIT 1")->fetch();
    jsonOk($row ? flashRow($row) : ['active'=>false,'code'=>'','discount'=>0,'endTime'=>null,'banner'=>'']);
}

if ($method === 'POST' || $method === 'PUT') {
    requireAdmin();
    $b = jsonBody();
    $existing = $db->query("SELECT id FROM flash_sale LIMIT 1")->fetch();
    if ($existing) {
        $stmt = $db->prepare("UPDATE flash_sale SET active=?,code=?,discount=?,end_time=?,banner=? WHERE id=?");
        $stmt->execute([
            isset($b['active'])?($b['active']?1:0):0,
            $b['code']??'',
            $b['discount']??0,
            $b['endTime']??null,
            $b['banner']??'',
            $existing['id']
        ]);
    } else {
        $stmt = $db->prepare("INSERT INTO flash_sale (active,code,discount,end_time,banner) VALUES (?,?,?,?,?)");
        $stmt->execute([
            isset($b['active'])?($b['active']?1:0):0,
            $b['code']??'',
            $b['discount']??0,
            $b['endTime']??null,
            $b['banner']??'',
        ]);
    }
    jsonOk(['saved'=>true]);
}

jsonError('Method not allowed', 405);
