<?php
// api/cashfree.php — Cashfree Payment Gateway Backend
// Secret Key is stored only here — never sent to browser.
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ─── Always-JSON error safety net ────────────────────────────────────────
// Prevents HTML error pages / PHP warnings from breaking the frontend
// ("Unexpected token '<'" errors).
@ini_set('display_errors', '0');
error_reporting(E_ALL);
if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
ob_start();
set_error_handler(function($no, $msg, $file, $line){
    if (!(error_reporting() & $no)) return false;
    while (ob_get_level() > 0) ob_end_clean();
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>"PHP error: $msg (".basename($file).":$line)"]);
    exit;
});
register_shutdown_function(function(){
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        while (ob_get_level() > 0) ob_end_clean();
        http_response_code(500);
        echo json_encode(['ok'=>false,'error'=>"PHP fatal: {$e['message']} (".basename($e['file']).":{$e['line']})"]);
    }
});
// PHP 7 polyfill
if (!function_exists('str_contains')) {
    function str_contains(string $h, string $n): bool { return $n === '' || strpos($h, $n) !== false; }
}
// Verify cURL is available (Cashfree API needs it)
if (!function_exists('curl_init')) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'PHP cURL extension not enabled on server. Enable php-curl.']);
    exit;
}

try { $db = getDB(); } catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'DB connect failed: '.$e->getMessage()]);
    exit;
}

// ─── Cashfree config helper ───────────────────────────────────────────────
function getCfConfig(PDO $db): array {
    $rows = $db->query("SELECT skey, svalue FROM settings WHERE skey = 'cashfree'")->fetchAll();
    if (!$rows) return [];
    $val = json_decode($rows[0]['svalue'] ?? '{}', true);
    if (is_string($val)) $val = json_decode($val, true);
    return is_array($val) ? $val : [];
}

// ─── GET /api/cashfree?action=config  (Public — returns only appId + mode, NOT secret) ─
if ($method === 'GET') {
    $action = $_GET['action'] ?? '';
    if ($action === 'config') {
        $cf = getCfConfig($db);
        jsonOk([
            'enabled' => !empty($cf['enabled']),
            'mode'    => $cf['mode'] ?? 'sandbox',
            'appId'   => $cf['appId'] ?? '',
            // Secret Key is NEVER sent to frontend
        ]);
    }
    jsonError('Not found', 404);
}

// ─── POST /api/cashfree ─────────────────────────────────────────────────────
if ($method === 'POST') {
    $body   = jsonBody();
    $action = $body['action'] ?? '';

    // ── create-order: Frontend → Backend → Cashfree API → return session_id ──
    if ($action === 'create-order') {
        $cf = getCfConfig($db);
        if (empty($cf['enabled']))    jsonError('Payment gateway not enabled', 400);
        if (empty($cf['appId']))      jsonError('Cashfree App ID not configured', 400);
        if (empty($cf['secretKey'])) jsonError('Cashfree Secret Key not configured', 400);

        $orderId    = $body['orderId']    ?? '';
        $amount     = (float)($body['amount'] ?? 0);
        $name       = trim($body['name']       ?? '');
        $phone      = preg_replace('/\D/', '', $body['phone'] ?? '');
        $email      = trim($body['email']      ?? '');

        if (!$orderId || $amount <= 0 || !$name) {
            jsonError('Missing order details', 400);
        }

        // Pad phone to 10 digits if shorter (Cashfree requires 10 digits)
        $phone = $phone ?: '9999999999';
        if (strlen($phone) < 10) $phone = str_pad($phone, 10, '0', STR_PAD_LEFT);
        $phone = substr($phone, -10); // last 10 digits

        $isSandbox = ($cf['mode'] !== 'production');
        $baseUrl   = $isSandbox
            ? 'https://sandbox.cashfree.com/pg/orders'
            : 'https://api.cashfree.com/pg/orders';

        $returnUrl  = $cf['returnUrl'] ?? (SITE_URL . '/');
        // Append orderId to return URL so we can verify after redirect
        $sep = (str_contains($returnUrl, '?')) ? '&' : '?';
        $returnUrl .= $sep . 'cf_order=' . urlencode($orderId) . '&cf_status=SUCCESS';

        $payload = [
            'order_id'       => $orderId,
            'order_amount'   => round($amount, 2),
            'order_currency' => 'INR',
            'customer_details' => [
                'customer_id'    => 'cust_' . preg_replace('/\W/', '_', $name) . '_' . substr(md5($phone), 0, 6),
                'customer_name'  => $name,
                'customer_email' => $email ?: 'noreply@my3dgifts.com',
                'customer_phone' => $phone,
            ],
            'order_meta' => [
                'return_url'    => $returnUrl,
                'notify_url'    => SITE_URL . '/api/cashfree?action=webhook',
            ],
        ];

        $ch = curl_init($baseUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'x-api-version: 2023-08-01',
                'x-client-id: '     . $cf['appId'],
                'x-client-secret: ' . $cf['secretKey'],
            ],
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($err) jsonError('cURL error: ' . $err, 500);

        $data = json_decode($res, true);
        if ($code !== 200) {
            $msg = $data['message'] ?? $data['error'] ?? ('Cashfree error ' . $code);
            jsonError($msg, 400);
        }

        // Save payment_session_id mapping in DB orders table
        try {
            $has = $db->query("SHOW COLUMNS FROM orders LIKE 'cf_session_id'")->fetch();
            if (!$has) {
                $db->exec("ALTER TABLE orders ADD COLUMN cf_session_id VARCHAR(128) DEFAULT NULL");
            }
            $db->prepare("UPDATE orders SET cf_session_id = :sid WHERE id = :oid")
               ->execute([':sid' => $data['payment_session_id'] ?? '', ':oid' => $orderId]);
        } catch (Throwable $e) {
            error_log('CF session save: ' . $e->getMessage());
        }

        jsonOk([
            'payment_session_id' => $data['payment_session_id'],
            'order_id'           => $data['order_id'],
            'cf_order_id'        => $data['cf_order_id'] ?? '',
        ]);
    }

    // ── verify-payment: Called after redirect / button press ──────────────
    if ($action === 'verify-payment') {
        $cf      = getCfConfig($db);
        $orderId = $body['orderId'] ?? '';
        if (!$orderId) jsonError('Missing orderId', 400);

        $isSandbox = ($cf['mode'] !== 'production');
        $url = ($isSandbox
            ? 'https://sandbox.cashfree.com/pg/orders/'
            : 'https://api.cashfree.com/pg/orders/')
            . urlencode($orderId);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'x-api-version: 2023-08-01',
                'x-client-id: '     . ($cf['appId'] ?? ''),
                'x-client-secret: ' . ($cf['secretKey'] ?? ''),
            ],
            CURLOPT_TIMEOUT => 15,
        ]);
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($res, true);
        $status = $data['order_status'] ?? 'UNKNOWN';

        if ($status === 'PAID') {
            // Mark order as paid in DB
            try {
                $db->prepare("UPDATE orders SET payment_status = 'Paid', status = 'Confirmed' WHERE id = :oid")
                   ->execute([':oid' => $orderId]);
            } catch (Throwable $e) {
                error_log('CF verify update: ' . $e->getMessage());
            }
        }
        jsonOk(['status' => $status, 'order_id' => $orderId]);
    }

    // ── Webhook from Cashfree ──────────────────────────────────────────────
    if ($action === 'webhook') {
        $raw       = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '';
        $ts        = $_SERVER['HTTP_X_WEBHOOK_TIMESTAMP'] ?? '';
        $cf        = getCfConfig($db);

        // Verify webhook signature
        if ($cf['secretKey'] && $signature) {
            $expected = base64_encode(hash_hmac('sha256', $ts . $raw, $cf['secretKey'], true));
            if (!hash_equals($expected, $signature)) {
                http_response_code(401);
                echo 'Invalid signature';
                exit;
            }
        }

        $event = json_decode($raw, true);
        $type  = $event['type'] ?? '';
        if (str_contains($type, 'PAYMENT_SUCCESS')) {
            $orderId = $event['data']['order']['order_id'] ?? '';
            if ($orderId) {
                try {
                    $db->prepare("UPDATE orders SET payment_status = 'Paid', status = 'Confirmed' WHERE id = :oid")
                       ->execute([':oid' => $orderId]);
                } catch (Throwable $e) {
                    error_log('CF webhook update: ' . $e->getMessage());
                }
            }
        }
        http_response_code(200);
        echo 'OK';
        exit;
    }

    jsonError('Unknown action', 400);
}

jsonError('Method not allowed', 405);
