<?php
// ============================================================
//  api/affiliate.php — Affiliate Products + Click Tracking
//  Routes (via api/index.php router):
//    GET    /api/affiliate                 -> list (public, active only)
//    GET    /api/affiliate?all=1           -> list ALL (admin)
//    GET    /api/affiliate/{id}            -> single
//    POST   /api/affiliate                 -> create (admin)
//    PUT    /api/affiliate/{id}            -> update (admin)
//    DELETE /api/affiliate/{id}            -> delete (admin)
//    POST   /api/affiliate/click/{id}      -> track outbound click (public)
//    GET    /api/affiliate/analytics       -> aggregated stats (admin)
// ============================================================

if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// Re-parse path so we can support /affiliate/click/{id} and /affiliate/analytics
$uri  = $_SERVER['REQUEST_URI'] ?? '';
$path = parse_url($uri, PHP_URL_PATH);
$path = preg_replace('#^.*/api/?#', '', $path);
$path = trim($path, '/');
$segs = explode('/', $path);
// segs[0] = 'affiliate' (or 'affiliate.php')
$action = $segs[1] ?? null;       // null | id | 'click' | 'analytics'
$subId  = $segs[2] ?? null;       // when action === 'click'

$db = getDB();

// -------- ensure tables exist (safe idempotent) --------
$db->exec("CREATE TABLE IF NOT EXISTS `affiliate_products` (
  `id`            VARCHAR(40) PRIMARY KEY,
  `title`         VARCHAR(255) NOT NULL,
  `image`         TEXT,
  `price`         DECIMAL(10,2) DEFAULT 0,
  `source`        VARCHAR(40) NOT NULL DEFAULT 'amazon',
  `affiliate_url` TEXT NOT NULL,
  `show_on_home`  TINYINT(1) DEFAULT 0,
  `active`        TINYINT(1) DEFAULT 1,
  `sort_order`    INT DEFAULT 999,
  `click_count`   INT DEFAULT 0,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS `affiliate_clicks` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `affiliate_id` VARCHAR(40) NOT NULL,
  `source`       VARCHAR(40),
  `click_date`   DATE NOT NULL,
  `ip`           VARCHAR(64),
  `ua`           VARCHAR(255),
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_aff_id` (`affiliate_id`),
  KEY `idx_aff_date` (`click_date`),
  KEY `idx_aff_source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

function affRow(array $r): array {
    return [
        'id'           => $r['id'],
        'title'        => $r['title'],
        'image'        => $r['image'] ?? '',
        'price'        => (float)($r['price'] ?? 0),
        'source'       => $r['source'] ?? 'amazon',
        'affiliateUrl' => $r['affiliate_url'] ?? '',
        'showOnHome'   => (int)($r['show_on_home'] ?? 0) === 1,
        'active'       => (int)($r['active'] ?? 1) === 1,
        'sortOrder'    => (int)($r['sort_order'] ?? 999),
        'clickCount'   => (int)($r['click_count'] ?? 0),
        'createdAt'    => $r['created_at'] ?? null,
        'updatedAt'    => $r['updated_at'] ?? null,
    ];
}

// =================== CLICK TRACKING (public) ===================
if ($action === 'click' && $method === 'POST' && $subId) {
    $stmt = $db->prepare("SELECT id, source, affiliate_url, active FROM affiliate_products WHERE id = ?");
    $stmt->execute([$subId]);
    $row = $stmt->fetch();
    if (!$row) jsonError('Affiliate product not found', 404);
    if ((int)$row['active'] !== 1) jsonError('Inactive', 410);

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 240);
    $db->prepare("INSERT INTO affiliate_clicks (affiliate_id, source, click_date, ip, ua) VALUES (?, ?, CURDATE(), ?, ?)")
       ->execute([$subId, $row['source'], $ip, $ua]);
    $db->prepare("UPDATE affiliate_products SET click_count = click_count + 1 WHERE id = ?")->execute([$subId]);

    jsonOk(['url' => $row['affiliate_url'], 'source' => $row['source']]);
}

// =================== ANALYTICS (admin) ===================
if ($action === 'analytics' && $method === 'GET') {
    requireAdmin();
    $totalClicks = (int)($db->query("SELECT COUNT(*) c FROM affiliate_clicks")->fetch()['c'] ?? 0);

    $bySource = $db->query("SELECT source, COUNT(*) c FROM affiliate_clicks GROUP BY source ORDER BY c DESC")
                   ->fetchAll();
    $sourceMap = [];
    foreach ($bySource as $r) $sourceMap[$r['source'] ?: 'unknown'] = (int)$r['c'];

    $top = $db->query("
        SELECT p.id, p.title, p.source, p.image, p.click_count
        FROM affiliate_products p
        ORDER BY p.click_count DESC, p.title ASC
        LIMIT 20
    ")->fetchAll();
    $topList = array_map('affRow', $top);

    $last7 = $db->query("
        SELECT click_date, COUNT(*) c
        FROM affiliate_clicks
        WHERE click_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY click_date
        ORDER BY click_date ASC
    ")->fetchAll();
    $daily = [];
    foreach ($last7 as $r) $daily[$r['click_date']] = (int)$r['c'];

    jsonOk([
        'totalClicks' => $totalClicks,
        'bySource'    => $sourceMap,
        'topProducts' => $topList,
        'last7Days'   => $daily,
        'productCount'=> (int)($db->query("SELECT COUNT(*) c FROM affiliate_products")->fetch()['c'] ?? 0),
    ]);
}

// =================== CRUD ===================
if ($method === 'GET' && !$action) {
    $showAll = isset($_GET['all']) && $_GET['all'] === '1';
    if ($showAll) requireAdmin();
    $sql = "SELECT * FROM affiliate_products"
         . ($showAll ? "" : " WHERE active = 1")
         . " ORDER BY sort_order ASC, created_at DESC";
    $rows = $db->query($sql)->fetchAll();
    jsonOk(array_map('affRow', $rows));
}

if ($method === 'GET' && $action) {
    $stmt = $db->prepare("SELECT * FROM affiliate_products WHERE id = ?");
    $stmt->execute([$action]);
    $row = $stmt->fetch();
    if (!$row) jsonError('Not found', 404);
    jsonOk(affRow($row));
}

if ($method === 'POST' && !$action) {
    requireAdmin();
    $b = jsonBody();
    $title = trim($b['title'] ?? '');
    $url   = trim($b['affiliateUrl'] ?? $b['affiliate_url'] ?? '');
    if ($title === '' || $url === '') jsonError('title & affiliateUrl required');
    $allowed = ['amazon','flipkart','meesho','other'];
    $source  = in_array($b['source'] ?? '', $allowed, true) ? $b['source'] : 'amazon';
    if (!preg_match('#^https?://#i', $url)) jsonError('affiliateUrl must be http(s)');

    $id = 'aff_' . bin2hex(random_bytes(6));
    $stmt = $db->prepare("INSERT INTO affiliate_products
      (id,title,image,price,source,affiliate_url,show_on_home,active,sort_order)
      VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $id,
        $title,
        trim($b['image'] ?? ''),
        (float)($b['price'] ?? 0),
        $source,
        $url,
        !empty($b['showOnHome']) ? 1 : 0,
        isset($b['active']) ? ((int)!!$b['active']) : 1,
        (int)($b['sortOrder'] ?? 999),
    ]);
    $row = $db->prepare("SELECT * FROM affiliate_products WHERE id = ?");
    $row->execute([$id]);
    jsonOk(affRow($row->fetch()));
}

if ($method === 'PUT' && $action) {
    requireAdmin();
    $b = jsonBody();
    $exists = $db->prepare("SELECT id FROM affiliate_products WHERE id = ?");
    $exists->execute([$action]);
    if (!$exists->fetch()) jsonError('Not found', 404);

    $fields = [];
    $vals   = [];
    $map = [
        'title'        => 'title',
        'image'        => 'image',
        'price'        => 'price',
        'source'       => 'source',
        'affiliateUrl' => 'affiliate_url',
        'showOnHome'   => 'show_on_home',
        'active'       => 'active',
        'sortOrder'    => 'sort_order',
    ];
    foreach ($map as $k => $col) {
        if (!array_key_exists($k, $b)) continue;
        $v = $b[$k];
        if (in_array($col, ['show_on_home','active'], true)) $v = !empty($v) ? 1 : 0;
        if ($col === 'price') $v = (float)$v;
        if ($col === 'sort_order') $v = (int)$v;
        if ($col === 'affiliate_url' && !preg_match('#^https?://#i', (string)$v)) jsonError('affiliateUrl must be http(s)');
        $fields[] = "`$col` = ?";
        $vals[]   = $v;
    }
    if (!$fields) jsonError('Nothing to update');
    $vals[] = $action;
    $sql = "UPDATE affiliate_products SET " . implode(',', $fields) . " WHERE id = ?";
    $db->prepare($sql)->execute($vals);

    $r = $db->prepare("SELECT * FROM affiliate_products WHERE id = ?");
    $r->execute([$action]);
    jsonOk(affRow($r->fetch()));
}

if ($method === 'DELETE' && $action) {
    requireAdmin();
    $db->prepare("DELETE FROM affiliate_clicks WHERE affiliate_id = ?")->execute([$action]);
    $del = $db->prepare("DELETE FROM affiliate_products WHERE id = ?");
    $del->execute([$action]);
    jsonOk(['deleted' => $del->rowCount() > 0]);
}

jsonError('Method not allowed', 405);
