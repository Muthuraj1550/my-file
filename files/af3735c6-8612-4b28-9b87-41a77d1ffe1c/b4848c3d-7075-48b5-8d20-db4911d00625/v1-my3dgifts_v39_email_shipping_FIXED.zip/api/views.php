<?php
// Standalone direct-access header (works both via index.php router and direct .php URL)
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    // id is the segment after the php filename or resource name
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
// api/views.php
$db = getDB();

// Make sure the detailed log table exists (safe no-op if already created via install.sql)
$db->exec("CREATE TABLE IF NOT EXISTS `product_view_log` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `product_id`  VARCHAR(40) NOT NULL,
  `view_date`   DATE NOT NULL,
  `seconds`     INT DEFAULT 0,
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_pv_product` (`product_id`),
  KEY `idx_pv_date` (`view_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

if ($method === 'GET') {
    // Legacy flat map (productId -> total count) — kept for backward-compat
    // with any code still reading GET /views as { [productId]: count }
    $rows = $db->query("SELECT product_id, count FROM product_views")->fetchAll();
    $flat = [];
    foreach ($rows as $r) $flat[$r['product_id']] = (int)$r['count'];

    // If caller wants the richer breakdown, pass ?detailed=1
    if (isset($_GET['detailed'])) {
        $today     = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));

        $stmtToday = $db->prepare("SELECT COUNT(*) c FROM product_view_log WHERE view_date = ?");
        $stmtToday->execute([$today]);
        $todayCount = (int)($stmtToday->fetch()['c'] ?? 0);

        $stmtYest = $db->prepare("SELECT COUNT(*) c FROM product_view_log WHERE view_date = ?");
        $stmtYest->execute([$yesterday]);
        $yestCount = (int)($stmtYest->fetch()['c'] ?? 0);

        $totalCount = (int)($db->query("SELECT COUNT(*) c FROM product_view_log")->fetch()['c'] ?? 0);

        // Top 5 products by total time spent (seconds), all-time
        $topTimeRows = $db->query(
            "SELECT product_id, SUM(seconds) AS total_seconds, COUNT(*) AS view_count
             FROM product_view_log
             GROUP BY product_id
             ORDER BY total_seconds DESC
             LIMIT 5"
        )->fetchAll();
        $topByTime = array_map(function ($r) {
            return [
                'productId'    => $r['product_id'],
                'totalSeconds' => (int)$r['total_seconds'],
                'viewCount'    => (int)$r['view_count'],
            ];
        }, $topTimeRows);

        // Today's per-product view counts
        $stmtTodayByProd = $db->prepare(
            "SELECT product_id, COUNT(*) AS c FROM product_view_log WHERE view_date = ? GROUP BY product_id"
        );
        $stmtTodayByProd->execute([$today]);
        $todayByProduct = [];
        foreach ($stmtTodayByProd->fetchAll() as $r) $todayByProduct[$r['product_id']] = (int)$r['c'];

        // Yesterday's per-product view counts
        $stmtYestByProd = $db->prepare(
            "SELECT product_id, COUNT(*) AS c FROM product_view_log WHERE view_date = ? GROUP BY product_id"
        );
        $stmtYestByProd->execute([$yesterday]);
        $yestByProduct = [];
        foreach ($stmtYestByProd->fetchAll() as $r) $yestByProduct[$r['product_id']] = (int)$r['c'];

        jsonOk([
            'flat'               => $flat,          // productId -> total count (legacy)
            'today'              => $todayCount,
            'yesterday'          => $yestCount,
            'total'              => $totalCount,
            'todayByProduct'     => $todayByProduct,
            'yesterdayByProduct' => $yestByProduct,
            'topByTime'          => $topByTime,      // top 5 products by time spent
        ]);
    }

    jsonOk($flat);
}

if ($method === 'POST') {
    $b = jsonBody();
    $pid = $b['productId'] ?? $id ?? '';

    // ── Update time spent on an existing log row ──
    // Called when the user leaves a product page: { viewId, seconds }
    if (isset($b['viewId']) && isset($b['seconds'])) {
        $viewId = (int)$b['viewId'];
        $seconds = max(0, (int)$b['seconds']);
        if ($viewId > 0) {
            $db->prepare("UPDATE product_view_log SET seconds = ? WHERE id = ?")
               ->execute([$seconds, $viewId]);
        }
        jsonOk(['updated' => true]);
    }

    if (!$pid) jsonError('productId required');

    // Legacy total counter (kept for products.php / old dashboards)
    $db->prepare("INSERT INTO product_views (product_id, count) VALUES (?,1)
                  ON DUPLICATE KEY UPDATE count = count + 1")->execute([$pid]);

    // New date-stamped log row — one row per view, time-spent filled in later
    $today = date('Y-m-d');
    $db->prepare("INSERT INTO product_view_log (product_id, view_date, seconds) VALUES (?,?,0)")
       ->execute([$pid, $today]);
    $viewId = (int)$db->lastInsertId();

    jsonOk(['incremented' => $pid, 'viewId' => $viewId]);
}

jsonError('Method not allowed', 405);
