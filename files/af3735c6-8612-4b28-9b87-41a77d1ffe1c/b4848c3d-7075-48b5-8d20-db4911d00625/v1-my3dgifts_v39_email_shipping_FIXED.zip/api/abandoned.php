<?php
// api/abandoned.php — Abandoned cart recovery
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!isset($id)) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');
    $segs = explode('/', $path);
    $last = end($segs);
    $id = (count($segs) > 1 && $last && !str_ends_with($last, '.php')) ? $last : null;
}
$db = getDB();

// Auto-heal: if table missing OR has wrong schema, create the v14 schema
try {
    $check = $db->query("SHOW COLUMNS FROM abandoned_carts LIKE 'customer_name'")->fetch();
    if (!$check) {
        $db->exec("DROP TABLE IF EXISTS abandoned_carts");
        $db->exec("CREATE TABLE abandoned_carts (
            id VARCHAR(40) PRIMARY KEY,
            customer_name VARCHAR(255), customer_phone VARCHAR(30), customer_email VARCHAR(255),
            items LONGTEXT, total DECIMAL(10,2) DEFAULT 0,
            last_step VARCHAR(50) DEFAULT 'cart',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
} catch (Throwable $e) {
    $db->exec("CREATE TABLE IF NOT EXISTS abandoned_carts (
        id VARCHAR(40) PRIMARY KEY,
        customer_name VARCHAR(255), customer_phone VARCHAR(30), customer_email VARCHAR(255),
        items LONGTEXT, total DECIMAL(10,2) DEFAULT 0,
        last_step VARCHAR(50) DEFAULT 'cart',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function abandonRow(array $r): array {
    return [
        'id' => $r['id'],
        'customerName'  => $r['customer_name'],
        'customerPhone' => $r['customer_phone'],
        'customerEmail' => $r['customer_email'],
        'items'         => json_decode($r['items'] ?? '[]', true) ?: [],
        'total'         => (float)$r['total'],
        'lastStep'      => $r['last_step'],
        'createdAt'     => $r['created_at'],
    ];
}

if ($method === 'GET') {
    requireAdmin();
    $rows = $db->query("SELECT * FROM abandoned_carts ORDER BY created_at DESC LIMIT 200")->fetchAll();
    jsonOk(array_map('abandonRow', $rows));
}

// POST /api/abandoned/approve/{id}  → convert abandoned cart to a real order
if ($method === 'POST') {
    $uri2  = $_SERVER['REQUEST_URI'] ?? '';
    $path2 = trim(parse_url($uri2, PHP_URL_PATH), '/');
    $segs2 = explode('/', $path2);
    // Detect approve action: any segment equals 'approve'
    $approveIdx = array_search('approve', $segs2);
    if ($approveIdx !== false) {
        requireAdmin();
        $cartId = $segs2[$approveIdx + 1] ?? '';
        if (!$cartId) {
            $b = jsonBody();
            $cartId = $b['id'] ?? '';
        }
        if (!$cartId) jsonError('Cart id required');

    $st = $db->prepare("SELECT * FROM abandoned_carts WHERE id = ?");
    $st->execute([$cartId]);
    $cart = $st->fetch();
    if (!$cart) jsonError('Cart not found', 404);

    $items = json_decode($cart['items'] ?? '[]', true) ?: [];
    if (empty($items)) jsonError('Cart is empty');

    $oid      = 'ORD-' . strtoupper(substr(md5(uniqid()),0,8));
    $tracking = 'TRK-' . strtoupper(substr(md5(uniqid()),0,6));
    $now      = date('c');
    $history  = [['status'=>'New','at'=>$now,'note'=>'Approved from cart recovery']];

    $stmt = $db->prepare("INSERT INTO orders
        (id, tracking, customer_name, customer_phone, customer_email,
         address, pincode, items, total, discount, shipping, coupon,
         pay_method, payment_status, status, history, notes, source)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $oid, $tracking,
        $cart['customer_name'] ?? '',
        $cart['customer_phone'] ?? '',
        $cart['customer_email'] ?? '',
        '', '',
        json_encode($items, JSON_UNESCAPED_UNICODE),
        (float)$cart['total'],
        0, 0, '',
        'whatsapp', 'Confirmed', 'New',
        json_encode($history, JSON_UNESCAPED_UNICODE),
        'Recovered from abandoned cart',
        'whatsapp'
    ]);

    // Remove from abandoned list
    $db->prepare("DELETE FROM abandoned_carts WHERE id = ?")->execute([$cartId]);
    jsonOk(['orderId' => $oid, 'tracking' => $tracking]);
    } // end approve block
}

if ($method === 'POST' || $method === 'PUT') {
    // Public: storefront writes abandoned cart (no admin auth needed)
    $b = jsonBody();
    $cartId = $b['id'] ?? ('ab_' . bin2hex(random_bytes(6)));
    $stmt = $db->prepare("INSERT INTO abandoned_carts (id, customer_name, customer_phone, customer_email, items, total, last_step) VALUES (?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE customer_name=VALUES(customer_name), customer_phone=VALUES(customer_phone), customer_email=VALUES(customer_email), items=VALUES(items), total=VALUES(total), last_step=VALUES(last_step)");
    $stmt->execute([
        $cartId,
        $b['customerName'] ?? '',
        $b['customerPhone'] ?? '',
        $b['customerEmail'] ?? '',
        json_encode($b['items'] ?? [], JSON_UNESCAPED_UNICODE),
        (float)($b['total'] ?? 0),
        $b['lastStep'] ?? 'cart',
    ]);
    jsonOk(['id' => $cartId]);
}

if ($method === 'DELETE') {
    requireAdmin();
    if (!$id) jsonError('Missing id', 400);
    $db->prepare("DELETE FROM abandoned_carts WHERE id=?")->execute([$id]);
    jsonOk(['deleted' => $id]);
}

jsonError('Method not allowed', 405);
