<?php
// api/fix-images.php — v23
// One-time admin script to fix legacy absolute image URLs in the products table.
// Converts "http://anyhost/uploads/xxx.jpg" → "/uploads/xxx.jpg" so the same
// image works on every device, every domain, and over HTTPS.
//
// Usage (from a logged-in admin browser):
//   GET  /api/fix-images.php           → DRY RUN, shows what WILL change
//   POST /api/fix-images.php           → APPLY the fix
//
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!isset($method)) $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
requireAdmin();

function fixOne($url) {
    if (!is_string($url) || $url === '') return $url;
    if (strpos($url, 'data:') === 0) return $url;
    if (strpos($url, '/uploads/') === 0) return $url;
    if (preg_match('#^https?://[^/]+(/uploads/.+)$#i', $url, $m)) return $m[1];
    return $url;
}
function fixArr($arr) {
    if (!is_array($arr)) return [$arr, false];
    $changed = false;
    $out = [];
    foreach ($arr as $x) {
        if (is_array($x)) {
            if (isset($x['url'])) {
                $n = fixOne($x['url']);
                if ($n !== $x['url']) $changed = true;
                $x['url'] = $n;
            }
            $out[] = $x;
        } else {
            $n = fixOne((string)$x);
            if ($n !== $x) $changed = true;
            $out[] = $n;
        }
    }
    return [$out, $changed];
}

$db = getDB();
// FIX: also select `image` (main cover column) — previously missing!
$rows = $db->query("SELECT id, name, image, images, options FROM products")->fetchAll();

$apply = ($method === 'POST');
$report = ['scanned' => count($rows), 'will_update' => 0, 'updated' => 0, 'examples' => []];

foreach ($rows as $row) {
    $imgs = json_decode($row['images'] ?? '[]', true) ?: [];
    $opts = json_decode($row['options'] ?? '{}', true) ?: [];

    // FIX: also normalize the main cover `image` column
    $mainImg        = $row['image'] ?? '';
    $mainImgFixed   = fixOne($mainImg);
    $mainImgChanged = ($mainImgFixed !== $mainImg);

    [$imgs2, $imgsChanged] = fixArr($imgs);
    $optsChanged = false;
    foreach (['coverImage','image','gifUrl','videoUrl'] as $k) {
        if (isset($opts[$k]) && is_string($opts[$k])) {
            $n = fixOne($opts[$k]);
            if ($n !== $opts[$k]) { $opts[$k] = $n; $optsChanged = true; }
        }
    }
    if ($mainImgChanged || $imgsChanged || $optsChanged) {
        $report['will_update']++;
        if (count($report['examples']) < 5) {
            $report['examples'][] = [
                'id'        => $row['id'],
                'name'      => $row['name'],
                'old_image' => $mainImg,
                'new_image' => $mainImgFixed,
            ];
        }
        if ($apply) {
            $st = $db->prepare("UPDATE products SET image = ?, images = ?, options = ? WHERE id = ?");
            $st->execute([
                $mainImgFixed,
                json_encode($imgs2, JSON_UNESCAPED_UNICODE),
                json_encode($opts,  JSON_UNESCAPED_UNICODE),
                $row['id']
            ]);
            $report['updated']++;
        }
    }
}

// Also fix media table URLs (fixes broken preview in media library)
$mediaRows = $db->query("SELECT id, url FROM media")->fetchAll();
$mediaFixed = 0;
foreach ($mediaRows as $mr) {
    $fixed = fixOne($mr['url']);
    if ($fixed !== $mr['url']) {
        if ($apply) {
            $db->prepare("UPDATE media SET url = ? WHERE id = ?")->execute([$fixed, $mr['id']]);
        }
        $mediaFixed++;
    }
}
$report['media_will_fix'] = $mediaFixed;
$report['mode'] = $apply ? 'APPLIED' : 'DRY-RUN — POST to apply';
jsonOk($report);
