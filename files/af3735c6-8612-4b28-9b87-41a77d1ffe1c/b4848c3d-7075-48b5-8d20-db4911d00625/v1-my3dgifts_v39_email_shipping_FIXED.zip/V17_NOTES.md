# MY 3D Gifts — v17 Release Notes

## ✅ Fixes & New Features

### 🖼️ Product Images — Fixed!
- `.htaccess` now skips `/uploads/` from rewrite (Apache no longer routes images to PHP)
- Apache 2.4 syntax (`Require all granted`); legacy `Order/Allow` removed
- `uploads/.htaccess` blocks PHP execution & sets CORS for cross-origin image loads
- Upload limit raised to 10 MB; safer MIME detection via `finfo`
- Auto-fallback extension if browser sends bad MIME type
- All image files served with `Access-Control-Allow-Origin: *` and 1-month cache

### ✂️ Image Crop Preview (Cropper.js)
- Product modal → "📤 Upload + Crop" opens Cropper.js modal automatically
- "✂️ Crop URL" button lets you crop an image already pasted as URL
- Aspect ratios: 1:1 / 4:3 / 16:9 / 3:4 / Free
- Cropped output uploaded as JPEG (≤1600x1600)
- **URL or upload — both show live preview** below the input

### 💰 Accounts (வரவு / செலவு)
New sidebar item **💰 Accounts**:
- Auto-sync orders → income; order shipping → expense (idempotent — safe to re-click)
- Manual entries: category (Filament / Electricity / Rent / Walk-in Sale / etc.)
- Date range filter + Income/Expense filter
- **Monthly summary** + Net profit/loss
- Edit/delete manual entries (synced order entries can be deleted but auto-recreate on re-sync)
- New table `accounts_ledger` (auto-created; also added to `migrate.php`)

### 🏷️ Product Type Label (Readymade / Customize)
- Product modal: 📦 Product Type dropdown + ⭐ Featured toggle (max 3)
- Storefront Shop page: tab bar **🛍️ All / 🎁 Readymade / ✨ Customize**
- Featured products get gold outline badge
- Stored inside `options.productType` and `options.featured` (no schema change needed)

### 🔄 Cart Recovery → Order Approval
- Recovery list now has **✅ Approve → Order** button
- Click → cart is converted to a real Order (status "New", payment "Confirmed", source "whatsapp")
- The cart is removed from the abandoned list automatically
- Endpoint: `POST /api/abandoned/approve/{cartId}`

### 🎨 Theme Presets Gallery (Gift-themed)
9 presets, each setting colors + 3D title style + display font in one click:
- 👑 Royal Gold, 🎂 Sweet Pink, 🌙 Midnight Luxe, 🌿 Mint Fresh,
  🌅 Sunset Pop, 🌊 Ocean Blue, ❤️ Classic Red, 🎈 Kids Party, 🕹️ Retro Arcade
- Live preview tile shows your store name in that 3D style
- New ✨ 3D Title Style panel: enable, front/shadow/glow colors, font family
  (Bungee, Pacifico, Lobster, Bangers, Permanent Marker, Press Start 2P, Fredoka One)

### 🧹 Removed (per request)
- ❌ Material picker toggle
- ❌ Size picker toggle
- ❌ "Option Labels (v15)" block (Size/Material/Color labels + Option Style)
- All such options now live in the much more flexible **🧩 Custom Options (Unlimited)**

## 🚀 Upgrade Steps
1. Backup your current site & DB.
2. Upload the contents of this zip over your existing install (overwrite all).
3. Visit `https://yoursite.com/migrate.php` once → creates `accounts_ledger` table.
4. **Delete `migrate.php`** after success.
5. Hard-refresh admin (Ctrl+F5).

## ⚠️ Known small follow-ups (not blocking)
- Featured strip placeholder element exists on storefront but the visual hero render
  isn't wired — featured products still surface naturally via Admin Order sort.
  Mark a product `featured` to test, then we can polish the hero strip in v17.1.
