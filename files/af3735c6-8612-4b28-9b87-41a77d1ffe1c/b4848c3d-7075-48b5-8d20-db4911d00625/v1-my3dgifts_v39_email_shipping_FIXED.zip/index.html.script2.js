
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
window.THREE = THREE; window.OrbitControls = OrbitControls;
window.FontLoader = FontLoader; window.TextGeometry = TextGeometry;
window.STLLoader = STLLoader;
window.dispatchEvent(new Event('three-ready'));
