<?php
// ============================================================
//  MY 3D Gifts — config.php  (FIXED)
//  Database connection + shared helpers
// ============================================================

// ---- DB credentials (உங்கள் hosting credentials) ----
define('DB_HOST',    'localhost');
define('DB_NAME',    'mydgift1_new55');
define('DB_USER',    'mydgift1_new55');
define('DB_PASS',    'Muthu55m@123');        // ← உங்கள் DB password
define('DB_CHARSET', 'utf8mb4');

// ---- Upload paths ----
define('UPLOAD_DIR', __DIR__ . '/uploads/');

// RELATIVE URL — works on every device & domain (no hard-coded host).
// Browsers resolve "/uploads/foo.jpg" against whatever host the page is on,
// so the same image loads correctly from localhost, the live domain, and
// other devices on the network. Storing absolute URLs with HTTP_HOST breaks
// this whenever the image is opened from a different host (e.g. saved on
// localhost, then viewed on the live site or a phone).
if (!defined('UPLOAD_URL')) {
    define('UPLOAD_URL', '/uploads/');
}

// ---- Dynamic Site URL (for absolute image URLs) ----
// Auto-detect: https://yourdomain.com  (no trailing slash)
if (!defined('SITE_URL')) {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    define('SITE_URL', $scheme . '://' . $host);
}

// ---- Admin credentials (username/password login) ----
define('ADMIN_USERNAME', 'Admin@my3dgifts');
define('ADMIN_PASSWORD', 'Muthu55m@123');

// ---- Admin secret key (X-Admin-Key header auth for API calls) ----
// This is derived from username+password for security
define('ADMIN_SECRET', 'MY3DG_' . sha1('Admin@my3dgifts' . ':' . 'Muthu55m@123'));

// ---- Error reporting (debug ஆக வைத்துக் கொள்ள. live-ல் 0 ஆக மாற்றவும்) ----
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// ---- PDO connection ----
function getDB(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        error_log('DB connect error: ' . $e->getMessage());
        jsonError('Database connection failed: ' . $e->getMessage(), 500);
        exit;
    }
    return $pdo;
}

// ---- JSON helpers ----
function jsonOk(mixed $data = null): void {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}
function jsonError(string $msg, int $code = 400): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

// ---- CORS ----
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Key');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

// ---- Request body helper ----
function jsonBody(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// ---- Admin auth guard ----
function requireAdmin(): void {
    $key = $_SERVER['HTTP_X_ADMIN_KEY'] ?? ($_POST['admin_key'] ?? '');
    if ($key !== ADMIN_SECRET) {
        jsonError('Unauthorized', 401);
    }
}

// ---- Simple session token ----
function makeToken(array $payload): string {
    $header = base64_encode(json_encode(['alg'=>'HS256']));
    $body   = base64_encode(json_encode($payload));
    $sig    = base64_encode(hash_hmac('sha256', "$header.$body", ADMIN_SECRET, true));
    return "$header.$body.$sig";
}
function verifyToken(string $token): ?array {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    [$h, $b, $s] = $parts;
    $expected = base64_encode(hash_hmac('sha256', "$h.$b", ADMIN_SECRET, true));
    if (!hash_equals($expected, $s)) return null;
    return json_decode(base64_decode($b), true);
}
