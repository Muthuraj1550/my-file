# v15 — Final feature wiring on top of v14

## What's new in v15

### Admin Panel (`admin-app.html`)
1. **Orders → source filter** — All / Online / Walk-in tabs now actually filter (`setOrderSrc`).
2. **+ Add Order modal** — Manual order entry (`openManualOrderModal`):
   - Product picker with quantity & price override
   - Customer name / phone / address / pincode
   - Payment status (Pending / Paid)
   - Saves with `source: 'walkin'`
3. **Media Library (`loadMedia`, `uploadMedia`)** — Multi-file upload, grid view, click image to copy URL, delete button.
4. **Product editor expanded**:
   - Custom 3D viewer HTML/JS textarea (`p3DHtml`)
   - Custom option-labels block (size label, material label, chips vs select toggle)
5. **Settings page** (general) extended:
   - Logo upload (file → uploads via api/upload.php → stored in `settings.logoUrl`)
   - Home Page dropdown (choose which custom page is the storefront home)
6. **Payment page**: WhatsApp UPI card — toggle + UPI ID input.
7. **Navigation page**: "Show bottom nav on desktop" toggle.

### Storefront (`index.html` + new `assets/v15-features.js`)
1. **Bottom nav** hidden on desktop ≥1024 px **unless** `settings.bottomNavDesktop===true`.
2. **Mobile sticky Add-to-Cart** — restored & always visible on product page on screens < 768 px.
3. **Custom 3D viewer HTML** rendered inside product detail when `product.options.viewer3dHtml` is set.
4. **Dynamic option labels** — uses `product.options.sizeLabel`, `materialLabel`, etc.
5. **WhatsApp UPI checkout button** in cart when `settings.whatsappUpi.enabled` — opens WhatsApp with pre-filled UPI ID + order summary.
6. **Home page selector** — if `settings.homePage` is a custom page slug, that page is shown as the landing screen instead of `shop`.

## How to apply
1. Replace project files with this zip's contents.
2. v14's `migrate.php` is included — visit `/migrate.php` once if you skipped v14.
3. Hard refresh admin + storefront (Ctrl+Shift+R).

No DB schema changes vs v14 — all new settings live in the existing JSON `settings` blob.
