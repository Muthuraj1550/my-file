# MY 3D Gifts — v25 Patch Notes

## 🛒 Admin Orders
- ✅ **Bulk select** checkboxes (per row + "Select all")
- ✅ **Bulk Delete** orders → uses `/api/orders/bulk-delete`
- ✅ **Bulk Status update** (New / In Production / Dispatch / Shipped / Delivered / Cancelled)
- ✅ Optional **"Send Email"** toggle during bulk status update (auto-fires confirm/tracking/delivered emails)
- ✅ **Item thumbnails** in Items column (up to 4 per row + count). Falls back to product image if order item lacks one. Shows ⚠️ for broken files, 🎁 for missing.

## 🛍️ Admin Products
- ✅ New **Image column** with thumbnail (40×40). Broken file → ⚠️ placeholder, missing → 🎁.
- ✅ Bulk delete now uses faster `/api/products/bulk-delete` endpoint.

## 🖼️ Image System
- ✅ **🔧 Auto-fix Images** button in Media Library
  - Dry-run preview shows count
  - Converts `http://localhost/uploads/...` → `/uploads/...`
  - Fixes both products (image, images[], options.coverImage/image/gifUrl) AND media library URLs
  - Already-correct images untouched

## 🪙 Loyalty Coins
- ✅ Toggle is now **instant-save** — flipping ON/OFF immediately persists to DB
- ✅ Storefront cart: when OFF, coins section is actively hidden (not just skipped)
- ✅ Storefront account: confusing "Coins இன்னும் enable ஆகவில்லை" message removed — now the entire coins card just disappears when OFF

## Upgrade
1. Replace files
2. Visit `/api/migrate.php` once
3. Open Admin → Media → click **🔧 Auto-fix Images** to repair existing broken links
