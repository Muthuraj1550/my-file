# V21 — Image Cross-Device Fix + HOT/NEW Animated Badges

## 🐛 முக்கிய Bug Fix: இமேஜ் ப்ரோக்கன் ஆகுதல் (Different Device)

### முன்பு என்ன பிரச்சனை?
- Admin பக்கத்தில் image upload செய்தவுடன், அதே browser-ல் image நன்றாக show ஆகும்.
- ஆனால் **வேறு device / phone / browser-ல்** தெரியும் பொழுது, broken image icon (🚫) காட்டியது.

### காரணம் என்ன?
`api/upload.php` image upload செய்த பிறகு **absolute URL** save செய்தது:
```
http://localhost/uploads/img_xxx.jpg     ← localhost வேலை செய்யாது other device
http://192.168.1.5/uploads/img_xxx.jpg   ← internal IP — internet-ல் fail
http://wrongdomain.com/uploads/img.jpg   ← URL stale ஆகி broken
```
DB-ல் இந்த URL save ஆனதால், எந்த device-ல் site open செய்தாலும் அதே URL-ஐ try செய்தது → broken.

### V21 Fix
1. **`api/upload.php`** — இப்போது **relative URL** (`/uploads/img_xxx.jpg`) மட்டும் save செய்கிறது.
   Browser current host-ல் தானாக resolve செய்யும் → எல்லா device-லும் வேலை செய்யும்.

2. **`api/products.php`** — Read மற்றும் Write-ல் URL normalize செய்யும். எந்த absolute URL-ம் தானாக relative-ஆக மாறும்.

3. **`index.html` — `imgUrl()` + `imgTag()` helpers** — Front-end-ல் எல்லா `<img>` tag-க்கும் broken-image fallback (🎁 emoji) சேர்க்கப்பட்டது.

4. **`api/fix-images.php` — One-time DB cleanup tool** (ADMIN ONLY)
   - Browser-ல் login செய்த பிறகு visit:
     - `https://yoursite.com/api/fix-images.php` — DRY RUN (என்ன மாறும் என்று காட்டும்)
     - `POST` to same URL — APPLY the fix to ALL legacy products
   - இது ஒரே ஒரு முறை run செய்யுங்கள், existing broken URLs எல்லாம் சரியாகும்.

   **Easy way:** browser console-ல் இதை paste செய்யுங்கள் (admin login ஆனதற்குப் பிறகு):
   ```js
   fetch('/api/fix-images.php', {
     method: 'POST',
     headers: { 'X-Admin-Key': localStorage.getItem('adminKey') }
   }).then(r => r.json()).then(console.log);
   ```

---

## ✨ HOT / NEW Animated Badges

### HOT Badge (Featured products)
- Red→orange→yellow gradient, pulse + shift animation
- Triggers when: product is `featured = true` OR has 2+ orders OR 5+ views
- **Top-right corner**, image-க்கு above (z-index: 5)

### NEW Badge (Recent products)
- Green→cyan gradient, bounce + shine sweep animation
- Triggers automatically: products created **within last 14 days**
- Stacks below HOT badge if both apply

### Z-Index Fix
Both badges now have `z-index: 5` so they appear **above** the product image (previously hidden behind).

---

## 📋 Deploy Steps (Hostinger / cPanel)

1. Old folder backup எடுக்கவும்.
2. ZIP-ஐ extract செய்து **public_html**-ல் upload செய்யவும்.
3. **`config.php`** — DB credentials check செய்யவும் (மாற்றவில்லை என்றால் same).
4. Browser open செய்து admin login செய்யவும்.
5. **One-time:** Browser console-ல் இதை paste செய்து old image URLs ஐ fix செய்யவும்:
   ```js
   fetch('/api/fix-images.php', {
     method: 'POST',
     headers: { 'X-Admin-Key': localStorage.getItem('adminKey') }
   }).then(r => r.json()).then(console.log);
   ```
6. Done! ✅ வேறு phone/device-ல் site open செய்து images சரியாக load ஆகுதா என்று verify செய்யுங்கள்.

---

## 🗂️ Files Changed
- `api/upload.php` — relative URL save
- `api/products.php` — normalize URLs (read + write) + `createdAt` field
- `api/fix-images.php` — **NEW** legacy cleanup tool
- `api/index.php` — register new endpoint
- `index.html` — `imgUrl()` / `imgTag()` helpers, HOT+NEW animated badges, broken-image fallbacks
