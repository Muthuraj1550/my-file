-- ============================================================
--  MY 3D Gifts — install.sql
--  phpMyAdmin: உங்கள் DB select செய்த பின் SQL tab → இதை paste → Go
--  (CREATE DATABASE / USE lines remove செய்யப்பட்டன — shared hosting-ல்
--   #1044 Access denied error வராமல் இருக்க)
-- ============================================================

-- ============ SETTINGS ============
CREATE TABLE IF NOT EXISTS `settings` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `skey`       VARCHAR(100) NOT NULL UNIQUE,
  `svalue`     LONGTEXT,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ THEME ============
CREATE TABLE IF NOT EXISTS `theme` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `tkey`       VARCHAR(100) NOT NULL UNIQUE,
  `tvalue`     LONGTEXT,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ PRODUCTS ============
CREATE TABLE IF NOT EXISTS `products` (
  `id`          VARCHAR(40) PRIMARY KEY,
  `name`        VARCHAR(255) NOT NULL,
  `base_price`  DECIMAL(10,2) NOT NULL DEFAULT 0,
  `description` TEXT,
  `category`    VARCHAR(100),
  `tags`        JSON,
  `images`      JSON,
  `options`     LONGTEXT,   -- JSON blob (all product options)
  `admin_order` INT DEFAULT 999,
  `view_count`  INT DEFAULT 0,
  `order_count` INT DEFAULT 0,
  `active`      TINYINT(1) DEFAULT 1,
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ ORDERS ============
CREATE TABLE IF NOT EXISTS `orders` (
  `id`              VARCHAR(40) PRIMARY KEY,
  `tracking`        VARCHAR(40),
  `customer_name`   VARCHAR(255),
  `customer_phone`  VARCHAR(30),
  `customer_email`  VARCHAR(255),
  `address`         TEXT,
  `pincode`         VARCHAR(10),
  `items`           LONGTEXT,  -- JSON
  `total`           DECIMAL(10,2),
  `discount`        DECIMAL(10,2) DEFAULT 0,
  `shipping`        DECIMAL(10,2) DEFAULT 0,
  `coupon`          VARCHAR(50),
  `pay_method`      VARCHAR(20) DEFAULT 'cod',
  `payment_status`  VARCHAR(30) DEFAULT 'Pending',
  `status`          VARCHAR(30) DEFAULT 'New',
  `courier`         VARCHAR(100),
  `courier_tracking` VARCHAR(100),
  `history`         LONGTEXT,  -- JSON array
  `notes`           TEXT,
  `user_id`         INT,
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ USERS (customers) ============
CREATE TABLE IF NOT EXISTS `users` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `name`       VARCHAR(255),
  `phone`      VARCHAR(30) UNIQUE,
  `email`      VARCHAR(255),
  `addresses`  JSON,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ COUPONS ============
CREATE TABLE IF NOT EXISTS `coupons` (
  `id`        INT AUTO_INCREMENT PRIMARY KEY,
  `code`      VARCHAR(50) UNIQUE NOT NULL,
  `type`      ENUM('percent','flat') DEFAULT 'percent',
  `value`     DECIMAL(10,2) NOT NULL DEFAULT 0,
  `min_order` DECIMAL(10,2) DEFAULT 0,
  `active`    TINYINT(1) DEFAULT 1,
  `uses`      INT DEFAULT 0,
  `max_uses`  INT DEFAULT 0,
  `expires_at` DATETIME,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ FLASH SALE ============
CREATE TABLE IF NOT EXISTS `flash_sale` (
  `id`       INT AUTO_INCREMENT PRIMARY KEY,
  `active`   TINYINT(1) DEFAULT 0,
  `code`     VARCHAR(50),
  `discount` DECIMAL(5,2) DEFAULT 0,
  `end_time` DATETIME,
  `banner`   TEXT,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ WISHLIST ============
CREATE TABLE IF NOT EXISTS `wishlist` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `session_id` VARCHAR(100),
  `user_id`    INT,
  `product_id` VARCHAR(40),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ PRODUCT VIEWS ============
CREATE TABLE IF NOT EXISTS `product_views` (
  `product_id` VARCHAR(40) PRIMARY KEY,
  `count`      INT DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ PRODUCT VIEW LOG (date-wise + time-spent) ============
CREATE TABLE IF NOT EXISTS `product_view_log` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `product_id`  VARCHAR(40) NOT NULL,
  `view_date`   DATE NOT NULL,
  `seconds`     INT DEFAULT 0,
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_pv_product` (`product_id`),
  KEY `idx_pv_date` (`view_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ ABANDONED CARTS ============
CREATE TABLE IF NOT EXISTS `abandoned_carts` (
  `id`             VARCHAR(40) PRIMARY KEY,
  `customer_name`  VARCHAR(255),
  `customer_phone` VARCHAR(30),
  `customer_email` VARCHAR(255),
  `items`          LONGTEXT,
  `total`          DECIMAL(10,2) DEFAULT 0,
  `last_step`      VARCHAR(50) DEFAULT 'cart',
  `created_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ DEFAULT SEED DATA ============

-- Default settings
INSERT IGNORE INTO `settings` (`skey`, `svalue`) VALUES
('whatsapp',       '"+919999999999"'),
('currency',       '"₹"'),
('defaultSort',    '"admin"'),
('gstPercent',     '0'),
('buyNowWhatsApp', 'true'),
('codEnabled',     'true'),
('onlineEnabled',  'true'),
('gridColsMobile', '2'),
('gridColsTablet', '2'),
('gridColsDesktop','3'),
('productsPerPage','12'),
('shippingZones',  '[{"pincodes":"600001-600100","charge":0,"label":"Free Delivery","days":"2-3"},{"pincodes":"600101-699999","charge":50,"label":"Standard","days":"3-5"},{"pincodes":"*","charge":100,"label":"Outstation","days":"5-7"}]'),
('globalColors',   '[{"name":"சிவப்பு (Red)","hex":"#ef4444"},{"name":"மஞ்சள் (Yellow)","hex":"#eab308"},{"name":"கருப்பு (Black)","hex":"#1e293b"},{"name":"வெள்ளை (White)","hex":"#f8fafc"},{"name":"ஊதா (Purple)","hex":"#8b5cf6"},{"name":"பச்சை (Green)","hex":"#22c55e"},{"name":"நீலம் (Blue)","hex":"#3b82f6"},{"name":"ஆரஞ்சு (Orange)","hex":"#f97316"}]'),
('contact',        '{"aboutText":"நாங்கள் custom 3D printed gifts வழங்குகிறோம்","phone":"+91 9999999999","whatsapp":"+91 9999999999","email":"info@my3dgifts.com","address":"123, Main Street, Chennai, Tamil Nadu - 600001","mapLink":"","workingHours":"Mon-Sat: 10am - 8pm","socials":{"instagram":"","facebook":"","youtube":""}}'),
('customPages',    '[]'),
('popup',          '{"enabled":false,"type":"info","icon":"🎉","title":"Welcome to MY 3D Gifts!","message":"Get 10% off on your first order. Use code WELCOME10.","ctaText":"Shop Now","ctaLink":"#shop","showShareBtn":true,"shareText":"Check out MY 3D Gifts!","shareUrl":"","maxPerDay":1,"maxTotal":0,"delayMs":1500}'),
('bottomNavItems', '[{"id":"home","label":"Home","icon":"🏠","view":"shop","enabled":true},{"id":"wishlist","label":"Wishlist","icon":"❤️","view":"wishlist","enabled":true,"badge":"wishCount"},{"id":"cart","label":"Cart","icon":"🛒","view":"cart","enabled":true,"badge":"cartCount"},{"id":"account","label":"Account","icon":"👤","view":"account","enabled":true}]'),
('sideNavItems',   '[{"id":"about","label":"About Us","icon":"ℹ️","view":"about","enabled":true},{"id":"track","label":"Track Order","icon":"📦","view":"track","enabled":true},{"id":"admin","label":"Admin Panel","icon":"⚙️","view":"admin","enabled":true}]'),
('cashfree',       '{"enabled":false,"mode":"sandbox","appId":"","secretKey":"","returnUrl":""}');

-- Default theme
INSERT IGNORE INTO `theme` (`tkey`, `tvalue`) VALUES
('storeName',  '"MY 3D Gifts"'),
('tagline',    '"Personalized 3D printed gifts"'),
('logoUrl',    '""'),
('primary',    '"#6366f1"'),
('primaryDark','"#4f46e5"'),
('bg',         '"#f8fafc"'),
('surface',    '"#ffffff"'),
('text',       '"#0f172a"'),
('muted',      '"#64748b"'),
('border',     '"#e2e8f0"'),
('accent',     '"#f59e0b"'),
('fontFamily', '"\'Inter\', system-ui, sans-serif"'),
('radius',     '"12px"'),
('presetId',   '"indigo"'),
('title3d',    '{"enabled":true,"frontColor":"#1e1b4b","shadowColor":"#c4b5fd","shadowOpacity":0.95,"glowColor":"#8b5cf6","glowOpacity":0.45,"fontFamily":"Bungee"}');

-- Default coupons
INSERT IGNORE INTO `coupons` (`code`,`type`,`value`,`min_order`,`active`) VALUES
('WELCOME10','percent',10,0,1),
('FLAT50','flat',50,200,1);

-- Default flash sale
INSERT IGNORE INTO `flash_sale` (`active`,`code`,`discount`,`end_time`,`banner`) VALUES
(0,'FLASH20',20,NULL,'');

-- Default products
INSERT IGNORE INTO `products` (`id`,`name`,`base_price`,`description`,`category`,`tags`,`images`,`options`,`admin_order`) VALUES
('p1','Custom Flip Name Plate',250,'Personalized flip name plate, 2 sides 2 names.','nameplate','["name","plate","flip"]','[]',
'{"sizeEnabled":true,"sizes":[{"label":"Small","extra":0},{"label":"Medium","extra":80},{"label":"Large","extra":150}],"materialEnabled":true,"materials":[{"label":"PLA","extra":0},{"label":"ABS","extra":50}],"colorEnabled":true,"colorMode":"sync","dualColorEnabled":true,"dualColorExtra":60,"customColors":[],"photoEnabled":false,"photoLabel":"Upload reference photo","photoExtra":0,"nameInputs":[{"label":"Side A Name","maxChars":15,"perChar":8},{"label":"Side B Name","maxChars":15,"perChar":8}],"preview3D":{"type":"text","source":""},"preview3DEnabled":true,"gifUrl":"","videoUrl":"","youtubeUrl":"","videoAutoplay":false,"youtubeAutoplay":false,"dynamicOptions":[]}',
1),
('p2','Custom Photo Keychain',150,'Upload your photo, we 3D print it on a keychain.','keychain','["photo","keychain"]','[]',
'{"sizeEnabled":false,"sizes":[],"materialEnabled":true,"materials":[{"label":"PLA","extra":0}],"colorEnabled":true,"colorMode":"sync","dualColorEnabled":false,"dualColorExtra":0,"customColors":[],"photoEnabled":true,"photoLabel":"Upload your photo","photoExtra":50,"nameInputs":[],"preview3D":{"type":"text","source":""},"preview3DEnabled":true,"gifUrl":"","videoUrl":"","youtubeUrl":"","videoAutoplay":false,"youtubeAutoplay":false,"dynamicOptions":[]}',
2),
('p3','Name Keychain',99,'Single-name keychain with color choice.','keychain','["name","keychain"]','[]',
'{"sizeEnabled":false,"sizes":[],"materialEnabled":false,"materials":[],"colorEnabled":true,"colorMode":"sync","dualColorEnabled":false,"dualColorExtra":0,"customColors":[],"photoEnabled":false,"photoLabel":"","photoExtra":0,"nameInputs":[{"label":"Your Name","maxChars":12,"perChar":10}],"preview3D":{"type":"text","source":""},"preview3DEnabled":true,"gifUrl":"","videoUrl":"","youtubeUrl":"","videoAutoplay":false,"youtubeAutoplay":false,"dynamicOptions":[]}',
3);

-- ============ POPUPS (notification popups) ============
CREATE TABLE IF NOT EXISTS `popups` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `title`      VARCHAR(255),
  `body`       TEXT,
  `type`       VARCHAR(20) DEFAULT 'info',
  `icon`       VARCHAR(20) DEFAULT '🎉',
  `cta_label`  VARCHAR(100),
  `cta_url`    VARCHAR(500),
  `active`     TINYINT(1) DEFAULT 1,
  `show_after_sec` INT DEFAULT 3,
  `show_once`  TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ CUSTOM PAGES ============
CREATE TABLE IF NOT EXISTS `pages` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `slug`         VARCHAR(120) UNIQUE NOT NULL,
  `title`        VARCHAR(255) NOT NULL,
  `content`      LONGTEXT,
  `show_in_nav`  TINYINT(1) DEFAULT 1,
  `sort_order`   INT DEFAULT 0,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ ABANDONED CARTS (v12) ============
CREATE TABLE IF NOT EXISTS `abandoned_carts` (
  `id`             VARCHAR(40) PRIMARY KEY,
  `customer_name`  VARCHAR(255),
  `customer_phone` VARCHAR(30),
  `customer_email` VARCHAR(255),
  `items`          LONGTEXT,
  `total`          DECIMAL(10,2) DEFAULT 0,
  `last_step`      VARCHAR(50) DEFAULT 'cart',
  `created_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============ MEDIA LIBRARY (v14) ============
CREATE TABLE IF NOT EXISTS `media` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `url`        VARCHAR(500) NOT NULL,
  `name`       VARCHAR(255),
  `mime`       VARCHAR(60),
  `size`       INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- v14: orders.source ('online' / 'walkin') for analytics split
-- (added via migrate.php for existing installs)

-- ============ V34: AFFILIATE PRODUCTS ============
CREATE TABLE IF NOT EXISTS `affiliate_products` (
  `id`            VARCHAR(40) PRIMARY KEY,
  `title`         VARCHAR(255) NOT NULL,
  `image`         TEXT,
  `price`         DECIMAL(10,2) DEFAULT 0,
  `source`        VARCHAR(40) NOT NULL DEFAULT 'amazon',
  `affiliate_url` TEXT NOT NULL,
  `show_on_home`  TINYINT(1) DEFAULT 0,
  `active`        TINYINT(1) DEFAULT 1,
  `sort_order`    INT DEFAULT 999,
  `click_count`   INT DEFAULT 0,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `affiliate_clicks` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `affiliate_id` VARCHAR(40) NOT NULL,
  `source`       VARCHAR(40),
  `click_date`   DATE NOT NULL,
  `ip`           VARCHAR(64),
  `ua`           VARCHAR(255),
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_aff_id` (`affiliate_id`),
  KEY `idx_aff_date` (`click_date`),
  KEY `idx_aff_source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
