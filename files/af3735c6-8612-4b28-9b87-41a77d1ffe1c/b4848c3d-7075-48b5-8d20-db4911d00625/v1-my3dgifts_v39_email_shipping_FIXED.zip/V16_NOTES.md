# v16 — Custom Options + Direct Upload + Product Sync Fixes

## What's new in v16

### 🐛 Fix: Products disappearing after refresh (CRITICAL)
- **Root cause**: `assets/api-bridge.js` `apiPut`/`apiPost` resolved with the response JSON
  (success or error) and never threw. The "fallback to POST on PUT failure" branch in
  `syncToAPI` therefore never fired, and newly-created products were saved only to
  `localStorage` — they reappeared until the page was reloaded, then vanished because
  the server never had them.
- **Fix**: HTTP helpers now throw on `!ok`. `syncToAPI` awaits each upsert, tracks
  the last-synced product IDs to detect deletions, and propagates server errors via
  toast so failures are visible.

### 📤 Direct image upload buttons (admin-app.html)
- "📤 Upload" button next to **Main Image** field — uploads via `/api/upload.php`
  and pastes the resulting `/uploads/...` URL automatically.
- "📤 Upload Multiple" button below **Extra Images** textarea — appends one URL per line.
- "📤" button next to **GIF URL** field — same one-click upload for GIFs.
- Live thumbnail preview of the main image after upload.

### 🎬 Video & YouTube fields in admin-app.html
- New **Video URL (.mp4)** input + **Auto-play Video** toggle.
- New **YouTube URL** input + **Auto-play YouTube** toggle.
- Storefront already supports playing these (since v8) — the admin panel can now set them.

### 🧩 Custom Options (Unlimited) — admin-app.html
The repeatable custom options builder (text / textarea / number / dropdown / radio /
color / checkbox / file) that previously only existed in the storefront-side admin
editor is now also available in the dedicated admin panel.

Each option supports:
- **Type** dropdown (text, textarea, number, dropdown, radio, color, checkbox, file)
- **Required** Yes/No
- **Flat extra (₹)** — added once when the option has a value
- **Per char (₹)** — added per character (text/textarea types)
- **Per unit (₹)** — added per unit (number type)
- **Placeholder, Max chars** (text/textarea)
- **Accept** file types (file type)
- **Values** — one per line in `Label,ExtraPrice` format (dropdown/radio)
- **Reorder** with ↑ / ↓ buttons, **Remove** with ✕

Color values come from the global Filament Colors library; the option's "Flat extra"
is added per color choice, exactly like in the storefront.

### 📤 Storefront editor uploads to server (not data URLs)
- `addImagesFromFiles` now POSTs to `/api/upload.php` first when an admin key is
  available, so images are stored as real `/uploads/...` URLs (not 1-MB base64
  strings that bloat the JSON product blob and risk silent save failures).
- Falls back to data URL when not logged in or upload fails.

### 💾 Storefront editor "Save" awaits server sync
- After saving, the editor now explicitly PUT/POSTs the product to the API and
  surfaces success/failure via toast. New products are no longer lost on reload.
- Any data URL images embedded in the product are auto-uploaded to `/uploads/`
  before sync via the new `uploadDataUrlImages` helper.

## How to apply
1. **Backup** your existing files (especially `config.php`).
2. Replace project files with this zip's contents.
3. **Keep your existing `config.php`** — do not overwrite credentials.
4. No DB schema change vs v14/v15 — `dynamicOptions` lives inside the existing
   `options` JSON blob.
5. Hard refresh admin + storefront (Ctrl+Shift+R / Cmd+Shift+R).

## Phase 2 (planned, not in v16)
- Theme presets (gift-themed palettes + 3D text title presets)
- Accounts page (income/expense, auto-pull orders, monthly analytics)
- Cart Recovery → Approve → Order button + image upload in edit
- Customizable vs Ready-made product type label + separate shop sections

Made for MY 3D Gifts — v16 (April 2026)
