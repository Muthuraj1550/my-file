-- Today's List — hosting schema
-- Import this file once via phpMyAdmin (or `mysql -u user -p dbname < schema.sql`)

CREATE TABLE IF NOT EXISTS settings (
  `key` VARCHAR(50) PRIMARY KEY,
  `value` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tasks (
  id VARCHAR(32) PRIMARY KEY,
  name VARCHAR(140) NOT NULL,
  done TINYINT(1) NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notes (
  id VARCHAR(32) PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  created_at BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS note_items (
  id VARCHAR(32) PRIMARY KEY,
  note_id VARCHAR(32) NOT NULL,
  text VARCHAR(200) NOT NULL,
  done TINYINT(1) NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL,
  FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS files (
  id VARCHAR(32) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(255) NOT NULL,
  size BIGINT NOT NULL,
  type VARCHAR(100),
  created_at BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Health tab: tablet stock tracking (main storage + daily take-out batch)
-- next_consult_date / consult_interval_months are only used by a FRESH install;
-- if your tablets table already exists from before, use the ALTER lines below instead.
CREATE TABLE IF NOT EXISTS tablets (
  id VARCHAR(32) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  morning_time VARCHAR(8) DEFAULT NULL,
  night_time VARCHAR(8) DEFAULT NULL,
  total_stock INT NOT NULL DEFAULT 0,
  low_stock_threshold INT NOT NULL DEFAULT 10,
  batch_qty INT NOT NULL DEFAULT 0,
  batch_remaining INT NOT NULL DEFAULT 0,
  batch_consumed INT NOT NULL DEFAULT 0,
  next_consult_date DATE DEFAULT NULL,
  consult_interval_months INT NOT NULL DEFAULT 3,
  created_at BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Run these two lines ONCE if your tablets table already existed before today
-- (i.e. CREATE TABLE above did nothing because the table was already there).
-- If phpMyAdmin says "Duplicate column name", that just means it's already
-- applied — ignore that specific error and move on.
ALTER TABLE tablets ADD COLUMN next_consult_date DATE DEFAULT NULL;
ALTER TABLE tablets ADD COLUMN consult_interval_months INT NOT NULL DEFAULT 3;

-- One row per tablet per day per slot (morning/night) — taken or skipped
CREATE TABLE IF NOT EXISTS tablet_logs (
  id VARCHAR(32) PRIMARY KEY,
  tablet_id VARCHAR(32) NOT NULL,
  log_date DATE NOT NULL,
  slot ENUM('morning','night') NOT NULL,
  status ENUM('taken','skipped') NOT NULL,
  created_at BIGINT NOT NULL,
  UNIQUE KEY uniq_tablet_date_slot (tablet_id, log_date, slot),
  FOREIGN KEY (tablet_id) REFERENCES tablets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row per doctor-visit purchase (date + qty added to total stock)
CREATE TABLE IF NOT EXISTS tablet_purchases (
  id VARCHAR(32) PRIMARY KEY,
  tablet_id VARCHAR(32) NOT NULL,
  purchase_date DATE NOT NULL,
  qty INT NOT NULL,
  created_at BIGINT NOT NULL,
  FOREIGN KEY (tablet_id) REFERENCES tablets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
