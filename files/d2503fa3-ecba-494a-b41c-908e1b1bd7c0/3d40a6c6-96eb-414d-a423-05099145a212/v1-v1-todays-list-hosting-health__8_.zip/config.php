<?php
/**
 * Database configuration
 * -----------------------
 * Change DB_HOST only if your hosting provider gives you a different
 * MySQL host (cPanel hosts are almost always "localhost").
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'mydgifts_pd');
define('DB_USER', 'mydgifts_pd');
define('DB_PASS', 'Todo@1550');

// Folder (relative to this file) where uploaded files are stored on disk.
define('UPLOAD_DIR', __DIR__ . '/uploads');

// Max upload size per file (bytes). 20MB — change if you like (also check
// your php.ini upload_max_filesize / post_max_size on the host).
define('MAX_FILE_SIZE', 20 * 1024 * 1024);

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'DB connection failed: ' . $e->getMessage()]);
            exit;
        }
    }
    return $pdo;
}

function uid(): string {
    return substr(bin2hex(random_bytes(8)), 0, 16);
}
