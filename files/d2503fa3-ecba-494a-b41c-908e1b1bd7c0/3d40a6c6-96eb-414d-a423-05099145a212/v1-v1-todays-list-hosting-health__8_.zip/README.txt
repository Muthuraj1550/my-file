Today's List — Hosting Package (PHP + MySQL)
=============================================

இதில் என்ன இருக்கு:
--------------------
  index.html   → முழு app (UI + JS, api.php-ஐ அழைக்கும்)
  api.php      → எல்லா actions-ஐயும் கையாளும் backend (tasks, notes, files, password)
  config.php   → DB settings (ஏற்கனவே உங்கள் credentials போடப்பட்டுள்ளது)
  schema.sql   → MySQL டேபிள்களை உருவாக்க
  uploads/     → அப்லோட் செய்யும் கோப்புகள் இங்கே சேமிக்கப்படும் (.htaccess மூலம் direct access பிளாக் செய்யப்பட்டுள்ளது)

Setup படிகள் (cPanel):
-----------------------
1. cPanel → File Manager → public_html (அல்லது நீங்கள் விரும்பும் subfolder, எ.கா. public_html/todo)
   இதில் இந்த zip-இல் உள்ள எல்லா கோப்புகளையும் upload செய்து extract செய்யவும்.

2. "uploads" ஃபோல்டருக்கு write permission இருக்கணும் — File Manager-இல் அதன் மேல்
   right-click → Permissions → 755 (அல்லது தேவைப்பட்டால் 775) செட் செய்யவும்.

3. cPanel → MySQL Databases:
   - Database: mydgifts_pd (இது ஏற்கனவே இருந்தால் அப்படியே பயன்படுத்தவும்;
     இல்லையென்றால் இதே பெயரில் உருவாக்கவும்)
   - User: mydgifts_pd, இதே DB-க்கு "All Privileges" கொடுக்கவும்.
   (இவை config.php-இல் ஏற்கனவே அமைக்கப்பட்டுள்ளன. உங்கள் ஹோஸ்ட் username prefix
   சேர்க்கும்படி இருந்தால் — எ.கா. cpaneluser_mydgifts_pd — config.php-இல்
   DB_NAME / DB_USER-ஐ அதற்கேற்ப மாற்றவும்.)

4. cPanel → phpMyAdmin → அந்த database-ஐத் தேர்ந்தெடுத்து → Import tab →
   schema.sql கோப்பைத் தேர்ந்தெடுத்து Go அழுத்தவும். (இது tasks, notes,
   note_items, files, settings டேபிள்களை உருவாக்கும்.)

5. config.php-ஐத் திறந்து DB_HOST சரியா எனச் சரிபார்க்கவும் — பெரும்பாலான
   cPanel ஹோஸ்டுகளில் இது "localhost" ஆகவே இருக்கும். வேறு மதிப்பு
   கொடுத்திருந்தால் மட்டும் மாற்றவும்.

6. உங்கள் டொமைன்/சப்-ஃபோல்டரை பிரவுசரில் திறக்கவும் (எ.கா.
   https://yourdomain.com/todo/index.html). Default password: 1234
   (பின்னர் 🔒 பட்டனில் இருந்து மாற்றலாம்.)

குறிப்புகள்:
------------
- ஒரு கோப்புக்கு அதிகபட்ச அப்லோட் அளவு api.php / config.php-இல்
  MAX_FILE_SIZE-ல் அமைக்கப்பட்டுள்ளது (இப்போது 20MB). இதை php.ini-இல் உள்ள
  upload_max_filesize / post_max_size-உடன் ஒத்துப்போகுமாறு வைத்திருக்கவும்.
- "எல்லாம் ZIP" பட்டன் இப்போது சர்வரிலேயே (PHP ZipArchive) ZIP தயார் செய்து
  தரும் — இதற்கு உங்கள் ஹோஸ்டிங்கில் PHP ZipArchive extension enable
  செய்யப்பட்டிருக்க வேண்டும் (பெரும்பாலான cPanel ஹோஸ்டுகளில் இது default-ஆகவே
  இருக்கும்).
- இது single-user/personal பயன்பாட்டுக்கானது; பாஸ்வேர்ட் ஒரு "board lock"
  தான், பல பயனர் logins கிடையாது.
