<?php
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

$pdo = db();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

function input(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function ok($data = []) {
    echo json_encode(array_merge(['ok' => true], $data));
    exit;
}
function fail(string $msg, int $code = 400) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

switch ($action) {

    /* ---------------- FULL STATE ---------------- */
    case 'state': {
        $tasks = $pdo->query('SELECT id, name, done, created_at FROM tasks ORDER BY created_at DESC')->fetchAll();
        foreach ($tasks as &$t) { $t['done'] = (bool)$t['done']; $t['created_at'] = (int)$t['created_at']; }

        $notes = $pdo->query('SELECT id, title, created_at FROM notes ORDER BY created_at DESC')->fetchAll();
        $itemsStmt = $pdo->prepare('SELECT id, text, done FROM note_items WHERE note_id = ? ORDER BY created_at ASC');
        foreach ($notes as &$n) {
            $itemsStmt->execute([$n['id']]);
            $items = $itemsStmt->fetchAll();
            foreach ($items as &$it) { $it['done'] = (bool)$it['done']; }
            $n['items'] = $items;
        }

        $files = $pdo->query('SELECT id, name, size, type, created_at FROM files ORDER BY created_at DESC')->fetchAll();
        foreach ($files as &$f) { $f['size'] = (int)$f['size']; $f['created_at'] = (int)$f['created_at']; }

        $pwRow = $pdo->query("SELECT `value` FROM settings WHERE `key`='app-lock-password'")->fetch();
        $usingDefault = false;
        if (!$pwRow) {
            $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('app-lock-password', ?)")
                ->execute([password_hash('1234', PASSWORD_DEFAULT)]);
            $usingDefault = true;
        } else {
            $usingDefault = password_verify('1234', $pwRow['value']);
        }

        ok(['tasks' => $tasks, 'notes' => $notes, 'files' => $files, 'using_default_password' => $usingDefault]);
    }

    /* ---------------- PASSWORD ---------------- */
    case 'check_password': {
        $body = input();
        $pw = (string)($body['password'] ?? '');
        $row = $pdo->query("SELECT `value` FROM settings WHERE `key`='app-lock-password'")->fetch();
        if (!$row) fail('no password set', 500);
        ok(['match' => password_verify($pw, $row['value'])]);
    }

    case 'set_password': {
        $body = input();
        $pw = (string)($body['password'] ?? '');
        if (strlen($pw) < 4) fail('password too short');
        $hash = password_hash($pw, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('app-lock-password', ?)
                                ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)");
        $stmt->execute([$hash]);
        ok();
    }

    /* ---------------- TASKS ---------------- */
    case 'add_task': {
        $body = input();
        $name = trim((string)($body['name'] ?? ''));
        if ($name === '') fail('empty name');
        $id = uid();
        $pdo->prepare('INSERT INTO tasks (id, name, done, created_at) VALUES (?, ?, 0, ?)')
            ->execute([$id, $name, (int)(microtime(true) * 1000)]);
        ok(['id' => $id]);
    }

    case 'toggle_task': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('UPDATE tasks SET done = 1 - done WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'delete_task': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('DELETE FROM tasks WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'clear_completed': {
        $pdo->exec('DELETE FROM tasks WHERE done = 1');
        ok();
    }

    /* ---------------- NOTES (websites) ---------------- */
    case 'add_note': {
        $body = input();
        $title = trim((string)($body['title'] ?? ''));
        if ($title === '') fail('empty title');
        $id = uid();
        $pdo->prepare('INSERT INTO notes (id, title, created_at) VALUES (?, ?, ?)')
            ->execute([$id, $title, (int)(microtime(true) * 1000)]);
        ok(['id' => $id]);
    }

    case 'delete_note': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('DELETE FROM notes WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'add_note_item': {
        $body = input();
        $noteId = (string)($body['note_id'] ?? '');
        $text = trim((string)($body['text'] ?? ''));
        if ($text === '' || $noteId === '') fail('missing fields');
        $id = uid();
        $pdo->prepare('INSERT INTO note_items (id, note_id, text, done, created_at) VALUES (?, ?, ?, 0, ?)')
            ->execute([$id, $noteId, $text, (int)(microtime(true) * 1000)]);
        ok(['id' => $id]);
    }

    case 'toggle_note_item': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('UPDATE note_items SET done = 1 - done WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'delete_note_item': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('DELETE FROM note_items WHERE id = ?')->execute([$id]);
        ok();
    }

    /* ---------------- FILES ---------------- */
    case 'upload_file': {
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            fail('upload error');
        }
        $f = $_FILES['file'];
        if ($f['size'] > MAX_FILE_SIZE) fail('file too large');

        if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);

        $id = uid();
        $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
        $storedName = $id . ($ext ? '.' . preg_replace('/[^a-zA-Z0-9]/', '', $ext) : '');
        $dest = UPLOAD_DIR . '/' . $storedName;

        if (!move_uploaded_file($f['tmp_name'], $dest)) fail('could not save file', 500);

        $pdo->prepare('INSERT INTO files (id, name, stored_name, size, type, created_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$id, $f['name'], $storedName, $f['size'], $f['type'], (int)(microtime(true) * 1000)]);

        ok(['id' => $id]);
    }

    case 'delete_file': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $row = $pdo->prepare('SELECT stored_name FROM files WHERE id = ?');
        $row->execute([$id]);
        $rec = $row->fetch();
        if ($rec) {
            $path = UPLOAD_DIR . '/' . $rec['stored_name'];
            if (is_file($path)) @unlink($path);
            $pdo->prepare('DELETE FROM files WHERE id = ?')->execute([$id]);
        }
        ok();
    }

    case 'download_file': {
        $id = (string)($_GET['id'] ?? '');
        $stmt = $pdo->prepare('SELECT name, stored_name, type FROM files WHERE id = ?');
        $stmt->execute([$id]);
        $rec = $stmt->fetch();
        if (!$rec) fail('not found', 404);
        $path = UPLOAD_DIR . '/' . $rec['stored_name'];
        if (!is_file($path)) fail('file missing on disk', 404);

        header('Content-Type: ' . ($rec['type'] ?: 'application/octet-stream'));
        header('Content-Disposition: attachment; filename="' . basename($rec['name']) . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    case 'zip_all': {
        $files = $pdo->query('SELECT name, stored_name FROM files')->fetchAll();
        if (!$files) fail('no files');
        if (!class_exists('ZipArchive')) fail('ZipArchive not available on this server', 500);

        $tmpZip = tempnam(sys_get_temp_dir(), 'zip');
        $zip = new ZipArchive();
        $zip->open($tmpZip, ZipArchive::OVERWRITE);
        $used = [];
        foreach ($files as $f) {
            $path = UPLOAD_DIR . '/' . $f['stored_name'];
            if (!is_file($path)) continue;
            $name = $f['name'];
            if (isset($used[$name])) {
                $dot = strrpos($name, '.');
                $name = $dot !== false
                    ? substr($name, 0, $dot) . ' (' . substr($f['stored_name'], 0, 4) . ')' . substr($name, $dot)
                    : $name . ' (' . substr($f['stored_name'], 0, 4) . ')';
            }
            $used[$name] = true;
            $zip->addFile($path, $name);
        }
        $zip->close();

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="files-' . date('Y-m-d') . '.zip"');
        header('Content-Length: ' . filesize($tmpZip));
        readfile($tmpZip);
        unlink($tmpZip);
        exit;
    }

    default:
        fail('unknown action', 404);
}
