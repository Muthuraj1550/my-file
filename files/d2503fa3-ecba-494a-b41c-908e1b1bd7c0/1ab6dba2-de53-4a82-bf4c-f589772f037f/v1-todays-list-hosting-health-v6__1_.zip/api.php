<?php
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

$pdo = db();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

function input(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function ok($data = []) {
    echo json_encode(array_merge(['ok' => true], $data));
    exit;
}
function fail(string $msg, int $code = 400) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

try {
switch ($action) {

    /* ---------------- FULL STATE ---------------- */
    case 'state': {
        $tasks = $pdo->query('SELECT id, name, done, created_at FROM tasks ORDER BY created_at DESC')->fetchAll();
        foreach ($tasks as &$t) { $t['done'] = (bool)$t['done']; $t['created_at'] = (int)$t['created_at']; }

        $notes = $pdo->query('SELECT id, title, created_at FROM notes ORDER BY created_at DESC')->fetchAll();
        $itemsStmt = $pdo->prepare('SELECT id, text, done FROM note_items WHERE note_id = ? ORDER BY created_at ASC');
        foreach ($notes as &$n) {
            $itemsStmt->execute([$n['id']]);
            $items = $itemsStmt->fetchAll();
            foreach ($items as &$it) { $it['done'] = (bool)$it['done']; }
            $n['items'] = $items;
        }

        $files = $pdo->query('SELECT id, name, size, type, created_at FROM files ORDER BY created_at DESC')->fetchAll();
        foreach ($files as &$f) { $f['size'] = (int)$f['size']; $f['created_at'] = (int)$f['created_at']; }

        // client's local YYYY-MM-DD and HH:MM (so "today"/"now" match the user's
        // device, not the server)
        $today = (string)($_GET['today'] ?? date('Y-m-d'));
        $now = (string)($_GET['now'] ?? date('H:i'));
        $tablets = $pdo->query('SELECT id, name, morning_time, night_time, total_stock, low_stock_threshold, batch_qty, batch_remaining, batch_consumed, created_at FROM tablets ORDER BY created_at DESC')->fetchAll();
        $logStmt = $pdo->prepare('SELECT slot, status FROM tablet_logs WHERE tablet_id = ? AND log_date = ?');
        $insertLog = $pdo->prepare('INSERT INTO tablet_logs (id, tablet_id, log_date, slot, status, created_at) VALUES (?, ?, ?, ?, ?, ?)');
        $updateTablet = $pdo->prepare('UPDATE tablets SET batch_remaining = ?, batch_consumed = ? WHERE id = ?');
        $purchStmt = $pdo->prepare('SELECT purchase_date, qty FROM tablet_purchases WHERE tablet_id = ? ORDER BY purchase_date DESC, created_at DESC');
        foreach ($tablets as &$tb) {
            $tb['total_stock'] = (int)$tb['total_stock'];
            $tb['low_stock_threshold'] = (int)$tb['low_stock_threshold'];
            $tb['batch_qty'] = (int)$tb['batch_qty'];
            $tb['batch_remaining'] = (int)$tb['batch_remaining'];
            $tb['batch_consumed'] = (int)$tb['batch_consumed'];
            $tb['created_at'] = (int)$tb['created_at'];
            $logStmt->execute([$tb['id'], $today]);
            $todayLogs = ['morning' => null, 'night' => null];
            foreach ($logStmt->fetchAll() as $lg) { $todayLogs[$lg['slot']] = $lg['status']; }

            // Default is "taken" — a scheduled dose auto-counts as taken unless the
            // person taps Skip. Only fill in slots that (a) have a time set, (b) that
            // scheduled time has actually arrived today (compared to the client's
            // current clock, not just the date), (c) aren't logged yet today, and
            // (d) there's stock left in the daily pile.
            $remaining = $tb['batch_remaining'];
            $consumed = $tb['batch_consumed'];
            $changed = false;
            foreach (['morning', 'night'] as $slot) {
                if ($tb[$slot . '_time'] === null) continue;
                if ($todayLogs[$slot] !== null) continue;
                if ($tb[$slot . '_time'] > $now) continue; // scheduled time hasn't arrived yet
                if ($remaining <= 0) continue;
                $remaining -= 1; $consumed += 1;
                $insertLog->execute([uid(), $tb['id'], $today, $slot, 'taken', (int)(microtime(true) * 1000)]);
                $todayLogs[$slot] = 'taken';
                $changed = true;
            }
            if ($changed) {
                $updateTablet->execute([$remaining, $consumed, $tb['id']]);
                $tb['batch_remaining'] = $remaining;
                $tb['batch_consumed'] = $consumed;
            }

            $tb['today'] = $todayLogs;

            $purchStmt->execute([$tb['id']]);
            $purchases = $purchStmt->fetchAll();
            foreach ($purchases as &$p) { $p['qty'] = (int)$p['qty']; }
            $tb['purchases'] = $purchases;
        }

        $pwRow = $pdo->query("SELECT `value` FROM settings WHERE `key`='app-lock-password'")->fetch();
        $usingDefault = false;
        if (!$pwRow) {
            $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('app-lock-password', ?)")
                ->execute([password_hash('1234', PASSWORD_DEFAULT)]);
            $usingDefault = true;
        } else {
            $usingDefault = password_verify('1234', $pwRow['value']);
        }

        // ONE shared doctor-consultation date for the whole Health tab (not per tablet) —
        // e.g. "see the doctor once every 3 months, when all tablets are about to finish".
        $consultDateRow = $pdo->query("SELECT `value` FROM settings WHERE `key`='health-next-consult-date'")->fetch();
        $consultIntervalRow = $pdo->query("SELECT `value` FROM settings WHERE `key`='health-consult-interval-months'")->fetch();
        $healthNextConsultDate = ($consultDateRow && $consultDateRow['value'] !== '') ? $consultDateRow['value'] : null;
        $healthConsultIntervalMonths = $consultIntervalRow ? (int)$consultIntervalRow['value'] : 3;
        if ($healthConsultIntervalMonths <= 0) $healthConsultIntervalMonths = 3;

        ok([
            'tasks' => $tasks, 'notes' => $notes, 'files' => $files, 'tablets' => $tablets,
            'using_default_password' => $usingDefault,
            'health_next_consult_date' => $healthNextConsultDate,
            'health_consult_interval_months' => $healthConsultIntervalMonths
        ]);
    }

    /* ---------------- PASSWORD ---------------- */
    case 'check_password': {
        $body = input();
        $pw = (string)($body['password'] ?? '');
        $row = $pdo->query("SELECT `value` FROM settings WHERE `key`='app-lock-password'")->fetch();
        if (!$row) fail('no password set', 500);
        ok(['match' => password_verify($pw, $row['value'])]);
    }

    case 'set_password': {
        $body = input();
        $pw = (string)($body['password'] ?? '');
        if (strlen($pw) < 4) fail('password too short');
        $hash = password_hash($pw, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('app-lock-password', ?)
                                ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)");
        $stmt->execute([$hash]);
        ok();
    }

    case 'reset_password': {
        // Forgot the password — reset it straight back to the default (1234).
        // This app has no email/SMS to verify identity, and the lock screen is a
        // soft family-privacy feature (not real auth — the data itself loads
        // before unlocking), so a direct reset here is the practical option.
        $hash = password_hash('1234', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('app-lock-password', ?)
                                ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)");
        $stmt->execute([$hash]);
        ok();
    }

    /* ---------------- TASKS ---------------- */
    case 'add_task': {
        $body = input();
        $name = trim((string)($body['name'] ?? ''));
        if ($name === '') fail('empty name');
        $id = uid();
        $pdo->prepare('INSERT INTO tasks (id, name, done, created_at) VALUES (?, ?, 0, ?)')
            ->execute([$id, $name, (int)(microtime(true) * 1000)]);
        ok(['id' => $id]);
    }

    case 'toggle_task': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('UPDATE tasks SET done = 1 - done WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'delete_task': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('DELETE FROM tasks WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'clear_completed': {
        $pdo->exec('DELETE FROM tasks WHERE done = 1');
        ok();
    }

    /* ---------------- NOTES (websites) ---------------- */
    case 'add_note': {
        $body = input();
        $title = trim((string)($body['title'] ?? ''));
        if ($title === '') fail('empty title');
        $id = uid();
        $pdo->prepare('INSERT INTO notes (id, title, created_at) VALUES (?, ?, ?)')
            ->execute([$id, $title, (int)(microtime(true) * 1000)]);
        ok(['id' => $id]);
    }

    case 'delete_note': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('DELETE FROM notes WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'add_note_item': {
        $body = input();
        $noteId = (string)($body['note_id'] ?? '');
        $text = trim((string)($body['text'] ?? ''));
        if ($text === '' || $noteId === '') fail('missing fields');
        $id = uid();
        $pdo->prepare('INSERT INTO note_items (id, note_id, text, done, created_at) VALUES (?, ?, ?, 0, ?)')
            ->execute([$id, $noteId, $text, (int)(microtime(true) * 1000)]);
        ok(['id' => $id]);
    }

    case 'toggle_note_item': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('UPDATE note_items SET done = 1 - done WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'delete_note_item': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('DELETE FROM note_items WHERE id = ?')->execute([$id]);
        ok();
    }

    /* ---------------- FILES ---------------- */
    case 'upload_file': {
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            fail('upload error');
        }
        $f = $_FILES['file'];
        if ($f['size'] > MAX_FILE_SIZE) fail('file too large');

        if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);

        $id = uid();
        $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
        $storedName = $id . ($ext ? '.' . preg_replace('/[^a-zA-Z0-9]/', '', $ext) : '');
        $dest = UPLOAD_DIR . '/' . $storedName;

        if (!move_uploaded_file($f['tmp_name'], $dest)) fail('could not save file', 500);

        $pdo->prepare('INSERT INTO files (id, name, stored_name, size, type, created_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$id, $f['name'], $storedName, $f['size'], $f['type'], (int)(microtime(true) * 1000)]);

        ok(['id' => $id]);
    }

    case 'delete_file': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $row = $pdo->prepare('SELECT stored_name FROM files WHERE id = ?');
        $row->execute([$id]);
        $rec = $row->fetch();
        if ($rec) {
            $path = UPLOAD_DIR . '/' . $rec['stored_name'];
            if (is_file($path)) @unlink($path);
            $pdo->prepare('DELETE FROM files WHERE id = ?')->execute([$id]);
        }
        ok();
    }

    case 'download_file': {
        $id = (string)($_GET['id'] ?? '');
        $stmt = $pdo->prepare('SELECT name, stored_name, type FROM files WHERE id = ?');
        $stmt->execute([$id]);
        $rec = $stmt->fetch();
        if (!$rec) fail('not found', 404);
        $path = UPLOAD_DIR . '/' . $rec['stored_name'];
        if (!is_file($path)) fail('file missing on disk', 404);

        header('Content-Type: ' . ($rec['type'] ?: 'application/octet-stream'));
        header('Content-Disposition: attachment; filename="' . basename($rec['name']) . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    case 'zip_all': {
        $files = $pdo->query('SELECT name, stored_name FROM files')->fetchAll();
        if (!$files) fail('no files');
        if (!class_exists('ZipArchive')) fail('ZipArchive not available on this server', 500);

        $tmpZip = tempnam(sys_get_temp_dir(), 'zip');
        $zip = new ZipArchive();
        $zip->open($tmpZip, ZipArchive::OVERWRITE);
        $used = [];
        foreach ($files as $f) {
            $path = UPLOAD_DIR . '/' . $f['stored_name'];
            if (!is_file($path)) continue;
            $name = $f['name'];
            if (isset($used[$name])) {
                $dot = strrpos($name, '.');
                $name = $dot !== false
                    ? substr($name, 0, $dot) . ' (' . substr($f['stored_name'], 0, 4) . ')' . substr($name, $dot)
                    : $name . ' (' . substr($f['stored_name'], 0, 4) . ')';
            }
            $used[$name] = true;
            $zip->addFile($path, $name);
        }
        $zip->close();

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="files-' . date('Y-m-d') . '.zip"');
        header('Content-Length: ' . filesize($tmpZip));
        readfile($tmpZip);
        unlink($tmpZip);
        exit;
    }

    /* ---------------- HEALTH (tablets) ---------------- */
    case 'add_tablet': {
        $body = input();
        $name = trim((string)($body['name'] ?? ''));
        if ($name === '') fail('empty name');
        $morning = trim((string)($body['morning_time'] ?? ''));
        $night = trim((string)($body['night_time'] ?? ''));
        $morning = $morning === '' ? null : $morning;
        $night = $night === '' ? null : $night;
        $initialStock = max(0, (int)($body['initial_stock'] ?? 0));
        // low_stock_threshold now means "warn me this many days before the daily pile runs out"
        $warnDays = (int)($body['low_stock_threshold'] ?? 3);
        if ($warnDays <= 0) $warnDays = 3;
        $id = uid();
        $pdo->prepare('INSERT INTO tablets (id, name, morning_time, night_time, total_stock, low_stock_threshold, batch_qty, batch_remaining, batch_consumed, created_at) VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, ?)')
            ->execute([$id, $name, $morning, $night, $initialStock, $warnDays, (int)(microtime(true) * 1000)]);
        ok(['id' => $id]);
    }

    case 'delete_tablet': {
        $body = input();
        $id = (string)($body['id'] ?? '');
        $pdo->prepare('DELETE FROM tablets WHERE id = ?')->execute([$id]);
        ok();
    }

    case 'update_tablet': {
        // Edit an existing tablet's name / dose times / warn-days / total stock in
        // storage / daily-use pile count (all editable from one place)
        $body = input();
        $id = (string)($body['id'] ?? '');
        $name = trim((string)($body['name'] ?? ''));
        if ($name === '') fail('empty name');
        $morning = trim((string)($body['morning_time'] ?? ''));
        $night = trim((string)($body['night_time'] ?? ''));
        $morning = $morning === '' ? null : $morning;
        $night = $night === '' ? null : $night;
        $warnDays = (int)($body['low_stock_threshold'] ?? 3);
        if ($warnDays <= 0) $warnDays = 3;
        $totalStock = max(0, (int)($body['total_stock'] ?? 0));
        $batchRemaining = max(0, (int)($body['batch_remaining'] ?? 0));
        // Current values, so partial edits (e.g. only the stock table) keep the rest intact
        $curStmt = $pdo->prepare('SELECT batch_qty, batch_consumed FROM tablets WHERE id = ?');
        $curStmt->execute([$id]);
        $cur = $curStmt->fetch() ?: ['batch_qty' => 0, 'batch_consumed' => 0];
        $batchQty = array_key_exists('batch_qty', $body)
            ? max(0, (int)$body['batch_qty'])
            : (int)$cur['batch_qty'];
        $batchConsumed = array_key_exists('batch_consumed', $body)
            ? max(0, (int)$body['batch_consumed'])
            : (int)$cur['batch_consumed'];
        $pdo->prepare('UPDATE tablets SET name = ?, morning_time = ?, night_time = ?, low_stock_threshold = ?, total_stock = ?, batch_remaining = ?, batch_qty = ?, batch_consumed = ? WHERE id = ?')
            ->execute([$name, $morning, $night, $warnDays, $totalStock, $batchRemaining, $batchQty, $batchConsumed, $id]);
        ok();
    }

    case 'set_health_consult': {
        // ONE shared doctor-consultation date/interval for the whole Health tab
        $body = input();
        $date = trim((string)($body['next_consult_date'] ?? ''));
        $interval = (int)($body['consult_interval_months'] ?? 3);
        if ($interval <= 0) $interval = 3;
        $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('health-next-consult-date', ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)")
            ->execute([$date]);
        $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES ('health-consult-interval-months', ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)")
            ->execute([(string)$interval]);
        ok();
    }

    case 'add_stock': {
        // Doctor visit refill — adds to the main storage total, and logs the purchase (date + qty)
        $body = input();
        $id = (string)($body['id'] ?? '');
        $qty = (int)($body['qty'] ?? 0);
        $date = (string)($body['purchase_date'] ?? date('Y-m-d'));
        if ($qty <= 0) fail('invalid qty');
        $pdo->prepare('UPDATE tablets SET total_stock = total_stock + ? WHERE id = ?')->execute([$qty, $id]);
        $pdo->prepare('INSERT INTO tablet_purchases (id, tablet_id, purchase_date, qty, created_at) VALUES (?, ?, ?, ?, ?)')
            ->execute([uid(), $id, $date, $qty, (int)(microtime(true) * 1000)]);
        ok();
    }

    case 'take_out_batch': {
        // Move N tablets from main storage into the "daily use" pile (e.g. 10 or 15)
        $body = input();
        $id = (string)($body['id'] ?? '');
        $qty = (int)($body['qty'] ?? 0);
        if ($qty <= 0) fail('invalid qty');
        $row = $pdo->prepare('SELECT total_stock FROM tablets WHERE id = ?');
        $row->execute([$id]);
        $rec = $row->fetch();
        if (!$rec) fail('not found', 404);
        if ((int)$rec['total_stock'] < $qty) fail('Not enough stock in total storage');
        $pdo->prepare('UPDATE tablets SET total_stock = total_stock - ?, batch_qty = ?, batch_remaining = batch_remaining + ? WHERE id = ?')
            ->execute([$qty, $qty, $qty, $id]);
        ok();
    }

    case 'mark_dose': {
        // Mark today's morning/night dose as taken or skipped
        $body = input();
        $id = (string)($body['id'] ?? '');
        $slot = (string)($body['slot'] ?? '');
        $status = (string)($body['status'] ?? '');
        $date = (string)($body['date'] ?? date('Y-m-d'));
        if (!in_array($slot, ['morning', 'night'], true)) fail('bad slot');
        if (!in_array($status, ['taken', 'skipped'], true)) fail('bad status');

        $tabStmt = $pdo->prepare('SELECT batch_remaining, batch_consumed FROM tablets WHERE id = ?');
        $tabStmt->execute([$id]);
        $tab = $tabStmt->fetch();
        if (!$tab) fail('not found', 404);
        $remaining = (int)$tab['batch_remaining'];
        $consumed = (int)$tab['batch_consumed'];

        $stmt = $pdo->prepare('SELECT id, status FROM tablet_logs WHERE tablet_id = ? AND log_date = ? AND slot = ?');
        $stmt->execute([$id, $date, $slot]);
        $existing = $stmt->fetch();

        if ($existing && $existing['status'] === $status) {
            ok(['batch_remaining' => $remaining, 'batch_consumed' => $consumed]);
        }

        if ($existing) {
            // undo the previous effect first
            if ($existing['status'] === 'taken') { $remaining += 1; $consumed = max(0, $consumed - 1); }
        }
        if ($status === 'taken') {
            if ($remaining <= 0) fail('No tablets left in the daily pile — take out more from storage');
            $remaining -= 1; $consumed += 1;
        }

        if ($existing) {
            $pdo->prepare('UPDATE tablet_logs SET status = ? WHERE id = ?')->execute([$status, $existing['id']]);
        } else {
            $newId = uid();
            $pdo->prepare('INSERT INTO tablet_logs (id, tablet_id, log_date, slot, status, created_at) VALUES (?, ?, ?, ?, ?, ?)')
                ->execute([$newId, $id, $date, $slot, $status, (int)(microtime(true) * 1000)]);
        }

        $pdo->prepare('UPDATE tablets SET batch_remaining = ?, batch_consumed = ? WHERE id = ?')
            ->execute([$remaining, $consumed, $id]);

        ok(['batch_remaining' => $remaining, 'batch_consumed' => $consumed]);
    }

    /* ---------------- BACKUP (export / import full data as XML) ---------------- */
    case 'export_xml': {
        $tasks = $pdo->query('SELECT id, name, done, created_at FROM tasks ORDER BY created_at ASC')->fetchAll();
        $notes = $pdo->query('SELECT id, title, created_at FROM notes ORDER BY created_at ASC')->fetchAll();
        $itemsStmt = $pdo->prepare('SELECT id, text, done, created_at FROM note_items WHERE note_id = ? ORDER BY created_at ASC');
        $tablets = $pdo->query('SELECT id, name, morning_time, night_time, total_stock, low_stock_threshold, batch_qty, batch_remaining, batch_consumed, created_at FROM tablets ORDER BY created_at ASC')->fetchAll();
        $purchStmt = $pdo->prepare('SELECT purchase_date, qty, created_at FROM tablet_purchases WHERE tablet_id = ? ORDER BY purchase_date ASC');
        $logStmtAll = $pdo->prepare('SELECT log_date, slot, status, created_at FROM tablet_logs WHERE tablet_id = ? ORDER BY log_date ASC');

        $xml = new SimpleXMLElement('<backup/>');
        $xml->addAttribute('exported_at', date('c'));

        $tasksEl = $xml->addChild('tasks');
        foreach ($tasks as $t) {
            $te = $tasksEl->addChild('task');
            $te->addAttribute('id', $t['id']);
            $te->addAttribute('done', $t['done'] ? '1' : '0');
            $te->addAttribute('created_at', (string)$t['created_at']);
            $te->addChild('name', htmlspecialchars($t['name'], ENT_XML1, 'UTF-8'));
        }

        $notesEl = $xml->addChild('notes');
        foreach ($notes as $n) {
            $ne = $notesEl->addChild('note');
            $ne->addAttribute('id', $n['id']);
            $ne->addAttribute('created_at', (string)$n['created_at']);
            $ne->addChild('title', htmlspecialchars($n['title'], ENT_XML1, 'UTF-8'));
            $itemsStmt->execute([$n['id']]);
            $itemsEl = $ne->addChild('items');
            foreach ($itemsStmt->fetchAll() as $it) {
                $ie = $itemsEl->addChild('item');
                $ie->addAttribute('id', $it['id']);
                $ie->addAttribute('done', $it['done'] ? '1' : '0');
                $ie->addAttribute('created_at', (string)$it['created_at']);
                $ie->addChild('text', htmlspecialchars($it['text'], ENT_XML1, 'UTF-8'));
            }
        }

        $tabletsEl = $xml->addChild('tablets');
        foreach ($tablets as $tb) {
            $tbe = $tabletsEl->addChild('tablet');
            $tbe->addAttribute('id', $tb['id']);
            $tbe->addAttribute('created_at', (string)$tb['created_at']);
            $tbe->addChild('name', htmlspecialchars($tb['name'], ENT_XML1, 'UTF-8'));
            $tbe->addChild('morning_time', htmlspecialchars((string)$tb['morning_time'], ENT_XML1, 'UTF-8'));
            $tbe->addChild('night_time', htmlspecialchars((string)$tb['night_time'], ENT_XML1, 'UTF-8'));
            $tbe->addChild('total_stock', (string)$tb['total_stock']);
            $tbe->addChild('low_stock_threshold', (string)$tb['low_stock_threshold']);
            $tbe->addChild('batch_qty', (string)$tb['batch_qty']);
            $tbe->addChild('batch_remaining', (string)$tb['batch_remaining']);
            $tbe->addChild('batch_consumed', (string)$tb['batch_consumed']);

            $purchStmt->execute([$tb['id']]);
            $purchEl = $tbe->addChild('purchases');
            foreach ($purchStmt->fetchAll() as $p) {
                $pe = $purchEl->addChild('purchase');
                $pe->addAttribute('date', $p['purchase_date']);
                $pe->addAttribute('qty', (string)$p['qty']);
                $pe->addAttribute('created_at', (string)$p['created_at']);
            }

            $logStmtAll->execute([$tb['id']]);
            $logsEl = $tbe->addChild('logs');
            foreach ($logStmtAll->fetchAll() as $lg) {
                $le = $logsEl->addChild('log');
                $le->addAttribute('date', $lg['log_date']);
                $le->addAttribute('slot', $lg['slot']);
                $le->addAttribute('status', $lg['status']);
                $le->addAttribute('created_at', (string)$lg['created_at']);
            }
        }

        $healthSettingsRows = $pdo->query("SELECT `key`, `value` FROM settings WHERE `key` IN ('health-next-consult-date','health-consult-interval-months')")->fetchAll();
        $settingsEl = $xml->addChild('settings');
        foreach ($healthSettingsRows as $s) {
            $se = $settingsEl->addChild('setting');
            $se->addAttribute('key', $s['key']);
            $se->addChild('value', htmlspecialchars((string)$s['value'], ENT_XML1, 'UTF-8'));
        }

        $xmlStr = $xml->asXML();
        header('Content-Type: application/xml; charset=utf-8');
        header('Content-Disposition: attachment; filename="todos-backup-' . date('Y-m-d') . '.xml"');
        header('Content-Length: ' . strlen($xmlStr));
        echo $xmlStr;
        exit;
    }

    case 'import_xml': {
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) fail('upload error');
        $xmlStr = file_get_contents($_FILES['file']['tmp_name']);
        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($xmlStr);
        if ($xml === false) fail('invalid xml file');

        $pdo->beginTransaction();
        try {
            // Wipe existing Todo / Notes / Health data — uploaded Files and the
            // lock password are left untouched.
            $pdo->exec('DELETE FROM tablet_logs');
            $pdo->exec('DELETE FROM tablet_purchases');
            $pdo->exec('DELETE FROM tablets');
            $pdo->exec('DELETE FROM note_items');
            $pdo->exec('DELETE FROM notes');
            $pdo->exec('DELETE FROM tasks');

            $insTask = $pdo->prepare('INSERT INTO tasks (id, name, done, created_at) VALUES (?, ?, ?, ?)');
            foreach ($xml->tasks->task ?? [] as $t) {
                $insTask->execute([
                    (string)$t['id'] ?: uid(),
                    (string)$t->name,
                    ((string)$t['done'] === '1') ? 1 : 0,
                    (int)$t['created_at'] ?: (int)(microtime(true) * 1000)
                ]);
            }

            $insNote = $pdo->prepare('INSERT INTO notes (id, title, created_at) VALUES (?, ?, ?)');
            $insItem = $pdo->prepare('INSERT INTO note_items (id, note_id, text, done, created_at) VALUES (?, ?, ?, ?, ?)');
            foreach ($xml->notes->note ?? [] as $n) {
                $noteId = (string)$n['id'] ?: uid();
                $insNote->execute([$noteId, (string)$n->title, (int)$n['created_at'] ?: (int)(microtime(true) * 1000)]);
                foreach ($n->items->item ?? [] as $it) {
                    $insItem->execute([
                        (string)$it['id'] ?: uid(), $noteId, (string)$it->text,
                        ((string)$it['done'] === '1') ? 1 : 0,
                        (int)$it['created_at'] ?: (int)(microtime(true) * 1000)
                    ]);
                }
            }

            $insTablet = $pdo->prepare('INSERT INTO tablets (id, name, morning_time, night_time, total_stock, low_stock_threshold, batch_qty, batch_remaining, batch_consumed, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $insPurch = $pdo->prepare('INSERT INTO tablet_purchases (id, tablet_id, purchase_date, qty, created_at) VALUES (?, ?, ?, ?, ?)');
            $insLog = $pdo->prepare('INSERT INTO tablet_logs (id, tablet_id, log_date, slot, status, created_at) VALUES (?, ?, ?, ?, ?, ?)');
            foreach ($xml->tablets->tablet ?? [] as $tb) {
                $tabletId = (string)$tb['id'] ?: uid();
                $mt = (string)$tb->morning_time;
                $nt = (string)$tb->night_time;
                $insTablet->execute([
                    $tabletId, (string)$tb->name,
                    $mt === '' ? null : $mt, $nt === '' ? null : $nt,
                    (int)$tb->total_stock, (int)((string)$tb->low_stock_threshold ?: 3),
                    (int)$tb->batch_qty, (int)$tb->batch_remaining, (int)$tb->batch_consumed,
                    (int)$tb['created_at'] ?: (int)(microtime(true) * 1000)
                ]);
                foreach ($tb->purchases->purchase ?? [] as $p) {
                    $insPurch->execute([uid(), $tabletId, (string)$p['date'], (int)$p['qty'], (int)$p['created_at'] ?: (int)(microtime(true) * 1000)]);
                }
                foreach ($tb->logs->log ?? [] as $lg) {
                    $insLog->execute([uid(), $tabletId, (string)$lg['date'], (string)$lg['slot'], (string)$lg['status'], (int)$lg['created_at'] ?: (int)(microtime(true) * 1000)]);
                }
            }

            foreach ($xml->settings->setting ?? [] as $s) {
                $key = (string)$s['key'];
                if ($key === '') continue;
                $val = (string)$s->value;
                $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)")
                    ->execute([$key, $val]);
            }

            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            fail('import failed: ' . $e->getMessage(), 500);
        }

        ok();
    }

    default:
        fail('unknown action', 404);
}
} catch (Throwable $e) {
    // Any unexpected DB/PHP error (e.g. a column missing because schema.sql
    // wasn't re-run) now comes back as real JSON instead of an HTML error
    // page that breaks the app with a generic "check your connection" alert.
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
    exit;
}
